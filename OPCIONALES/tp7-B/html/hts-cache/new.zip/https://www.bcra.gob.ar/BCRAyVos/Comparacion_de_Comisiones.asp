<!DOCTYPE HTML>
<html lang="es">
<head>

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-72541502-1', 'auto');
  ga('send', 'pageview');

(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-N969B5K');
</script>


	<meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7" />
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"/>
	<title>Comparar comisiones bancarias </title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    
	
	
    
    <meta name="description" content="Con el objeto de generar mayor transparencia en la determinaci�n del valor de las comisiones bancarias, se publican las tablas comparativas con los valores que los bancos cobran a sus clientes por distintos productos.">
	<meta name="keywords" content="BCRA, Comparaci�n, comisiones, bancarias transparencia, tablas comparativas">
    
    <!--[if lt IE 9]><script src="./JS/html5.js"></script>
	<![endif]-->

    <link rel="stylesheet" href="../estilos/estilos.css">    
    <link rel="stylesheet" href="../Includescomunes/estilos-generales/css/color-theme.css"/>
	
	<link rel="stylesheet" href="../Includescomunes/estilos-generales/bootstrap/css/bootstrap.min.css"/>
    <link rel="stylesheet" href="../Includescomunes/estilos-generales/font-awesome/css/font-awesome.min.css"/>    

	<script src="../js/jquery.js"></script>
    <script src="../js/bootstrap.min.js"></script>
       
<!--Inicio Inclusite-->

<!--Fin Inclusite-->





</head>

<body>

<div class="container">

<header>
	<div class="containner">	
	
	
    <script type="text/javascript">
        $(document).ready(function(){
            $(".popover-top").popover({
                trigger: 'hover', placement : 'top'
                });
        });
    </script>
    <script type="text/javascript">
        $(document).ready(function(){
            $(".dropdown").focus(
                function() {
                    $('.dropdown-menu', this).not('.in .dropdown-menu').stop(true,true).slideDown("400");
                    $(this).toggleClass('open');        
                },
                function() {
                    $('.dropdown-menu', this).not('.in .dropdown-menu').stop(true,true).slideUp("400");
                    $(this).toggleClass('open');       
                }
            );
            
            /*Este es el c�digo que hace funcionar el hover*/
            /*
            $('li.dropdown-submenu').hover(function() {
                $(this).find('.dropdown-submenu2').stop(true, true).fadeIn("fast");
            }, function() {
                $(this).find('.dropdown-submenu2').stop(true, true).fadeOut("slow");
            });
            */
            
            $("li.dropdown-submenu").click(
                function() {
                    $(this).find('> ul').slideToggle();
                }
            );
            $("li.dropdown-submenu").click(
                function(e) {
                    e.stopPropagation()
                }
            );
            
            
        /*FIN del c�digo que hace funcionar el hover, ojo que deben quedar dentro del corchete y par�ntesis final */
        });
    </script>

		
<div class="topnav-barra">
	<div class="AL-encabezado">
		<span class="ayuda">
			<a href="../Varios/Ayuda_en_linea.asp" onclick="ga('send', 'event', 'Principal', 'Click', 'AD-Ayuda en Linea, '0');">Ayuda en l�nea</a> 		
		</span>
		<span class="redes">
			<span-AL><a href="../Varios/buscador-interno-temporario.asp" onclick="ga('send', 'event', 'Principal', 'Click', 'AD-English', '0');">Buscar</a></span-AL>	
			
			<span-FB><a href="https://www.facebook.com/BancoCentralAR/" onclick="ga('send', 'event', 'Principal', 'Click', 'AD-Facebook, '0');" target="_blank"><i class="fa fa-facebook" style="color:white"></i></a></span-FB>
			<span-LE><a href="https://www.instagram.com/bancocentral_ar/?hl=es-la" target="_blank"><i class="fa fa-instagram" style="color:white"></i></a></span-LE>
			<span-LE><a href="https://www.linkedin.com/company/bcra" target="_blank"><i class="fa fa-linkedin" style="color:white"></i></a></span-LE>
			<span-TW><a href="https://twitter.com/bancocentral_ar" onclick="ga('send', 'event', 'Principal', 'Click', 'AD-twitter, '0');" target="_blank"><svg xmlns="http://www.w3.org/2000/svg" height="1em" style="fill:white; translate: 0px 3px" viewBox="0 0 512 512"><path d="M389.2 48h70.6L305.6 224.2 487 464H345L233.7 318.6 106.5 464H35.8L200.7 275.5 26.8 48H172.4L272.9 180.9 389.2 48zM364.4 421.8h39.1L151.1 88h-42L364.4 421.8z"/></svg></a></span-TW>
			<span-YT><a href="https://www.youtube.com/@BancoCentral_AR" onclick="ga('send', 'event', 'Principal', 'Click', 'AD-Youtube, '0');" target="_blank"><i class="fa fa-youtube" style="color:white"></i></a></span-YT>
			<span-AL><a href="../Varios/English_information.asp" onclick="ga('send', 'event', 'Principal', 'Click', 'AD-English', '0');">ENG</a></span-AL>		
		</span>
	</div>
</div>

<a href="../default.asp"><img src="../Imagenes/header/encabezado.jpg" width="100%" height="auto" class="img-fluid"></a>
	
	<!-- MEN� -->	
		
    <nav class="navbar navbar-default navbar-static" style="" role="navigation">
        <div class="navbar-header">
    		<button class="navbar-toggle" type="button" data-toggle="collapse" data-target=".js-navbar-collapse">
    			<span class="sr-only">Men�</span>
    			<span class="icon-bar"></span>
    			<span class="icon-bar"></span>
    			<span class="icon-bar"></span>
    		</button>
    	</div>

	   <div class="collapse navbar-collapse js-navbar-collapse">
		  <ul class="nav navbar-nav">
            <!-- BOT�N INSTITUCIONAL -->
			<li class="dropdown dropdown-large">
				<a href="#" class="dropdown-toggle botonera" data-toggle="dropdown">Institucional</a>
				<ul class="dropdown-menu dropdown-menu-large row"><!-- -->
				    <li class="col-sm-4">
						<ul class="boxLista">
							<li class="dropdown-header">MISI�N</li>
                            <li><a href="../Institucional/Carta_Organica.asp">Carta Org�nica</a></li>
                            <li><a href="../Institucional/Objetivos_y_Planes.asp">Objetivos y planes</a></li>
                            <li><a href="../Institucional/Rendicion_Cuentas.asp">Rendici�n de cuentas</a></li>
                            <li><a href="../Institucional/Acceso_Informacion.asp">Acceso a la Informaci�n P�blica</a></li>
                        </ul>
						<ul class="boxLista">	
						    <li class="dropdown-header">C�MO FUNCIONA</li>
                            <li><a href="../Institucional/Autoridades.asp">Autoridades</a></li>
                            <li><a href="../Institucional/Estructura.asp">Estructura y funciones</a></li>
                            <li><a href="../Institucional/Comisiones_del_Directorio.asp">Comisiones del Directorio </a></li>
                            <li><a href="../Institucional/Codigo_de_Etica.asp">C�digo de �tica para el Personal</a> </li>
							  <li><a href="../Institucional/manual-estilo-para-proyectos-resolucion-directorio.asp">Manual de Estilo para Proyectos de Resoluci�n</a> </li>
                   		</ul>
					</li>
					<li class="col-sm-4">
						<ul class="boxLista">
                            <li class="dropdown-header">ACUERDOS</li>
                            <li><a href="../Institucional/Acuerdos_Nacionales.asp">Nacionales</a></li>
                            <li><a href="../Institucional/Acuerdos_Internacionales.asp">Internacionales</a></li>
                        </ul>         

                        <ul class="boxLista">         
							<li class="dropdown-header">ACTIVIDAD ACAD�MICA</li>
                            <li><a href="../Institucional/Jornadas_monetarias_bancarias.asp">Jornadas y conferencias</a></li>
                            <li><a href="../Institucional/Seminarios_de_economia.asp">Seminarios de Econom�a</a></li>
                            <li><a href="../Institucional/Premio_de_investigacion.asp">Premio Anual de Investigaci�n Econ�mica</a></li>
						</ul>
						<!--ul class="boxLista">         
							<li class="dropdown-header">PRENSA</li>
                             <li>
                                <form action="../Institucional/Prensa.asp" method="POST" name="formComPre">    
                                    <a onClick="formComPre.submit()">Comunicados de prensa</a>
                                    <input type="hidden" name="tipo" value="2"/>
                                </form>
                            </li>
                                
                            <li>
                                <form action="../Institucional/Prensa.asp" method="POST" name="formComP">
                                    <input type="hidden" name="tipo" value="1"/>
                                    <a onClick="formComP.submit()">Comunicados P</a>
                                </form>
                            </li>
                       
                            <li>
                                <form action="../Institucional/Prensa.asp" method="POST" name="formPolMonLeb">
                                    <input type="hidden" name="tipo" value="5"/>
                                    <a onClick="formPolMonLeb.submit()">Comunicados de Pol�tica Monetaria y de licitaciones de letras</a>
                                </form>
                            </li>
                            <li>
                                <form action="../Institucional/Prensa.asp" method="POST" name="formDiscPre">    
                                    <a onClick="formDiscPre.submit()"> Discursos y presentaciones</a>
                                    <input type="hidden" name="tipo" value="4"/>
                                </form>
                            </li>
                        
                            <li><a href="../Institucional/Contacto-para-Periodistas.asp">Contacto para periodistas</a></li>
						</ul -->
					</li>
					<li class="col-sm-4">
						<ul class="boxLista">
                            <li class="dropdown-header">PROVEEDORES</li>
                          	<li><a href="../Institucional/Portal-proveedores.asp">Informaci�n sobre el Portal de Proveedores</a></li> 
							<li><a href="https://ps.bcra.gob.ar/psp/sup/SUPPLIER/ERP/h/?tab=DEFAULT">Acceso al Portal de Proveedores</a></li> 
						
					
						</ul>
                        <ul class="boxLista">                
                            <li class="dropdown-header">M�S SOBRE EL BCRA</li>
                            <li><a href="../Institucional/Historia.asp">Historia</a></li>
                            <li><a href="../Institucional/Presidentes_Anteriores.asp">Presidencias anteriores</a></li>
                            <li><a href="../Institucional/Patrimonio_Arquitectonico.asp">Patrimonio arquitect�nico</a></li>
                            <li><a href="../Institucional/premio-pintura-bcra-PNP.asp">Premio Nacional de Pintura Banco Central</a></li>
						</ul>
					</li>
				</ul>
			</li>
            
            <!-- BOT�N POL�TICA MONETARIA -->
				<li class="dropdown dropdown-large">
			 
				 <a href="#" class="dropdown-toggle botonera" data-toggle="dropdown">Pol�tica Monetaria </a> 
				<ul class="dropdown-menu dropdown-menu-large row">
					<!--<li class="col-sm-4">
						<ul class="boxLista">
                            <li><a href="../PoliticaMonetaria/Politica_Monetaria.asp">Lineamientos de pol�tica monetaria</a></li>
						</ul>
                    </li>-->
                   <li class="col-sm-4">
						<ul class="boxLista">
                            <li><a href="../PublicacionesEstadisticas/Informe_politica_monetaria.asp">Informe de Pol�tica Monetaria</a></li>
						</ul>
                    </li>
					<li class="col-sm-4">
						<ul class="boxLista">
                           
							<li><a href="../PoliticaMonetaria/comunicados.asp">Comunicados de Pol�tica Monetaria</a></li>
						</ul>
                    </li>
				</ul>
			</li>
            
            
            <!-- BOT�N SISTEMA FINANCIERO -->
		<li class="dropdown dropdown-large">
				<a href="#" class="dropdown-toggle botonera" data-toggle="dropdown">Sistema Financiero</a>
				<ul class="dropdown-menu dropdown-menu-large row">
					<li class="col-sm-4">
						<ul class="boxLista">
							<li class="dropdown-header"> SOBRE ENTIDADES FINANCIERAS</li>
                            <li><a href="../SistemasFinancierosYdePagos/Entidades_financieras.asp">Por entidad</a></li>
                            <li class="dropdown-submenu">Por grupo
                            	  <ul class="dropdown-submenu">
                                    <li><a href="../SistemasFinancierosYdePagos/Sistema_financiero.asp?opcion=2&tit=2">P�blicas</a></li>
                                    <li><a href="../SistemasFinancierosYdePagos/Sistema_financiero.asp?opcion=3&tit=3">Privadas</a></li>
                                    <li><a href="../SistemasFinancierosYdePagos/Sistema_financiero.asp?opcion=5&tit=5">Compa��as financieras</a></li>
                                    <!--<li><a href="../SistemasFinancierosYdePagos/Sistema_financiero.asp?opcion=6&tit=6">Cajas de cr�dito</a></li>-->
                                    <li><a href="../SistemasFinancierosYdePagos/Sistema_financiero.asp?opcion=1&tit=1">Sistema Financiero</a></li>
                                    <li><a href="../SistemasFinancierosYdePagos/Sistema_financiero.asp?opcion=4&tit=4">Primeros 10 bancos privados</a></li>
                            	 </ul>
                            </li>
                            
                            <li><a href="../SistemasFinancierosYdePagos/Entidades_en_liquidacion.asp">Entidades en Liquidaci�n</a></li> 
							<!--<li><a href="../SistemasFinancierosYdePagos/ex-entidades-financieras.asp">Ex entidades</a></li>-->
                           
                        </ul>
                    	<ul class="boxLista">
							<li class="dropdown-header"> SOBRE ENTIDADES NO FINANCIERAS</li>
							<li>Registro de operadores de cambio:</li>
							<li class="dropdown-submenu">Agencias de cambio
								<ul class="dropdown-submenu">
									<li>
										<a href="../SistemasFinancierosYdePagos/Agencias_de_cambio.asp">Listado con domicilios legales </a>
									</li>
									<li>
										<a href="../SistemasFinancierosYdePagos/Agencias_de_cambio_dependencias.asp">Listado de dependencias operativas </a>
									</li>
								</ul>
							</li>
							<li class="dropdown-submenu">Casas de cambio
								<ul class="dropdown-submenu">
									<li>
										<a href="../SistemasFinancierosYdePagos/Casas_de_cambio.asp">Listado con domicilios legales </a>
									</li>
									<li>
										<a href="../SistemasFinancierosYdePagos/Casas_de_cambio_dependencias.asp">Listado de dependencias operativas </a>
									</li>
								</ul>
							</li>
							<br>
							<li>Otros registros:</li>
							<li><a href="../SistemasFinancierosYdePagos/Proveedores-servicios-de-billeteras-digitales-Interoperables.asp">Billeteras digitales interoperables</a></li>
					<li><a href="../SistemasFinancierosYdePagos/Emisoras_tarjetas_credito_compra.asp">Empresas no financieras emisoras de tarjetas de cr�dito o compra</a></li>
							
							<li><a href="../SistemasFinancierosYdePagos/Registro_exportadores_importadores.asp">Informaci�n cambiaria de exportadores e importadores de bienes </a></li>
							<li><a href="../SistemasFinancierosYdePagos/Fondos-de-garantia-de-caracter-publico.asp">Fondos de Garant�a de Car�cter P�blico</a></li>	
									
							<li><a href="../SistemasFinancierosYdePagos/Proveedores-servicios-de-creditos.asp">Proveedores de servicios de cr�dito entre particulares a trav�s de plataformas </a></li>
							
							<li><a href="../SistemasFinancierosYdePagos/Proveedores-servicios-de-pago-ofrecen-cuentas-de-pago.asp"> Proveedores de servicios de pago</a></li>
									
							<li><a href="../SistemasFinancierosYdePagos/Plataformas_financiamiento_MiPyME.asp"> Registro de Plataformas para el Financiamiento MiPyME</a></li>		
									
							<li><a href="../SistemasFinancierosYdePagos/Proveedores_no_financieros.asp">Otros proveedores no financieros</a>	</li>
									
									
									
							<li><a href="../SistemasFinancierosYdePagos/Sociedades_garantia_reciproca.asp">Sociedades de Garant�a Rec�proca</a></li>		
							<li><a href="../SistemasFinancierosYdePagos/Transportadoras_de_caudales.asp">Transportadoras de caudales</a></li>
								
						<br>
							<li><a href="../SistemasFinancierosYdePagos/Fideicomisos_financieros.asp">Fideicomisos Financieros</a></li>
							<li class="pepe"><a href="../SistemasFinancierosYdePagos/Representantes_entidades_financieras_del_exterior.asp">Representantes de entidades financieras del exterior</a></li>
							
						
							
                        </ul>
						
						
							
								
						
					</li>
							
					<li class="col-sm-4">
					
						<ul class="boxLista">
							<li class="dropdown-header">POL�TICA FINANCIERA</li>
                            <li><a href="../SistemasFinancierosYdePagos/Politica_Financiera.asp#a">Estabilidad Financiera</a></li>
                            <li><a href="../SistemasFinancierosYdePagos/Politica_Financiera.asp#b">Desarrollo y eficiencia</a></li>
                            <li><a href="../SistemasFinancierosYdePagos/Politica_Financiera.asp#c">Inclusi�n Financiera</a></li>
						</ul>
					
						
							<ul class="boxLista">
							<li class="dropdown-header"><a href="../SistemasFinancierosYdePagos/Innovacion_financiera.asp ">INNOVACI�N FINANCIERA</a></li>
                        </ul>
						
						<ul class="boxLista">
							<li class="dropdown-header"><a href="../SistemasFinancierosYdePagos/finanzas-sostenibles-riesgos-clima.asp">FINANZAS SOSTENIBLES Y RIESGOS FINANCIEROS RELACIONADOS CON EL CLIMA</a></li>
                        </ul>
						
						
						
						<ul class="boxLista">
							<li class="dropdown-header">CIBERSEGURIDAD</li>
							<li><a href="../SistemasFinancierosYdePagos/Ciberseguridad.asp#Regulaci�n">Regulaci�n</a></li>
							<li><a href="../SistemasFinancierosYdePagos/Ciberseguridad.asp#Lineamientos%20de%20Ciberseguridad">Lineamientos de Ciberseguridad</a></li>
							<li><a href="../SistemasFinancierosYdePagos/Ciberseguridad.asp#Glosario">Glosario</a></li>
						</ul>	
					
							<ul class="boxLista">

                            <li><a href="../PublicacionesEstadisticas/Advertencia-sobre-criptoactivos.asp">CRIPTOACTIVOS</a></li>
												
						</ul>			
								
						
                         	
                       
					</li>	
					<li class="col-sm-4">
                    	
						
						<ul class="boxLista">
                            <li class="dropdown-header">MARCO LEGAL Y NORMATIVO</li>
                            <li><a href="../SistemasFinancierosYdePagos/Buscador_de_comunicaciones.asp">Buscador de comunicaciones</a></li>
                            <li><a href="../SistemasFinancierosYdePagos/Ordenamiento_y_resumenes.asp">Ordenamientos y res�menes</a></li>
                            <li><a href="../SistemasFinancierosYdePagos/Aplicativos.asp">Aplicativos</a></li>
                            <li><a href="../SistemasFinancierosYdePagos/Interpretaciones_preguntas.asp">Interpretaciones y preguntas</a></li>
                            <li><a href="../SistemasFinancierosYdePagos/Sumarios-financieros-2025.asp">Sumarios Financieros</a></li>
                            <li><a href="../SistemasFinancierosYdePagos/Regulaciones_exterior_y_cambios.asp">Normativa de Exterior y Cambios</a></li>
                           <li><a href="../SistemasFinancierosYdePagos/Relevamiento_activos_y_pasivos_externos.asp">Relevamiento de activos y pasivos externos</a></li> 
							
							<li><a href="../SistemasFinancierosYdePagos/Entidades_de_importancia_sistemica.asp">Entidades de Importancia Sist�mica</a></li>
							<li><a href="../SistemasFinancierosYdePagos/RRII-preguntas-frecuentes.asp">Consultas frecuentes sobre R�gimen Informativo</a></li>
						</ul>
							
							<ul class="boxLista">
							<li class="dropdown-header"><a href="../SistemasFinancierosYdePagos/Gu�as-de-supervisi�n.asp">GU�AS DE SUPERVISI�N</a></li>
                        </ul>
					
						<ul class="boxLista">
							<li class="dropdown-header"><a href="../sistemasFinancierosYdePagos/tramites_entidades_financieras_y_no_financieras.asp">Tr�mites</a></li>
                        </ul>
                        
					</li>
				</ul>
			</li>
            <!-- BOT�N MEDIOS DE PAGO -->
            <li class="dropdown dropdown-large">
				<a href="#" class="dropdown-toggle botonera" data-toggle="dropdown">Medios de Pago</a>
				<ul class="dropdown-menu dropdown-menu-large row">
                	<li class="col-sm-4">
						<ul class="boxLista">
							<li class="dropdown-header"><a href="../MediosPago/Sistema_de_Pago.asp">SISTEMA DE PAGOS</a></li>
                        </ul>
                        <ul class="boxLista">
                            <li class="dropdown-header">BILLETES Y MONEDAS</li>
							<li><a href="../MediosPago/Emisiones_vigentes.asp">Emisiones vigentes</a></li>
							<!--<li><a href="../MediosPago/Nueva_familia_billetes.asp">Billetes de la Rep�blica Argentina</a></li>
                            <li><a href="../MediosPago/Nueva_familia_monedas.asp">Monedas de la Rep�blica Argentina</a></li>-->
							<!--<li><a href="../MediosPago/Cambio_monedas_billetes.asp">Cambio de monedas y billetes</a></li>-->
							<li><a href="../MediosPago/Emisiones_anteriores.asp">Emisiones anteriores</a></li>
							<li><a href="../MediosPago/Emisiones_conmemorativas.asp">Emisiones conmemorativas</a></li>
                   		</ul>
					</li>
				<li class="col-sm-4">
						<ul class="boxLista">
							<li class="dropdown-header"><a href="../MediosPago/Politica_Pagos.asp">POL�TICA DE PAGOS</a></li>
							<li><a href="../MediosPago/Politica_Pagos.asp#efectivo">Efectivo</a></li>
						
							
							
							
				<!--	<li class="dropdown-submenu" id="segundo">-->
							<li><a href="../MediosPago/Politica_Pagos.asp#electronicos">Pagos electr�nicos</a>
							   <ul class="dropdown-submenu">
								 <li><a href="../MediosPago/Transferencias-3-0.asp">Transferencias 3.0</a></li>
                              	 <li><a href="/MediosPago/Clave-Bancaria-Uniforme.asp">Clave Bancaria Uniforme (CBU)</a></li>
                                 <li><a href="/MediosPago/Clave-Virtual-Uniforme.asp">Clave Virtual Uniforme (CVU)</a></li>
								 <li><a href="../MediosPago/Alias-CBU.asp">Alias CBU</a></li>
								 <li><a href="../MediosPago/Alias-CVU.asp">Alias CVU</a></li>
								 <li><a href="../MediosPago/Debin.asp"> DEBIN | D�bito Inmediato </a></li>
								 <li><a href="../MediosPago/Echeq.asp">ECHEQ | Cheque Electr�nico</a></li>
							     <li><a href="../MediosPago/Tarjeta-de-debito.asp">Tarjeta de d�bito</a></li>
                             		<!--<li><a href="../MediosPago/Politica_Pagos.asp#g">Transferencias por montos superiores</a></li>-->
							  </ul>
						    </li>	</ul>
					
					</li>
                        
                       
					<li class="col-sm-4">
						<ul class="boxLista">
                            <li class="dropdown-header"><a href="../MediosPago/Regulacion_de_pagos.asp">REGULACI�N DE PAGOS</a></li>
                        </ul>
				
					
						<ul class="boxLista">
                            <li class="dropdown-header">CONVENIOS INTERNACIONALES DE PAGO </li>
							<li><a href="../MediosPago/Convenio-de-Pagos-Creditos-Reciprocos-ALADI.asp">Convenio de Pagos y Cr�ditos Rec�procos - ALADI</a></li>
							<li><a href="../MediosPago/Sistema_de_Pagos_en_Moneda_Local-SML.asp">Sistema de Pagos en Moneda Local (SML)</a></li>	
                        </ul>
					</li>
				</ul>
			</li>            
            
          
            <!-- BOT�N PUBLICACIONES -->
			<li class="dropdown dropdown-large">
				<a href="#" class="dropdown-toggle botonera" data-toggle="dropdown">Publicaciones</a>
				<ul class="dropdown-menu dropdown-menu-large row"><!-- -->
					<li class="col-sm-4">
						<ul class="boxLista">
						<!--	<li class="dropdown-header">PUBLICACIONES</li>-->
                            <li class="dropdown-header">Pol�tica monetaria</li> 
                               
                                    <li><a href="../PublicacionesEstadisticas/Informe_politica_monetaria.asp">Informe de Pol�tica Monetaria</a></li>
                                    <li><a href="../PublicacionesEstadisticas/Informe_monetario_mensual.asp">Informe Monetario Mensual</a></li>
                                    <li><a href="../PublicacionesEstadisticas/Informe_monetario_diario.asp">Informe Monetario Diario</a></li>
                                   
									

                               
                            
						</ul>
													<ul class="boxLista">

                            <li class="dropdown-header">Estabilidad financiera</li>
         						
                                    <li><a href="../PublicacionesEstadisticas/Informe_de_estabilidad_financiera.asp">Informe de Estabilidad Financiera</a></li>
                                	<li><a href="../PublicacionesEstadisticas/Informe_mensual_sobre_bancos.asp">Informe sobre Bancos</a></li>
                              
                            
						</ul>
													<ul class="boxLista">

							<li class="dropdown-header">Sector externo </li> 
														
														
									<li><a href="../PublicacionesEstadisticas/Mercado_de_cambios.asp">Informe de la Evoluci�n del Mercado de Cambios y Balance Cambiario</a></li>	
									<li> <a href="../PublicacionesEstadisticas/Deuda_externa_privada.asp">Informe sobre Deuda Externa Privada</a></li>
									<li> <a href="../PublicacionesEstadisticas/informe-inversion-extranjera-directa.asp">Informe sobre Inversi�n Extranjera Directa </a></li>	
										 <li><a href="../PublicacionesEstadisticas/Guia-para-importadores.asp">BOPREAL | Gu�a para importadores </a>	</li> 				
														
														
									<li> <a href="../PublicacionesEstadisticas/Informe-regimen-disponibilidad-divisas-para-inversores-extranjeros.asp">Informe sobre el R�gimen de Disponibilidad de Divisas para Inversores Extranjeros </a></li>
									<li> <a href="../PublicacionesEstadisticas/proyecciones-de-la-balanza-comercial-2024-2030.asp">Proyecciones de la balanza comercial 2024-2030 </a></li>					
									<li> <a href="../PublicacionesEstadisticas/pagos-deuda-externa-financiera-sector-privado.asp">Informe de Pagos de Deuda Externa Financiera del Sector Privado 2020-2022 </a></li>			
									<li><a href="../PublicacionesEstadisticas/Informe-mercado-cambios-deuda-formacion-activos-externos-2015-2019.asp">	Informe de Mercado de Cambios, Deuda y Formaci�n de Activos Externos 2015-2019</a></li>
									
                                    
                                   
                                    
                                    
														
								
                            	
									
                            
                            
						</ul>
							
							
						
							
					</li>	
					<li class="col-sm-4">
						
						<ul class="boxLista">

							<li class="dropdown-header">Sistema financiero </li>   
                                    <li><a href="../PublicacionesEstadisticas/Entidades_financieras.asp">Entidades Financieras</a></li>
                                    <li><a href="../PublicacionesEstadisticas/Entidades_no_financieras.asp">Entidades No Financieras</a></li>
                                    <li><a href="../PublicacionesEstadisticas/Marco_Legal.asp">Marco Legal del Sistema Financiero</a></li>
                                    <li><a href="../PublicacionesEstadisticas/Productos_Derivados_Financieros.asp">Productos Derivados Financieros</a></li>
                         		
                        	
							
						</ul>
                    	<ul class="boxLista">
							<li class="dropdown-header">Inclusi�n Financiera</li>    
                                    <li><a href="../PublicacionesEstadisticas/Informe-Inclusion-Financiera.asp">Informe de Inclusi�n Financiera</a></li>
                                   <li><a href="../PublicacionesEstadisticas/Informe-proveedores-no-financieros-credito.asp">Informe sobre  Proveedores No Financieros de Cr�dito</a></li>
                        	
							
						</ul>
						
						
						<ul class="boxLista">
							<li class="dropdown-header">Usuarios Financieros</li>    
                                    <li><a href="../PublicacionesEstadisticas/Informe-protecion-personas-usuarias.asp"> Informe sobre Protecci�n a las Personas Usuarias de Servicios Financieros</a></li> 
                                
                        	
							
						</ul>
						
							<ul class="boxLista">
                            <li class="dropdown-header">Investigaci�n econ�mica </li> 
								<li><a href="../PublicacionesEstadisticas/Ensayos_economicos.asp">Revista Ensayos Econ�micos</a></li>
								<li><a href="../PublicacionesEstadisticas/Estudios_economicos.asp">Estudios Econ�micos</a></li>
                                    
                                    <li><a href="../PublicacionesEstadisticas/Documentos_de_trabajo.asp">Documentos de Trabajo</a></li>
									<li><a href="../PublicacionesEstadisticas/Notas-tecnicas.asp">Notas T�cnicas</a></li>
                            	
                             
								
						</ul>
						
						<!--<ul class="boxLista">
							<li class="dropdown-header"><a href="https://www.centraldeideas.blog">BLOG | CENTRAL DE IDEAS</a></li>
                        </ul>-->
						
						
													
                    </li>
					<li class="col-sm-4">
						
								<ul class="boxLista">

							<li class="dropdown-header">Medios de Pago</li>
											<li><a href="../PublicacionesEstadisticas/Informe-pagos-minoristas.asp">Informe de Pagos Minoristas</a></li>

										
							
						</ul>
						
							
						
						<ul class="boxLista">

                            <li><a href="../PublicacionesEstadisticas/Politicas-de-prevencion-del-La-Ft-Fp.asp">POL�TICAS DE PREVENCI�N DEL LA/FT/FP </a></li>
												
						</ul>
						
						
						<ul class="boxLista">

                            <li><a href="../PublicacionesEstadisticas/Informe_anual_al_congreso.asp">Informe Anual al Congreso</a></li>
                          
                            
                           
						   	
						</ul>
						
                    	<ul class="boxLista">
							
							
							  <li class="dropdown-header">Balances</li>
                                    <li><a href="../PublicacionesEstadisticas/balances_semanales.asp">Semanales</a></li>
                                    <li><a href="../PublicacionesEstadisticas/balances_anuales.asp">Anuales</a></li>
                            
							
						</ul>
						                	<ul class="boxLista">

                            <li><a href="../PublicacionesEstadisticas/Memoria_anual.asp">Memoria Anual</a></li>
												
						</ul>
						
						
	
					</li>
					
				</ul>
			</li>
            
            <!-- BOT�N ESTADISTICAS -->
						<li class="dropdown dropdown-large">
				<a href="#" class="dropdown-toggle botonera" data-toggle="dropdown">Estad�sticas</a>
				<ul class="dropdown-menu dropdown-menu-large row">
					<li class="col-sm-4">
						<ul class="boxLista">
                           <li class="dropdown-header"><a href="../PublicacionesEstadisticas/Principales_variables.asp">Principales variables</a></li>
							
						</ul>
							<ul class="boxLista">
                        	  <li class="dropdown-header">Monetarias y financieras
                                    <li><a href="../PublicacionesEstadisticas/Consultas_Personalizadas_Series_Estadisticas.asp">Consultas personalizadas de series estad�sticas</a></li>
                                    <li><a href="../PublicacionesEstadisticas/Cuadros_estandarizados_series_estadisticas.asp">Cuadros estandarizados de series estad�sticas</a></li>
                                    <li><a href="../PublicacionesEstadisticas/Boletin_estadistico.asp">Bolet�n Estad�stico</a></li>
                                    <li><a href="../PublicacionesEstadisticas/Metodologias.asp">Metodolog�as</a></li>
                               
                            </li> 
							
						</ul>
						
											
						
					</li>	
					<li class="col-sm-4">
                    	<ul class="boxLista">	
                             <li class="dropdown-header">Sector externo
                               
                                    <li><a href="../PublicacionesEstadisticas/Estad�sticas_Mercado_de_cambios.asp">Evoluci�n del Mercado de Cambios </a></li>
                                    <li><a href="../PublicacionesEstadisticas/Estadisticas_deuda_externa_privada.asp">Deuda Externa Privada</a></li>
                                    <li><a href="../PublicacionesEstadisticas/Estadisticas-inversion-extranjera-directa.asp">Inversi�n Extranjera Directa </a></li>
                                    <li><a href="../PublicacionesEstadisticas/Libor.asp">Tasas LIBOR</a></li>
                                    <li><a href="../PublicacionesEstadisticas/Precios_materias_primas.asp">Precios de Materias Primas</a></li>
                             
                            </li> 
							</ul>
		   
		   
		   
		   
		   <ul class="boxLista">	
		    <li class="dropdown-header">Cambiarias
                                
                                    <li><a href="../PublicacionesEstadisticas/Tipos_de_cambios.asp">Tipos de cambio</a></li>
                                    <li><a href="../PublicacionesEstadisticas/Indices_tipo_cambio_multilateral.asp">�ndices de Tipo de Cambio Multilateral</a></li>
                               
                            </li>
		   </ul>
		   
					</li>	
					<li class="col-sm-4">
                    	<ul class="boxLista">
                          
						
                            <li><a href="../PublicacionesEstadisticas/Sistema_nacional_de_pagos.asp">Sistema Nacional de Pagos</a></li>
							
						</ul>
							 <ul class="boxLista">
								 
                            <li><a href="../PublicacionesEstadisticas/Relevamiento_Expectativas_de_Mercado.asp">Relevamiento de Expectativas de Mercado (REM)</a></li>
								 </ul>
								  <ul class="boxLista">
                            <li><a href="../PublicacionesEstadisticas/Encuesta_de_condiciones_crediticias.asp">Encuesta de Condiciones Crediticias (ECC)</a></li>
									 </ul> 
							 <ul class="boxLista">
                            <li><a href="../PublicacionesEstadisticas/Normas_estandar_divulgacion_datos.asp">Normas Especiales para la Divulgaci�n de Datos - FMI</a></li>
							</ul>			   
							    <ul class="boxLista">
							<li><a href="../PublicacionesEstadisticas/Operaciones-y-subastas.asp">Operaciones de Regulaci�n Monetaria</a></li>
							</ul>					
								 <ul class="boxLista">
							<li><a href="../PublicacionesEstadisticas/subasta-dolares-hacienda.asp">Subasta de d�lares por cuenta y orden de Hacienda</a></li>
                        </ul>
    				</li>
					
			
				</ul>
			</li>
            
            
            <!-- BOT�N EL BCRA Y VOS -->
				<li class="dropdown dropdown-large botonaranja">
				<a href="#" class="dropdown-toggle botonaranja" data-toggle="dropdown">El BCRA y vos </a>
				
				<ul class="dropdown-menu dropdown-menu-large dropdown-menu-large-naranja row">
					<li class="col-sm-4">
						
						
						<ul class="boxLista">
							<li><a href="../BCRAyVos/Como-hacer-un-reclamo-ante-el-Banco-Central.asp">HACER UN RECLAMO</a></li>
							
						</ul>  
						<ul class="boxLista">
							<li class="dropdown-header">CONSULT�</li>
                       		<li><a href="../BCRAyVos/Situacion_Crediticia.asp">Central de Deudores</a></li>
							<li><a href="../BCRAyVos/Central-de-Facturas-de-Credito-Electronicas-Impagas-CenFIV.asp">Central de Facturas de Cr�dito Electr�nicas MiPyME impagas al vencimiento (CenFIV)</a></li>
                       		<li><a href="../BCRAyVos/Cheques_Denunciados.asp">Cheques Denunciados</a></li>
							<li><a href="../Noticias/Relanzamiento-Cuenta-Gratuita-Universal.asp">Cuenta Gratuita Universal (CGU)</a></li>
                       		<li><a href="../BCRAyVos/Realizacion_de_activos.asp">Realizaci�n de activos</a></li>
							<li><a href="../BCRAyVos/Oficios_judiciales.asp">Oficios Judiciales</a></li>
                       		<li><a href="../SistemasFinancierosYdePagos/Como_pagar_multa.asp">Pago de multas cambiarias y financieras</a></li>
							<li><a href="../BCRAyVos/exportaciones-bcra-certificados-cumplidos-secoexpo.asp">Certificaciones de cumplido (SECOEXPO)</a></li>
							<li><a href="../BCRAyVos/calculadora-intereses-tasa-justicia.asp">Calculadora de intereses | Tasa de inter�s para uso de la Justicia - Comunicado P 14290</a></li>
						</ul>
                        <ul class="boxLista">	
							<li class="dropdown-header">COMPAR�</li>&nbsp
                       		<li><a href="../BCRAyVos/Comparacion_de_Comisiones.asp#a">Comparaci�n de comisiones</a></li>
							<!--<li><a href="../BCRAyVos/Ingresos-Brutos-Provinciales.asp">Ingresos Brutos Provinciales</a></li> -->
							<li><a href="../BCRAyVos/Regimen_de_transparencia.asp">R�gimen de Transparencia</a></li>
								<li><a href="../BCRAyVos/Plazos_fijos_online.asp">Tasas Plazos Fijos <em>Online</em> en Pesos</a></li>
                       		
						</ul>
						
						
                    	     		
                         
										
					</li>
					
					
					
					<li class="col-sm-4">
						<ul class="boxLista">
							<li><a href="../BCRAyVos/Usuarios_Financieros.asp">USUARIOS FINANCIEROS</a></li>
							<li><a href="../BCRAyVos/Sobre-el-acceso-al-mercado-de-cambios-y-la-compra-de-dolar-ahorro.asp">Acceso al mercado de cambios y la compra de d�lar ahorro </a></li>
							<!--<li><a href="../BCRAyVos/Situacion_Crediticia.asp">Central de Deudores</a></li>
							<li><a href="../BCRAyVos/Cheques_Denunciados.asp">Cheques Denunciados</a></li>-->
							
							<li><a href="../BCRAyVos/Como-prevenir-estafas-virtuales.asp">C�mo prevenir estafas</a>

<li><a href="../BCRAyVos/Como-hacer-un-reclamo-ante-el-Banco-Central.asp">C�mo hacer un reclamo ante el Banco Central</a>
							
							
							
						<!--	<li><a href="../BCRAyVos/Como-prevenir-estafas-virtuales.asp">C�mo prevenir estafas</a></li> 
							<li><a href="../BCRAyVos/Reclamos.asp">C�mo reclamar ante el Banco Central </a></li>
							<li> <a href="../BCRAyVos/Pedido-de-rectificacion-supresion-de-registro-en-la-central-de-deudores.asp">C�mo rectificar o suprimir registros en la Central de Deudores</a></li>-->
							<li><a href="../BCRAyVos/como-usar-productos-bancarios.asp">C�mo usar los productos bancarios </a></li> 
													
						<!--	<li><a href="../BCRAyVos/Comparacion_de_Comisiones.asp">Comparar comisiones bancarias </a></li>-->
							<li><a href="../BCRAyVos/Preguntas_frecuentes.asp">Consultar: respuestas a preguntas frecuentes sobre productos bancarios </a></li>
						<!--	<li><a href="../SistemasFinancierosYdePagos/Entidades_financieras.asp">Datos de las entidades financieras</a></li>--> 
							<li><a href="../BCRAyVos/diccionario-financiero.asp">Diccionario financiero</a></li>
							<li><a href="../BCRAyVos/Feriados-bancarios-2025.asp">Feriados bancarios</a></li>
						<!--	<li><a href="../PublicacionesEstadisticas/Informe-protecion-personas-usuarias.asp">Informe sobre Protecci�n a las Personas Usuarias de Servicios Financieros</a></li> -->
                            <li><a href="../BCRAyVos/responsables-de-atencion-al-usuario.asp">Responsables de atenci�n al usuario</a></li>
							<li><a href="../BCRAyVos/sugerencias-o-quejas.asp">Sugerir y presentar quejas</a></li> 
							<li><a href="../BCRAyVos/tus-derechos-y-obligaciones-de-los-bancos.asp">Tus derechos y las obligaciones de los bancos </a></li>
							
													
					   </ul>		
					
					</li>
					
					<li class="col-sm-4">
						
						<ul class="boxLista">
							<li><a href="../BCRAyVos/catalogo-de-APIs-banco-central.asp">APIS DEL BANCO CENTRAL</a></li>
							
						</ul>  
						<ul class="boxLista">
                           		<li><a href="../Saber_es_central/index.html">SABER ES CENTRAL</a></li>
								
                           	</ul>
					</li>	
						
					<!--	<ul class="boxLista">
                           		<li><a href="../Institucional/premio-pintura-bcra-PNP.asp">PREMIO NACIONAL DE PINTURA BANCO CENTRAL</a></li>
								
                           	</ul>-->
						
						
					</li>
					<li class="col-sm-4">
						<ul class="boxLista">
							<li><a href="../BCRAyVos/Educacion-Financiera.asp">EDUCACI�N FINANCIERA</a></li>
						<!--	<li class="dropdown-header">EDUCACI�N FINANCIERA</li>
							<li class="dropdown-submenu">Aprendiendo a Ahorrar
								<ul class="dropdown-submenu">
									<li><a href="../BCRAyVos/Aprendiendo-a-ahorrar-sobre-el-programa.asp">Sobre el programa</a></li>
									<li><a href="../BCRAyVos/Aprendiendo-a-ahorrar-que-es-el-ahorro.asp">Qu� es el ahorro</a></li>
									<li><a href="../BCRAyVos/Aprendiendo-a-ahorrar-como-ahorrar-en-5-pasos.asp">C�mo ahorrar en 5 pasos</a></li>
									<li><a href="../BCRAyVos/Aprendiendo-a-ahorrar-cuentas-ahorro-menores-18.asp">Cuentas de ahorro para menores de 18 a�os</a></li>
								</ul>	
							</li>
							<li class="dropdown-submenu">Habilidades Financieras para la Vida
								<ul class="dropdown-submenu">
									<li><a href="../BCRAyVos/Habilidades-financieras-sobre-el-progrma.asp">Sobre el programa</a></li>
									<li><a href="../BCRAyVos/Habilidades-Recorridos.asp">Recorridos | Material did�ctico</a></li>
								</ul>	
							</li>-->
							<li><a href="../BCRAyVos/Programas-Educacion-Financiera-bcra.asp">Programas de Educaci�n Financiera </a></li>
							<li><a href="../BCRAyVos/encuesta_caf.asp">Encuesta de medici�n de capacidades financieras </a></li>
							<li><a href="../BCRAyVos/Educacion-Financiera-material-didactico.asp">M�s | Material did�ctico de Educaci�n Financiera   </a></li>

						</ul>
						
						<ul class="boxLista">	
						    <li class="dropdown-header">VISITANOS</li>
                       		<li><a href="../BCRAyVos/Bibliotecas.asp">Bibliotecas</a></li>
                       		<li><a href="../BCRAyVos/Museo_Historico_y_Numismatico.asp">Museo Hist�rico y Numism�tico</a></li>
                       		<li><a href="../BCRAyVos/Stand_Numismatico.asp">Stand de emisiones numism�ticas</a></li>
							<!--<li><a href="../BCRAyVos/Tecnopolis-2023.asp">Tecn�polis</a></li>-->
						</ul>
						
						<ul class="boxLista">	
                       		<li><a href="../BCRAyVos/Trabaja-en-el-BCRA-busquedas-vigentes.asp">Trabaj� en el BCRA</a></li>
                            <!--li><a href="#">Eventos</a></li-->
                       		<li><a href="../BCRAyVos/Contacto.asp">Contactanos</a></li>					
						</ul>
					</li>
				</ul>
			</li>
		</ul>
		
		
	</div><!-- /.nav-collapse -->
</nav>



</div>
</header>

<div class="navegacion-breadcrumb">
    <ol class="breadcrumb paginas">
        <li class="disabled">El BCRA y vos</li>
        <li class="disabled"><a href="Usuarios_Financieros.asp">Usuarios financieros</a></li>
        <li class="active">Comparar comisiones bancarias</li>
    </ol>
</div>

<!--CONTENIDO PRINCIPAL-->

<div class="contenido">
	<div class="row">    
		<div class="col-xs-12 col-md-8">
      		<div class="clearfix pagina-interior">
            	<h2>Comparar comisiones bancarias </h2>

<p class="post-pagina-interior">Con el objeto de generar mayor transparencia en la determinaci�n del valor de las comisiones bancarias, se publican las tablas comparativas con los valores que los bancos cobran a sus personas clientas por distintos productos.
<p class="post-pagina-interior">En base a lo establecido por la <a href="../Pdfs/comytexord/A5928.pdf" target="_blank" onClick="ga('send', 'event', 'MLN-Comunicaciones', 'Click', 'A5928.pdf', '0');">Comunicaci�n A 5928</a>,  los bancos deber�n enviar esas tablas a sus clientes cuando informen las variaciones en el valor de las comisiones. De ese modo, las personas usuarias de los servicios financieros contar�n con mayor informaci�n para tomar mejores decisiones y elegir al banco que mejor se ajuste a sus necesidades.<br>
<br>
 <strong><a href="Primeras_10_entidades.asp" target="_self">Primeras 10 entidades</a></strong><br><br>

  <strong><a href="Comisiones_cargos.asp" target="_self">Sistema financiero</a></strong>
 
<p class="post-pagina-interior"><br> 
   		  </div>
      	</div>
    </div>	
</div>

<footer>
	<meta name="format-detection" content="telephone=no">
<p>&nbsp;</p>

<footer class="footer-bcra">
	<div class="row">
	  	<div class="col-xs-12 col-sm-5 col-md-5 footer-bcra-contacto">
		  
            <ul>
				<li style="font-weight: bolder">BANCO CENTRAL DE LA REP�BLICA ARGENTINA</li>
            	<li>Reconquista 266 </li>
			<li>C1003ABF</li>
				<li>Ciudad Aut�noma de Buenos Aires,  Argentina</li>
                <li>Tel. +54 11 4348-3500 / + 54 11 4000-1200</li>
                <li>www.bcra.gob.ar</li>
            </ul>     
			
      	</div>
      	<div class="col-xs-12 col-sm-4 col-md-4 footer-bcra-contacto">
		 
            <ul>
            	<li>
						<a href="../Varios/Aviso_legal.asp" onclick="ga('send', 'event', 'Principal', 'Click', 'Footer- Aviso Legal', '0');">Aviso legal</a>
				</li>
		
			
<li><a href="../Varios/Mapa_del_sitio.asp" onclick="ga('send', 'event', 'Principal', 'Click', 'Footer- Mapa del sitio', '0');">Buscar</a></li>
<li><a href="../BCRAyVos/Contacto.asp">Contactanos</a></li>
	
				
				
		<!--<li onclick="MM_openBrWindow('http://bcra.perfit.com.ar/gestion2/form.php','Alertas','scrollbars=yes,width=620,height=615')">
				-->
						<li>
					<a href="../Varios/Mapa_del_sitio.asp" onclick="ga('send', 'event', 'Principal', 'Click', 'Footer- Mapa del sitio', '0');">Mapa del sitio</a></li>
				<li><a href="https://www.dopplerpages.com/alertas-7CE97/Notificaciones-bcra">Suscribirse</a>
				</li>
				
				
				<!--<li>
						<a href="https://webmail.bcra.gob.ar/owa/auth/logon.aspx?replaceCurrent=1&url=https%3a%2f%2fwebmail.bcra.gob.ar%2fowa%2f" target="_blank" >Webmail</a>
				</li>-->
            </ul>     
			
	  	</div>
		<div class="col-xs-12 col-sm-3 col-md-3 footer-bcra-contacto">

			<ul>
			<li>
					<a href="../Varios/English_information.asp" >ENG</a>
				</li>
                <li>
					<a href="BCRAyVos/Usuarios_Financieros.asp" >Usuarios Financieros</a>
				</li>
                <li>
					<a href="https://twitter.com/bcrausuarios" target="_blank" onclick="ga('send', 'event', 'Principal', 'Click', 'Footer- Twitter Usuarios', '0');"><svg xmlns="http://www.w3.org/2000/svg" height="1em" style="fill:white; translate: 0px 3px" viewBox="0 0 512 512"><path d="M389.2 48h70.6L305.6 224.2 487 464H345L233.7 318.6 106.5 464H35.8L200.7 275.5 26.8 48H172.4L272.9 180.9 389.2 48zM364.4 421.8h39.1L151.1 88h-42L364.4 421.8z"/></svg> @BCRAusuarios</a>
				</li>
				
				
          	</ul>

			</div>
		<div class="col-xs-12 hidden-sm hidden-md hidden-lg hidden-xl footer-bcra-social">

			<ul>
				<li style="font-weight: bolder">Seguinos</li>
                <li><a href="https://www.facebook.com/BancoCentralAR/" target="_blank"><i class="fa fa-facebook"></i> Facebook</a></li>
				<li><a href="https://www.instagram.com/bancocentral_ar/?hl=es-la" target="_blank"><i class="fa fa-instagram" style="color:white"></i> Instagram</a></li>
                <li><a href="https://www.linkedin.com/company/bcra" target="_blank"><i class="fa fa-linkedin"></i> Linkedin</a></li>
				<li><a href="https://twitter.com/bancocentral_ar" target="_blank"><i class="fa fa-twitter"></i> Twitter</a></li>
				<li><a href="https://www.youtube.com/channel/UCq1CEC9JxvblsszG71-CPKw" target="_blank"><i class="fa fa-youtube"></i> Youtube</a></li>

          	</ul>
		
			</div>
		
	</div>
	
</footer>

	
<section style="text-align:center; margin:10px auto; color:#B4B4B4; font-size: 100%; font-family:Calibri, Candara, Segoe, Optima, Arial, sans-serif;">
	<p>El BCRA es el Banco Central de la Rep�blica Argentina. No ofrece servicios bancarios o financieros al p�blico en general.</p>
	<p>Copyright 2006-2023 � | Banco Central de la Rep�blica Argentina | Todos los derechos reservados</p>
</section>
<script type="text/javascript">
function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);
}
</script>
  
</footer>

</div>

</body>
</html>
<script id="f5_cspm">(function(){var f5_cspm={f5_p:'MBDGJGIEMIFCIFHJGODHLGDIADAFPPALFFNGMDDEMBHFNOHHCOGNGBJGFNMGJCHALLDBBDMKAAJKHADGOKAABKBMAACBPONCFPJPJAKCPEHMCOJFDBGGMOOBFEHPHOPP',setCharAt:function(str,index,chr){if(index>str.length-1)return str;return str.substr(0,index)+chr+str.substr(index+1);},get_byte:function(str,i){var s=(i/16)|0;i=(i&15);s=s*32;return((str.charCodeAt(i+16+s)-65)<<4)|(str.charCodeAt(i+s)-65);},set_byte:function(str,i,b){var s=(i/16)|0;i=(i&15);s=s*32;str=f5_cspm.setCharAt(str,(i+16+s),String.fromCharCode((b>>4)+65));str=f5_cspm.setCharAt(str,(i+s),String.fromCharCode((b&15)+65));return str;},set_latency:function(str,latency){latency=latency&0xffff;str=f5_cspm.set_byte(str,40,(latency>>8));str=f5_cspm.set_byte(str,41,(latency&0xff));str=f5_cspm.set_byte(str,35,2);return str;},wait_perf_data:function(){try{var wp=window.performance.timing;if(wp.loadEventEnd>0){var res=wp.loadEventEnd-wp.navigationStart;if(res<60001){var cookie_val=f5_cspm.set_latency(f5_cspm.f5_p,res);window.document.cookie='f5avr0410840495aaaaaaaaaaaaaaaa_cspm_='+encodeURIComponent(cookie_val)+';path=/;'+'';}
return;}}
catch(err){return;}
setTimeout(f5_cspm.wait_perf_data,100);return;},go:function(){var chunk=window.document.cookie.split(/\s*;\s*/);for(var i=0;i<chunk.length;++i){var pair=chunk[i].split(/\s*=\s*/);if(pair[0]=='f5_cspm'&&pair[1]=='1234')
{var d=new Date();d.setTime(d.getTime()-1000);window.document.cookie='f5_cspm=;expires='+d.toUTCString()+';path=/;'+';';setTimeout(f5_cspm.wait_perf_data,100);}}}}
f5_cspm.go();}());</script>