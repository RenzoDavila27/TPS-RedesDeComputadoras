<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
	<meta http-equiv="Pragma" content="no-cache">
	<meta http-equiv="Expires" content="0">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Banco Patagonia</title>
	<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-NL73B44');</script>
<!-- End Google Tag Manager -->

<link rel="shortcut icon" href="favicon.ico" type="image/x-icon"/>
<link href="assets/fonts/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="assets/js/mtabs/bootstrap-responsive-tabs.css" rel="stylesheet" type="text/css">
<link href="assets/js/slick/slick.css" rel="stylesheet" type="text/css">
<link href="assets/js/fancybox/jquery.fancybox.min.css" rel="stylesheet" type="text/css">
<link href="assets/css/styles.css" rel="stylesheet" type="text/css">
<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]--></head>

<body>
	<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NL73B44"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

<div class="placeholder-bar">
	<div class="container-fluid header-bar">
		<div class="row">
			<header class="container">
				<div class="row">
					<div class="col-md-3 col-dsk-6 col-sm-6">
						<span class="c-hamburger c-hamburger--htx">
							<span>toggle menu</span>
						</span>
                        <!-- -->
                        <!--<img style="position: absolute; width: 42px; top: 20px; right: 40px;" class="dsk" src="<php echo $path ?>assets/images/layout/icon-verano-2022.svg">-->
                        <!-- -->
						<h1>
                            <!--<img style="position: absolute; width: 32px; top: 12px; left: 102px;" class="dsk" src="<php echo $path ?>assets/images/layout/icon-navidad-2021.svg">-->
                            <a href="index.php" class="main-logo">Banco Patagonia</a>
                        </h1>
					</div>
					<div class="col-md-9 col-dsk-6 col-sm-6">
						<div class="general-links">
							<ul class="list-unstyled">
                                								<li><a href="preguntas-frecuentes/index.php" class="">Ayuda</a></li>
								<!--<li><a href="<php echo $folder_canales ?>index.php" class="<php echo $canales ?>">Canales de atención</a></li>-->
								<!--<li><a href="http://sucursalesycajeros.bancopatagonia.com.ar/sucursales.html" target="_blank">Sucursales y cajeros</a></li>-->
								<!--<li><a href="<php echo $folder_contactenos ?>index.php" class="<php echo $contactenos ?>">Contactanos</a></li>-->
                                <!--<li><a href="<php echo $path ?>ayuda/index.php" class="<php echo $ayuda ?>">Ayuda</a></li>-->
							</ul>
						</div>
						<div class="top-links">
							<ul class="list-unstyled">
								<li><a href="personas/index.php" class="">PERSONAS</a></li>
								<li><a href="nyps/index.php" class="">PROFESIONALES Y COMERCIOS</a></li>
								<li><a href="pyme/index.php" class="">PYME</a></li>
								<li><a href="agro/index.php" class="">AGRO</a></li>
								<li><a href="empresas/index.php" class="">EMPRESAS</a></li>
								<li><a href="sector-publico/index.php" class="">SECTOR PÚBLICO</a></li>
								<li><a href="institucional/index.php" class="">INSTITUCIONAL</a></li>
							</ul>
							<div class="ebank">
                            <!-- antes href: <php echo $folder_empresas ?><php echo $url_ebank ?>-->
															<a href="https://ebankpersonas.bancopatagonia.com.ar/eBanking/usuarios/login.htm" class="patagonia-ebank" target="_blank">Patagonia e-Bank</a>
														</div>
						</div>
					</div>
				</div>
			</header>
		</div>
	</div>
</div>

<div class="container-fluid nav-bar">
	<div class="row">
		<nav class="container">
			<div class="row">
				<!--<div class="col-md-9 col-md-offset-3">-->
                <div class="col-md-10 col-md-offset-3"><!-- ajuste agro -->
					<ul class="list-unstyled sub-navbar">
						
						                        
                                                
                                                
                        						
												
												
						
													<li class="menu-spacer"></li>
											</ul>
				</div>
			</div>
		</nav>
	</div>
</div>

<div class="mobile-nav-bar">
	<ul class="list-unstyled">
        
        <!-- PERSONAS -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">PERSONAS <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="personas/index.php" class="">HOME</a></li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA CLÁSICA</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="personas/patagonia-clasica/patagonia-ahorro/productos.php">Patagonia Ahorro</a></li>
                        <li><a href="personas/patagonia-clasica/paquete/productos.php">Patagonia Clásica</a></li>
                        <!--<li><a href="<php echo $path ?>personas/patagonia-clasica/mas/productos.php">Patagonia Clásica Más</a></li>-->
                        <li><a href="personas/patagonia-clasica/premium/productos.php">Patagonia Clásica Premium</a></li>
                        <li><a href="personas/patagonia-clasica/patagonia-sueldo/productos.php">Patagonia Sueldo</a></li>
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA PLUS</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="personas/patagonia-plus/productos.php">Patagonia Plus</a></li>
                        <li><a href="personas/patagonia-plus/premium/productos.php">Patagonia Plus Premium</a></li>
                    </ul>						
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA SINGULAR</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="personas/patagonia-singular/paquete/propuesta.php">Patagonia Singular</a></li>
                        <li><a href="personas/patagonia-singular/beneficios-exclusivos.php">Beneficios Exclusivos</a></li>
                        <!--<li><a href="<php echo $path ?>personas/patagonia-singular/atencion-exclusiva/index.php">Atención Exclusiva</a></li>-->
                        <!--<li><a href="<php echo $path ?>personas/patagonia-singular/eventos-y-novedades/index.php">Eventos y Novedades</a></li>-->
                    </ul>
                </li>
				<!--<li class="nav-sub-item"><a href="<php echo $path ?>patagoniaon/index.php" target="_blank">PATAGONIA ON</a></li>-->
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA ON</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="patagoniaon/index.php" target="_blank">Patagonia ON</a></li>
						<li><a href="personas/productos-y-servicios/patagonia-universitaria.php">Patagonia ON Universitaria</a></li>
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PRODUCTOS Y SERVICIOS</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="personas/apple-pay.php">Apple Pay</a></li>
                        <li><a href="personas/productos-y-servicios/caja-de-seguridad.php">Caja de Seguridad</a></li>
                        <li><a href="personas/productos-y-servicios/comercio-exterior/productos.php">Comercio exterior</a></li>
						<!--<li><a href="<php echo $path ?>personas/productos-y-servicios/beneficios-wapa.php">Comercios WAPA</a></li>-->
						<li><a href="personas/cuotifica-al-toque.php">Cuotificá al Toque</a></li>
						<li><a href="personas/google-pay.php">Google Pay</a></li>
                        <li><a href="personas/productos-y-servicios/inversiones.php">Inversiones</a></li>
                        <li><a href="personas/jubilados/index.php">Jubilados</a></li>
                        <li><a href="personas/productos-y-servicios/patagonia-para-menores.php">Patagonia para Menores</a></li>
                        <!--<li><a href="<php echo $path ?>personas/productos-y-servicios/patagonia-universitaria.php">Patagonia Universitaria</a></li>-->
                        <li><a href="personas/productos-y-servicios/prestamos.php">Prestamos</a></li>
                        <li><a href="personas/seguros/index.php">Seguros</a></li>
                        <li><a href="personas/productos-y-servicios/tarjetas-de-credito/visa.php">Tarjetas de crédito</a></li>
                        <li><a href="personas/productos-y-servicios/tarjetas-de-debito/patagonia-24.php">Tarjetas de débito</a></li>
                    </ul>
                </li>
			</ul>
		</li>
        <!-- FIN PERSONAS -->
        
        <!-- NYPS -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">PROFESIONALES Y COMERCIOS <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="nyps/index.php" class="">HOME</a></li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA CLÁSICA</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="nyps/patagonia-clasica/premium/productos.php">Patagonia Clásica Premium</a></li>
                        <li><a href="nyps/patagonia-clasica/patagonia-emprendimiento/productos.php">Patagonia Emprendimiento</a></li>
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA PLUS</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="nyps/patagonia-plus/productos.php">Patagonia Plus</a></li>
                        <li><a href="nyps/patagonia-plus/premium/productos.php">Patagonia Plus Premium</a></li>
                    </ul>						
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA SINGULAR</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="nyps/patagonia-singular/paquete/propuesta.php">Patagonia Singular</a></li>
                        <li><a href="nyps/patagonia-singular/beneficios-exclusivos.php">Beneficios Exclusivos</a></li>
                        <!--<li><a href="<php echo $path ?>nyps/patagonia-singular/eventos-y-novedades/index.php">Eventos y Novedades</a></li>-->
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PRODUCTOS Y SERVICIOS</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="nyps/productos-y-servicios/tarjetas-de-debito/patagonia-24.php">Tarjetas de débito</a></li>
                        <li><a href="nyps/productos-y-servicios/tarjetas-de-credito/visa.php">Tarjetas de crédito</a></li>
                        <li><a href="nyps/productos-y-servicios/prestamos.php">Prestamos</a></li>
                        <li><a href="nyps/seguros/index.php">Seguros</a></li>
                        <li><a href="nyps/productos-y-servicios/inversiones.php">Inversiones</a></li>
                        <li><a href="nyps/productos-y-servicios/comercio-exterior/productos.php">Comercio exterior</a></li>
                        <li><a href="nyps/productos-y-servicios/caja-de-seguridad.php">Caja de Seguridad</a></li>
                        <li><a href="nyps/productos-y-servicios/factura-electronica.php">Factura electrónica</a></li>
                        <li><a href="nyps/productos-y-servicios/pagos-afip.php">Pagos AFIP</a></li>
                        <!--<li><a href="<php echo $path ?>nyps/productos-y-servicios/soluciones-para-tu-empresa.php">Soluciones para tu empresa</a></li>-->
                        <!--<li><a href="<php echo $path ?>nyps/productos-y-servicios/comercios-patagonia.php">Comercios Patagonia</a></li>-->
						<li><a href="nyps/productos-y-servicios/wapa.php">WAPA</a></li>
                    </ul>
                </li>
			</ul>		
		</li>
        <!-- FIN NYPS -->
        
        <!-- PYME -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">PYME <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="pyme/index.php" class="">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">CUENTAS</a>
					<ul class="list-unstyled submenu">
                        <li><a href="pyme/cuentas/pequenas-empresas.php">Pyme Pequeñas Empresas</a></li>
				        <li><a href="pyme/cuentas/medianas-empresas.php">Pyme Medianas Empresas</a></li>
                        <!--
						<li><a href="pyme/cuentas/patagonia-empresario.php">Patagonia Empresario</a></li>
						<li><a href="pyme/cuentas/patagonia-empresario-premier.php">Patagonia Empresario Premier</a></li>
						<li><a href="pyme/cuentas/patagonia-empresa.php">Patagonia Empresa</a></li>
                        -->
                        <!--<li><a href="pyme/cuentas/patagonia-comercio.php">Patagonia Comercio</a></li>-->
                        <li><a href="pyme/cuentas/patagonia-consorcio.php">Patagonia Consorcio</a></li>
						<li><a href="pyme/cuentas/cuenta-corriente.php">Cuenta Corriente</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA SUELDO</a>
					<ul class="list-unstyled submenu">
						<li><a href="pyme/patagonia-sueldo/servicios.php">Servicios</a></li>
						<li><a href="pyme/patagonia-sueldo/preguntas-frecuentes.php">Preguntas Frecuentes</a></li>
						<li><a href="pyme/patagonia-sueldo/guia-implementacion.php">Guía de Implementación</a></li>
					</ul>
				</li>						
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">COMERCIO EXTERIOR</a>
					<ul class="list-unstyled submenu">
						<li><a href="pyme/comercio-exterior/solicitud-electronica.php">Solicitud Electrónica</a></li>
						<li><a href="pyme/comercio-exterior/productos.php">Productos</a></li>
						<li><a href="pyme/comercio-exterior/otros-servicios.php">Servicios</a></li>
						<!--<li><a href="<php echo $folder_pymeCexterior ?>financiaciones.php">Financiaciones</a></li>-->
                        <li><a href="pyme/comercio-exterior/herramientas-para-exportar.php">Herramientas para Exportar</a></li>
						<li><a href="pyme/comercio-exterior/marco-regulatorio/normas-y-regulaciones.php">Marco Regulatorio</a></li>
					</ul>
				</li>						
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">FINANCIACIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="pyme/financiacion/patagonia-leasing.php">Patagonia Leasing</a></li>
						<li><a href="pyme/financiacion/mercado-capitales.php">Mercado de Capitales</a></li>
						<li><a href="pyme/financiacion/alternativas-de-financiacion.php">Alternativas de Financiación</a></li>
					</ul>
				</li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">SEGUROS</a>
					<ul class="list-unstyled submenu">
						<li><a href="pyme/seguros/protege-tus-bienes/integral-comercio.php">Protegé tus Bienes</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">INVERSIONES</a>
					<ul class="list-unstyled submenu">
						<li><a href="pyme/inversiones/plazo-fijo.php">Plazo Fijo</a></li>
						<li><a href="pyme/inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
						<li><a href="pyme/inversiones/fidecomisos-financieros.php">Fidecomisos Financieros</a></li>
					</ul>
				</li>						
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">SERVICIOS</a>
					<ul class="list-unstyled submenu">
						<li><a href="pyme/servicios/recaudaciones.php">Recaudaciones</a></li>
						<li><a href="pyme/servicios/pagos.php">Pagos</a></li>
						<li><a href="pyme/servicios/tarjetas-comerciales.php">Tarjetas Comerciales</a></li>
						<li><a href="pyme/servicios/comercios-patagonia.php">Comercios Patagonia</a></li>
                        <li><a href="pyme/servicios/pago-de-servicios.php">Pago de Servicios</a></li>
						<li><a href="pyme/servicios/interbanking.php">Interbanking</a></li>
						<li><a href="pyme/servicios/interfacturas.php">Interfacturas</a></li>
						<li><a href="pyme/servicios/pagos-afip.php">Pagos AFIP</a></li>
						<li><a href="pyme/servicios/wapa.php">WAPA</a></li>
					</ul>
				</li>
			</ul>		
		</li>
        <!-- FIN PYME -->
        
        <!-- AGRO -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">AGRO <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="agro/index.php" class="">HOME</a></li>
                <!-- -->
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">OFERTA AGRO</a>
					<ul class="list-unstyled submenu">
                    	<!--<li><a href="<php echo $folder_agroFinanciacion ?>insumos.php">Insumos en USD</a></li>-->
                        <li><a href="agro/convenios/acuerdos-y-beneficios.php">Acuerdos y convenios</a></li>
						<li><a href="agro/financiacion/maquinaria-agricola.php">Financiación Maquinaria Agrícola</a></li>
						<li><a href="agro/seguros/campo.php">Seguros para tu campo</a></li>
					</ul>
				</li>
                <!-- -->
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">TARJETA PATAGONIA AGRO</a>
					<ul class="list-unstyled submenu">
						<li><a href="agro/tarjeta-patagonia-agro/para-usuarios.php">Para Usuarios</a></li>
						<li><a href="agro/tarjeta-patagonia-agro/para-comercios.php">Para Comercios</a></li>
						<li><a href="agro/tarjeta-patagonia-agro/acuerdo-tasa-0.php">Tarjetas Agro Convenios Preferenciales</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="agro/cuenta-agro/cuenta-agro.php" class="">CUENTA AGRO</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">FINANCIACIÓN</a>
					<ul class="list-unstyled submenu">
                        <li><a href="agro/insumos/index.php">Insumos</a></li>
                        <li><a href="agro/financiacion/maquinaria-agricola.php">Maquinarias</a></li>
                        <li><a href="empresas/financiacion/convenios-de-financiacion.php">Camiones</a></li>
						<!--<li><a href="<php echo $folder_agroFinanciacion ?>capital-de-trabajo.php">Capital de Trabajo</a></li>-->
						<!--<li><a href="<php echo $folder_agroFinanciacion ?>proyectos-de-inversion.php">Proyectos de Inversión</a></li>-->
						<!--<li><a href="<php echo $folder_agroFinanciacion ?>creditos-para-hacienda.php">Créditos para Hacienda</a></li>-->
						<!--<li><a href="<php echo $folder_agroFinanciacion ?>leasing-y-prendarios.php">Leasing y Prendarios</a></li>-->
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">INVERSIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="agro/inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
						<li><a href="agro/inversiones/fidecomisos-financieros.php">Fidecomisos Financieros</a></li>
						<li><a href="agro/inversiones/plazos-fijos.php">Plazos Fijos</a></li>
					</ul>
				</li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">COMERCIO EXTERIOR</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="agro/comercio-exterior/solicitud-electronica.php">Solicitud Electrónica</a></li>
                        <li><a href="agro/comercio-exterior/productos.php">Productos</a></li>
                        <li><a href="agro/comercio-exterior/otros-servicios.php">Servicios</a></li>
                        <li><a href="agro/comercio-exterior/herramientas-para-exportar.php">Herramientas para Exportar</a></li>
                        <li><a href="agro/comercio-exterior/marco-regulatorio/normas-y-regulaciones.php">Marco Regulatorio</a></li>
                    </ul>
                </li>
                <!--
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">SERVICIOS</a>
					<ul class="list-unstyled submenu">
						<li><a href="agro/servicios/centro-atencion-empresas.php">Centro de Atención para Empresas</a></li>
					</ul>
				</li>
                -->
                <!-- -->
                <li class="nav-sub-item"><a href="agro/seguros/campo.php" class="">SEGUROS</a></li>
                <!-- -->
			</ul>
		</li>
        <!-- FIN AGRO -->
        
        <!-- EMPRESAS -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">EMPRESAS <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="empresas/index.php" class="">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA SUELDO</a>
					<ul class="list-unstyled submenu">
						<li><a href="empresas/patagonia-sueldo/servicios.php">Servicios</a></li>
						<li><a href="empresas/patagonia-sueldo/preguntas-frecuentes.php">Preguntas Frecuentes</a></li>
						<li><a href="empresas/patagonia-sueldo/guia-implementacion.php">Guía de Implementación</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">COMERCIO EXTERIOR</a>
					<ul class="list-unstyled submenu">
						<li><a href="empresas/comercio-exterior/solicitud-electronica.php">Solicitud Electrónica</a></li>
						<li><a href="empresas/comercio-exterior/productos.php">Productos</a></li>
						<li><a href="empresas/comercio-exterior/otros-servicios.php">Servicios</a></li>
						<!--<li><a href="<php echo $folder_Cexterior ?>financiaciones.php">Financiaciones</a></li>-->
                        <li><a href="empresas/comercio-exterior/herramientas-para-exportar.php">Herramientas para Exportar</a></li>
						<li><a href="empresas/comercio-exterior/marco-regulatorio/normas-y-regulaciones.php">Marco Regulatorio</a></li>
					</ul>
				</li>
                <!-- -->
				<!--<li class="nav-sub-item"><a href="empresas/comunidades-de-negocios/index.php" class="">COMUNIDADES DE NEGOCIOS</a></li>-->
                <!-- -->
				<li class="nav-sub-item"><a href="index.php" class="nav-lnk ">COMERCIOS PATAGONIA</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">FINANCIACIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="empresas/financiacion/patagonia-leasing.php">Patagonia Leasing</a></li>
						<li><a href="empresas/financiacion/mercado-capitales.php">Mercado Capitales</a></li>
						<li><a href="empresas/financiacion/alternativas-de-financiacion.php">Alternativas de Financiación</a></li>
                        <li><a href="empresas/financiacion/convenios-de-financiacion.php">Convenios de Financiación</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">INVERSIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="empresas/inversiones/plazos-fijos.php">Plazos Fijos</a></li>
						<li><a href="empresas/inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
						<li><a href="empresas/inversiones/compra-venta-titulos-acciones.php">Compra - Venta de Títulos y Acciones</a></li>
						<li><a href="empresas/inversiones/custodia-de-titulos.php">Custodia de Títulos</a></li>
						<li><a href="empresas/inversiones/fidecomisos-financieros.php">Fidecomisos Financieros</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">SERVICIOS</a>
					<ul class="list-unstyled submenu">
                        <li><a href="empresas/patagonia-movil-empresas.php">Patagonia Móvil Empresas</a></li>
						<li><a href="empresas/servicios/pagos.php">Pagos</a></li>
						<li><a href="empresas/servicios/recaudaciones.php">Recuadaciones</a></li>
						<li><a href="empresas/servicios/pago-de-servicios.php">Pago de Servicios</a></li>
						<li><a href="empresas/servicios/interbanking.php">Interbanking</a></li>
						<li><a href="empresas/servicios/interfacturas.php">Interfacturas</a></li>
						<li><a href="empresas/servicios/tarjetas-comerciales.php">Tarjetas Comerciales</a></li>
                        <!-- -->
						<!--<li><a href="empresas/servicios/comercios-patagonia.php">Comercios Patagonia</a></li>-->
                        <!-- -->
                        <li><a href="empresas/servicios/centro-atencion-empresas.php">Centro de Atención para Empresas</a></li>
					</ul>
				</li>
			</ul>
		</li>
        <!-- FIN EMPRESAS -->
        
        <!-- SECTOR PÚBLICO -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">SECTOR PÚBLICO <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="sector-publico/index.php" class="">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">INVERSIONES</a>
					<ul class="list-unstyled submenu">
						<li><a href="sector-publico/inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
						<li><a href="sector-publico/inversiones/plazo-fijo.php">Plazo Fijo</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">SERVICIOS</a>
					<ul class="list-unstyled submenu">
						<li><a href="sector-publico/servicios/servicio-de-recaudacion.php">Servicio de Recaudación</a></li>
						<li><a href="sector-publico/servicios/servicio-de-pagos.php">Servicio de Pagos</a></li>
						<li><a href="sector-publico/servicios/servicios-para-personal.php">Servicios para el Personal</a></li>
						<li><a href="sector-publico/servicios/financiacion.php">Financiación</a></li>
						<li><a href="sector-publico/servicios/otros-servicios.php">Servicios</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">PROGRAMA UNIVERSIDADES</a>
					<ul class="list-unstyled submenu">
						<li><a href="sector-publico/programa-universidades/relacion-institucional.php">Relación Institucional</a></li>
						<li><a href="sector-publico/programa-universidades/docentes-yno-docentes.php">Docentes y No Docentes</a></li>
						<li><a href="sector-publico/programa-universidades/alumnos.php">Alumnos</a></li>
						<li><a href="sector-publico/programa-universidades/graduados.php">Graduados</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">BENEFICIOS RÍO NEGRO</a>
					<ul class="list-unstyled submenu">
						<li><a href="sector-publico/rio-negro/presencia.php">Presencia en Río Negro</a></li>
                        <li><a href="sector-publico/rio-negro/propuesta-valor.php">Propuesta de valor exclusiva</a></li>
					</ul>
				</li>
			</ul>
		</li>
        <!-- FIN SECTOR PUBLICO -->
        
        <!-- INSTITUCIONAL -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">INSTITUCIONAL <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="institucional/index.php" class="">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">BANCO PATAGONIA</a>
					<ul class="list-unstyled submenu">
						<li><a href="institucional/banco-patagonia/historia.php">Historia</a></li>
						<li><a href="institucional/banco-patagonia/mercado-de-capitales.php">Mercado de Capitales</a></li>
						<li><a href="institucional/banco-patagonia/patagonia-inversora.php">Patagonia Inversora</a></li>
						<li><a href="institucional/banco-patagonia/patagonia-valores-sa.php">Patagonia Valores S.A</a></li>
						<li><a href="https://bp.bancopatagonia.com.ar/relacion-con-inversores/es/institucional" target="_blank">Relación con Inversores</a></li>
						<li><a href="institucional/banco-patagonia/desarrollo-humano.php">Desarrollo Humano</a></li>
						<li><a href="institucional/banco-patagonia/sustentabilidad.php">Sustentabilidad</a></li>
						<li><a href="institucional/banco-patagonia/politicas-aml-cft.php">Póliticas AML/CFT</a></li>
						<li><a href="institucional/banco-patagonia/disciplina-del-mercado.php">Disciplina de Mercado</a></li>
                        <li><a href="institucional/banco-patagonia/asistencia-a-vinculados.php">Asistencia a vinculados</a></li>
                        <li><a href="institucional/banco-patagonia/etica-e-integridad.php">Ética e Integridad</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">ORGANIZACIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="institucional/organizacion/accionistas.php">Accionistas</a></li>
						<li><a href="institucional/organizacion/autoridades.php">Autoridades</a></li>
                        <li><a href="institucional/organizacion/comites.php">Comités</a></li>
						<li><a href="institucional/organizacion/sector-financiero.php">Sector Financiero</a></li>
					</ul>
				</li>
			</ul>
		</li>
        <!-- FIN INSTITUCIONAL -->
        
        		<li class="nav-main-item"><a href="preguntas-frecuentes/index.php" class="" style="text-transform: none;">Ayuda</a></li>
		<!--<li class="nav-main-item"><a href="<php echo $folder_canales ?>index.php" class="<php echo $canales ?>" style="text-transform: none;">Canales de Atención</a></li>-->
		<!--<li class="nav-main-item"><a href="http://sucursalesycajeros.bancopatagonia.com.ar/sucursales.html" target="_blank" style="text-transform: none;">Sucursales y Cajeros</a></li>-->
		<!--<li class="nav-main-item"><a href="<php echo $folder_contactenos ?>index.php" class="<php echo $contactenos ?>" style="text-transform: none;">Contactanos</a></li>-->
        <!--<li class="nav-main-item"><a href="<php echo $path ?>ayuda/index.php" class="<php echo $ayuda ?>" style="text-transform: none;">Ayuda</a></li>-->
	</ul>
</div>	<section class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
				<ol class="breadcrumb">
					<li class="active">Cláusulas Legales</li>
				</ol>
			</div>
		</div>
	</section>
	<section class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
			  <div class="text-data">
					<h1>Cláusulas Legales</h1>
					<h3>BANCO  PATAGONIA S.A. : POLÍTICA DE PRIVACIDAD DE DATOS</h3>
                    <p><strong>(i).- Responsable de la privacidad de los datos</strong></p>
                    <p>Banco Patagonia S.A., CUIT:  30-50000661- 3, con domicilio legal sito en Av. de Mayo 701 Piso 24 (C1084AAC),  Ciudad Autónoma de Buenos Aires (En adelante, el &ldquo;Banco&rdquo;).</p>
                    <p><strong>(ii).- Jurisdicción y Legislación aplicable</strong></p>
                    <p>Argentina - Leyes N° 19.550, 25.326, y  sus normas modificatorias y complementarias.</p>
                    <p><strong>(iii).- Alcance de la presente política</strong></p>
                    <p>Todos los sitios  webs y aplicativos del Banco recolectan &ldquo;cookies&rdquo; (*) e información para su correcto  funcionamiento. Asimismo, los sitios webs y aplicativos del Banco pueden  redireccionar a otros sitios externos cuya política de privacidad y medidas de  seguridad no están bajo la directiva y responsabilidad de Banco Patagonia S.A.,  dado que nuestra entidad no posee acceso ni control sobre la información recogida  por las  cookies presentes en dichos  sitios.</p>
                    <p><strong>(iv).- Fuentes de datos</strong></p>
                    <p>El Banco recolecta información  personal de los usuarios de sus sitios webs y aplicativos para ofrecerles los  productos y servicios que comercializa, a fin de mejorar su experiencia con  nuestra entidad. El orígen de dicha información surge de los datos ingresados  para la validación de identidad en sus sitios webs y aplicativos, como así  también al momento de la contratación de un producto/servicio comercializado  por el Banco.</p>
                    <p>Los datos indispensables – entre otros- para la  contratación de un producto y/o servicio del Banco son: Prenombre y apellido,  domicilio, mail, nacionalidad, edad, sexo, DNI y los datos biométricos  identificatorios.</p>
                    <p><strong>(v).- Uso de la información</strong></p>
                    <p>La recolección y el tratamiento de tu información  personal nos permite prestarte adecuadamente nuestros servicios para que puedas  realizar tus operaciones de forma rápida y segura, como así también ofrecerte  soluciones que se adaptan mejor a tus necesidades.</p>
                    <p>El almacenamiento de la información se efectúa en un  entorno adecuado de acuerdo a la normativa vigente y tiene como propósito mejorar  nuestros servicios y productos, desarrollar nuevos, ofrecerte una mejor  experiencia, cumplir con obligaciones legales y requerimientos de autoridades  competentes, prevenir fraudes y delitos para proteger la seguridad de nuestros  usuarios, comunicarte anuncios y promociones, entre otros.</p>
                    <p>Sólo almacenaremos tu información personal durante  el tiempo necesario para cumplir con el propósito para el cual se ha recolectado  y para cumplir con requisitos reglamentarios y/o legales. Cumplido dicho plazo,  los datos serán eliminados o anonimizados, según corresponda, de acuerdo a lo  dispuesto por la normativa vigente.</p>
                    <p><strong>(vi).- Datos que compartimos con terceros</strong></p>
                    <p>Conforme lo dispuesto por la normativa  vigente, el Banco tiene la posibilidad de intercambiar información con diversas  empresas de riesgo crediticio. </p>
                    <p>En tal sentido, durante el proceso de  contratación de un proveedor que brinda servicios de apoyo - cualquiera sea su  naturaleza-, se verifica con anterioridad que el mismo de cumplimiento con la  política de privacidad y seguridad surgida del presente texto, las normas  internas del Banco y la normativa nacional vigente.</p>
                    <p>¿Quiénes pueden acceder a la  información del Banco?</p>
                    <ul>
                      <li>Usted, y en caso de corresponder, su familia,  sus socios y/o sus representantes.</li>
                      <li>Autoridades gubernamentales judiciales y/o  administrativas (Por ejemplo: Fiscales y reguladoras, entre otras), o  autoridades similares, previa notificación formal al Banco en la cual conste su  finalidad.</li>
                      <li>Terceros encargados del tratamiento (Ejemplo: Proveedores  de servicios de pago) ubicados en cualquier parte del mundo, con sujeción a los  requisitos dispuestos por la normativa vigente. </li>
                    </ul>
                    <p>Todo comprador(es) tercero(s) relevante(s),  en caso de que vendamos o transfiramos la totalidad o cualquier parte relevante  de nuestro negocio o activos (incluyendo en caso de una reorganización,  disolución o liquidación) o de los activos o negocios de nuestros fondos;</p>
                    </p>
                    <p><strong>(vii).- Transferencia internacional de datos</strong></p>
                    <p>Las  ofertas de productos y servicios del Banco se basan en plataformas tecnológicas  que requieren de infraestructura subyacente tales como bases de datos,  servidores, y/o componentes de red, que pueden estar ubicados en la red local  física y/o virtual de Banco Patagonia o en servicios alojados en la nube - tanto  propia como provista por terceros-. </p>
                    <p>En caso de  que los proveedores estuvieran alojados en el extranjero, se priorizarán  aquellos cuyos países dispongan de condiciones vigentes para dar cumplimiento con  lo dispuesto por nuestra normativa local. En caso de que esto último no fuera  posible, se labrará entre las partes un acuerdo de transferencia internacional  de datos para permitir que aquellos proveedores de servicios tercerizados cuya  legislación local no coincida con la de Argentina, asuman el compromiso  efectivo de cumplir con nuestra normativa vigente.</p>
                    <p><strong>(viii).- </strong>En  cumplimiento con lo dispuesto por la Ley de Protección de Datos Personales (Ley  N° 25.326), los usuarios podrán ratificar, rectificar o suprimir la información  que ingresen/declaren al Banco, en cualquiera de nuestras sucursales o comunicándose  al 0810 888 8500 de lunes a viernes de 9 a 19 hs.</p>
                    <p>El titular de los datos personales tiene  la facultad de ejercer el derecho de acceso a los mismos en forma gratuita en intervalos  no inferiores a seis meses, salvo que se acredite un interés legítimo al  efecto, conforme lo establecido en el artículo 14, inciso 3 de la Ley 25.326.  La DIRECCIÓN NACIONAL DE PROTECCIÓN DE DATOS PERSONALES, Órgano de Control de  la Ley 25.326, tiene la atribución de atender las denuncias y reclamos que se  interpongan con relación al incumplimiento de las normas sobre protección de  datos personales.</p>
                    <p>Banco Patagonia S.A. asume el carácter de  Responsable Registrado ya que ha cumplimentado con todos los requisitos que  exige esta ley. </p>
                    <p><strong>(ix).- </strong>Los  accionistas de Banco Patagonia S.A. (CUIT: 30-50000661- 3, Av. de Mayo 701 Piso  24 (C1084AAC), Ciudad Autónoma de Buenos Aires) limitan su responsabilidad a la  integración de las acciones suscriptas. En virtud de ello, ni los accionistas  mayoritarios de capital extranjero ni los accionistas locales o extranjeros,  responden en exceso de la citada integración accionaria por las obligaciones  emergentes de las operaciones concertadas por la entidad financiera. Ley 25.738.</p>
                    <!-- -->
                    <hr>
                    <!-- -->
                    <h3>BANCO PATAGONIA S.A.: TÉRMINOS Y CONDICIONES</h3>
                    <p>Términos y condiciones Generales del sitio <a href="personas/index.php">www.bancopatagonia.com.ar</a></p>
                    <br>
                    <p><strong>Uso de www.bancopatagonia.com.ar</strong></p>
                    <p>Estimado usuario, antes de comenzar a usar el sitio de Banco Patagonia  S.A., sírvase leer atentamente los términos y condiciones expresados  seguidamente. El ingreso al sitio implica la aceptación de los mismos.</p>
                    <p>Banco Patagonia S.A. se reserva el derecho de modificar total o parcialmente  éstos términos y condiciones, sin previo aviso y en cualquier momento. Dichas  modificaciones regirán desde el momento de su publicación en este medio.</p>
                    <p>Banco Patagonia S.A. se reserva todos los derechos sobre sus marcas registradas  e identificatorias de los servicios ofrecidos por el mismo, como así también  los derechos de propiedad intelectual sobre el diseño y los contenidos del  sitio.</p>
                    <br>
                    <p><strong>Informaciones y servicios</strong></p>
                    <p>La información, bienes, productos y/o servicios que se describen en el  sitio www.bancopatagonia.com.ar están sujetos a cambios, no encontrándose  disponibles en todas las áreas geográficas del país y/o del exterior.</p>
                    <p>Será facultativo para Banco Patagonia S.A., el otorgamiento de cada uno de los  productos y/o servicios que pudieran ofrecerse en este sitio, encontrándose  sujeta su aprobación al cumplimiento de las condiciones que la entidad  establezca al efecto en cada caso. La elegibilidad para ciertos productos y  servicios está sujeta a la determinación y aceptación final de Banco Patagonia  S.A.</p>
                    <p>La información y demás contenidos exhibidos en el sitio son para uso exclusivo  del usuario, y no pueden ser reproducidos o transmitidos gratuita u  onerosamente a terceros por ningún medio. Tal información y contenidos no  suponen un asesoramiento, calificación o sugerencia de compra o de venta de  ningún producto o servicio. Se recomienda al usuario que, en el caso que así lo  considere conveniente, consulte con el experto y/o profesional que  correspondiere para el manejo de esta información.</p>
                    <br>
                    <p><strong>Vínculos a sitios de Terceros</strong></p>
                    <p>Banco Patagonia S.A. ofrece al usuario una lista de vínculos a  sitios de terceros, cuya propiedad y administración corresponde a dichos  terceros. La función de los vínculos a sitios de terceros que aparecen en el  sitio www.bancopatagonia.com.ar es exclusivamente la de informar al usuario  sobre la existencia de otras fuentes de información sobre la materia en  Internet, donde podrá ampliar los datos ofrecidos en este sitio. Dichos  vínculos a sitios de terceros no suponen una sugerencia, invitación o  recomendación para la visita de los lugares de destino, y por ello, el Banco  Patagonia S.A. no será responsable del resultado obtenido a través de dichos  enlaces.</p>
                    <p>Banco Patagonia S.A. no verifica ni controla de modo alguno el funcionamiento y  contenidos de los sitios de terceros, por lo tanto no garantiza ni el correcto  funcionamiento de los mismos, ni tampoco la veracidad ni la exactitud de sus  contenidos (información, gráficos, productos y servicios ofrecidos, etc.).</p>
                    <br>
                    <p><strong>Responsabilidades</strong></p>
                    <p>Banco Patagonia S.A. no se responsabiliza por el uso que se haga  del sitio www.bancopatagonia.com.ar</p>
                    <p>La integridad, veracidad y exactitud de la información vertida en el sitio no  está garantizada, por lo tanto Banco Patagonia S.A. no se responsabiliza por la  existencia de posibles errores u omisiones en la misma.</p>
                    <p>Banco Patagonia S.A. no se responsabiliza por daños en el equipo del usuario  causado por fallas en el sistema, en el servidor o en internet como así tampoco  por virus de computadora.</p>
                    <p>Banco Patagonia S.A. no se responsabiliza por la interrupción temporal o  permanente o por la finalización de los servicios ofrecidos por el sitio.</p>
                    <p>El usuario asume plena responsabilidad frente al Banco Patagonia S.A. y/o  frente a terceros, por los daños y perjuicios que se produjeran como  consecuencia del accionar propio, de sus dependientes o de terceros conectados  a través del usuario y los que resulten de la inobservancia de las leyes o  reglamentaciones o de hechos ilícitos, o del mal uso que se haga del servicio,  debiendo el usuario indemnizar y mantener indemne al Banco Patagonia S.A. ante  cualquier reclamo que se pudiera interponer.</p>
                    <!-- -->
                    <hr>
                    <!-- -->
                    <h3>TÉRMINOS Y CONDICIONES GENERALES DE PATAGONIA MÓVIL</h3>
                    <p><strong>Uso de Patagonia Móvil</strong></p>
                    <p>Al utilizar  &ldquo;Patagonia Móvil&rdquo;, el Cliente autoriza a Banco Patagonia S.A a: (i) Transmitir  información sobre sus cuentas, tarjetas u otros productos y/o servicios  contratados con el Banco Patagonia S.A, a través de Internet o de una red privada  de datos autorizada por el Banco, a fin de realizar las transacciones  solicitadas sobre sus cuentas, tarjetas, operaciones y otros servicios que el  Banco implemente a través de &quot;pagomiscuentas.com&quot;, bajo las  condiciones que el Cliente declara conocer y aceptar; (ii) Utilizar los datos  de IMEI (Identidad internacional de equipo móvil) del dispositivo móvil del  Cliente, a fin de brindar mayor seguridad a sus transacciones, (iii) &ldquo;Patagonia  Móvil&rdquo; requiere también su consentimiento para el uso del número telefónico del  dispositivo a fin de brindar mayor seguridad en sus transacciones, (iv)  &ldquo;Patagonia Móvil&rdquo; requiere su consentimiento de acceso a su ubicación, cuando  la aplicación está en uso, al momento de realizar transacciones detectando  actividad poco frecuente.</p>
                    <p>Los datos de  uso se recopilan automáticamente cuando se utiliza Patagonia Móvil. Los datos  de uso pueden incluir información como la dirección de Protocolo de Internet de  su dispositivo (por ejemplo, la dirección IP), el tipo de navegador, la versión  del navegador, las páginas de nuestro Servicio que visita, la hora y fecha de  su visita, el tiempo que pasó en esas páginas, dispositivo único  identificadores y otros datos de diagnóstico.</p>
                    <p>Cuando accede Patagonia Móvil a través de un  dispositivo móvil, podemos recopilar cierta información automáticamente, que  incluye, entre otros, el tipo de dispositivo móvil que utiliza, la  identificación única de su dispositivo móvil, la dirección IP de su dispositivo  móvil, su dispositivo móvil sistema operativo, el tipo de navegador de Internet  móvil que utiliza, identificadores de dispositivo únicos y otros datos de  diagnóstico.</p>
                    <p>También podemos recopilar información que su  navegador envía cada vez que visita Patagonia Móvil o cuando accede a Patagonia  Móvil a través de un dispositivo móvil.</p>
                    <br>
                    <p><strong>Informaciones y servicios</strong></p>
                    <p>Mientras usamos nuestra aplicación, con el fin de proporcionar  características de nuestra aplicación, podemos recopilar, con su permiso  previo:</p>
                    <ul>
                      <li>Información sobre su ubicación</li>
                      <li>Información de la agenda telefónica de su dispositivo (lista de contactos)</li>
                      <li>Imágenes y otra información de la biblioteca de fotos y la cámara de su dispositivo</li>
                    </ul>
                    <p>Usamos esta información para proporcionar características de Patagonia  Móvil, para mejorar y personalizar Patagonia Móvil. La información se puede  cargar en los servidores de la Compañía y / o en el servidor de un Proveedor de  servicios o simplemente se puede almacenar en Su dispositivo. Puede habilitar o deshabilitar el acceso a esta información en cualquier  momento, a través de la configuración de su dispositivo.</p>
                    <p>Banco Patagonia S.A. puede utilizar los Datos Personales para los  siguientes propósitos:</p>
                    <ul>
                      <li>Para administrar Su Cuenta: para administrar Su registro como usuario de Patagonia Móvil. Los Datos Personales que proporcione pueden darle acceso a diferentes funcionalidades que están disponibles para Usted como usuario registrado.</li>
                      <li>Para contactarlo: Para contactarlo por correo electrónico, llamadas telefónicas, SMS u otras formas equivalentes de comunicación electrónica, como las notificaciones push de una aplicación móvil sobre actualizaciones o comunicaciones informativas relacionadas con las funcionalidades, productos o servicios contratados, incluidas las actualizaciones de seguridad, cuando sea necesario o razonable para su implementación.</li>
                      <li>Para proporcionarle noticias, ofertas especiales e información general sobre otros bienes, servicios y eventos que ofrecemos y que son similares a los que ya ha comprado o sobre los que ha consultado, a menos que haya optado por no recibir dicha información.</li>
                      <li>Para otros fines: podemos utilizar su información para otros fines, como análisis de datos, identificación de tendencias de uso, determinación de la eficacia de nuestras campañas promocionales y para evaluar productos, servicios, marketing y su experiencia.</li>
                    </ul>
                    <br>
                    <p><strong>Vínculos a sitios de Terceros</strong></p>
                    <p>Podemos compartir su información personal en las siguientes  situaciones:</p>
                    <ul>
                      <li>Con proveedores de servicios: podemos compartir su información personal con proveedores de servicios para monitorear y analizar el uso de Patagonia       Móvil.</li>
                      <li>Para transferencias comerciales: podemos compartir o transferir Su información personal en relación con, o durante las negociaciones de, cualquier       fusión, venta de activos de la Compañía, financiamiento o adquisición de la totalidad o una parte de Nuestro negocio a otra compañía.</li>
                      <li>Con afiliados: podemos compartir su información con nuestros afiliados, en cuyo caso les exigiremos que cumplan con esta Política de privacidad. Los       afiliados incluyen nuestra empresa matriz y cualquier otra subsidiaria, socios de empresas conjuntas u otras empresas que controlemos o que estén       bajo control común con nosotros.</li>
                      <li>Con socios comerciales: podemos compartir su información con nuestros socios comerciales para ofrecerle ciertos productos, servicios o promociones.</li>
                      <li>Con otros usuarios: cuando comparte información personal o interactúa de otro modo en las áreas públicas con otros usuarios, dicha información puede ser vista por todos los usuarios y puede distribuirse públicamente en el exterior. Si interactúa con otros usuarios o se registra a través de un servicio de redes sociales de terceros, sus contactos en el servicio de redes sociales de terceros pueden ver su nombre, perfil, imágenes y descripción de su actividad. Del mismo modo, otros usuarios podrán ver descripciones de su actividad, comunicarse con usted y ver su perfil.</li>
                      <li>Con su consentimiento: podemos divulgar su información personal para cualquier otro propósito con su consentimiento.</li>
                    </ul>
                </div>
			</div>
		</div>
	</section>
	<div class="container-fluid footer-bar">
	<div class="row">
		<footer class="container">
			<div class="row">
				<div class="col-md-12">
					<p class="flnks"><a href="registro-nacional-base-datos.php">Registro Nacional de Base de Datos</a> <span>|</span>   <a href="codigo-practicas-bancarias.php">Código de Prácticas Bancarias</a> <span>|</span>   <a href="defensa-ley-consumidor.php">Defensa del Consumidor</a>
						<span>|</span>   <a href="https://www.argentina.gob.ar/produccion/defensadelconsumidor/formulario">Defensa de las y los consumidores. Para reclamos ingrese aquí</a><span>|</span> <br class="tbl"> <a href="persona-expuesta-politicamente.php">Persona Expuesta Políticamente</a> <span class="tbl">|</span> <br class="dsk">
						
					<a href="agencia-acceso-informacion-publica.php">Agencia de Acceso a la Información Pública</a> <span>|</span> <br class="tbl"> 
					<a href="cnv-advertencia-publico-inversor.php">CNV - Advertencia al Público Inversor</a> <span>|</span> <a href="docs/Idoneos.pdf" target="_blank"> Idóneos en Mercado de Capitales - CNV</a><span>|</span>   <a href="codigo-proteccion-inversor.php">Código de Protección al Inversor</a> <span>|</span>   <a href="clausulas-legales.php">Cláusulas Legales</a> <span>|</span> <a href="resolucion-022021.php">Resol. 02/21 Dir.Gral. Defensa del consumidor Córdoba</a></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<p class="redes">
                        <span>Seguinos en:</span>
                        <!-- -->
                        <a href="https://www.facebook.com/BancoPatagonia/" target="_blank"><img src="assets/images/layout/icon-facebook.svg" alt="Facebook"></a>
                        <a href="https://twitter.com/banco_patagonia" target="_blank"><img src="assets/images/layout/icon-twitter.svg" alt="Twitter"></a>
                        <a href="https://www.instagram.com/banco_patagonia/" target="_blank"><img src="assets/images/layout/icon-instagram.svg" alt="Instagram"></a>
                        <a href="https://www.youtube.com/user/bancopatagonia" target="_blank"><img src="assets/images/layout/icon-youtube.svg" alt="Youtube"></a>
                        <!-- -->
                        <!--
                        <a href="https://www.facebook.com/BancoPatagonia/" target="_blank"><i class="fa fa-facebook-square"></i></a>
                        <a href="https://twitter.com/banco_patagonia" target="_blank"><i class="fa fa-twitter"></i></a>
                        <a href="https://www.instagram.com/banco_patagonia/" target="_blank"><i class="fa fa-instagram"></i></a>
                        <a href="https://www.youtube.com/user/bancopatagonia" target="_blank"><i class="fa fa-youtube-play"></i></a>
                        -->
                    </p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					                    <!---->
				    <p class="flegal">BANCO PATAGONIA S.A. ES UNA SOCIEDAD ANÓNIMA CONSTITUIDA BAJO LAS LEYES DE LA REPÚBLICA ARGENTINA CUYOS ACCIONISTAS LIMITAN SU RESPONSABILIDAD A LA INTEGRACIÓN DE LAS ACCIONES SUSCRITAS DE ACUERDO A LA LEY 19.550. POR CONSIGUIENTE, Y EN CUMPLIMIENTO DE LA LEY 25.738, SE INFORMA QUE NI LOS ACCIONISTAS MAYORITARIOS DE CAPITAL EXTRANJERO NI LOS ACCIONISTAS LOCALES O EXTRANJEROS RESPONDEN, EN EXCESO DE LA CITADA INTEGRACIÓN ACCIONARIA, POR LAS OBLIGACIONES EMERGENTES DE LAS OPERACIONES CONCERTADAS POR LA ENTIDAD FINANCIERA.</p>
                    <p class="flegal" style="font-size:10px;">Banco Patagonia S.A. - Agente de Liquidacion y Compensacion y Agente de Negociacion Integral, inscripto en CNV bajo el N° 66</p>
					<p class="flegal">© 2025 Banco Patagonia . Todos los derechos reservados. Prohibida la duplicación , distribución o almacenamiento en cualquier medio.</p>
				</div>
			</div>
		</footer>
	</div>
</div>
<div class="tbl mbl placeholder-shortlinks">
	<div class="container shortlinks">
		<div class="row">
            <!--<php if ($home_personas == false) { ?>
                <div class="col-sm-3 col-xs-3">
                    <a href="#"><span class="icon icon-contacto"></span></a>
                </div>
            <php } ?>-->
            			<div class="col-sm-3 col-xs-3">
				<a href="http://sucursalesycajeros.bancopatagonia.com.ar/sucursales.html" target="_blank"><span class="icon icon-sucursales"></span>Sucursales y Cajeros</a>
			</div>
			<div class="col-sm-3 col-xs-3">
				<a href="preguntas-frecuentes/index.php"><span class="icon icon-contacto"></span>Ayuda</a>
			</div>
			<div class="col-sm-3 col-xs-3 last">
				<a href="empresas/patagonia-ebank-empresas-mbl.php"><span class="icon icon-ebank"></span>Patagonia e-Bank</a>
			</div>
		</div>
	</div>
</div>	<script src="assets/js/jquery-3.5.1.min.js"></script>
<script src="assets/bootstrap/js/bootstrap.min.js"></script>
<script src="assets/js/slick/slick.min.js"></script>
<script src="assets/js/fancybox/jquery.fancybox.min.js"></script>
<script src="assets/js/mtabs/jquery.bootstrap-responsive-tabs.min.js"></script>
<script src="assets/js/funciones.js"></script>

<!-- Global site tag (gtag.js) - Google Analytics (original) -->
<!--
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-32588129-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-32588129-1');
</script>
-->

<!-- Google Analytics (version anterior / eventos ok)  -->
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');
  ga('create', 'UA-32588129-1', 'auto');
  ga('send', 'pageview');
</script>

<!-- GA4 - Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-C6LG1PT98X"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-C6LG1PT98X');
</script>
</body>
</html>