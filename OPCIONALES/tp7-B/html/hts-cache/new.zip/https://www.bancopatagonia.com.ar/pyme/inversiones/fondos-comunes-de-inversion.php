<!DOCTYPE html>
<html lang="es">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
		<meta http-equiv="Pragma" content="no-cache">
		<meta http-equiv="Expires" content="0">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Fondos Comunes de Inversión | Inversiones | Banco Patagonia</title>
		<meta name="description" content="Impulsá tus proyectos.">
		<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-NL73B44');</script>
<!-- End Google Tag Manager -->

<link rel="shortcut icon" href="../../favicon.ico" type="image/x-icon"/>
<link href="../../assets/fonts/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="../../assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="../../assets/js/mtabs/bootstrap-responsive-tabs.css" rel="stylesheet" type="text/css">
<link href="../../assets/js/slick/slick.css" rel="stylesheet" type="text/css">
<link href="../../assets/js/fancybox/jquery.fancybox.min.css" rel="stylesheet" type="text/css">
<link href="../../assets/css/styles.css" rel="stylesheet" type="text/css">
<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->		
		<!-- IMPORTANTE: Indicar en el siguiente tag la pagina de origen para evitar el contenido duplicado -->
		<link rel="canonical" href="https://www.bancopatagonia.com.ar/empresas/inversiones/fondos-comunes-de-inversion.php">
		
        <!-- SLIDES RESPONSIVE -->
        <style>
            /* DSK */
            #head-fondos-comunes-de-inversion {background-image: url(../../personas/inversiones/images/head-fondos-comunes-de-inversion-dsk.jpg)}

            @media screen and (max-width: 1200px) {
                /* TBT */
                #head-fondos-comunes-de-inversion {background-image: url(../../personas/inversiones/images/head-fondos-comunes-de-inversion-tbl.jpg); background-size: auto !important ;}
            }
            @media screen and (max-width: 560px) {
                /* MBL */
                #head-fondos-comunes-de-inversion {background-image: url(../../personas/inversiones/images/head-fondos-comunes-de-inversion-mbl.jpg)}
            }
        </style>
        <!-- -->
		
	</head>
<body>
	<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NL73B44"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

<div class="placeholder-bar">
	<div class="container-fluid header-bar">
		<div class="row">
			<header class="container">
				<div class="row">
					<div class="col-md-3 col-dsk-6 col-sm-6">
						<span class="c-hamburger c-hamburger--htx">
							<span>toggle menu</span>
						</span>
                        <!-- -->
                        <!--<img style="position: absolute; width: 42px; top: 20px; right: 40px;" class="dsk" src="<php echo $path ?>assets/images/layout/icon-verano-2022.svg">-->
                        <!-- -->
						<h1>
                            <!--<img style="position: absolute; width: 32px; top: 12px; left: 102px;" class="dsk" src="<php echo $path ?>assets/images/layout/icon-navidad-2021.svg">-->
                            <a href="../../index.php" class="main-logo">Banco Patagonia</a>
                        </h1>
					</div>
					<div class="col-md-9 col-dsk-6 col-sm-6">
						<div class="general-links">
							<ul class="list-unstyled">
                                								<li><a href="../../preguntas-frecuentes/index.php" class="">Ayuda</a></li>
								<!--<li><a href="<php echo $folder_canales ?>index.php" class="<php echo $canales ?>">Canales de atención</a></li>-->
								<!--<li><a href="http://sucursalesycajeros.bancopatagonia.com.ar/sucursales.html" target="_blank">Sucursales y cajeros</a></li>-->
								<!--<li><a href="<php echo $folder_contactenos ?>index.php" class="<php echo $contactenos ?>">Contactanos</a></li>-->
                                <!--<li><a href="<php echo $path ?>ayuda/index.php" class="<php echo $ayuda ?>">Ayuda</a></li>-->
							</ul>
						</div>
						<div class="top-links">
							<ul class="list-unstyled">
								<li><a href="../../personas/index.php" class="">PERSONAS</a></li>
								<li><a href="../../nyps/index.php" class="">PROFESIONALES Y COMERCIOS</a></li>
								<li><a href="../index.php" class="active">PYME</a></li>
								<li><a href="../../agro/index.php" class="">AGRO</a></li>
								<li><a href="../../empresas/index.php" class="">EMPRESAS</a></li>
								<li><a href="../../sector-publico/index.php" class="">SECTOR PÚBLICO</a></li>
								<li><a href="../../institucional/index.php" class="">INSTITUCIONAL</a></li>
							</ul>
							<div class="ebank">
                            <!-- antes href: <php echo $folder_empresas ?><php echo $url_ebank ?>-->
															<a href="https://ebankempresas.bancopatagonia.com.ar/desktop-webserver/sso" target="_blank" class="patagonia-ebank-empresas">Patagonia e-Bank Empresas</a>
														</div>
						</div>
					</div>
				</div>
			</header>
		</div>
	</div>
</div>

<div class="container-fluid nav-bar">
	<div class="row">
		<nav class="container">
			<div class="row">
				<!--<div class="col-md-9 col-md-offset-3">-->
                <div class="col-md-10 col-md-offset-3"><!-- ajuste agro -->
					<ul class="list-unstyled sub-navbar">
						
						                        
                                                
                        						<!-- PYME -->
						<li class="nav-item"><a href="#" class="nav-lnk ">CUENTAS</a>
							<ul class="list-unstyled submenu">
                                <li><a href="../cuentas/pequenas-empresas.php">Pyme Pequeñas Empresas</a></li>
								<li><a href="../cuentas/medianas-empresas.php">Pyme Medianas Empresas</a></li>
                                <!--
								<li><a href="../cuentas/patagonia-empresario.php">Patagonia Empresario</a></li>
								<li><a href="../cuentas/patagonia-empresario-premier.php">Patagonia Empresario Premier</a></li>
								<li><a href="../cuentas/patagonia-empresa.php">Patagonia Empresa</a></li>
                                -->
                                <!--<li><a href="../cuentas/patagonia-comercio.php">Patagonia Comercio</a></li>-->
                                <li><a href="../cuentas/patagonia-consorcio.php">Patagonia Consorcio</a></li>
								<li><a href="../cuentas/cuenta-corriente.php">Cuenta Corriente</a></li>
							</ul>
						</li>
						<li class="nav-item"><a href="#" class="nav-lnk ">PATAGONIA SUELDO</a>
							<ul class="list-unstyled submenu">
								<li><a href="../patagonia-sueldo/servicios.php">Servicios</a></li>
								<li><a href="../patagonia-sueldo/preguntas-frecuentes.php">Preguntas Frecuentes</a></li>
								<li><a href="../patagonia-sueldo/guia-implementacion.php">Guía de Implementación</a></li>
							</ul>
						</li>						
						<li class="nav-item"><a href="#" class="nav-lnk ">COMERCIO EXTERIOR</a>
							<ul class="list-unstyled submenu">
								<li><a href="../comercio-exterior/solicitud-electronica.php">Solicitud Electrónica</a></li>
								<li><a href="../comercio-exterior/productos.php">Productos</a></li>
								<li><a href="../comercio-exterior/otros-servicios.php">Servicios</a></li>
								<!--<li><a href="<php echo $folder_pymeCexterior ?>financiaciones.php">Financiaciones</a></li>-->
                                <li><a href="../comercio-exterior/herramientas-para-exportar.php">Herramientas para Exportar</a></li>
								<li><a href="../comercio-exterior/marco-regulatorio/normas-y-regulaciones.php">Marco Regulatorio</a></li>
							</ul>
						</li>						
						<li class="nav-item"><a href="#" class="nav-lnk ">FINANCIACIÓN</a>
							<ul class="list-unstyled submenu">
								<li><a href="../financiacion/patagonia-leasing.php">Patagonia Leasing</a></li>
								<li><a href="../financiacion/mercado-capitales.php">Mercado de Capitales</a></li>
								<li><a href="../financiacion/alternativas-de-financiacion.php">Alternativas de Financiación</a></li>
							</ul>
						</li>
                        <li class="nav-item"><a href="#" class="nav-lnk ">SEGUROS</a>
							<ul class="list-unstyled submenu">
								<li><a href="../../pyme/seguros/protege-tus-bienes/integral-comercio.php">Protegé tus Bienes</a></li>
							</ul>
						</li>
						<li class="nav-item"><a href="#" class="nav-lnk active">INVERSIONES</a>
							<ul class="list-unstyled submenu">
								<li><a href="plazo-fijo.php">Plazo Fijo</a></li>
								<li><a href="fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
								<li><a href="fidecomisos-financieros.php">Fidecomisos Financieros</a></li>
							</ul>
						</li>						
						<li class="nav-item"><a href="#" class="nav-lnk ">SERVICIOS</a>
							<ul class="list-unstyled submenu">
								<li><a href="../servicios/recaudaciones.php">Recaudaciones</a></li>
								<li><a href="../servicios/pagos.php">Pagos</a></li>
								<li><a href="../servicios/tarjetas-comerciales.php">Tarjetas Comerciales</a></li>
								<li><a href="../servicios/comercios-patagonia.php">Comercios Patagonia</a></li>
                                <li><a href="../servicios/pago-de-servicios.php">Pago de Servicios</a></li>
								<li><a href="../servicios/interbanking.php">Interbanking</a></li>
								<li><a href="../servicios/interfacturas.php">Interfacturas</a></li>
								<li><a href="../servicios/pagos-afip.php">Pagos AFIP</a></li>
								<li><a href="../servicios/wapa.php">WAPA</a></li>
							</ul>
						</li>
						<!-- FIN PYME -->
						                        
                        						
												
												
						
											</ul>
				</div>
			</div>
		</nav>
	</div>
</div>

<div class="mobile-nav-bar">
	<ul class="list-unstyled">
        
        <!-- PERSONAS -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">PERSONAS <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../personas/index.php" class="">HOME</a></li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA CLÁSICA</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../personas/patagonia-clasica/patagonia-ahorro/productos.php">Patagonia Ahorro</a></li>
                        <li><a href="../../personas/patagonia-clasica/paquete/productos.php">Patagonia Clásica</a></li>
                        <!--<li><a href="<php echo $path ?>personas/patagonia-clasica/mas/productos.php">Patagonia Clásica Más</a></li>-->
                        <li><a href="../../personas/patagonia-clasica/premium/productos.php">Patagonia Clásica Premium</a></li>
                        <li><a href="../../personas/patagonia-clasica/patagonia-sueldo/productos.php">Patagonia Sueldo</a></li>
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA PLUS</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../personas/patagonia-plus/productos.php">Patagonia Plus</a></li>
                        <li><a href="../../personas/patagonia-plus/premium/productos.php">Patagonia Plus Premium</a></li>
                    </ul>						
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA SINGULAR</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../personas/patagonia-singular/paquete/propuesta.php">Patagonia Singular</a></li>
                        <li><a href="../../personas/patagonia-singular/beneficios-exclusivos.php">Beneficios Exclusivos</a></li>
                        <!--<li><a href="<php echo $path ?>personas/patagonia-singular/atencion-exclusiva/index.php">Atención Exclusiva</a></li>-->
                        <!--<li><a href="<php echo $path ?>personas/patagonia-singular/eventos-y-novedades/index.php">Eventos y Novedades</a></li>-->
                    </ul>
                </li>
				<!--<li class="nav-sub-item"><a href="<php echo $path ?>patagoniaon/index.php" target="_blank">PATAGONIA ON</a></li>-->
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA ON</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../patagoniaon/index.php" target="_blank">Patagonia ON</a></li>
						<li><a href="../../personas/productos-y-servicios/patagonia-universitaria.php">Patagonia ON Universitaria</a></li>
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PRODUCTOS Y SERVICIOS</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../personas/apple-pay.php">Apple Pay</a></li>
                        <li><a href="../../personas/productos-y-servicios/caja-de-seguridad.php">Caja de Seguridad</a></li>
                        <li><a href="../../personas/productos-y-servicios/comercio-exterior/productos.php">Comercio exterior</a></li>
						<!--<li><a href="<php echo $path ?>personas/productos-y-servicios/beneficios-wapa.php">Comercios WAPA</a></li>-->
						<li><a href="../../personas/cuotifica-al-toque.php">Cuotificá al Toque</a></li>
						<li><a href="../../personas/google-pay.php">Google Pay</a></li>
                        <li><a href="../../personas/productos-y-servicios/inversiones.php">Inversiones</a></li>
                        <li><a href="../../personas/jubilados/index.php">Jubilados</a></li>
                        <li><a href="../../personas/productos-y-servicios/patagonia-para-menores.php">Patagonia para Menores</a></li>
                        <!--<li><a href="<php echo $path ?>personas/productos-y-servicios/patagonia-universitaria.php">Patagonia Universitaria</a></li>-->
                        <li><a href="../../personas/productos-y-servicios/prestamos.php">Prestamos</a></li>
                        <li><a href="../../personas/seguros/index.php">Seguros</a></li>
                        <li><a href="../../personas/productos-y-servicios/tarjetas-de-credito/visa.php">Tarjetas de crédito</a></li>
                        <li><a href="../../personas/productos-y-servicios/tarjetas-de-debito/patagonia-24.php">Tarjetas de débito</a></li>
                    </ul>
                </li>
			</ul>
		</li>
        <!-- FIN PERSONAS -->
        
        <!-- NYPS -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">PROFESIONALES Y COMERCIOS <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../nyps/index.php" class="">HOME</a></li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA CLÁSICA</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../nyps/patagonia-clasica/premium/productos.php">Patagonia Clásica Premium</a></li>
                        <li><a href="../../nyps/patagonia-clasica/patagonia-emprendimiento/productos.php">Patagonia Emprendimiento</a></li>
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA PLUS</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../nyps/patagonia-plus/productos.php">Patagonia Plus</a></li>
                        <li><a href="../../nyps/patagonia-plus/premium/productos.php">Patagonia Plus Premium</a></li>
                    </ul>						
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA SINGULAR</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../nyps/patagonia-singular/paquete/propuesta.php">Patagonia Singular</a></li>
                        <li><a href="../../nyps/patagonia-singular/beneficios-exclusivos.php">Beneficios Exclusivos</a></li>
                        <!--<li><a href="<php echo $path ?>nyps/patagonia-singular/eventos-y-novedades/index.php">Eventos y Novedades</a></li>-->
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PRODUCTOS Y SERVICIOS</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../nyps/productos-y-servicios/tarjetas-de-debito/patagonia-24.php">Tarjetas de débito</a></li>
                        <li><a href="../../nyps/productos-y-servicios/tarjetas-de-credito/visa.php">Tarjetas de crédito</a></li>
                        <li><a href="../../nyps/productos-y-servicios/prestamos.php">Prestamos</a></li>
                        <li><a href="../../nyps/seguros/index.php">Seguros</a></li>
                        <li><a href="../../nyps/productos-y-servicios/inversiones.php">Inversiones</a></li>
                        <li><a href="../../nyps/productos-y-servicios/comercio-exterior/productos.php">Comercio exterior</a></li>
                        <li><a href="../../nyps/productos-y-servicios/caja-de-seguridad.php">Caja de Seguridad</a></li>
                        <li><a href="../../nyps/productos-y-servicios/factura-electronica.php">Factura electrónica</a></li>
                        <li><a href="../../nyps/productos-y-servicios/pagos-afip.php">Pagos AFIP</a></li>
                        <!--<li><a href="<php echo $path ?>nyps/productos-y-servicios/soluciones-para-tu-empresa.php">Soluciones para tu empresa</a></li>-->
                        <!--<li><a href="<php echo $path ?>nyps/productos-y-servicios/comercios-patagonia.php">Comercios Patagonia</a></li>-->
						<li><a href="../../nyps/productos-y-servicios/wapa.php">WAPA</a></li>
                    </ul>
                </li>
			</ul>		
		</li>
        <!-- FIN NYPS -->
        
        <!-- PYME -->
		<li class="nav-main-item"><a href="#" class="has-sub-items active">PYME <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../index.php" class="active">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">CUENTAS</a>
					<ul class="list-unstyled submenu">
                        <li><a href="../cuentas/pequenas-empresas.php">Pyme Pequeñas Empresas</a></li>
				        <li><a href="../cuentas/medianas-empresas.php">Pyme Medianas Empresas</a></li>
                        <!--
						<li><a href="../cuentas/patagonia-empresario.php">Patagonia Empresario</a></li>
						<li><a href="../cuentas/patagonia-empresario-premier.php">Patagonia Empresario Premier</a></li>
						<li><a href="../cuentas/patagonia-empresa.php">Patagonia Empresa</a></li>
                        -->
                        <!--<li><a href="../cuentas/patagonia-comercio.php">Patagonia Comercio</a></li>-->
                        <li><a href="../cuentas/patagonia-consorcio.php">Patagonia Consorcio</a></li>
						<li><a href="../cuentas/cuenta-corriente.php">Cuenta Corriente</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA SUELDO</a>
					<ul class="list-unstyled submenu">
						<li><a href="../patagonia-sueldo/servicios.php">Servicios</a></li>
						<li><a href="../patagonia-sueldo/preguntas-frecuentes.php">Preguntas Frecuentes</a></li>
						<li><a href="../patagonia-sueldo/guia-implementacion.php">Guía de Implementación</a></li>
					</ul>
				</li>						
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">COMERCIO EXTERIOR</a>
					<ul class="list-unstyled submenu">
						<li><a href="../comercio-exterior/solicitud-electronica.php">Solicitud Electrónica</a></li>
						<li><a href="../comercio-exterior/productos.php">Productos</a></li>
						<li><a href="../comercio-exterior/otros-servicios.php">Servicios</a></li>
						<!--<li><a href="<php echo $folder_pymeCexterior ?>financiaciones.php">Financiaciones</a></li>-->
                        <li><a href="../comercio-exterior/herramientas-para-exportar.php">Herramientas para Exportar</a></li>
						<li><a href="../comercio-exterior/marco-regulatorio/normas-y-regulaciones.php">Marco Regulatorio</a></li>
					</ul>
				</li>						
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">FINANCIACIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../financiacion/patagonia-leasing.php">Patagonia Leasing</a></li>
						<li><a href="../financiacion/mercado-capitales.php">Mercado de Capitales</a></li>
						<li><a href="../financiacion/alternativas-de-financiacion.php">Alternativas de Financiación</a></li>
					</ul>
				</li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">SEGUROS</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../pyme/seguros/protege-tus-bienes/integral-comercio.php">Protegé tus Bienes</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu active">INVERSIONES</a>
					<ul class="list-unstyled submenu">
						<li><a href="plazo-fijo.php">Plazo Fijo</a></li>
						<li><a href="fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
						<li><a href="fidecomisos-financieros.php">Fidecomisos Financieros</a></li>
					</ul>
				</li>						
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">SERVICIOS</a>
					<ul class="list-unstyled submenu">
						<li><a href="../servicios/recaudaciones.php">Recaudaciones</a></li>
						<li><a href="../servicios/pagos.php">Pagos</a></li>
						<li><a href="../servicios/tarjetas-comerciales.php">Tarjetas Comerciales</a></li>
						<li><a href="../servicios/comercios-patagonia.php">Comercios Patagonia</a></li>
                        <li><a href="../servicios/pago-de-servicios.php">Pago de Servicios</a></li>
						<li><a href="../servicios/interbanking.php">Interbanking</a></li>
						<li><a href="../servicios/interfacturas.php">Interfacturas</a></li>
						<li><a href="../servicios/pagos-afip.php">Pagos AFIP</a></li>
						<li><a href="../servicios/wapa.php">WAPA</a></li>
					</ul>
				</li>
			</ul>		
		</li>
        <!-- FIN PYME -->
        
        <!-- AGRO -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">AGRO <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../agro/index.php" class="">HOME</a></li>
                <!-- -->
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">OFERTA AGRO</a>
					<ul class="list-unstyled submenu">
                    	<!--<li><a href="<php echo $folder_agroFinanciacion ?>insumos.php">Insumos en USD</a></li>-->
                        <li><a href="../../agro/convenios/acuerdos-y-beneficios.php">Acuerdos y convenios</a></li>
						<li><a href="../../agro/financiacion/maquinaria-agricola.php">Financiación Maquinaria Agrícola</a></li>
						<li><a href="../../agro/seguros/campo.php">Seguros para tu campo</a></li>
					</ul>
				</li>
                <!-- -->
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">TARJETA PATAGONIA AGRO</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../agro/tarjeta-patagonia-agro/para-usuarios.php">Para Usuarios</a></li>
						<li><a href="../../agro/tarjeta-patagonia-agro/para-comercios.php">Para Comercios</a></li>
						<li><a href="../../agro/tarjeta-patagonia-agro/acuerdo-tasa-0.php">Tarjetas Agro Convenios Preferenciales</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="../../agro/cuenta-agro/cuenta-agro.php" class="">CUENTA AGRO</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">FINANCIACIÓN</a>
					<ul class="list-unstyled submenu">
                        <li><a href="../../agro/insumos/index.php">Insumos</a></li>
                        <li><a href="../../agro/financiacion/maquinaria-agricola.php">Maquinarias</a></li>
                        <li><a href="../../empresas/financiacion/convenios-de-financiacion.php">Camiones</a></li>
						<!--<li><a href="<php echo $folder_agroFinanciacion ?>capital-de-trabajo.php">Capital de Trabajo</a></li>-->
						<!--<li><a href="<php echo $folder_agroFinanciacion ?>proyectos-de-inversion.php">Proyectos de Inversión</a></li>-->
						<!--<li><a href="<php echo $folder_agroFinanciacion ?>creditos-para-hacienda.php">Créditos para Hacienda</a></li>-->
						<!--<li><a href="<php echo $folder_agroFinanciacion ?>leasing-y-prendarios.php">Leasing y Prendarios</a></li>-->
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">INVERSIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../agro/inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
						<li><a href="../../agro/inversiones/fidecomisos-financieros.php">Fidecomisos Financieros</a></li>
						<li><a href="../../agro/inversiones/plazos-fijos.php">Plazos Fijos</a></li>
					</ul>
				</li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">COMERCIO EXTERIOR</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../agro/comercio-exterior/solicitud-electronica.php">Solicitud Electrónica</a></li>
                        <li><a href="../../agro/comercio-exterior/productos.php">Productos</a></li>
                        <li><a href="../../agro/comercio-exterior/otros-servicios.php">Servicios</a></li>
                        <li><a href="../../agro/comercio-exterior/herramientas-para-exportar.php">Herramientas para Exportar</a></li>
                        <li><a href="../../agro/comercio-exterior/marco-regulatorio/normas-y-regulaciones.php">Marco Regulatorio</a></li>
                    </ul>
                </li>
                <!--
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">SERVICIOS</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../agro/servicios/centro-atencion-empresas.php">Centro de Atención para Empresas</a></li>
					</ul>
				</li>
                -->
                <!-- -->
                <li class="nav-sub-item"><a href="../../agro/seguros/campo.php" class="">SEGUROS</a></li>
                <!-- -->
			</ul>
		</li>
        <!-- FIN AGRO -->
        
        <!-- EMPRESAS -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">EMPRESAS <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../empresas/index.php" class="">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA SUELDO</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../empresas/patagonia-sueldo/servicios.php">Servicios</a></li>
						<li><a href="../../empresas/patagonia-sueldo/preguntas-frecuentes.php">Preguntas Frecuentes</a></li>
						<li><a href="../../empresas/patagonia-sueldo/guia-implementacion.php">Guía de Implementación</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">COMERCIO EXTERIOR</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../empresas/comercio-exterior/solicitud-electronica.php">Solicitud Electrónica</a></li>
						<li><a href="../../empresas/comercio-exterior/productos.php">Productos</a></li>
						<li><a href="../../empresas/comercio-exterior/otros-servicios.php">Servicios</a></li>
						<!--<li><a href="<php echo $folder_Cexterior ?>financiaciones.php">Financiaciones</a></li>-->
                        <li><a href="../../empresas/comercio-exterior/herramientas-para-exportar.php">Herramientas para Exportar</a></li>
						<li><a href="../../empresas/comercio-exterior/marco-regulatorio/normas-y-regulaciones.php">Marco Regulatorio</a></li>
					</ul>
				</li>
                <!-- -->
				<!--<li class="nav-sub-item"><a href="../../empresas/comunidades-de-negocios/index.php" class="">COMUNIDADES DE NEGOCIOS</a></li>-->
                <!-- -->
				<li class="nav-sub-item"><a href="index.php" class="nav-lnk ">COMERCIOS PATAGONIA</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">FINANCIACIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../empresas/financiacion/patagonia-leasing.php">Patagonia Leasing</a></li>
						<li><a href="../../empresas/financiacion/mercado-capitales.php">Mercado Capitales</a></li>
						<li><a href="../../empresas/financiacion/alternativas-de-financiacion.php">Alternativas de Financiación</a></li>
                        <li><a href="../../empresas/financiacion/convenios-de-financiacion.php">Convenios de Financiación</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">INVERSIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../empresas/inversiones/plazos-fijos.php">Plazos Fijos</a></li>
						<li><a href="../../empresas/inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
						<li><a href="../../empresas/inversiones/compra-venta-titulos-acciones.php">Compra - Venta de Títulos y Acciones</a></li>
						<li><a href="../../empresas/inversiones/custodia-de-titulos.php">Custodia de Títulos</a></li>
						<li><a href="../../empresas/inversiones/fidecomisos-financieros.php">Fidecomisos Financieros</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">SERVICIOS</a>
					<ul class="list-unstyled submenu">
                        <li><a href="../../empresas/patagonia-movil-empresas.php">Patagonia Móvil Empresas</a></li>
						<li><a href="../../empresas/servicios/pagos.php">Pagos</a></li>
						<li><a href="../../empresas/servicios/recaudaciones.php">Recuadaciones</a></li>
						<li><a href="../../empresas/servicios/pago-de-servicios.php">Pago de Servicios</a></li>
						<li><a href="../../empresas/servicios/interbanking.php">Interbanking</a></li>
						<li><a href="../../empresas/servicios/interfacturas.php">Interfacturas</a></li>
						<li><a href="../../empresas/servicios/tarjetas-comerciales.php">Tarjetas Comerciales</a></li>
                        <!-- -->
						<!--<li><a href="../../empresas/servicios/comercios-patagonia.php">Comercios Patagonia</a></li>-->
                        <!-- -->
                        <li><a href="../../empresas/servicios/centro-atencion-empresas.php">Centro de Atención para Empresas</a></li>
					</ul>
				</li>
			</ul>
		</li>
        <!-- FIN EMPRESAS -->
        
        <!-- SECTOR PÚBLICO -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">SECTOR PÚBLICO <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../sector-publico/index.php" class="">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">INVERSIONES</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../sector-publico/inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
						<li><a href="../../sector-publico/inversiones/plazo-fijo.php">Plazo Fijo</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">SERVICIOS</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../sector-publico/servicios/servicio-de-recaudacion.php">Servicio de Recaudación</a></li>
						<li><a href="../../sector-publico/servicios/servicio-de-pagos.php">Servicio de Pagos</a></li>
						<li><a href="../../sector-publico/servicios/servicios-para-personal.php">Servicios para el Personal</a></li>
						<li><a href="../../sector-publico/servicios/financiacion.php">Financiación</a></li>
						<li><a href="../../sector-publico/servicios/otros-servicios.php">Servicios</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">PROGRAMA UNIVERSIDADES</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../sector-publico/programa-universidades/relacion-institucional.php">Relación Institucional</a></li>
						<li><a href="../../sector-publico/programa-universidades/docentes-yno-docentes.php">Docentes y No Docentes</a></li>
						<li><a href="../../sector-publico/programa-universidades/alumnos.php">Alumnos</a></li>
						<li><a href="../../sector-publico/programa-universidades/graduados.php">Graduados</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">BENEFICIOS RÍO NEGRO</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../sector-publico/rio-negro/presencia.php">Presencia en Río Negro</a></li>
                        <li><a href="../../sector-publico/rio-negro/propuesta-valor.php">Propuesta de valor exclusiva</a></li>
					</ul>
				</li>
			</ul>
		</li>
        <!-- FIN SECTOR PUBLICO -->
        
        <!-- INSTITUCIONAL -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">INSTITUCIONAL <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../institucional/index.php" class="">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">BANCO PATAGONIA</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../institucional/banco-patagonia/historia.php">Historia</a></li>
						<li><a href="../../institucional/banco-patagonia/mercado-de-capitales.php">Mercado de Capitales</a></li>
						<li><a href="../../institucional/banco-patagonia/patagonia-inversora.php">Patagonia Inversora</a></li>
						<li><a href="../../institucional/banco-patagonia/patagonia-valores-sa.php">Patagonia Valores S.A</a></li>
						<li><a href="https://bp.bancopatagonia.com.ar/relacion-con-inversores/es/institucional" target="_blank">Relación con Inversores</a></li>
						<li><a href="../../institucional/banco-patagonia/desarrollo-humano.php">Desarrollo Humano</a></li>
						<li><a href="../../institucional/banco-patagonia/sustentabilidad.php">Sustentabilidad</a></li>
						<li><a href="../../institucional/banco-patagonia/politicas-aml-cft.php">Póliticas AML/CFT</a></li>
						<li><a href="../../institucional/banco-patagonia/disciplina-del-mercado.php">Disciplina de Mercado</a></li>
                        <li><a href="../../institucional/banco-patagonia/asistencia-a-vinculados.php">Asistencia a vinculados</a></li>
                        <li><a href="../../institucional/banco-patagonia/etica-e-integridad.php">Ética e Integridad</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">ORGANIZACIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../institucional/organizacion/accionistas.php">Accionistas</a></li>
						<li><a href="../../institucional/organizacion/autoridades.php">Autoridades</a></li>
                        <li><a href="../../institucional/organizacion/comites.php">Comités</a></li>
						<li><a href="../../institucional/organizacion/sector-financiero.php">Sector Financiero</a></li>
					</ul>
				</li>
			</ul>
		</li>
        <!-- FIN INSTITUCIONAL -->
        
        		<li class="nav-main-item"><a href="../../preguntas-frecuentes/index.php" class="" style="text-transform: none;">Ayuda</a></li>
		<!--<li class="nav-main-item"><a href="<php echo $folder_canales ?>index.php" class="<php echo $canales ?>" style="text-transform: none;">Canales de Atención</a></li>-->
		<!--<li class="nav-main-item"><a href="http://sucursalesycajeros.bancopatagonia.com.ar/sucursales.html" target="_blank" style="text-transform: none;">Sucursales y Cajeros</a></li>-->
		<!--<li class="nav-main-item"><a href="<php echo $folder_contactenos ?>index.php" class="<php echo $contactenos ?>" style="text-transform: none;">Contactanos</a></li>-->
        <!--<li class="nav-main-item"><a href="<php echo $path ?>ayuda/index.php" class="<php echo $ayuda ?>" style="text-transform: none;">Ayuda</a></li>-->
	</ul>
</div>	<section class="sec-head" title="Fondos comunes de inversión. Impulsá tus proyectos">
        <div class="sec-pic-head" id="head-fondos-comunes-de-inversion">
        </div>
        <!--
		<div class="sec-pic-head" style="background-image: url(../../personas/inversiones/images/head-fondos-comunes-de-Inversion.jpg);">
			<div class="container">
				<div class="row">
					<div class="col-md-4 col-sm-6 col-xs-12 sec-pic-area">
						<div class="sec-head-card">
							<h2 class="with-border">Fondos comunes de inversión</h2>
							<p>Descubrí las mejores alternativas para hacer crecer tu proyecto.</p>
						</div>
					</div>
				</div>
			</div>
		</div>
        -->
	</section>
	<section class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
				<ol class="breadcrumb">
					<li><a href="../index.php">PyME</a></li>
					<li>Inversiones</li>
					<li class="active">Fondos Comunes de Inversión</li>
				</ol>
			</div>
		</div>
	</section>
	<section class="container">
	<div class="row">
		<div class="col-md-12 col-sm-12 col-xs-12">
			<p>&nbsp;</p>
            <div class="row equal-height info-blocks">
                				<div class="col-md-4 col-sm-4 col-xs-12">
					<a href="fondos-lombard.php" class="info-block">
						<h3>Fondos Lombard</h3>
						<p>Mejorá tus alternativas de inversión</p>
						<span class="btn-m-info"><i>+</i> INFO</span>
					</a>
				</div>
                                <div class="col-md-4 col-sm-4 col-xs-12">
					<a href="abc-de-los-fondos-comunes-de-inversion.php" class="info-block">
						<h3>El ABC de los fondos</h3>
						<p>Todo lo que necesitás saber acerca de los Fondos Comunes de Inversión</p>
						<span class="btn-m-info"><i>+</i> INFO</span>
					</a>
				</div>
			    <div class="col-md-4 col-sm-4 col-xs-12">
					<a href="opciones-de-fondos.php" class="info-block">
						<h3>Opciones de Fondos</h3>
						<p>Todas las opciones para ganar rentabilidad en tus inversiones</p>
						<span class="btn-m-info"><i>+</i> INFO</span>
					</a>
				</div>
            			</div>
			<div class="row equal-height info-blocks">
            				<div class="col-md-4 col-sm-4 col-xs-12">
					<a href="como-operar.php" class="info-block">
						<h3>Cómo operar</h3>
						<p>Aprendé cómo gestionar online tus fondos</p>
                                                <span class="btn-m-info"><i>+</i> INFO</span>
					</a>
				</div>
                				<div class="col-md-4 col-sm-4 col-xs-12">
					<a href="tipos-de-inversores.php" class="info-block">
						<h3>Tipos de Inversores</h3>
						<p>Definí tu perfil de inversor</p>
						<span class="btn-m-info"><i>+</i> INFO</span>
					</a>
				</div>
                			</div>
			<!--<php if ($submenu_personas == true) { ?>
			<div class="row equal-height info-blocks">
				<div class="col-md-4 col-sm-4 col-xs-12">
					<a href="tratamiento-impositivo.php" class="info-block">
						<h3>Tratamiento impositivo</h3>
						<br>
						<span class="btn-m-info"><i>+</i> INFO</span>
					</a>
				</div>
			</div>
			<php } ?>-->
            
            <!--
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="text-data">
                        <hr>
                        <h2 style="line-height: 1.3em;">Informamos que en virtud de lo dispuesto por el Decreto N° 842/2022 del Poder Ejecutivo Nacional, los Fondos Lombard administrados por esta Sociedad operarán para suscripciones y rescates con horario reducido hasta las 11hs.</h2>
                        <hr>
                    </div>
                </div>
            </div>
            -->
            
			<div class="row">
				<div class="col-md-12 col-sm-12 col-xs-12">
					<a href="#modal1" data-toggle="modal" target="_blank" class="btn-lnk-block">
						<h4>Agente de Custodia de Productos de Inversión Colectiva de Fondos Comunes de Inversión nº23 - Registro de Idóneos</h4>
						<i class="icon icon-more"></i>
					</a>
				</div>
			</div>
			
			<div class="row">
				<div class="col-md-4 col-sm-6 col-xs-12">
					<!--<a href="<php echo $path ?>fondos/Tratamiento_Impositivo.xlsx" class="btn-lnk-block">-->
					<a href="../../fondos/Tratamiento_Impositivo.pdf" target="_blank" class="btn-lnk-block">
						<h4>Tratamiento impositivo</h4>
						<i class="icon icon-pdf"></i>
					</a>
				</div>
			</div>
            
            <!-- MODAL -->
            <div class="modal fade" id="modal1">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal"><span>X</span></button>
                        </div>
                        <div class="modal-body">
                          <div class="text-data">
                                <p>&nbsp;</p>
                                <h3><strong>Idóneos en Mercado de Capitales</strong></h3>
                                <p>&nbsp;</p>
                                <table class="table table-bordered" style="text-align:center;">
                                    <thead>
                                        <tr>
                                            <th width="703" bgcolor="#eeeeee" style="text-align:center;">&nbsp;</th>
                                        </tr>
                                    </thead>
                                    <tr>
                                      <td>AGOTBORDE,    NESTOR RODOLFO&nbsp;  </td>
                                    </tr>
                                    <tr>
                                      <td>ALI,LEILA&nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>ALOY,SILVIA    MIRIAM&nbsp; &nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>ALTIERI,MARTIN    GABRIEL&nbsp;  </td>
                                    </tr>
                                    <tr>
                                      <td>ALVAREZ,JORGE    HECTOR&nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>AMAGO,CRISTIAN    EDUARDO&nbsp; &nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>ANTON,MARIA    PATRICIA</td>
                                    </tr>
                                    <tr>
                                      <td>ARANDA,ARIEL&nbsp;    &nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>ARENA,SUSANA    ALICIA&nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>ARNALDO    DABRESCIA,ANA LAURA&nbsp; &nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>ARRARAS,MARIA    JIMENA&nbsp; &nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>ASIN,JUAN    MANUEL&nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>AVALOS,DANIELA    ALFONSO</td>
                                    </tr>
                                    <tr>
                                      <td>AVILA,ROCIO</td>
                                    </tr>
                                    <tr>
                                      <td>BADRA,ANIBAL    JERONIMO</td>
                                    </tr>
                                    <tr>
                                      <td>BAUDRY,MARIA    AYELEN&nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>BELLI,JAVIER    MARIA&nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>BONO,ARIEL    MARTIN&nbsp;&nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>BORDONI,LEANDRO    ENRIQUE&nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>BOTTERO,EUGENIA    CAROLINA&nbsp;  </td>
                                    </tr>
                                    <tr>
                                      <td>BOTTINI,MATIAS</td>
                                    </tr>
                                    <tr>
                                      <td>BOUZA,MARIA    LETICIA&nbsp; &nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>BURGARELLI,ERIKA    IVANA</td>
                                    </tr>
                                    <tr>
                                      <td>BUTTAZZI,MATIAS    LEONARDO&nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>CABRERA    FERNANDEZ,ALBERTO RAFAEL &nbsp; &nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>CAPORAZZO,LUCAS&nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>CAPUTO,NICOLAS    DIEGO CEFERINO&nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>CARBALLO,SEBASTIAN&nbsp;    &nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>CARDOZO,JUAN    EDUARDO</td>
                                    </tr>
                                    <tr>
                                      <td>CARRICO,MARTIN    MIGUEL&nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>CASTRO,ADRIAN    JULIAN&nbsp; &nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>CASTRO,MARIANA&nbsp;    &nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>CASTRO,OSCAR    ALFREDO&nbsp; &nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>CATENA,MARIA    PAULA&nbsp; &nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>CORVALAN,PAMELA    ELIZABETH</td>
                                    </tr>
                                    <tr>
                                      <td>COSTA,MARIA    GUILLERMINA&nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>DALLA    COSTA,CECILIA INES&nbsp; &nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>DE    BONIS,RICARDO ARIEL&nbsp; &nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>DE LA    PEÑA,VALERIA&nbsp;&nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>DE LA    VEGA,&nbsp;JOSE IGNACIO &nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>DOMINGUEZ    ACUÑA,CLAUDIA VERONICA&nbsp;  </td>
                                    </tr>
                                    <tr>
                                      <td>ENRICH,GLADYS    MARIA&nbsp; &nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>ESCALADA,MAURO    GERMAN</td>
                                    </tr>
                                    <tr>
                                      <td>FAVUZZI,JUAN    PABLO&nbsp; &nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>FERNANDEZ,ANALIA    VERONICA</td>
                                    </tr>
                                    <tr>
                                      <td>FERNANDEZ,MATIAS&nbsp;  </td>
                                    </tr>
                                    <tr>
                                      <td>FERRAZZUOLO,LEONARDO    DAVID&nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>FERREYRA,DIEGO    ANDRES&nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>FIRPO,MATIAS    SEBASTIAN&nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>FLYNN,MOIRA&nbsp;  </td>
                                    </tr>
                                    <tr>
                                      <td>FONTEÑEZ,VANESA    SOLEDAD&nbsp; &nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>FRIAS,GUSTAVO    EMILIO&nbsp; &nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>GALUPPO,LAURA&nbsp;  </td>
                                    </tr>
                                    <tr>
                                      <td>GARCIA    DIEZ,MATIAS DIEGO&nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>GEDELLA,MARIANA    &nbsp; &nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>GELBER,    CLAUDIA JUDITH</td>
                                    </tr>
                                    <tr>
                                      <td>GENITIEMPO,LUCAS    DAMIAN&nbsp; &nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>GIAMPIERI,SOFIA</td>
                                    </tr>
                                    <tr>
                                      <td>GIGIREY    LARREGAIN,DANIEL NELSON&nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>GIORDANO,CARINA    BEATRIZ</td>
                                    </tr>
                                    <tr>
                                      <td>GIORGETTI,MARCELO    ADRIAN&nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>GODOY,JOSE    IGNACIO</td>
                                    </tr>
                                    <tr>
                                      <td>GONZALEZ    LACROIX,HERNAN &nbsp; &nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>GRIPPALDI,LUCAS    PAULO</td>
                                    </tr>
                                    <tr>
                                      <td>GUERRA,MANUEL    IGNACIO&nbsp;  </td>
                                    </tr>
                                    <tr>
                                      <td>GUEVARA,ALEXIS    LIONEL&nbsp;&nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>GUIRAL,MATIAS&nbsp;    &nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>HEISS,FEDERICO    GERMAN&nbsp; &nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>IANNICE,ROXANA&nbsp;&nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>JALIL,CARLA    ROCA</td>
                                    </tr>
                                    <tr>
                                      <td>LAURO,DIEGO&nbsp;    &nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>LEVATINO,JIMENA</td>
                                    </tr>
                                    <tr>
                                      <td>LISOTTI,FRANCO    LAUREANO&nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>LLORET,LAURA    NANCY&nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>LOZANO,FERNANDO    ARIEL&nbsp; &nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>MANDUCA,MARIANO    EDUARDO&nbsp; &nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>MARROU,NAHUEL    OSCAR&nbsp; &nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>MARTINI,ALFONSINA    BELEN</td>
                                    </tr>
                                    <tr>
                                      <td>MAYORAL,ELENA    BEATRIZ</td>
                                    </tr>
                                    <tr>
                                      <td>MEDINA,EDUARDO&nbsp;    &nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>MENDEZ,ANDREA    ROSANNA&nbsp;&nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>MESSI,GUIDO    LUIS&nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>MIROCHNIK,HERNAN    LEONARDO&nbsp; &nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>MONTERO,SANTIAGO    &nbsp; &nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>MORAGLIO,ALEJANDRO&nbsp;  </td>
                                    </tr>
                                    <tr>
                                      <td>MOROZ,SILVANA    ROMINA</td>
                                    </tr>
                                    <tr>
                                      <td>MOSCATO,NICOLAS&nbsp;    &nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>NAVARRO,LEANDRO    ADRIAN&nbsp; &nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>NIETO,PAOLA    NOELIA&nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>NOVELLO,SERGIO    GUIDO&nbsp;  </td>
                                    </tr>
                                    <tr>
                                      <td>ORIA,FERMIN    DANIEL&nbsp;  </td>
                                    </tr>
                                    <tr>
                                      <td>ORTIZ,RAMIRO&nbsp;    &nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>OTERMIN,ALEJANDRO    ANIBAL</td>
                                    </tr>
                                    <tr>
                                      <td>OXILIA,GUSTAVO    ADRIAN&nbsp; &nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>PALADINO,MARIA    NOEL&nbsp;  </td>
                                    </tr>
                                    <tr>
                                      <td>PALOMO,ANDRES    HERNAN</td>
                                    </tr>
                                    <tr>
                                      <td>PANOS,FLORENCIA    LUCIANA&nbsp;  </td>
                                    </tr>
                                    <tr>
                                      <td>PANUNZIO,GISEL    ROMINA</td>
                                    </tr>
                                    <tr>
                                      <td>PEDRO,LAURA    CECILIA</td>
                                    </tr>
                                    <tr>
                                      <td>PELAYES,GABRIELA    FERNANDA</td>
                                    </tr>
                                    <tr>
                                      <td>PERALTA,GRACIELA    ELSA&nbsp;  </td>
                                    </tr>
                                    <tr>
                                      <td>PEREGO,LUCIA    MARIA&nbsp; &nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>PEREYRA,    VERONICA LORENA</td>
                                    </tr>
                                    <tr>
                                      <td>PEREZ,CARMEN&nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>PESCE,ALEJANDRO    LUIS&nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>PICCOLO    FERRO,NELSON FERNANDO&nbsp;  </td>
                                    </tr>
                                    <tr>
                                      <td>PICOLINI,MARIA    LAURA&nbsp;  </td>
                                    </tr>
                                    <tr>
                                      <td>PIRITAGUARI,LUCAS    EMANUEL&nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>PRADO,FEDERICO    CARLOS&nbsp; &nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>RAMIREZ,LEONARDO    GABRIEL&nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>RANDAZZO,MARIA    LAURA</td>
                                    </tr>
                                    <tr>
                                      <td>RESCIA,LEONARDO    JAVIER</td>
                                    </tr>
                                    <tr>
                                      <td>RIOS,FEDERICO    CARLOS&nbsp;  </td>
                                    </tr>
                                    <tr>
                                      <td>RODRIGUEZ,GUSTAVO    DANIEL</td>
                                    </tr>
                                    <tr>
                                      <td>RODRIGUEZ,MARIA    JESUS</td>
                                    </tr>
                                    <tr>
                                      <td>ROMERO,YANINA    ELIZABETH</td>
                                    </tr>
                                    <tr>
                                      <td>RUCHTEIN,ERIKA    FABIANA&nbsp; &nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>RUILOVA,MARIA    VIRGINIA</td>
                                    </tr>
                                    <tr>
                                      <td>SALA,MARIA    PIA&nbsp;  </td>
                                    </tr>
                                    <tr>
                                      <td>SALMAIN,TOMAS    ADOLFO&nbsp; &nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>SALOMON,ALEJANDRO    JAVIER&nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>SAN    VITO,ANALIA&nbsp; &nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>SANCHEZ    SEOANE,ADRIAN MARTIN&nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>SANCHEZ,ALBERTO    ALFREDO&nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>SANDOLI,MARIA    LAURA&nbsp;  </td>
                                    </tr>
                                    <tr>
                                      <td>SANTOS,FABIANA    CECILIA</td>
                                    </tr>
                                    <tr>
                                      <td>SCIARRILLO,MARIANA&nbsp;    &nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>SICA,LEONARDO    ANIBAL</td>
                                    </tr>
                                    <tr>
                                      <td>SIMONELLI,ANTONELLA    BEATRIZ&nbsp;  </td>
                                    </tr>
                                    <tr>
                                      <td>STRUGO,VICTORIA    LAURA&nbsp; &nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>TABOADA,MANUEL    SANTIAGO&nbsp; &nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>TEIXEIRA,CAROLINA    MARCELA</td>
                                    </tr>
                                    <tr>
                                      <td>TOLOSA,HECTOR    FABIAN&nbsp; &nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>TORRE,CARLA    ROMINA&nbsp; &nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>TORRES    CARBONELL,FACUNDO&nbsp; &nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>TROTTA,FERNANDO    GABRIEL&nbsp; &nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>VARELA,LAURA    CAROLINA</td>
                                    </tr>
                                    <tr>
                                      <td>VELIZ,ROSANA    MARIELA&nbsp; &nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>VELOZ    PAZ,VERONICA ANDREA&nbsp; &nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>VERGARA,EMILIANO    MARTIN&nbsp; &nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>VILARIÑO,JULIO    IGNACIO&nbsp; &nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>VILLANUEVA,VERONICA    LAURA&nbsp; &nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>ZABALA    NUÑEZ,MARCIA ANABELLA&nbsp; &nbsp; </td>
                                    </tr>
                                    <tr>
                                      <td>ZAGDAÑSKI,JONATHAN    EDGAR</td>
                                    </tr>
                                    <tr>
                                      <td>ZAIA,NICOLAS    MIGUEL&nbsp; &nbsp; </td>
                                    </tr>
                                </table>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
			<!-- FIN MODAL -->
            
			<!--<div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="text-data">
                        <hr>
                        <h2>A partir del lunes 27/5/24 se reduce el plazo de liquidación a 24hs hábiles, de los fondos:</h2>
                        <ul>
                            <li>Lombard Renta Fija</li>
							<li>Lombard Renta Fija en USD</li>
							<li>Lombard Acciones Líderes</li>
							<li>Lombard Abierto Pymes</li>
                        </ul>
                        <hr>
                    </div>
                </div>
            </div>-->
			
            <!--
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="text-data">
                        <hr>
                        <h1>A partir del día 01/07/2021 los honorarios de nuestros Fondos Comunes de Inversión son:</h1>
                        <div class="row">
                            <div class="col-md-3 col-sm-4 col-xs-12">
                                <p><strong>Lombard Renta en Pesos:</strong></p>
                                <ul>
                                    <li>Honorarios totales: 1.20% *</li>
                                </ul>
                            </div>
                            <div class="col-md-3 col-sm-4 col-xs-12">
                                <p><strong>Lombard Capital:</strong></p>
                                <ul>
                                    <li>Honorarios totales: 1.80% *</li>
                                </ul>
                            </div>
                            <div class="col-md-3 col-sm-4 col-xs-12">
                                <p><strong>Lombard Abierto Plus:</strong></p>
                                <ul>
                                    <li>Honorarios totales: 1.80% *</li>
                                </ul>
                            </div>
                            <div class="col-md-3 col-sm-4 col-xs-12">
                                <p><strong>Lombard Renta Fija en Dólares:</strong></p>
                                <ul>
                                    <li>Honorarios totales: 0.35% *</li>
                                </ul>
                            </div>
                            <div class="col-md-3 col-sm-4 col-xs-12">
                                <p><strong>Lombard Renta Fija:</strong></p>
                                <ul>
                                    <li>Honorarios totales: 2.20% *</li>
                                </ul>
                            </div>
                            <div class="col-md-3 col-sm-4 col-xs-12">
                                <p><strong>Lombard Acciones Líderes</strong></p>
                                <ul>
                                    <li>Honorarios totales: 2.00% *</li>
                                </ul>
                            </div>
                            <div class="col-md-3 col-sm-4 col-xs-12">
                                <p><strong>Lombard Ahorro Plus:</strong></p>
                                <ul>
                                    <li>Honorarios totales: 0.40% *</li>
                                </ul>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <p style="font-size: 12px;">* Los honorarios mencionados son anuales.</p>
                            </div>
                        </div>
                        <hr>
                    </div>
                </div>
            </div>
            -->
            
            <p>&nbsp;</p>
            
            
                            <!-- ----------------------------------------------- -->
                <!-- CONSULTA (PYME, AGRO, SECTOR PÚBLICO, EMPRESAS) -->
                <!-- ----------------------------------------------- -->
                <div class="row consulta">
    <div class="col-md-4 col-sm-4 col-xs-12"></div>
    <div class="col-md-4 col-sm-4 col-xs-12">
        <a href="formulario-de-consulta-fondos.php" class="lnk">Realizá tu consulta online</a>
    </div>
</div>                                    
            
                            <!-- ------------------------------------------------- -->
                <!-- PRE FOOTER (PYME, AGRO, SECTOR PÚBLICO, EMPRESAS) -->
                <!-- ------------------------------------------------- -->
                <div class="row consulta">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <h4>Solicitalo en</h4>
    </div>
    <div class="col-md-4 col-sm-4 col-xs-12">
        <a href="patagonia-ebank-empresas.php" class="lnk">PATAGONIA E-BANK</a>
    </div>
    <div class="col-md-4 col-sm-4 col-xs-12">
        <a href="tel:41326275" class="lnk lnk-2-lines phone">Telefónicamente<br>
        4132 6275 | 4132 6368</a>
    </div>
        <div class="col-md-4 col-sm-4 col-xs-12">
        <a href="http://sucursalesycajeros.bancopatagonia.com.ar/sucursales.html" target="_blank" class="lnk last">EN LA SUCURSAL</a>
    </div>
        </div>


                                        

            <!-- --------------- -->
            <!-- LEGALES (TODOS) -->
            <!-- --------------- -->
            <div class="row legal-int">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <p>LAS INVERSIONES EN CUOTAS DEL FONDO NO CONSTITUYEN DEPÓSITOS EN BANCO PATAGONIA S.A. A LOS FINES DE LEY DE ENTIDADES FINANCIERAS NI CUENTAN CON NINGUNA DE LAS GARANTÍAS QUE TALES DEPÓSITOS A LA VISTA O A PLAZOS PUEDAN GOZAR DE ACUERDO A LA LEGISLACIÓN Y REGLAMENTACIÓN APLICABLES EN MATERIA DE DEPÓSITOS EN ENTIDADES FINANCIERAS. ASIMISMO, BANCO PATAGONIA S.A. SE ENCUENTRA IMPEDIDO POR NORMAS DEL BANCO CENTRAL DE LA REPÚBLICA ARGENTINA DE ASUMIR, TÁCITA O EXPRESAMENTE, COMPROMISO ALGUNO EN CUANTO AL MANTENIMIENTO, EN CUALQUIER MOMENTO, DEL VALOR DEL CAPITAL INVERTIDO, AL RENDIMIENTO, AL VALOR DEL RESCATE DE LAS CUOTASPARTANTES O AL OTORGAMIENTO DE LIQUIDEZ A TAL FIN, PATAGONIA INVERSORA SE ENCUENTRA REGISTRADO ANTE LA COMISION NACIONAL DE VALORES COMO AGENTE DE ADMINISTRACIÓN DE PRODUCTOS DE INVERSIÓN COLECTIVA DE FONDOS COMUNES DE INVERSIÓN BAJO EL Nº 14, POR SU PARTE, BANCO PATAGONIA S.A. SE ENCUENTRA REGISTRADO ANTE LA COMISIÓN NACIONAL DE VALORES COMO AGENTE DE CUSTODIA DE PRODUCTOS DE INVERSIÓN COLECTIVA DE FONDOS COMUNES DE INVERSIÓN BAJO EL Nº23.</p>
    </div>
</div>            
		</div>
	</div>
</section>
<!-- EXTERNAL LNK -->
<!--
<div class="modal fade" id="external">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal"><span>X</span></button>
				<h4 class="modal-title"><img src="../../assets/images/layout/logo.svg" width="206" height="22" alt=""/></h4>
			</div>
			<div class="modal-body">
				<div class="external-legend">
					<p>Estás abandonado el sitio de Banco Patagonia S.A. El usuario reconoce que las hiperconexiones con otro medios de Internet son a tu propio riesgo. Banco Patagonia no investiga, verifica, controla ni responde el contenido, la exactitud, las opiniones expresada y otras conexiones suministradas por estos medios. </p>
				</div>
			</div>
			<div class="modal-footer">
				<a href="https://aif.cnv.gov.ar/Aif/registropublico/idoneo.aspx" target="_blank" class="cta-btn">Aceptar</a>
				<a href="#" class="cta-btn-cancel" data-dismiss="modal">Cancelar</a>
			</div>
		</div>
	</div>
</div>
-->
<!-- FIN EXTERNAL LNK -->	<div class="container-fluid footer-bar">
	<div class="row">
		<footer class="container">
			<div class="row">
				<div class="col-md-12">
					<p class="flnks"><a href="../../registro-nacional-base-datos.php">Registro Nacional de Base de Datos</a> <span>|</span>   <a href="../../codigo-practicas-bancarias.php">Código de Prácticas Bancarias</a> <span>|</span>   <a href="../../defensa-ley-consumidor.php">Defensa del Consumidor</a>
						<span>|</span>   <a href="https://www.argentina.gob.ar/produccion/defensadelconsumidor/formulario">Defensa de las y los consumidores. Para reclamos ingrese aquí</a><span>|</span> <br class="tbl"> <a href="../../persona-expuesta-politicamente.php">Persona Expuesta Políticamente</a> <span class="tbl">|</span> <br class="dsk">
						
					<a href="../../agencia-acceso-informacion-publica.php">Agencia de Acceso a la Información Pública</a> <span>|</span> <br class="tbl"> 
					<a href="../../cnv-advertencia-publico-inversor.php">CNV - Advertencia al Público Inversor</a> <span>|</span> <a href="../../docs/Idoneos.pdf" target="_blank"> Idóneos en Mercado de Capitales - CNV</a><span>|</span>   <a href="../../codigo-proteccion-inversor.php">Código de Protección al Inversor</a> <span>|</span>   <a href="../../clausulas-legales.php">Cláusulas Legales</a> <span>|</span> <a href="../../resolucion-022021.php">Resol. 02/21 Dir.Gral. Defensa del consumidor Córdoba</a></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<p class="redes">
                        <span>Seguinos en:</span>
                        <!-- -->
                        <a href="https://www.facebook.com/BancoPatagonia/" target="_blank"><img src="../../assets/images/layout/icon-facebook.svg" alt="Facebook"></a>
                        <a href="https://twitter.com/banco_patagonia" target="_blank"><img src="../../assets/images/layout/icon-twitter.svg" alt="Twitter"></a>
                        <a href="https://www.instagram.com/banco_patagonia/" target="_blank"><img src="../../assets/images/layout/icon-instagram.svg" alt="Instagram"></a>
                        <a href="https://www.youtube.com/user/bancopatagonia" target="_blank"><img src="../../assets/images/layout/icon-youtube.svg" alt="Youtube"></a>
                        <!-- -->
                        <!--
                        <a href="https://www.facebook.com/BancoPatagonia/" target="_blank"><i class="fa fa-facebook-square"></i></a>
                        <a href="https://twitter.com/banco_patagonia" target="_blank"><i class="fa fa-twitter"></i></a>
                        <a href="https://www.instagram.com/banco_patagonia/" target="_blank"><i class="fa fa-instagram"></i></a>
                        <a href="https://www.youtube.com/user/bancopatagonia" target="_blank"><i class="fa fa-youtube-play"></i></a>
                        -->
                    </p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					                    <!---->
				    <p class="flegal">BANCO PATAGONIA S.A. ES UNA SOCIEDAD ANÓNIMA CONSTITUIDA BAJO LAS LEYES DE LA REPÚBLICA ARGENTINA CUYOS ACCIONISTAS LIMITAN SU RESPONSABILIDAD A LA INTEGRACIÓN DE LAS ACCIONES SUSCRITAS DE ACUERDO A LA LEY 19.550. POR CONSIGUIENTE, Y EN CUMPLIMIENTO DE LA LEY 25.738, SE INFORMA QUE NI LOS ACCIONISTAS MAYORITARIOS DE CAPITAL EXTRANJERO NI LOS ACCIONISTAS LOCALES O EXTRANJEROS RESPONDEN, EN EXCESO DE LA CITADA INTEGRACIÓN ACCIONARIA, POR LAS OBLIGACIONES EMERGENTES DE LAS OPERACIONES CONCERTADAS POR LA ENTIDAD FINANCIERA.</p>
                    <p class="flegal" style="font-size:10px;">Banco Patagonia S.A. - Agente de Liquidacion y Compensacion y Agente de Negociacion Integral, inscripto en CNV bajo el N° 66</p>
					<p class="flegal">© 2025 Banco Patagonia . Todos los derechos reservados. Prohibida la duplicación , distribución o almacenamiento en cualquier medio.</p>
				</div>
			</div>
		</footer>
	</div>
</div>
<div class="tbl mbl placeholder-shortlinks">
	<div class="container shortlinks">
		<div class="row">
            <!--<php if ($home_personas == false) { ?>
                <div class="col-sm-3 col-xs-3">
                    <a href="#"><span class="icon icon-contacto"></span></a>
                </div>
            <php } ?>-->
            			<div class="col-sm-3 col-xs-3">
				<a href="http://sucursalesycajeros.bancopatagonia.com.ar/sucursales.html" target="_blank"><span class="icon icon-sucursales"></span>Sucursales y Cajeros</a>
			</div>
			<div class="col-sm-3 col-xs-3">
				<a href="../../preguntas-frecuentes/index.php"><span class="icon icon-contacto"></span>Ayuda</a>
			</div>
			<div class="col-sm-3 col-xs-3 last">
				<a href="../../empresas/patagonia-ebank-empresas-mbl.php"><span class="icon icon-ebank"></span>Patagonia e-Bank</a>
			</div>
		</div>
	</div>
</div>	<script src="../../assets/js/jquery-3.5.1.min.js"></script>
<script src="../../assets/bootstrap/js/bootstrap.min.js"></script>
<script src="../../assets/js/slick/slick.min.js"></script>
<script src="../../assets/js/fancybox/jquery.fancybox.min.js"></script>
<script src="../../assets/js/mtabs/jquery.bootstrap-responsive-tabs.min.js"></script>
<script src="../../assets/js/funciones.js"></script>

<!-- Global site tag (gtag.js) - Google Analytics (original) -->
<!--
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-32588129-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-32588129-1');
</script>
-->

<!-- Google Analytics (version anterior / eventos ok)  -->
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');
  ga('create', 'UA-32588129-1', 'auto');
  ga('send', 'pageview');
</script>

<!-- GA4 - Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-C6LG1PT98X"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-C6LG1PT98X');
</script>
</body>
</html>