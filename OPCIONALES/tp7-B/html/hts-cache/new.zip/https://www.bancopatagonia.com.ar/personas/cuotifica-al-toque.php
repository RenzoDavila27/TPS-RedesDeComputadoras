<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
	<meta http-equiv="Pragma" content="no-cache">
	<meta http-equiv="Expires" content="0">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Cuotificá al toque | Banco Patagonia</title>
	<meta name="description" content="Ahora con Cuotificá al toque, podés pagar hasta en 6 cuotas fijas tus compras con QR desde Patagonia Móvil.">
	<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-NL73B44');</script>
<!-- End Google Tag Manager -->

<link rel="shortcut icon" href="../favicon.ico" type="image/x-icon"/>
<link href="../assets/fonts/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="../assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="../assets/js/mtabs/bootstrap-responsive-tabs.css" rel="stylesheet" type="text/css">
<link href="../assets/js/slick/slick.css" rel="stylesheet" type="text/css">
<link href="../assets/js/fancybox/jquery.fancybox.min.css" rel="stylesheet" type="text/css">
<link href="../assets/css/styles.css" rel="stylesheet" type="text/css">
<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->    <!-- SLIDES RESPONSIVE -->
    <style>
        /* DSK */
        #head-cuotifica { background-image: url(images/cuotifica/head-cuotifica-al-toque-dsk.jpg); background-image: -webkit-image-set ( url("images/cuotifica/head-cuotifica-al-toque-dsk.jpg") 1x, url("images/cuotifica/head-cuotifica-al-toque-dsk@2x.jpg") 2x ); }
		#section-patagonia-on { background-image: url(images/cuotifica/section-patagonia-on-dsk.png); background-image: -webkit-image-set ( url("images/cuotifica/section-patagonia-on-dsk.png") 1x, url("images/cuotifica/section-patagonia-on-dsk@2x.png") 2x ); }

        @media screen and (max-width: 1200px) {
            /* TBT */
            #head-cuotifica { background-image: url(images/cuotifica/head-cuotifica-al-toque-tbl.jpg); background-size: auto !important; background-image: -webkit-image-set ( url("images/cuotifica/head-cuotifica-al-toque-tbl.jpg") 1x, url("images/cuotifica/head-cuotifica-al-toque-tbl@2x.jpg") 2x ); }
			#section-patagonia-on { background-image: url(images/cuotifica/section-patagonia-on-tbl.png); background-size: auto !important; background-image: -webkit-image-set ( url("images/cuotifica/section-patagonia-on-tbl.png") 1x, url("images/cuotifica/section-patagonia-on-tbl@2x.png") 2x ); }
        }
        @media screen and (max-width: 560px) {
            /* MBL */
            #head-cuotifica { background-image: url(images/cuotifica/head-cuotifica-al-toque-mbl.jpg); background-image: -webkit-image-set ( url("images/cuotifica/head-cuotifica-al-toque-mbl.jpg") 1x, url("images/cuotifica/head-cuotifica-al-toque-mbl@2x.jpg") 2x ); }
			#section-patagonia-on { background-image: url(images/cuotifica/section-patagonia-on-mbl.png); background-image: -webkit-image-set ( url("images/cuotifica/section-patagonia-on-mbl.png") 1x, url("images/cuotifica/section-patagonia-on-mbl@2x.png") 2x ); }
        }
		
		/* PARCHE SECTION PAT ON (DSK) */
		@media screen and (min-width: 1200px) {
			#cat-sec-head .sec-pic-head { height: 417px; }
		}
		
    </style>
	<!-- CSS (CUOTIFICA) -->
	<style>
		#head-xl-cuotifica { background-image: url(images/cuotifica/01.png); padding-bottom: 30px; }
		#head-xl-cuotifica .text-data { max-width: 525px; margin-bottom: 15px; }
		#head-xl-cuotifica .text-data h1 { margin-bottom: 15px; }
		/*#head-xl-cuotifica .text-data h2 { letter-spacing: -0.5px; }*/
		/**/
		#content-xl-cuotifica .text-data h2 { display: inline-block; padding: 10px 50px 10px 15px; border-radius: 30px; background-repeat: no-repeat; background-position: center right 20px; background-image: url(images/cuotifica/icon-arrow.png); margin-bottom: 30px; }
		#content-xl-cuotifica .text-data ul { display: flex; flex-wrap: wrap; column-gap: 1.5%; row-gap: 30px; }
		#content-xl-cuotifica .text-data ul li:before { display: none; }
		#content-xl-cuotifica .text-data ul li { width: 13%; padding-left: 0; }
		#content-xl-cuotifica .text-data ul li img.cat-icon { width: 30px; height: 30px; margin-bottom: 15px; }
		#content-xl-cuotifica .text-data ul li h3 { height: 58px; margin-bottom: 10px; }
		/**/
		#cat-sec-head .sec-pic-head { background-color: #fff; margin-bottom: 45px; }
		
		@media screen and (max-width: 1200px) {
			#head-xl-cuotifica { padding-bottom: 15px; background-size: 640px; }
			#head-xl-cuotifica .text-data { max-width: 100%; }
			/**/
			#content-xl-cuotifica .text-data ul { column-gap: 4%; }
			#content-xl-cuotifica .text-data ul li { width: 22%; }
		}
		
		@media screen and (max-width: 560px) {
			#content-xl-cuotifica .text-data ul li { width: 48%; }
		
		}
		
	</style>
	<!-- -->
</head>

<body>
	<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NL73B44"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

<div class="placeholder-bar">
	<div class="container-fluid header-bar">
		<div class="row">
			<header class="container">
				<div class="row">
					<div class="col-md-3 col-dsk-6 col-sm-6">
						<span class="c-hamburger c-hamburger--htx">
							<span>toggle menu</span>
						</span>
                        <!-- -->
                        <!--<img style="position: absolute; width: 42px; top: 20px; right: 40px;" class="dsk" src="<php echo $path ?>assets/images/layout/icon-verano-2022.svg">-->
                        <!-- -->
						<h1>
                            <!--<img style="position: absolute; width: 32px; top: 12px; left: 102px;" class="dsk" src="<php echo $path ?>assets/images/layout/icon-navidad-2021.svg">-->
                            <a href="index.php" class="main-logo">Banco Patagonia</a>
                        </h1>
					</div>
					<div class="col-md-9 col-dsk-6 col-sm-6">
						<div class="general-links">
							<ul class="list-unstyled">
                                <li id="btn-hacete-cliente"><a href="https://tunuevacuenta.bancopatagonia.com.ar/?utm_source=sitiowebbp&utm_medium=sitiowebbp%20banner%20home&utm_campaign=onboarding_sitiowebp_bannerhome" target="_blank"><strong>Hacete cliente <i class="fa fa-angle-right"></i></strong></a></li>								<li><a href="../preguntas-frecuentes/index.php" class="">Ayuda</a></li>
								<!--<li><a href="<php echo $folder_canales ?>index.php" class="<php echo $canales ?>">Canales de atención</a></li>-->
								<!--<li><a href="http://sucursalesycajeros.bancopatagonia.com.ar/sucursales.html" target="_blank">Sucursales y cajeros</a></li>-->
								<!--<li><a href="<php echo $folder_contactenos ?>index.php" class="<php echo $contactenos ?>">Contactanos</a></li>-->
                                <!--<li><a href="<php echo $path ?>ayuda/index.php" class="<php echo $ayuda ?>">Ayuda</a></li>-->
							</ul>
						</div>
						<div class="top-links">
							<ul class="list-unstyled">
								<li><a href="index.php" class="">PERSONAS</a></li>
								<li><a href="../nyps/index.php" class="">PROFESIONALES Y COMERCIOS</a></li>
								<li><a href="../pyme/index.php" class="">PYME</a></li>
								<li><a href="../agro/index.php" class="">AGRO</a></li>
								<li><a href="../empresas/index.php" class="">EMPRESAS</a></li>
								<li><a href="../sector-publico/index.php" class="">SECTOR PÚBLICO</a></li>
								<li><a href="../institucional/index.php" class="">INSTITUCIONAL</a></li>
							</ul>
							<div class="ebank">
                            <!-- antes href: <php echo $folder_empresas ?><php echo $url_ebank ?>-->
															<a href="https://ebankpersonas.bancopatagonia.com.ar/eBanking/usuarios/login.htm" class="patagonia-ebank" target="_blank">Patagonia e-Bank</a>
														</div>
						</div>
					</div>
				</div>
			</header>
		</div>
	</div>
</div>

<div class="container-fluid nav-bar">
	<div class="row">
		<nav class="container">
			<div class="row">
				<!--<div class="col-md-9 col-md-offset-3">-->
                <div class="col-md-10 col-md-offset-3"><!-- ajuste agro -->
					<ul class="list-unstyled sub-navbar">
						
												<!-- PERSONAS -->
                        <li class="nav-item"><a href="#" class="nav-lnk ">PATAGONIA CLÁSICA</a>
							<ul class="list-unstyled submenu">
                                <li><a href="../personas/patagonia-clasica/patagonia-ahorro/productos.php">Patagonia Ahorro</a></li>
                                <li><a href="../personas/patagonia-clasica/paquete/productos.php">Patagonia Clásica</a></li>
                                <!--<li><a href="<php echo $path ?>personas/patagonia-clasica/mas/productos.php">Patagonia Clásica Más</a></li>-->
                                <li><a href="../personas/patagonia-clasica/premium/productos.php">Patagonia Clásica Premium</a></li>
                                <li><a href="../personas/patagonia-clasica/patagonia-sueldo/productos.php">Patagonia Sueldo</a></li>
							</ul>
						</li>
						<li class="nav-item"><a href="#" class="nav-lnk ">PATAGONIA PLUS</a>
							<ul class="list-unstyled submenu">
                                <li><a href="../personas/patagonia-plus/productos.php">Patagonia Plus</a></li>
                                <li><a href="../personas/patagonia-plus/premium/productos.php">Patagonia Plus Premium</a></li>
							</ul>						
						</li>
						<li class="nav-item"><a href="#" class="nav-lnk ">PATAGONIA SINGULAR</a>
							<ul class="list-unstyled submenu">
								<li><a href="../personas/patagonia-singular/paquete/propuesta.php">Patagonia Singular</a></li>
                                <li><a href="../personas/patagonia-singular/beneficios-exclusivos.php">Beneficios Exclusivos</a></li>
                                <!--<li><a href="<php echo $path ?>personas/patagonia-singular/atencion-exclusiva/index.php">Atención Exclusiva</a></li>-->
                                <!--<li><a href="<php echo $path ?>personas/patagonia-singular/eventos-y-novedades/index.php">Eventos y Novedades</a></li>-->
							</ul>
						</li>
						<!--<li class="nav-item"><a href="<php echo $path ?>patagoniaon/index.php" target="_blank" class="nav-lnk">PATAGONIA ON</a></li>-->
						<li class="nav-item"><a href="#" class="nav-lnk ">PATAGONIA ON</a>
							<ul class="list-unstyled submenu">
                                <li><a href="../patagoniaon/index.php" target="_blank">Patagonia ON</a></li>
								<li><a href="../personas/productos-y-servicios/patagonia-universitaria.php">Patagonia ON Universitaria</a></li>
							</ul>
						</li>
						<li class="nav-item"><a href="#" class="nav-lnk ">PRODUCTOS Y SERVICIOS</a>
							<ul class="list-unstyled submenu">
                                <li><a href="../personas/apple-pay.php">Apple Pay</a></li>
                                <li><a href="../personas/productos-y-servicios/caja-de-seguridad.php">Caja de Seguridad</a></li>
                                <li><a href="../personas/productos-y-servicios/comercio-exterior/productos.php">Comercio exterior</a></li>
								<!--<li><a href="<php echo $path ?>personas/productos-y-servicios/beneficios-wapa.php">Comercios WAPA</a></li>-->
								<li><a href="../personas/cuotifica-al-toque.php">Cuotificá al Toque</a></li>
								<li><a href="../personas/google-pay.php">Google Pay</a></li>
                                <li><a href="../personas/productos-y-servicios/inversiones.php">Inversiones</a></li>
                                <li><a href="../personas/jubilados/index.php">Jubilados</a></li>
                                <li><a href="../personas/productos-y-servicios/patagonia-para-menores.php">Patagonia para Menores</a></li>
                                <!--<li><a href="<php echo $path ?>personas/productos-y-servicios/patagonia-universitaria.php">Patagonia Universitaria</a></li>-->
                                <li><a href="../personas/productos-y-servicios/prestamos.php">Prestamos</a></li>
                                <li><a href="../personas/seguros/index.php">Seguros</a></li>
                                <li><a href="../personas/productos-y-servicios/tarjetas-de-credito/visa.php">Tarjetas de crédito</a></li>
								<li><a href="../personas/productos-y-servicios/tarjetas-de-debito/patagonia-24.php">Tarjetas de débito</a></li>
							</ul>
						</li>
						<!-- FIN PERSONAS -->
						                        
                                                
                                                
                        						
												
												
						
											</ul>
				</div>
			</div>
		</nav>
	</div>
</div>

<div class="mobile-nav-bar">
	<ul class="list-unstyled">
        
        <!-- PERSONAS -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">PERSONAS <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="index.php" class="">HOME</a></li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA CLÁSICA</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../personas/patagonia-clasica/patagonia-ahorro/productos.php">Patagonia Ahorro</a></li>
                        <li><a href="../personas/patagonia-clasica/paquete/productos.php">Patagonia Clásica</a></li>
                        <!--<li><a href="<php echo $path ?>personas/patagonia-clasica/mas/productos.php">Patagonia Clásica Más</a></li>-->
                        <li><a href="../personas/patagonia-clasica/premium/productos.php">Patagonia Clásica Premium</a></li>
                        <li><a href="../personas/patagonia-clasica/patagonia-sueldo/productos.php">Patagonia Sueldo</a></li>
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA PLUS</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../personas/patagonia-plus/productos.php">Patagonia Plus</a></li>
                        <li><a href="../personas/patagonia-plus/premium/productos.php">Patagonia Plus Premium</a></li>
                    </ul>						
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA SINGULAR</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../personas/patagonia-singular/paquete/propuesta.php">Patagonia Singular</a></li>
                        <li><a href="../personas/patagonia-singular/beneficios-exclusivos.php">Beneficios Exclusivos</a></li>
                        <!--<li><a href="<php echo $path ?>personas/patagonia-singular/atencion-exclusiva/index.php">Atención Exclusiva</a></li>-->
                        <!--<li><a href="<php echo $path ?>personas/patagonia-singular/eventos-y-novedades/index.php">Eventos y Novedades</a></li>-->
                    </ul>
                </li>
				<!--<li class="nav-sub-item"><a href="<php echo $path ?>patagoniaon/index.php" target="_blank">PATAGONIA ON</a></li>-->
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA ON</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../patagoniaon/index.php" target="_blank">Patagonia ON</a></li>
						<li><a href="../personas/productos-y-servicios/patagonia-universitaria.php">Patagonia ON Universitaria</a></li>
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PRODUCTOS Y SERVICIOS</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../personas/apple-pay.php">Apple Pay</a></li>
                        <li><a href="../personas/productos-y-servicios/caja-de-seguridad.php">Caja de Seguridad</a></li>
                        <li><a href="../personas/productos-y-servicios/comercio-exterior/productos.php">Comercio exterior</a></li>
						<!--<li><a href="<php echo $path ?>personas/productos-y-servicios/beneficios-wapa.php">Comercios WAPA</a></li>-->
						<li><a href="../personas/cuotifica-al-toque.php">Cuotificá al Toque</a></li>
						<li><a href="../personas/google-pay.php">Google Pay</a></li>
                        <li><a href="../personas/productos-y-servicios/inversiones.php">Inversiones</a></li>
                        <li><a href="../personas/jubilados/index.php">Jubilados</a></li>
                        <li><a href="../personas/productos-y-servicios/patagonia-para-menores.php">Patagonia para Menores</a></li>
                        <!--<li><a href="<php echo $path ?>personas/productos-y-servicios/patagonia-universitaria.php">Patagonia Universitaria</a></li>-->
                        <li><a href="../personas/productos-y-servicios/prestamos.php">Prestamos</a></li>
                        <li><a href="../personas/seguros/index.php">Seguros</a></li>
                        <li><a href="../personas/productos-y-servicios/tarjetas-de-credito/visa.php">Tarjetas de crédito</a></li>
                        <li><a href="../personas/productos-y-servicios/tarjetas-de-debito/patagonia-24.php">Tarjetas de débito</a></li>
                    </ul>
                </li>
			</ul>
		</li>
        <!-- FIN PERSONAS -->
        
        <!-- NYPS -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">PROFESIONALES Y COMERCIOS <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../nyps/index.php" class="">HOME</a></li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA CLÁSICA</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../nyps/patagonia-clasica/premium/productos.php">Patagonia Clásica Premium</a></li>
                        <li><a href="../nyps/patagonia-clasica/patagonia-emprendimiento/productos.php">Patagonia Emprendimiento</a></li>
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA PLUS</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../nyps/patagonia-plus/productos.php">Patagonia Plus</a></li>
                        <li><a href="../nyps/patagonia-plus/premium/productos.php">Patagonia Plus Premium</a></li>
                    </ul>						
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA SINGULAR</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../nyps/patagonia-singular/paquete/propuesta.php">Patagonia Singular</a></li>
                        <li><a href="../nyps/patagonia-singular/beneficios-exclusivos.php">Beneficios Exclusivos</a></li>
                        <!--<li><a href="<php echo $path ?>nyps/patagonia-singular/eventos-y-novedades/index.php">Eventos y Novedades</a></li>-->
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PRODUCTOS Y SERVICIOS</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../nyps/productos-y-servicios/tarjetas-de-debito/patagonia-24.php">Tarjetas de débito</a></li>
                        <li><a href="../nyps/productos-y-servicios/tarjetas-de-credito/visa.php">Tarjetas de crédito</a></li>
                        <li><a href="../nyps/productos-y-servicios/prestamos.php">Prestamos</a></li>
                        <li><a href="../nyps/seguros/index.php">Seguros</a></li>
                        <li><a href="../nyps/productos-y-servicios/inversiones.php">Inversiones</a></li>
                        <li><a href="../nyps/productos-y-servicios/comercio-exterior/productos.php">Comercio exterior</a></li>
                        <li><a href="../nyps/productos-y-servicios/caja-de-seguridad.php">Caja de Seguridad</a></li>
                        <li><a href="../nyps/productos-y-servicios/factura-electronica.php">Factura electrónica</a></li>
                        <li><a href="../nyps/productos-y-servicios/pagos-afip.php">Pagos AFIP</a></li>
                        <!--<li><a href="<php echo $path ?>nyps/productos-y-servicios/soluciones-para-tu-empresa.php">Soluciones para tu empresa</a></li>-->
                        <!--<li><a href="<php echo $path ?>nyps/productos-y-servicios/comercios-patagonia.php">Comercios Patagonia</a></li>-->
						<li><a href="../nyps/productos-y-servicios/wapa.php">WAPA</a></li>
                    </ul>
                </li>
			</ul>		
		</li>
        <!-- FIN NYPS -->
        
        <!-- PYME -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">PYME <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../pyme/index.php" class="">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">CUENTAS</a>
					<ul class="list-unstyled submenu">
                        <li><a href="../pyme/cuentas/pequenas-empresas.php">Pyme Pequeñas Empresas</a></li>
				        <li><a href="../pyme/cuentas/medianas-empresas.php">Pyme Medianas Empresas</a></li>
                        <!--
						<li><a href="../pyme/cuentas/patagonia-empresario.php">Patagonia Empresario</a></li>
						<li><a href="../pyme/cuentas/patagonia-empresario-premier.php">Patagonia Empresario Premier</a></li>
						<li><a href="../pyme/cuentas/patagonia-empresa.php">Patagonia Empresa</a></li>
                        -->
                        <!--<li><a href="../pyme/cuentas/patagonia-comercio.php">Patagonia Comercio</a></li>-->
                        <li><a href="../pyme/cuentas/patagonia-consorcio.php">Patagonia Consorcio</a></li>
						<li><a href="../pyme/cuentas/cuenta-corriente.php">Cuenta Corriente</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA SUELDO</a>
					<ul class="list-unstyled submenu">
						<li><a href="../pyme/patagonia-sueldo/servicios.php">Servicios</a></li>
						<li><a href="../pyme/patagonia-sueldo/preguntas-frecuentes.php">Preguntas Frecuentes</a></li>
						<li><a href="../pyme/patagonia-sueldo/guia-implementacion.php">Guía de Implementación</a></li>
					</ul>
				</li>						
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">COMERCIO EXTERIOR</a>
					<ul class="list-unstyled submenu">
						<li><a href="../pyme/comercio-exterior/solicitud-electronica.php">Solicitud Electrónica</a></li>
						<li><a href="../pyme/comercio-exterior/productos.php">Productos</a></li>
						<li><a href="../pyme/comercio-exterior/otros-servicios.php">Servicios</a></li>
						<!--<li><a href="<php echo $folder_pymeCexterior ?>financiaciones.php">Financiaciones</a></li>-->
                        <li><a href="../pyme/comercio-exterior/herramientas-para-exportar.php">Herramientas para Exportar</a></li>
						<li><a href="../pyme/comercio-exterior/marco-regulatorio/normas-y-regulaciones.php">Marco Regulatorio</a></li>
					</ul>
				</li>						
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">FINANCIACIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../pyme/financiacion/patagonia-leasing.php">Patagonia Leasing</a></li>
						<li><a href="../pyme/financiacion/mercado-capitales.php">Mercado de Capitales</a></li>
						<li><a href="../pyme/financiacion/alternativas-de-financiacion.php">Alternativas de Financiación</a></li>
					</ul>
				</li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">SEGUROS</a>
					<ul class="list-unstyled submenu">
						<li><a href="../pyme/seguros/protege-tus-bienes/integral-comercio.php">Protegé tus Bienes</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">INVERSIONES</a>
					<ul class="list-unstyled submenu">
						<li><a href="../pyme/inversiones/plazo-fijo.php">Plazo Fijo</a></li>
						<li><a href="../pyme/inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
						<li><a href="../pyme/inversiones/fidecomisos-financieros.php">Fidecomisos Financieros</a></li>
					</ul>
				</li>						
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">SERVICIOS</a>
					<ul class="list-unstyled submenu">
						<li><a href="../pyme/servicios/recaudaciones.php">Recaudaciones</a></li>
						<li><a href="../pyme/servicios/pagos.php">Pagos</a></li>
						<li><a href="../pyme/servicios/tarjetas-comerciales.php">Tarjetas Comerciales</a></li>
						<li><a href="../pyme/servicios/comercios-patagonia.php">Comercios Patagonia</a></li>
                        <li><a href="../pyme/servicios/pago-de-servicios.php">Pago de Servicios</a></li>
						<li><a href="../pyme/servicios/interbanking.php">Interbanking</a></li>
						<li><a href="../pyme/servicios/interfacturas.php">Interfacturas</a></li>
						<li><a href="../pyme/servicios/pagos-afip.php">Pagos AFIP</a></li>
						<li><a href="../pyme/servicios/wapa.php">WAPA</a></li>
					</ul>
				</li>
			</ul>		
		</li>
        <!-- FIN PYME -->
        
        <!-- AGRO -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">AGRO <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../agro/index.php" class="">HOME</a></li>
                <!-- -->
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">OFERTA AGRO</a>
					<ul class="list-unstyled submenu">
                    	<!--<li><a href="<php echo $folder_agroFinanciacion ?>insumos.php">Insumos en USD</a></li>-->
                        <li><a href="../agro/convenios/acuerdos-y-beneficios.php">Acuerdos y convenios</a></li>
						<li><a href="../agro/financiacion/maquinaria-agricola.php">Financiación Maquinaria Agrícola</a></li>
						<li><a href="../agro/seguros/campo.php">Seguros para tu campo</a></li>
					</ul>
				</li>
                <!-- -->
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">TARJETA PATAGONIA AGRO</a>
					<ul class="list-unstyled submenu">
						<li><a href="../agro/tarjeta-patagonia-agro/para-usuarios.php">Para Usuarios</a></li>
						<li><a href="../agro/tarjeta-patagonia-agro/para-comercios.php">Para Comercios</a></li>
						<li><a href="../agro/tarjeta-patagonia-agro/acuerdo-tasa-0.php">Tarjetas Agro Convenios Preferenciales</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="../agro/cuenta-agro/cuenta-agro.php" class="">CUENTA AGRO</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">FINANCIACIÓN</a>
					<ul class="list-unstyled submenu">
                        <li><a href="../agro/insumos/index.php">Insumos</a></li>
                        <li><a href="../agro/financiacion/maquinaria-agricola.php">Maquinarias</a></li>
                        <li><a href="../empresas/financiacion/convenios-de-financiacion.php">Camiones</a></li>
						<!--<li><a href="<php echo $folder_agroFinanciacion ?>capital-de-trabajo.php">Capital de Trabajo</a></li>-->
						<!--<li><a href="<php echo $folder_agroFinanciacion ?>proyectos-de-inversion.php">Proyectos de Inversión</a></li>-->
						<!--<li><a href="<php echo $folder_agroFinanciacion ?>creditos-para-hacienda.php">Créditos para Hacienda</a></li>-->
						<!--<li><a href="<php echo $folder_agroFinanciacion ?>leasing-y-prendarios.php">Leasing y Prendarios</a></li>-->
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">INVERSIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../agro/inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
						<li><a href="../agro/inversiones/fidecomisos-financieros.php">Fidecomisos Financieros</a></li>
						<li><a href="../agro/inversiones/plazos-fijos.php">Plazos Fijos</a></li>
					</ul>
				</li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">COMERCIO EXTERIOR</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../agro/comercio-exterior/solicitud-electronica.php">Solicitud Electrónica</a></li>
                        <li><a href="../agro/comercio-exterior/productos.php">Productos</a></li>
                        <li><a href="../agro/comercio-exterior/otros-servicios.php">Servicios</a></li>
                        <li><a href="../agro/comercio-exterior/herramientas-para-exportar.php">Herramientas para Exportar</a></li>
                        <li><a href="../agro/comercio-exterior/marco-regulatorio/normas-y-regulaciones.php">Marco Regulatorio</a></li>
                    </ul>
                </li>
                <!--
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">SERVICIOS</a>
					<ul class="list-unstyled submenu">
						<li><a href="../agro/servicios/centro-atencion-empresas.php">Centro de Atención para Empresas</a></li>
					</ul>
				</li>
                -->
                <!-- -->
                <li class="nav-sub-item"><a href="../agro/seguros/campo.php" class="">SEGUROS</a></li>
                <!-- -->
			</ul>
		</li>
        <!-- FIN AGRO -->
        
        <!-- EMPRESAS -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">EMPRESAS <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../empresas/index.php" class="">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA SUELDO</a>
					<ul class="list-unstyled submenu">
						<li><a href="../empresas/patagonia-sueldo/servicios.php">Servicios</a></li>
						<li><a href="../empresas/patagonia-sueldo/preguntas-frecuentes.php">Preguntas Frecuentes</a></li>
						<li><a href="../empresas/patagonia-sueldo/guia-implementacion.php">Guía de Implementación</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">COMERCIO EXTERIOR</a>
					<ul class="list-unstyled submenu">
						<li><a href="../empresas/comercio-exterior/solicitud-electronica.php">Solicitud Electrónica</a></li>
						<li><a href="../empresas/comercio-exterior/productos.php">Productos</a></li>
						<li><a href="../empresas/comercio-exterior/otros-servicios.php">Servicios</a></li>
						<!--<li><a href="<php echo $folder_Cexterior ?>financiaciones.php">Financiaciones</a></li>-->
                        <li><a href="../empresas/comercio-exterior/herramientas-para-exportar.php">Herramientas para Exportar</a></li>
						<li><a href="../empresas/comercio-exterior/marco-regulatorio/normas-y-regulaciones.php">Marco Regulatorio</a></li>
					</ul>
				</li>
                <!-- -->
				<!--<li class="nav-sub-item"><a href="../empresas/comunidades-de-negocios/index.php" class="">COMUNIDADES DE NEGOCIOS</a></li>-->
                <!-- -->
				<li class="nav-sub-item"><a href="index.php" class="nav-lnk ">COMERCIOS PATAGONIA</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">FINANCIACIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../empresas/financiacion/patagonia-leasing.php">Patagonia Leasing</a></li>
						<li><a href="../empresas/financiacion/mercado-capitales.php">Mercado Capitales</a></li>
						<li><a href="../empresas/financiacion/alternativas-de-financiacion.php">Alternativas de Financiación</a></li>
                        <li><a href="../empresas/financiacion/convenios-de-financiacion.php">Convenios de Financiación</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">INVERSIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../empresas/inversiones/plazos-fijos.php">Plazos Fijos</a></li>
						<li><a href="../empresas/inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
						<li><a href="../empresas/inversiones/compra-venta-titulos-acciones.php">Compra - Venta de Títulos y Acciones</a></li>
						<li><a href="../empresas/inversiones/custodia-de-titulos.php">Custodia de Títulos</a></li>
						<li><a href="../empresas/inversiones/fidecomisos-financieros.php">Fidecomisos Financieros</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">SERVICIOS</a>
					<ul class="list-unstyled submenu">
                        <li><a href="../empresas/patagonia-movil-empresas.php">Patagonia Móvil Empresas</a></li>
						<li><a href="../empresas/servicios/pagos.php">Pagos</a></li>
						<li><a href="../empresas/servicios/recaudaciones.php">Recuadaciones</a></li>
						<li><a href="../empresas/servicios/pago-de-servicios.php">Pago de Servicios</a></li>
						<li><a href="../empresas/servicios/interbanking.php">Interbanking</a></li>
						<li><a href="../empresas/servicios/interfacturas.php">Interfacturas</a></li>
						<li><a href="../empresas/servicios/tarjetas-comerciales.php">Tarjetas Comerciales</a></li>
                        <!-- -->
						<!--<li><a href="../empresas/servicios/comercios-patagonia.php">Comercios Patagonia</a></li>-->
                        <!-- -->
                        <li><a href="../empresas/servicios/centro-atencion-empresas.php">Centro de Atención para Empresas</a></li>
					</ul>
				</li>
			</ul>
		</li>
        <!-- FIN EMPRESAS -->
        
        <!-- SECTOR PÚBLICO -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">SECTOR PÚBLICO <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../sector-publico/index.php" class="">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">INVERSIONES</a>
					<ul class="list-unstyled submenu">
						<li><a href="../sector-publico/inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
						<li><a href="../sector-publico/inversiones/plazo-fijo.php">Plazo Fijo</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">SERVICIOS</a>
					<ul class="list-unstyled submenu">
						<li><a href="../sector-publico/servicios/servicio-de-recaudacion.php">Servicio de Recaudación</a></li>
						<li><a href="../sector-publico/servicios/servicio-de-pagos.php">Servicio de Pagos</a></li>
						<li><a href="../sector-publico/servicios/servicios-para-personal.php">Servicios para el Personal</a></li>
						<li><a href="../sector-publico/servicios/financiacion.php">Financiación</a></li>
						<li><a href="../sector-publico/servicios/otros-servicios.php">Servicios</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">PROGRAMA UNIVERSIDADES</a>
					<ul class="list-unstyled submenu">
						<li><a href="../sector-publico/programa-universidades/relacion-institucional.php">Relación Institucional</a></li>
						<li><a href="../sector-publico/programa-universidades/docentes-yno-docentes.php">Docentes y No Docentes</a></li>
						<li><a href="../sector-publico/programa-universidades/alumnos.php">Alumnos</a></li>
						<li><a href="../sector-publico/programa-universidades/graduados.php">Graduados</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">BENEFICIOS RÍO NEGRO</a>
					<ul class="list-unstyled submenu">
						<li><a href="../sector-publico/rio-negro/presencia.php">Presencia en Río Negro</a></li>
                        <li><a href="../sector-publico/rio-negro/propuesta-valor.php">Propuesta de valor exclusiva</a></li>
					</ul>
				</li>
			</ul>
		</li>
        <!-- FIN SECTOR PUBLICO -->
        
        <!-- INSTITUCIONAL -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">INSTITUCIONAL <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../institucional/index.php" class="">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">BANCO PATAGONIA</a>
					<ul class="list-unstyled submenu">
						<li><a href="../institucional/banco-patagonia/historia.php">Historia</a></li>
						<li><a href="../institucional/banco-patagonia/mercado-de-capitales.php">Mercado de Capitales</a></li>
						<li><a href="../institucional/banco-patagonia/patagonia-inversora.php">Patagonia Inversora</a></li>
						<li><a href="../institucional/banco-patagonia/patagonia-valores-sa.php">Patagonia Valores S.A</a></li>
						<li><a href="https://bp.bancopatagonia.com.ar/relacion-con-inversores/es/institucional" target="_blank">Relación con Inversores</a></li>
						<li><a href="../institucional/banco-patagonia/desarrollo-humano.php">Desarrollo Humano</a></li>
						<li><a href="../institucional/banco-patagonia/sustentabilidad.php">Sustentabilidad</a></li>
						<li><a href="../institucional/banco-patagonia/politicas-aml-cft.php">Póliticas AML/CFT</a></li>
						<li><a href="../institucional/banco-patagonia/disciplina-del-mercado.php">Disciplina de Mercado</a></li>
                        <li><a href="../institucional/banco-patagonia/asistencia-a-vinculados.php">Asistencia a vinculados</a></li>
                        <li><a href="../institucional/banco-patagonia/etica-e-integridad.php">Ética e Integridad</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">ORGANIZACIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../institucional/organizacion/accionistas.php">Accionistas</a></li>
						<li><a href="../institucional/organizacion/autoridades.php">Autoridades</a></li>
                        <li><a href="../institucional/organizacion/comites.php">Comités</a></li>
						<li><a href="../institucional/organizacion/sector-financiero.php">Sector Financiero</a></li>
					</ul>
				</li>
			</ul>
		</li>
        <!-- FIN INSTITUCIONAL -->
        
        <li class="nav-main-item"><a href="https://tunuevacuenta.bancopatagonia.com.ar/?utm_source=sitiowebbp&utm_medium=sitiowebbp%20banner%20home&utm_campaign=onboarding_sitiowebp_bannerhome" target="_blank" style="text-transform: none;">Hacete cliente</a></li>		<li class="nav-main-item"><a href="../preguntas-frecuentes/index.php" class="" style="text-transform: none;">Ayuda</a></li>
		<!--<li class="nav-main-item"><a href="<php echo $folder_canales ?>index.php" class="<php echo $canales ?>" style="text-transform: none;">Canales de Atención</a></li>-->
		<!--<li class="nav-main-item"><a href="http://sucursalesycajeros.bancopatagonia.com.ar/sucursales.html" target="_blank" style="text-transform: none;">Sucursales y Cajeros</a></li>-->
		<!--<li class="nav-main-item"><a href="<php echo $folder_contactenos ?>index.php" class="<php echo $contactenos ?>" style="text-transform: none;">Contactanos</a></li>-->
        <!--<li class="nav-main-item"><a href="<php echo $path ?>ayuda/index.php" class="<php echo $ayuda ?>" style="text-transform: none;">Ayuda</a></li>-->
	</ul>
</div>	<!-- -->
    <section class="sec-head" title="Cuotificá al toque">
        <div class="sec-pic-head" id="head-cuotifica">
        </div>
	</section>
	<!-- -->
	<section class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
				<ol class="breadcrumb">
					<li><a href="index.php">Personas</a></li>
                    <li class="active">Cuotificá al toque</li>
				</ol>
			</div>
		</div>
	</section>
	<!-- -->
	<section class="head-xl" id="head-xl-cuotifica">
		<div class="container">
			<div class="row">
				<div class="col-md-12 col-sm-12 col-xs-12">
					<div class="text-data">
						<h1 class="clr-azul"><strong>Ahora con Cuotificá al toque, podés pagar hasta en 6 cuotas fijas tus compras con QR desde Patagonia Móvil. </strong></h1>
						<h2 class="clr-verde"><strong>Accedés a una financiación 100% online y el monto se te acredita al instante en tu cuenta.</strong></h2>
						<a class="btn-store" href="#"><img src="../assets/images/layout/logo-patagonia-movil.svg" alt="Logo Patagonia Móvil"></a>
					</div>
				</div>
			</div>
		</div>
    </section>
	<!-- -->
    <!--<section id="cat-sec-head" class="sec-head" title="Si sos cliente ON podés comprar lo que querés y pagar en 3 cuotas con tasa del 1%.(1) ¡Sí, del 1%! &#x1F973">
        <div class="sec-pic-head" id="section-patagonia-on">
        </div>
	</section>-->
	<!-- -->
	<section id="content-xl-cuotifica">
		<div class="container">
			<div class="row">
				<div class="col-md-12 col-sm-12 col-xs-12">
					<div class="text-data">
						<h2 class="bgd-azul clr-blanco">¿Cómo funciona?</h2>
						<!--<ul>
							<li>
								<img class="cat-icon" src="images/cuotifica/icon-patagonia-movil.svg" alt="Icono Patagonia Móvil">
								<h3 class="clr-azul">Entrá a<br><strong> Patagonia Móvil.</strong></h3>
								<img src="images/cuotifica/screen-patagonia-movil.png" alt="Entrá a Patagonia Móvil" class="img-responsive">
							</li>
							<li>
								<img class="cat-icon" src="images/cuotifica/icon-qr.svg" alt="Icono QR">
								<h3 class="clr-azul">Escaneá<br><strong> el QR.</strong></h3>
								<img src="images/cuotifica/screen-qr.png" alt="Escaneá el QR" class="img-responsive">
							</li>
							<li>
								<img class="cat-icon" src="images/cuotifica/icon-medio-pago.svg" alt="Icono medio de pago">
								<h3 class="clr-azul">Seleccioná el<br><strong> medio de pago.</strong></h3>
								<img src="images/cuotifica/screen-medio-pago.png" class="img-responsive" alt="Seleccioná el medio de pago">
							</li>
							<li>
								<img class="cat-icon" src="images/cuotifica/icon-cantidad-cuotas.svg" alt="Icono cuotas">
								<h3 class="clr-azul">Elegí la<strong> cantidad<br> de cuotas</strong> que<br> querés pagar.</h3>
								<img src="images/cuotifica/screen-cantidad-cuotas.png" class="img-responsive" alt="Elegí la cantidad de cuotas que querés pagar">
							</li>
							<li>
								<img class="cat-icon" src="images/cuotifica/icon-detalle-pago.svg" alt="Icono detalle del pago">
								<h3 class="clr-azul">Revisá el<strong> detalle<br> del pago.</strong></h3>
								<img src="images/cuotifica/screen-detalle-pago.png" class="img-responsive" alt="Revisá el detalle del pago">
							</li>
							<li>
								<img class="cat-icon" src="images/cuotifica/icon-confirmacion.svg" alt="Icono confirmación">
								<h3 class="clr-azul"><strong>Confirmalo.</strong></h3>
								<img src="images/cuotifica/screen-confirmacion.png" class="img-responsive" alt="Confirmalo">
							</li>
							<li>
								<img class="cat-icon" src="images/cuotifica/icon-primera-cuota-30-dias.svg" alt="Icono 30 días">
								<h3 class="clr-azul"><strong class="clr-verde">¡Y listo!</strong> Tu primera cuota la pagás recién a los <strong>30 días.</strong></h3>
								<img src="images/cuotifica/screen-primera-cuota-30-dias.png" class="img-responsive" alt="Tu primera cuota la pagás recién a los 30 días">
							</li>
						</ul>-->
						<div class="row">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<figure class="video" style="margin-bottom: 0;">
									<video controls autoplay>
										<source src="videos/video-cuotificar.mp4" type="video/mp4">
									</video>
								</figure>
							</div>
						</div>
						<!-- -->
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- -->
	<!--<section class="container">
		<div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="text-data">
					<hr>
				</div>
            </div>
		</div>
	</section>-->
	<!-- -->
	<section class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
				<div class="text-data">
					<h2><strong>Recordá que es necesario tener <img style="width: 58px; margin: -2px 0px 0px 2px;" src="../assets/images/layout/logo-modo-azul.svg" alt="Modo"> en Patagonia Móvil</strong> - <a href="modo.php#adhesion"><u>¡Conocé como adherirte en simples pasos ingresando acá!</u></a></h2>
					<!-- -->
					<hr>
					<!-- -->
					<h2><strong>¿Todavía no descargaste Patagonia Móvil?</strong></h2>
					<p>Dale un click acá y ya lo tenés</p>
					<a class="btn-store" href="#googleplay" data-toggle="modal"><img src="../assets/images/layout/logo-google-play.svg" alt="Google Play"></a>
<a class="btn-store" href="#appstore" data-toggle="modal"><img src="../assets/images/layout/logo-app-store.svg" alt="App Store"></a>

<!-- EXTERNAL LNK -->
<div class="modal fade" id="googleplay">
    <div class="modal-dialog">
        <div class="modal-content">
            <!-- -->
			<div class="modal-header">
    <button type="button" class="close" data-dismiss="modal"><span>X</span></button>
    <span class="modal-title"><img src="../assets/images/layout/logo.svg" width="206" height="22" alt="Banco Patagonia"/></span>
</div>
<div class="modal-body">
    <div class="external-legend">
        <p>Estás abandonado el sitio de Banco Patagonia S.A. El usuario reconoce que las hiperconexiones con otro medios de Internet son a tu propio riesgo. Banco Patagonia no investiga, verifica, controla ni responde el contenido, la exactitud, las opiniones expresada y otras conexiones suministradas por estos medios.</p>
    </div>
</div>			<!-- -->
            <div class="modal-footer">
                <a href="https://play.google.com/store/apps/details?id=ar.com.bcopatagonia.android" target="_blank" class="cta-btn">Aceptar</a>
                <a href="#" class="cta-btn-cancel" data-dismiss="modal">Cancelar</a>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="appstore">
    <div class="modal-dialog">
        <div class="modal-content">
            <!-- -->
			<div class="modal-header">
    <button type="button" class="close" data-dismiss="modal"><span>X</span></button>
    <span class="modal-title"><img src="../assets/images/layout/logo.svg" width="206" height="22" alt="Banco Patagonia"/></span>
</div>
<div class="modal-body">
    <div class="external-legend">
        <p>Estás abandonado el sitio de Banco Patagonia S.A. El usuario reconoce que las hiperconexiones con otro medios de Internet son a tu propio riesgo. Banco Patagonia no investiga, verifica, controla ni responde el contenido, la exactitud, las opiniones expresada y otras conexiones suministradas por estos medios.</p>
    </div>
</div>			<!-- -->
            <div class="modal-footer">
                <a href="https://apps.apple.com/ar/app/patagonia-m%C3%B3vil/id1178757002?l=en&mt=8" target="_blank" class="cta-btn">Aceptar</a>
                <a href="#" class="cta-btn-cancel" data-dismiss="modal">Cancelar</a>
            </div>
        </div>
    </div>
</div>
<!-- FIN EXTERNAL LNK -->				</div>
            </div>
        </div>
	</section>
	<!-- PRE FOOTER -->
	<section class="container">
        <div class="row legal-int">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <p>EL OTORGAMIENTO DEL PRÉSTAMO SE ENCUENTRA SUJETO A LA APROBACIÓN DE SUS CONDICIONES CREDITICIAS Y DE CONTRATACIÓN DISPUESTAS POR BANCO PATAGONIA S.A. CONDICIONES FINANCIERAS AL 15/04/2014, LAS CUALES PODRÁN SER CONSULTADAS EN PATAGONIA Móvil ANTES DE SU ACEPTACIÓN, EN WWW. http://BANCOPATAGONIA.COM.AR Y EN CUALQUIERA DE NUESTRAS SUCURSALES.</p>
				<p>PARA COMPRAS ABONADAS EN CUOTAS POR USUARIOS DE SERVICIOS FINANCIEROS SE APLICARÁ: TASA NOMINAL ANUAL: 81% - TASA EFECTIVA ANUAL: 119,06% - COSTO FINANCIERO TOTAL EXPRESADO EN TASA EFECTIVA ANUAL (CFTNA).</p>
				<p style="font-size:50px;">C.F.T.E.A. SIN IVA: 119,06%</p>
				<p style="font-size:50px;">C.F.T.E.A. CON IVA: 156,67%</p>
				<!--<p>(1) CARTERA DE CONSUMO – PROMOCIÓN VÁLIDA EN LA REPÚBLICA ARGENTINA DESDE EL 01/05/2024 HASTA EL 30/09/2024, AMBAS FECHAS INCLUÍDAS, EXCLUSIVA PARA CLIENTES PERTENECIENTES AL SEGMENTO PATAGONIA ON. EL OTORGAMIENTO DEL PRÉSTAMO SE ENCUENTRA SUJETO A LA APROBACIÓN DE SUS CONDICIONES CREDITICIAS Y DE CONTRATACIÓN DISPUESTAS POR BANCO PATAGONIA S.A., LAS CUALES PODRÁN SER CONSULTADAS EN PATAGONIA Móvil ANTES DE SU ACEPTACIÓN, EN WWW. http://BANCOPATAGONIA.COM.AR Y EN CUALQUIERA DE NUESTRAS SUCURSALES. PARA COMPRAS ABONADAS EN CUOTAS POR USUARIOS DE SERVICIOS FINANCIEROS SE APLICARÁ: TASA NOMINAL ANUAL: 1% - TASA EFECTIVA ANUAL: 1% - COSTO FINANCIERO TOTAL EXPRESADO EN TASA EFECTIVA ANUAL (CFTNA).</p>
				<p style="font-size:50px;">C.F.T.E.A. SIN IVA: 1,00%</p>
				<p style="font-size:50px;">C.F.T.E.A. CON IVA: 1,22%</p>-->
				<p>IMPORTE MÁXIMO A OTORGAR PARA PRÉSTAMOS SOLICITADOS POR PATAGONIA MÓVIL: HASTA $150.000 (PESOS CIENTO CINCUENTA MIL). LA ACREDITACIÓN DEL MONTO DEL PRÉSTAMO SE EFECTUARÁ EN SU CAJA DE AHORRO EN PESOS. EL CAPITAL DEBERÁ SER REEMBOLSADO EN CUOTAS MENSUALES Y CONSECUTIVAS. EL IMPORTE DE CADA CUOTA RESULTARÁ DE APLICAR EL “SISTEMA DE AMORTIZACIÓN FRANCÉS” DE INTERÉS SIMPLE E INCLUIRÁ LOS INTERESES COMPENSATORIOS A LA TASA FIJA PACTADA, EL I.V.A. Y LOS IMPUESTOS LOCALES QUE PUDIERAN CORRESPONDER DE ACUERDO A LA JURISDICCIÓN DEL CLIENTE.</p>
				<p>PARA UTILIZAR PATAGONIA MÓVIL DEBERÁ: (I) ENCONTRARSE PREVIAMENTE ADHERIDO A PATAGONIAEBANK; (II) POSEER UN TELÉFONO CELULAR CON SISTEMA OPERATIVO ANDROID O IOS (IPHONE) CON ACCESO A INTERNET Y SERVICIO DE DATOS; (III) ACEPTAR PREVIAMENTE SUS TÉRMINOS Y CONDICIONES, LOS CUALES PODRÁN SER CONSULTADOS EN WWW.BANCOPATAGONIA.COM.AR O EN CUALQUIERA DE NUESTRAS SUCURSALES.</p>
				<p>SIEMPRE DESCARGUE LA APLICACIÓN DE TIENDAS OFICIALES, NO ACCEDA DESDE LINKS QUE PROVENGAN DE MAILS O SMS. LOS COSTOS DE LA DESCARGA, DEL USO DE LA APLICACIÓN Y EL DE LA NAVEGACIÓN, SERÁN LOS QUE COBRE LA EMPRESA DE TELEFONÍA CELULAR UTILIZADA POR EL CLIENTE Y SERÁN A SU EXCLUSIVO CARGO. BANCO PATAGONIA S.A. NO SERÁ RESPONSABLE POR LOS ERRORES EN EL SOFTWARE DE LA APLICACIÓN, NI POR LA SUSPENSIÓN, INTERRUPCIÓN O FALLA DEL SERVICIO PROVENIENTE DE UNA MEDIDA UNILATERAL DE SU EMPRESA DE TELEFONÍA CELULAR.</p>
				<p>Banco Patagonia nunca le solicitará que revele sus claves por ningún medio. Si recibe un e-mail o un llamado telefónico solicitándole sus claves personales, no lo responda. Nunca revele sus claves, datos personales o números de cuentas bancarias bajo ningún concepto. Ud. ha recibido este mensaje porque la empresa que lo remite considera que puede ser información de su interés.</p>
				<p>Ley 25.326, art. 27, inc. 3: El titular podrá en cualquier momento solicitar el retiro o bloqueo total a o parcial de su nombre de los bancos de datos a los que se refiere el presente artículo. Asimismo tiene la facultad de ejercer el derecho de acceso en forma gratuita a intervalos no inferiores a 6 meses. Art. 14 inc. 3) ley 25.326: lLa Dirección Nacional de Protección de Datos Personales tiene la atribución de atender denuncias y reclamos relativos al incumplimiento de normas sobre protección de datos personales. Banco Patagonia S.A. asume el carácter de Responsable Registrado ya que ha cumplimentado con todos los requisitos que exige esta ley.</p>
				<p>Los accionistas de Banco Patagonia S.A. (CUIT: 30-50000661- 3, Av. de Mayo 701 Piso 24 (C1084AAC), Ciudad Autónoma de Buenos Aires) limitan su responsabilidad a la integración de las acciones suscriptas. En virtud de ello, ni los accionistas mayoritarios de capital extranjero ni los accionistas locales o extranjeros, responden en exceso de la citada integración accionaria por las obligaciones emergentes de las operaciones concertadas por la entidad financiera. Ley 25.738.</p>
            </div>
        </div>
	</section>
    <!-- FIN PRE FOOTER -->
	<div class="container-fluid footer-bar">
	<div class="row">
		<footer class="container">
			<div class="row">
				<div class="col-md-12">
					<p class="flnks"><a href="../registro-nacional-base-datos.php">Registro Nacional de Base de Datos</a> <span>|</span>   <a href="../codigo-practicas-bancarias.php">Código de Prácticas Bancarias</a> <span>|</span>   <a href="../defensa-ley-consumidor.php">Defensa del Consumidor</a>
						<span>|</span>   <a href="https://www.argentina.gob.ar/produccion/defensadelconsumidor/formulario">Defensa de las y los consumidores. Para reclamos ingrese aquí</a><span>|</span> <br class="tbl"> <a href="../persona-expuesta-politicamente.php">Persona Expuesta Políticamente</a> <span class="tbl">|</span> <br class="dsk">
						
					<a href="../agencia-acceso-informacion-publica.php">Agencia de Acceso a la Información Pública</a> <span>|</span> <br class="tbl"> 
					<a href="../cnv-advertencia-publico-inversor.php">CNV - Advertencia al Público Inversor</a> <span>|</span> <a href="../docs/Idoneos.pdf" target="_blank"> Idóneos en Mercado de Capitales - CNV</a><span>|</span>   <a href="../codigo-proteccion-inversor.php">Código de Protección al Inversor</a> <span>|</span>   <a href="../clausulas-legales.php">Cláusulas Legales</a> <span>|</span> <a href="../resolucion-022021.php">Resol. 02/21 Dir.Gral. Defensa del consumidor Córdoba</a></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<p class="redes">
                        <span>Seguinos en:</span>
                        <!-- -->
                        <a href="https://www.facebook.com/BancoPatagonia/" target="_blank"><img src="../assets/images/layout/icon-facebook.svg" alt="Facebook"></a>
                        <a href="https://twitter.com/banco_patagonia" target="_blank"><img src="../assets/images/layout/icon-twitter.svg" alt="Twitter"></a>
                        <a href="https://www.instagram.com/banco_patagonia/" target="_blank"><img src="../assets/images/layout/icon-instagram.svg" alt="Instagram"></a>
                        <a href="https://www.youtube.com/user/bancopatagonia" target="_blank"><img src="../assets/images/layout/icon-youtube.svg" alt="Youtube"></a>
                        <!-- -->
                        <!--
                        <a href="https://www.facebook.com/BancoPatagonia/" target="_blank"><i class="fa fa-facebook-square"></i></a>
                        <a href="https://twitter.com/banco_patagonia" target="_blank"><i class="fa fa-twitter"></i></a>
                        <a href="https://www.instagram.com/banco_patagonia/" target="_blank"><i class="fa fa-instagram"></i></a>
                        <a href="https://www.youtube.com/user/bancopatagonia" target="_blank"><i class="fa fa-youtube-play"></i></a>
                        -->
                    </p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					                    <!---->
				    <p class="flegal">BANCO PATAGONIA S.A. ES UNA SOCIEDAD ANÓNIMA CONSTITUIDA BAJO LAS LEYES DE LA REPÚBLICA ARGENTINA CUYOS ACCIONISTAS LIMITAN SU RESPONSABILIDAD A LA INTEGRACIÓN DE LAS ACCIONES SUSCRITAS DE ACUERDO A LA LEY 19.550. POR CONSIGUIENTE, Y EN CUMPLIMIENTO DE LA LEY 25.738, SE INFORMA QUE NI LOS ACCIONISTAS MAYORITARIOS DE CAPITAL EXTRANJERO NI LOS ACCIONISTAS LOCALES O EXTRANJEROS RESPONDEN, EN EXCESO DE LA CITADA INTEGRACIÓN ACCIONARIA, POR LAS OBLIGACIONES EMERGENTES DE LAS OPERACIONES CONCERTADAS POR LA ENTIDAD FINANCIERA.</p>
                    <p class="flegal" style="font-size:10px;">Banco Patagonia S.A. - Agente de Liquidacion y Compensacion y Agente de Negociacion Integral, inscripto en CNV bajo el N° 66</p>
					<p class="flegal">© 2025 Banco Patagonia . Todos los derechos reservados. Prohibida la duplicación , distribución o almacenamiento en cualquier medio.</p>
				</div>
			</div>
		</footer>
	</div>
</div>
<div class="tbl mbl placeholder-shortlinks">
	<div class="container shortlinks">
		<div class="row">
            <!--<php if ($home_personas == false) { ?>
                <div class="col-sm-3 col-xs-3">
                    <a href="#"><span class="icon icon-contacto"></span></a>
                </div>
            <php } ?>-->
            			<div class="col-sm-3 col-xs-3">
				<a href="http://sucursalesycajeros.bancopatagonia.com.ar/sucursales.html" target="_blank"><span class="icon icon-sucursales"></span>Sucursales y Cajeros</a>
			</div>
			<div class="col-sm-3 col-xs-3">
				<a href="../preguntas-frecuentes/index.php"><span class="icon icon-contacto"></span>Ayuda</a>
			</div>
			<div class="col-sm-3 col-xs-3 last">
				<a href="../empresas/patagonia-ebank-empresas-mbl.php"><span class="icon icon-ebank"></span>Patagonia e-Bank</a>
			</div>
		</div>
	</div>
</div>	<script src="../assets/js/jquery-3.5.1.min.js"></script>
<script src="../assets/bootstrap/js/bootstrap.min.js"></script>
<script src="../assets/js/slick/slick.min.js"></script>
<script src="../assets/js/fancybox/jquery.fancybox.min.js"></script>
<script src="../assets/js/mtabs/jquery.bootstrap-responsive-tabs.min.js"></script>
<script src="../assets/js/funciones.js"></script>

<!-- Global site tag (gtag.js) - Google Analytics (original) -->
<!--
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-32588129-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-32588129-1');
</script>
-->

<!-- Google Analytics (version anterior / eventos ok)  -->
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');
  ga('create', 'UA-32588129-1', 'auto');
  ga('send', 'pageview');
</script>

<!-- GA4 - Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-C6LG1PT98X"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-C6LG1PT98X');
</script>

</body>
</html>