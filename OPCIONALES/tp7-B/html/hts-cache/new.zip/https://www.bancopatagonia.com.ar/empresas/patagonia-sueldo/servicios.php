<!DOCTYPE html>
<html lang="es">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
		<meta http-equiv="Pragma" content="no-cache">
		<meta http-equiv="Expires" content="0">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Banco Patagonia</title>
		<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-NL73B44');</script>
<!-- End Google Tag Manager -->

<link rel="shortcut icon" href="../../favicon.ico" type="image/x-icon"/>
<link href="../../assets/fonts/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="../../assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="../../assets/js/mtabs/bootstrap-responsive-tabs.css" rel="stylesheet" type="text/css">
<link href="../../assets/js/slick/slick.css" rel="stylesheet" type="text/css">
<link href="../../assets/js/fancybox/jquery.fancybox.min.css" rel="stylesheet" type="text/css">
<link href="../../assets/css/styles.css" rel="stylesheet" type="text/css">
<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->        <!-- SLIDES RESPONSIVE -->
        <style>
            /* DSK */
            #head-patagonia-sueldo {background-image: url(images/head-patagonia-sueldo-dsk.jpg)}

            @media screen and (max-width: 1200px) {
                /* TBT */
                #head-patagonia-sueldo {background-image: url(images/head-patagonia-sueldo-tbl.jpg); background-size: auto !important ;}
            }
            @media screen and (max-width: 560px) {
                /* MBL */
                #head-patagonia-sueldo {background-image: url(images/head-patagonia-sueldo-mbl.jpg)}
            }
        </style>
        <!-- -->
	</head>
<body>
	<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NL73B44"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

<div class="placeholder-bar">
	<div class="container-fluid header-bar">
		<div class="row">
			<header class="container">
				<div class="row">
					<div class="col-md-3 col-dsk-6 col-sm-6">
						<span class="c-hamburger c-hamburger--htx">
							<span>toggle menu</span>
						</span>
                        <!-- -->
                        <!--<img style="position: absolute; width: 42px; top: 20px; right: 40px;" class="dsk" src="<php echo $path ?>assets/images/layout/icon-verano-2022.svg">-->
                        <!-- -->
						<h1>
                            <!--<img style="position: absolute; width: 32px; top: 12px; left: 102px;" class="dsk" src="<php echo $path ?>assets/images/layout/icon-navidad-2021.svg">-->
                            <a href="../../index.php" class="main-logo">Banco Patagonia</a>
                        </h1>
					</div>
					<div class="col-md-9 col-dsk-6 col-sm-6">
						<div class="general-links">
							<ul class="list-unstyled">
                                								<li><a href="../../preguntas-frecuentes/index.php" class="">Ayuda</a></li>
								<!--<li><a href="<php echo $folder_canales ?>index.php" class="<php echo $canales ?>">Canales de atención</a></li>-->
								<!--<li><a href="http://sucursalesycajeros.bancopatagonia.com.ar/sucursales.html" target="_blank">Sucursales y cajeros</a></li>-->
								<!--<li><a href="<php echo $folder_contactenos ?>index.php" class="<php echo $contactenos ?>">Contactanos</a></li>-->
                                <!--<li><a href="<php echo $path ?>ayuda/index.php" class="<php echo $ayuda ?>">Ayuda</a></li>-->
							</ul>
						</div>
						<div class="top-links">
							<ul class="list-unstyled">
								<li><a href="../../personas/index.php" class="">PERSONAS</a></li>
								<li><a href="../../nyps/index.php" class="">PROFESIONALES Y COMERCIOS</a></li>
								<li><a href="../../pyme/index.php" class="">PYME</a></li>
								<li><a href="../../agro/index.php" class="">AGRO</a></li>
								<li><a href="../index.php" class="active">EMPRESAS</a></li>
								<li><a href="../../sector-publico/index.php" class="">SECTOR PÚBLICO</a></li>
								<li><a href="../../institucional/index.php" class="">INSTITUCIONAL</a></li>
							</ul>
							<div class="ebank">
                            <!-- antes href: <php echo $folder_empresas ?><php echo $url_ebank ?>-->
														
								<a href="https://ebankempresas.bancopatagonia.com.ar/desktop-webserver/sso" target="_blank" class="patagonia-ebank-empresas">Patagonia e-Bank Empresas</a>
														</div>
						</div>
					</div>
				</div>
			</header>
		</div>
	</div>
</div>

<div class="container-fluid nav-bar">
	<div class="row">
		<nav class="container">
			<div class="row">
				<!--<div class="col-md-9 col-md-offset-3">-->
                <div class="col-md-10 col-md-offset-3"><!-- ajuste agro -->
					<ul class="list-unstyled sub-navbar">
						
						                        
                                                
                                                
                        						
												<!-- EMPRESAS -->
						<li class="nav-item"><a href="#" class="nav-lnk active">PATAGONIA SUELDO</a>
							<ul class="list-unstyled submenu">
								<li><a href="servicios.php">Servicios</a></li>
								<li><a href="preguntas-frecuentes.php">Preguntas Frecuentes</a></li>
								<li><a href="guia-implementacion.php">Guía de Implementación</a></li>
							</ul>
						</li>
						<li class="nav-item"><a href="#" class="nav-lnk ">COMERCIO EXTERIOR</a>
							<ul class="list-unstyled submenu">
								<li><a href="../comercio-exterior/solicitud-electronica.php">Solicitud Electrónica</a></li>
								<li><a href="../comercio-exterior/productos.php">Productos</a></li>
								<li><a href="../comercio-exterior/otros-servicios.php">Servicios</a></li>
								<!--<li><a href="<php echo $folder_Cexterior ?>financiaciones.php">Financiaciones</a></li>-->
                                <li><a href="../comercio-exterior/herramientas-para-exportar.php">Herramientas para Exportar</a></li>
								<li><a href="../comercio-exterior/marco-regulatorio/normas-y-regulaciones.php">Marco Regulatorio</a></li>
							</ul>
						</li>
                        <!-- -->
						<!--<li class="nav-item"><a href="../comunidades-de-negocios/index.php" class="nav-lnk ">COMUNIDADES DE NEGOCIOS</a></li>-->
                        <!-- -->
                        <li class="nav-item"><a href="../comercios-patagonia/index.php" class="nav-lnk ">COMERCIOS PATAGONIA</a></li>
						<li class="nav-item"><a href="#" class="nav-lnk ">FINANCIACIÓN</a>
							<ul class="list-unstyled submenu">
								<li><a href="../financiacion/patagonia-leasing.php">Patagonia Leasing</a></li>
								<li><a href="../financiacion/mercado-capitales.php">Mercado de Capitales</a></li>
								<li><a href="../financiacion/alternativas-de-financiacion.php">Alternativas de Financiación</a></li>
                                <li><a href="../financiacion/convenios-de-financiacion.php">Convenios de Financiación</a></li>
							</ul>
						</li>
						<li class="nav-item"><a href="#" class="nav-lnk ">INVERSIONES</a>
							<ul class="list-unstyled submenu">
								<li><a href="../inversiones/plazos-fijos.php">Plazos Fijos</a></li>
								<li><a href="../inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
								<li><a href="../inversiones/compra-venta-titulos-acciones.php">Compra - Venta de Títulos y Acciones</a></li>
								<li><a href="../inversiones/custodia-de-titulos.php">Custodia de Títulos</a></li>
								<li><a href="../inversiones/fidecomisos-financieros.php">Fidecomisos Financieros</a></li>
							</ul>
						</li>
						<li class="nav-item"><a href="#" class="nav-lnk ">SERVICIOS</a>
							<ul class="list-unstyled submenu">
                                <li><a href="../patagonia-movil-empresas.php">Patagonia Móvil Empresas</a></li>
								<li><a href="../servicios/pagos.php">Pagos</a></li>
								<li><a href="../servicios/recaudaciones.php">Recaudaciones</a></li>
								<li><a href="../servicios/pago-de-servicios.php">Pago de Servicios</a></li>
								<li><a href="../servicios/interbanking.php">Interbanking</a></li>
								<li><a href="../servicios/interfacturas.php">Interfacturas</a></li>
								<li><a href="../servicios/tarjetas-comerciales.php">Tarjetas Comerciales</a></li>
								<!--<li><a href="../servicios/comercios-patagonia.php">Comercios Patagonia</a></li>-->
                                <li><a href="../servicios/centro-atencion-empresas.php">Centro de Atención para Empresas</a></li>
							</ul>
						</li>
						<!-- FIN EMPRESAS -->
												
												
						
											</ul>
				</div>
			</div>
		</nav>
	</div>
</div>

<div class="mobile-nav-bar">
	<ul class="list-unstyled">
        
        <!-- PERSONAS -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">PERSONAS <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../personas/index.php" class="">HOME</a></li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA CLÁSICA</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../personas/patagonia-clasica/patagonia-ahorro/productos.php">Patagonia Ahorro</a></li>
                        <li><a href="../../personas/patagonia-clasica/paquete/productos.php">Patagonia Clásica</a></li>
                        <!--<li><a href="<php echo $path ?>personas/patagonia-clasica/mas/productos.php">Patagonia Clásica Más</a></li>-->
                        <li><a href="../../personas/patagonia-clasica/premium/productos.php">Patagonia Clásica Premium</a></li>
                        <li><a href="../../personas/patagonia-clasica/patagonia-sueldo/productos.php">Patagonia Sueldo</a></li>
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA PLUS</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../personas/patagonia-plus/productos.php">Patagonia Plus</a></li>
                        <li><a href="../../personas/patagonia-plus/premium/productos.php">Patagonia Plus Premium</a></li>
                    </ul>						
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA SINGULAR</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../personas/patagonia-singular/paquete/propuesta.php">Patagonia Singular</a></li>
                        <li><a href="../../personas/patagonia-singular/beneficios-exclusivos.php">Beneficios Exclusivos</a></li>
                        <!--<li><a href="<php echo $path ?>personas/patagonia-singular/atencion-exclusiva/index.php">Atención Exclusiva</a></li>-->
                        <!--<li><a href="<php echo $path ?>personas/patagonia-singular/eventos-y-novedades/index.php">Eventos y Novedades</a></li>-->
                    </ul>
                </li>
				<!--<li class="nav-sub-item"><a href="<php echo $path ?>patagoniaon/index.php" target="_blank">PATAGONIA ON</a></li>-->
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA ON</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../patagoniaon/index.php" target="_blank">Patagonia ON</a></li>
						<li><a href="../../personas/productos-y-servicios/patagonia-universitaria.php">Patagonia ON Universitaria</a></li>
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PRODUCTOS Y SERVICIOS</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../personas/apple-pay.php">Apple Pay</a></li>
                        <li><a href="../../personas/productos-y-servicios/caja-de-seguridad.php">Caja de Seguridad</a></li>
                        <li><a href="../../personas/productos-y-servicios/comercio-exterior/productos.php">Comercio exterior</a></li>
						<!--<li><a href="<php echo $path ?>personas/productos-y-servicios/beneficios-wapa.php">Comercios WAPA</a></li>-->
						<li><a href="../../personas/cuotifica-al-toque.php">Cuotificá al Toque</a></li>
						<li><a href="../../personas/google-pay.php">Google Pay</a></li>
                        <li><a href="../../personas/productos-y-servicios/inversiones.php">Inversiones</a></li>
                        <li><a href="../../personas/jubilados/index.php">Jubilados</a></li>
                        <li><a href="../../personas/productos-y-servicios/patagonia-para-menores.php">Patagonia para Menores</a></li>
                        <!--<li><a href="<php echo $path ?>personas/productos-y-servicios/patagonia-universitaria.php">Patagonia Universitaria</a></li>-->
                        <li><a href="../../personas/productos-y-servicios/prestamos.php">Prestamos</a></li>
                        <li><a href="../../personas/seguros/index.php">Seguros</a></li>
                        <li><a href="../../personas/productos-y-servicios/tarjetas-de-credito/visa.php">Tarjetas de crédito</a></li>
                        <li><a href="../../personas/productos-y-servicios/tarjetas-de-debito/patagonia-24.php">Tarjetas de débito</a></li>
                    </ul>
                </li>
			</ul>
		</li>
        <!-- FIN PERSONAS -->
        
        <!-- NYPS -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">PROFESIONALES Y COMERCIOS <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../nyps/index.php" class="">HOME</a></li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA CLÁSICA</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../nyps/patagonia-clasica/premium/productos.php">Patagonia Clásica Premium</a></li>
                        <li><a href="../../nyps/patagonia-clasica/patagonia-emprendimiento/productos.php">Patagonia Emprendimiento</a></li>
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA PLUS</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../nyps/patagonia-plus/productos.php">Patagonia Plus</a></li>
                        <li><a href="../../nyps/patagonia-plus/premium/productos.php">Patagonia Plus Premium</a></li>
                    </ul>						
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA SINGULAR</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../nyps/patagonia-singular/paquete/propuesta.php">Patagonia Singular</a></li>
                        <li><a href="../../nyps/patagonia-singular/beneficios-exclusivos.php">Beneficios Exclusivos</a></li>
                        <!--<li><a href="<php echo $path ?>nyps/patagonia-singular/eventos-y-novedades/index.php">Eventos y Novedades</a></li>-->
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PRODUCTOS Y SERVICIOS</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../nyps/productos-y-servicios/tarjetas-de-debito/patagonia-24.php">Tarjetas de débito</a></li>
                        <li><a href="../../nyps/productos-y-servicios/tarjetas-de-credito/visa.php">Tarjetas de crédito</a></li>
                        <li><a href="../../nyps/productos-y-servicios/prestamos.php">Prestamos</a></li>
                        <li><a href="../../nyps/seguros/index.php">Seguros</a></li>
                        <li><a href="../../nyps/productos-y-servicios/inversiones.php">Inversiones</a></li>
                        <li><a href="../../nyps/productos-y-servicios/comercio-exterior/productos.php">Comercio exterior</a></li>
                        <li><a href="../../nyps/productos-y-servicios/caja-de-seguridad.php">Caja de Seguridad</a></li>
                        <li><a href="../../nyps/productos-y-servicios/factura-electronica.php">Factura electrónica</a></li>
                        <li><a href="../../nyps/productos-y-servicios/pagos-afip.php">Pagos AFIP</a></li>
                        <!--<li><a href="<php echo $path ?>nyps/productos-y-servicios/soluciones-para-tu-empresa.php">Soluciones para tu empresa</a></li>-->
                        <!--<li><a href="<php echo $path ?>nyps/productos-y-servicios/comercios-patagonia.php">Comercios Patagonia</a></li>-->
						<li><a href="../../nyps/productos-y-servicios/wapa.php">WAPA</a></li>
                    </ul>
                </li>
			</ul>		
		</li>
        <!-- FIN NYPS -->
        
        <!-- PYME -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">PYME <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../pyme/index.php" class="">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">CUENTAS</a>
					<ul class="list-unstyled submenu">
                        <li><a href="../../pyme/cuentas/pequenas-empresas.php">Pyme Pequeñas Empresas</a></li>
				        <li><a href="../../pyme/cuentas/medianas-empresas.php">Pyme Medianas Empresas</a></li>
                        <!--
						<li><a href="../../pyme/cuentas/patagonia-empresario.php">Patagonia Empresario</a></li>
						<li><a href="../../pyme/cuentas/patagonia-empresario-premier.php">Patagonia Empresario Premier</a></li>
						<li><a href="../../pyme/cuentas/patagonia-empresa.php">Patagonia Empresa</a></li>
                        -->
                        <!--<li><a href="../../pyme/cuentas/patagonia-comercio.php">Patagonia Comercio</a></li>-->
                        <li><a href="../../pyme/cuentas/patagonia-consorcio.php">Patagonia Consorcio</a></li>
						<li><a href="../../pyme/cuentas/cuenta-corriente.php">Cuenta Corriente</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA SUELDO</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../pyme/patagonia-sueldo/servicios.php">Servicios</a></li>
						<li><a href="../../pyme/patagonia-sueldo/preguntas-frecuentes.php">Preguntas Frecuentes</a></li>
						<li><a href="../../pyme/patagonia-sueldo/guia-implementacion.php">Guía de Implementación</a></li>
					</ul>
				</li>						
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">COMERCIO EXTERIOR</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../pyme/comercio-exterior/solicitud-electronica.php">Solicitud Electrónica</a></li>
						<li><a href="../../pyme/comercio-exterior/productos.php">Productos</a></li>
						<li><a href="../../pyme/comercio-exterior/otros-servicios.php">Servicios</a></li>
						<!--<li><a href="<php echo $folder_pymeCexterior ?>financiaciones.php">Financiaciones</a></li>-->
                        <li><a href="../../pyme/comercio-exterior/herramientas-para-exportar.php">Herramientas para Exportar</a></li>
						<li><a href="../../pyme/comercio-exterior/marco-regulatorio/normas-y-regulaciones.php">Marco Regulatorio</a></li>
					</ul>
				</li>						
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">FINANCIACIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../pyme/financiacion/patagonia-leasing.php">Patagonia Leasing</a></li>
						<li><a href="../../pyme/financiacion/mercado-capitales.php">Mercado de Capitales</a></li>
						<li><a href="../../pyme/financiacion/alternativas-de-financiacion.php">Alternativas de Financiación</a></li>
					</ul>
				</li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">SEGUROS</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../pyme/seguros/protege-tus-bienes/integral-comercio.php">Protegé tus Bienes</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">INVERSIONES</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../pyme/inversiones/plazo-fijo.php">Plazo Fijo</a></li>
						<li><a href="../../pyme/inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
						<li><a href="../../pyme/inversiones/fidecomisos-financieros.php">Fidecomisos Financieros</a></li>
					</ul>
				</li>						
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">SERVICIOS</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../pyme/servicios/recaudaciones.php">Recaudaciones</a></li>
						<li><a href="../../pyme/servicios/pagos.php">Pagos</a></li>
						<li><a href="../../pyme/servicios/tarjetas-comerciales.php">Tarjetas Comerciales</a></li>
						<li><a href="../../pyme/servicios/comercios-patagonia.php">Comercios Patagonia</a></li>
                        <li><a href="../../pyme/servicios/pago-de-servicios.php">Pago de Servicios</a></li>
						<li><a href="../../pyme/servicios/interbanking.php">Interbanking</a></li>
						<li><a href="../../pyme/servicios/interfacturas.php">Interfacturas</a></li>
						<li><a href="../../pyme/servicios/pagos-afip.php">Pagos AFIP</a></li>
						<li><a href="../../pyme/servicios/wapa.php">WAPA</a></li>
					</ul>
				</li>
			</ul>		
		</li>
        <!-- FIN PYME -->
        
        <!-- AGRO -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">AGRO <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../agro/index.php" class="">HOME</a></li>
                <!-- -->
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">OFERTA AGRO</a>
					<ul class="list-unstyled submenu">
                    	<!--<li><a href="<php echo $folder_agroFinanciacion ?>insumos.php">Insumos en USD</a></li>-->
                        <li><a href="../../agro/convenios/acuerdos-y-beneficios.php">Acuerdos y convenios</a></li>
						<li><a href="../../agro/financiacion/maquinaria-agricola.php">Financiación Maquinaria Agrícola</a></li>
						<li><a href="../../agro/seguros/campo.php">Seguros para tu campo</a></li>
					</ul>
				</li>
                <!-- -->
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">TARJETA PATAGONIA AGRO</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../agro/tarjeta-patagonia-agro/para-usuarios.php">Para Usuarios</a></li>
						<li><a href="../../agro/tarjeta-patagonia-agro/para-comercios.php">Para Comercios</a></li>
						<li><a href="../../agro/tarjeta-patagonia-agro/acuerdo-tasa-0.php">Tarjetas Agro Convenios Preferenciales</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="../../agro/cuenta-agro/cuenta-agro.php" class="">CUENTA AGRO</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">FINANCIACIÓN</a>
					<ul class="list-unstyled submenu">
                        <li><a href="../../agro/insumos/index.php">Insumos</a></li>
                        <li><a href="../../agro/financiacion/maquinaria-agricola.php">Maquinarias</a></li>
                        <li><a href="../financiacion/convenios-de-financiacion.php">Camiones</a></li>
						<!--<li><a href="<php echo $folder_agroFinanciacion ?>capital-de-trabajo.php">Capital de Trabajo</a></li>-->
						<!--<li><a href="<php echo $folder_agroFinanciacion ?>proyectos-de-inversion.php">Proyectos de Inversión</a></li>-->
						<!--<li><a href="<php echo $folder_agroFinanciacion ?>creditos-para-hacienda.php">Créditos para Hacienda</a></li>-->
						<!--<li><a href="<php echo $folder_agroFinanciacion ?>leasing-y-prendarios.php">Leasing y Prendarios</a></li>-->
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">INVERSIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../agro/inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
						<li><a href="../../agro/inversiones/fidecomisos-financieros.php">Fidecomisos Financieros</a></li>
						<li><a href="../../agro/inversiones/plazos-fijos.php">Plazos Fijos</a></li>
					</ul>
				</li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">COMERCIO EXTERIOR</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../agro/comercio-exterior/solicitud-electronica.php">Solicitud Electrónica</a></li>
                        <li><a href="../../agro/comercio-exterior/productos.php">Productos</a></li>
                        <li><a href="../../agro/comercio-exterior/otros-servicios.php">Servicios</a></li>
                        <li><a href="../../agro/comercio-exterior/herramientas-para-exportar.php">Herramientas para Exportar</a></li>
                        <li><a href="../../agro/comercio-exterior/marco-regulatorio/normas-y-regulaciones.php">Marco Regulatorio</a></li>
                    </ul>
                </li>
                <!--
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">SERVICIOS</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../agro/servicios/centro-atencion-empresas.php">Centro de Atención para Empresas</a></li>
					</ul>
				</li>
                -->
                <!-- -->
                <li class="nav-sub-item"><a href="../../agro/seguros/campo.php" class="">SEGUROS</a></li>
                <!-- -->
			</ul>
		</li>
        <!-- FIN AGRO -->
        
        <!-- EMPRESAS -->
		<li class="nav-main-item"><a href="#" class="has-sub-items active">EMPRESAS <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../index.php" class="active">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu active">PATAGONIA SUELDO</a>
					<ul class="list-unstyled submenu">
						<li><a href="servicios.php">Servicios</a></li>
						<li><a href="preguntas-frecuentes.php">Preguntas Frecuentes</a></li>
						<li><a href="guia-implementacion.php">Guía de Implementación</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">COMERCIO EXTERIOR</a>
					<ul class="list-unstyled submenu">
						<li><a href="../comercio-exterior/solicitud-electronica.php">Solicitud Electrónica</a></li>
						<li><a href="../comercio-exterior/productos.php">Productos</a></li>
						<li><a href="../comercio-exterior/otros-servicios.php">Servicios</a></li>
						<!--<li><a href="<php echo $folder_Cexterior ?>financiaciones.php">Financiaciones</a></li>-->
                        <li><a href="../comercio-exterior/herramientas-para-exportar.php">Herramientas para Exportar</a></li>
						<li><a href="../comercio-exterior/marco-regulatorio/normas-y-regulaciones.php">Marco Regulatorio</a></li>
					</ul>
				</li>
                <!-- -->
				<!--<li class="nav-sub-item"><a href="../comunidades-de-negocios/index.php" class="">COMUNIDADES DE NEGOCIOS</a></li>-->
                <!-- -->
				<li class="nav-sub-item"><a href="../comercios-patagonia/index.php" class="nav-lnk ">COMERCIOS PATAGONIA</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">FINANCIACIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../financiacion/patagonia-leasing.php">Patagonia Leasing</a></li>
						<li><a href="../financiacion/mercado-capitales.php">Mercado Capitales</a></li>
						<li><a href="../financiacion/alternativas-de-financiacion.php">Alternativas de Financiación</a></li>
                        <li><a href="../financiacion/convenios-de-financiacion.php">Convenios de Financiación</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">INVERSIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../inversiones/plazos-fijos.php">Plazos Fijos</a></li>
						<li><a href="../inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
						<li><a href="../inversiones/compra-venta-titulos-acciones.php">Compra - Venta de Títulos y Acciones</a></li>
						<li><a href="../inversiones/custodia-de-titulos.php">Custodia de Títulos</a></li>
						<li><a href="../inversiones/fidecomisos-financieros.php">Fidecomisos Financieros</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">SERVICIOS</a>
					<ul class="list-unstyled submenu">
                        <li><a href="../patagonia-movil-empresas.php">Patagonia Móvil Empresas</a></li>
						<li><a href="../servicios/pagos.php">Pagos</a></li>
						<li><a href="../servicios/recaudaciones.php">Recuadaciones</a></li>
						<li><a href="../servicios/pago-de-servicios.php">Pago de Servicios</a></li>
						<li><a href="../servicios/interbanking.php">Interbanking</a></li>
						<li><a href="../servicios/interfacturas.php">Interfacturas</a></li>
						<li><a href="../servicios/tarjetas-comerciales.php">Tarjetas Comerciales</a></li>
                        <!-- -->
						<!--<li><a href="../servicios/comercios-patagonia.php">Comercios Patagonia</a></li>-->
                        <!-- -->
                        <li><a href="../servicios/centro-atencion-empresas.php">Centro de Atención para Empresas</a></li>
					</ul>
				</li>
			</ul>
		</li>
        <!-- FIN EMPRESAS -->
        
        <!-- SECTOR PÚBLICO -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">SECTOR PÚBLICO <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../sector-publico/index.php" class="">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">INVERSIONES</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../sector-publico/inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
						<li><a href="../../sector-publico/inversiones/plazo-fijo.php">Plazo Fijo</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">SERVICIOS</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../sector-publico/servicios/servicio-de-recaudacion.php">Servicio de Recaudación</a></li>
						<li><a href="../../sector-publico/servicios/servicio-de-pagos.php">Servicio de Pagos</a></li>
						<li><a href="../../sector-publico/servicios/servicios-para-personal.php">Servicios para el Personal</a></li>
						<li><a href="../../sector-publico/servicios/financiacion.php">Financiación</a></li>
						<li><a href="../../sector-publico/servicios/otros-servicios.php">Servicios</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">PROGRAMA UNIVERSIDADES</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../sector-publico/programa-universidades/relacion-institucional.php">Relación Institucional</a></li>
						<li><a href="../../sector-publico/programa-universidades/docentes-yno-docentes.php">Docentes y No Docentes</a></li>
						<li><a href="../../sector-publico/programa-universidades/alumnos.php">Alumnos</a></li>
						<li><a href="../../sector-publico/programa-universidades/graduados.php">Graduados</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">BENEFICIOS RÍO NEGRO</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../sector-publico/rio-negro/presencia.php">Presencia en Río Negro</a></li>
                        <li><a href="../../sector-publico/rio-negro/propuesta-valor.php">Propuesta de valor exclusiva</a></li>
					</ul>
				</li>
			</ul>
		</li>
        <!-- FIN SECTOR PUBLICO -->
        
        <!-- INSTITUCIONAL -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">INSTITUCIONAL <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../institucional/index.php" class="">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">BANCO PATAGONIA</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../institucional/banco-patagonia/historia.php">Historia</a></li>
						<li><a href="../../institucional/banco-patagonia/mercado-de-capitales.php">Mercado de Capitales</a></li>
						<li><a href="../../institucional/banco-patagonia/patagonia-inversora.php">Patagonia Inversora</a></li>
						<li><a href="../../institucional/banco-patagonia/patagonia-valores-sa.php">Patagonia Valores S.A</a></li>
						<li><a href="https://bp.bancopatagonia.com.ar/relacion-con-inversores/es/institucional" target="_blank">Relación con Inversores</a></li>
						<li><a href="../../institucional/banco-patagonia/desarrollo-humano.php">Desarrollo Humano</a></li>
						<li><a href="../../institucional/banco-patagonia/sustentabilidad.php">Sustentabilidad</a></li>
						<li><a href="../../institucional/banco-patagonia/politicas-aml-cft.php">Póliticas AML/CFT</a></li>
						<li><a href="../../institucional/banco-patagonia/disciplina-del-mercado.php">Disciplina de Mercado</a></li>
                        <li><a href="../../institucional/banco-patagonia/asistencia-a-vinculados.php">Asistencia a vinculados</a></li>
                        <li><a href="../../institucional/banco-patagonia/etica-e-integridad.php">Ética e Integridad</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">ORGANIZACIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../institucional/organizacion/accionistas.php">Accionistas</a></li>
						<li><a href="../../institucional/organizacion/autoridades.php">Autoridades</a></li>
                        <li><a href="../../institucional/organizacion/comites.php">Comités</a></li>
						<li><a href="../../institucional/organizacion/sector-financiero.php">Sector Financiero</a></li>
					</ul>
				</li>
			</ul>
		</li>
        <!-- FIN INSTITUCIONAL -->
        
        		<li class="nav-main-item"><a href="../../preguntas-frecuentes/index.php" class="" style="text-transform: none;">Ayuda</a></li>
		<!--<li class="nav-main-item"><a href="<php echo $folder_canales ?>index.php" class="<php echo $canales ?>" style="text-transform: none;">Canales de Atención</a></li>-->
		<!--<li class="nav-main-item"><a href="http://sucursalesycajeros.bancopatagonia.com.ar/sucursales.html" target="_blank" style="text-transform: none;">Sucursales y Cajeros</a></li>-->
		<!--<li class="nav-main-item"><a href="<php echo $folder_contactenos ?>index.php" class="<php echo $contactenos ?>" style="text-transform: none;">Contactanos</a></li>-->
        <!--<li class="nav-main-item"><a href="<php echo $path ?>ayuda/index.php" class="<php echo $ayuda ?>" style="text-transform: none;">Ayuda</a></li>-->
	</ul>
</div>	<section class="sec-head">
        <div class="sec-pic-head" id="head-patagonia-sueldo">
        </div>
        <!--
		<div class="sec-pic-head" style="background-image: url(images/head-servicios.jpg);">
			<div class="container">
				<div class="row">
					<div class="col-md-4 col-sm-6 col-xs-12 sec-pic-area">
						<div class="sec-head-card">
							<h2 class="with-border">Servicios Patagonia Sueldo</h2>
							<p>Variedad de productos y servicios para la administración de la nómina.</p>
						</div>
					</div>
				</div>
			</div>
		</div>
        -->
	</section>
	<section class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
				<ol class="breadcrumb">
					<li><a href="../index.php">Empresas</a></li>
					<li>Patagonia Sueldo</li>
					<li class="active">Servicios</li>
				</ol>
			</div>
		</div>
	</section>
	<section class="container">
    <!-- -->
    <div class="row">
		<div class="col-md-12 col-sm-12 col-xs-12">
            <div class="text-data">
                <h1>Servicios</h1>
                <h3>Funcionalidades</h3>
                <p>En Banco Patagonia creemos que el pago de los sueldos de tus empleados debe realizarse en forma simple, ágil y segura. Cada empresa es diferente y tiene necesidadesparticulares, por ello hemos desarrollado Patagonia Sueldo, que cuenta con la más completa variedad de productos y servicios que se adecuan a tus necesidades para la administración de tu nómina y también otorgando beneficios para los empleados.</p>
                <p><strong>Nuevas funcionalidades para que pagar haberes sea más fácil:</strong></p>
                <p>Te ofrecemos nuevas funcionalidades que complementan las ya existentes y además sumamos mayor información para que pagar haberes sea más sencillo:</p>
                <ul>
                    <li>Alta y Baja de empleados individual a través de la página sin envío de archivo.</li>
                    <li>Alta y Modificación de dependencias laborales en forma individual o a través de archivo.</li>
                    <li>Consulta de Nómina e Historial de acreditaciones. (*)</li>
                    <li>Descarga de toda la información en formatos xml, xls y txt.</li>
                </ul>
                <p>Para comenzar a utilizar las funcionalidades mencionadas, solo deberás ingresar a Patagonia e-bank Empresas con tu usuario Administrador y asignarlas a los operadores que utilizan el servicio Patagonia Sueldo.</p>
                <p>(*) Para la habilitación del historial de acreditaciones y consulta de nómina se requiere la presentación de la Solicitud de Servicios + Términos y Condiciones confirmados por los Apoderados de la empresa.</p>
                <hr>
                <h4>Servicios para la empresa</h4>
                <ul>
                    <li><strong>Eficiencia:</strong> Resolvé la administración de tu nómina de principio a fin, de manera ágil rápida y segura.</li>
                    <li><strong>Comodidad:</strong> Desde e bank Empresas podrás realizar todas las operaciones sin la necesidad de desplazarte y con un horario más amplio. 
                    <li><strong>Sencillez:</strong> Para pagar tu nómina sin importar en qué banco se encuentran las cuentas de tus empleados.</li>
                    <li><strong>Puntualidad:</strong> El pago a tus empleados se realiza con absoluto rigor, de acuerdo a tus instrucciones.</li>
                    <li><strong>Seguridad:</strong> La información que envías para programar tus pagos se transmite con los más altos niveles de seguridad en medios electrónicos.</li>
                    <li><strong>Cobertura:</strong> Mas de 180 puntos de atención a lo largo del país, para la atención de tu Empresa y de tu empleado.</li>
                    <li><strong>Soporte:</strong> Contás con una mesa de ayuda exclusiva para Patagonia Sueldo.</li>
                </ul>
                <p>El menú Patagonia Sueldo te permitirá administrar la nómina de empleados y gestionar acreditaciones en forma ágil y segura obteniendo a su vez información del estado de cada una de las operaciones realizadas. </p>
                <ul>
                    <li><strong>ABM Empleados:</strong> Alta y Baja de empleados individual, plantilla o bien masiva a través de archivo con formato.</li>
                    <li><strong>Consulta de Nómina:</strong> Información de la nómina vigente con acceso a información detallada de cada empleado.</li>
                    <li><strong>Pago de haberes:</strong> Generación de acreditaciones individuales y masivas mediante archivo con fecha diferida u online.</li>
                    <li><strong>Historial de Acreditaciones: </strong>Consulta histórica de acreditaciones enviadas.</li>
                    <li><strong>Dependencias: </strong>Consulta y generación de dependencias/Sucursales laborales.</li>
                    <li><strong>Consultas de envíos: </strong>Consulta de novedades (altas, bajas, dependencias y acreditaciones, devolución de cuentas)</li>
                    <li><strong>Autorizaciones: </strong>Autorización de operaciones por las instancias definidas en la empresa.</li>
                </ul>
                <hr>
                <h3>Sistema de Gestión de la Calidad implementado y certificados desde 2009 bajo la Norma ISO 9001:2008</h3>
                <div class="row">
                    <div class="col-md-2 col-sm-2 col-xs-12 text-center">
                        <p><img src="images/cert-iso.png" width="86" height="42" alt=""/></p>
                    </div>
                    <div class="col-md-10 col-sm-10 col-xs-12">
                        <p><strong>Alcance de la Certificación:</strong><br>
                        Certificado en el Sistema de Gestión de la Calidad para la Comercialización, Implementacion, administración, acreditación periódica de haberes,
                        entrega de kits de productos en la sucursal de radicación y servicio de atención al cliente (soporte al cliente y servicio post- venta)</p>
                    </div>
                </div>
                <p>&nbsp;</p>
                <div class="highlight-bar">
                    <h3>Atención al cliente <strong>0810-888-8500</strong></h3>
                </div>
            </div>
            <!-- PRE FOOTER -->
            <div class="row consulta">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <h4>Solicitalo en</h4>
                </div>
                <div class="col-md-4 col-sm-4 col-xs-12">
                    <a href="../patagonia-ebank-empresas.php" target="_blank" class="lnk">PATAGONIA E-BANK</a>
                </div>
                <div class="col-md-4 col-sm-4 col-xs-12">
                    <a href="tel:08109996655" class="lnk lnk-2-lines phone">Telefónicamente<br>
                    0810 888 8500<br />
                    </a>
                </div>
                <div class="col-md-4 col-sm-4 col-xs-12">
                    <a href="http://sucursalesycajeros.bancopatagonia.com.ar/sucursales.html" target="_blank" class="lnk last">EN LA SUCURSAL</a>
                </div>
            </div>
            <!-- FIN PRE FOOTER -->
        </div>
    </div>
    <!-- -->
    <!--
	<div class="row">
		<div class="col-md-12 col-sm-12 col-xs-12">
			<ul class="nav nav-tabs tabs-x2">
				<li class="active"><a href="#tab1" data-toggle="tab">Servicios</a></li>
				<li><a href="#tab2" data-toggle="tab">Beneficios</a></li>
			</ul>
			<div class="tab-content">
				<div class="tab-pane fade in active" id="tab1">
                    <div class="tab-data">
                    </div>
				</div>
				<div class="tab-pane fade" id="tab2">
					<div class="tab-data">
						<h1 class="clr-singular">Beneficios para los Empleados</h1>
						<h2 class="clr-singular">Sabías que tu sueldo en <strong>Banco Patagonia</strong> te da beneficios exclusivos desde el primer día?</h2>
						<p><strong>TE BONIFICAMOS AL 100% POR 6 MESES</strong> EL PAQUETE DE PRODUCTOS PATAGONIA <sup>(1)</sup></p>
                        <hr>
                        <div>
                            <h3 class="clr-singular"><strong>Restaurantes</strong></h3>
                            <div class="bnf-container bnf-flex">
                                <div class="bnf-box bnf-singular">
                                    <div class="bnf-card">
                                        <i class="bnf-icon bnf-icon-food"></i>
                                        <i class="bnf-misc"></i>
                                        <p>&nbsp;</p>
                                        <big>100<span>%</span></big>
                                        <p>de descuento</p>
                                    </div>
                                    <div class="bnf-card-data bnf-2-lines">
                                        <p><strong>Si sos cliente Singular.</strong></p>
                                        <p>Tope Visa: $5000.</p>
                                    </div>
                                </div>
                            </div>
                            <p class="clr-singular"><strong>Durante el primer mes, en tu 1er consumo en cualquier restaurante con tu nueva tarjeta de crédito Visa Signature <sup></sup></strong></p>
                        </div>
                        <div>
                            <p>&nbsp;</p>
                            <h3 class="clr-singular"><strong>En todos los supermercados</strong></h3>
                            <div class="bnf-container bnf-flex">
                                <div class="bnf-box bnf-singular">
                                    <div class="bnf-card">
                                        <i class="bnf-icon bnf-icon-cart"></i>
                                        <i class="bnf-misc"></i>
                                        <p>&nbsp;</p>
                                        <big>30<span>%</span></big>
                                        <p>de descuento</p>
                                    </div>
                                    <div class="bnf-card-data bnf-0-lines">
                                        <p><strong>Si sos cliente Singular.</strong></p>
                                        <p>Tope Visa: $5000.</p>
                                        <p>Tope Mastercard: $5000.</p>
                                    </div>
                                </div>
                                <div class="bnf-box bnf-plus">
                                    <div class="bnf-card">
                                        <i class="bnf-icon bnf-icon-cart"></i>
                                        <i class="bnf-misc"></i>
                                        <p>&nbsp;</p>
                                        <big>30<span>%</span></big>
                                        <p>de descuento</p>
                                    </div>
                                    <div class="bnf-card-data bnf-0-lines">
                                        <p><strong>Si sos cliente Plus.</strong></p>
                                        <p>Tope Visa: $3000.</p>
                                        <p>Tope Mastercard: $3000.</p>
                                    </div>
                                </div>
                                <div class="bnf-box bnf-clasica">
                                    <div class="bnf-card">
                                        <i class="bnf-icon bnf-icon-cart"></i>
                                        <i class="bnf-misc"></i>
                                        <p>&nbsp;</p>
                                        <big>30<span>%</span></big>
                                        <p>de descuento</p>
                                    </div>
                                    <div class="bnf-card-data bnf-0-lines">
                                        <p><strong>Si sos cliente Clásica.</strong></p>
                                        <p>Tope Visa: $2000.</p>
                                        <p>Tope Mastercard: $2000.</p>
                                    </div>
                                </div>
                            </div>
                            <p class="mbl">&nbsp;</p>
                            <p class="clr-singular"><strong>En tu 1er compra, en cualquier supermercado, con tus nuevas tarjetas de crédito <sup></sup></strong></p>
                        </div>
                        <hr>
						<h2 class="clr-plus"><strong>Además, accedes a descuentos exclusivos todas las semanas</strong></h2>
                        <h3 class="clr-plus"><strong>Carrefour</strong> - Todos los miércoles</h3>
                        <div class="bnf-box bnf-plus">
                            <div class="bnf-card">
                                <i class="bnf-icon bnf-icon-cart"></i>
                                <i class="bnf-misc"></i>
                                <p>&nbsp;</p>
                                <big>20<span>%<sup>(1)</sup></span></big>
                                <p>de descuento</p>
                            </div>
                            <div class="bnf-card-data bnf-3-lines">
                                <p><strong>Beneficio exclusivo por acreditar el sueldo en Banco.</strong></p>
                                <p>Con TC VISA y AMEX y TD.</p>
                                <p>Tope $1000.</p>
                            </div>
                        </div>
                        <p>&nbsp;</p>
                        <h3><strong>Peluquerías</strong> - Todos los miércoles</h3>
                        <div class="bnf-container bnf-flex">
                            <div class="bnf-box bnf-clasica">
                                <div class="bnf-card">
                                    <i class="bnf-icon bnf-icon-scissor"></i>
                                    <i class="bnf-misc"></i>
                                    <p>&nbsp;</p>
                                    <big>10<span>%<sup>(2)</sup></span></big>
                                    <p>de descuento</p>
                                </div>
                                <div class="bnf-card-data bnf-2-lines">
                                    <p>Con TD.</p>
                                    <p>Tope $300.</p>
                                </div>
                            </div>
                            <div class="bnf-box bnf-plus">
                                <div class="bnf-card">
                                    <i class="bnf-icon bnf-icon-scissor"></i>
                                    <i class="bnf-misc"></i>
                                    <p>&nbsp;</p>
                                    <big>15<span>%<sup>(3)</sup></span></big>
                                    <p>de descuento</p>
                                </div>
                                <div class="bnf-card-data bnf-3-lines">
                                    <p><strong>Exclusivo plus.</strong></p>
                                    <p>Con TC y TD.</p>
                                    <p>Tope $500.</p>
                                </div>
                            </div>
                        </div>
                        <p>&nbsp;</p>
                        <h3 class="clr-plus"><strong>Combustibles</strong> - Todos los jueves</h3>
                        <div class="bnf-box bnf-plus">
                            <div class="bnf-card">
                                <i class="bnf-icon bnf-icon-fuel"></i>
                                <i class="bnf-misc"></i>
                                <p>&nbsp;</p>
                                <big>20<span>%<sup>(4)</sup></span></big>
                                <p>de descuento</p>
                            </div>
                            <div class="bnf-card-data bnf-3-lines">
                                <p><strong>Beneficio exclusivo Patagonia Plus Plan Sueldos.</strong></p>
                                <p>Con TD.</p>
                                <p>Tope $500.</p>
                            </div>
                        </div>
                        <p>&nbsp;</p>
                        <h3 class="clr-plus"><strong>Restaurantes</strong> - Todos los viernes</h3>
                        <div class="bnf-box bnf-plus">
                            <div class="bnf-card">
                                <i class="bnf-icon bnf-icon-food"></i>
                                <i class="bnf-misc"></i>
                                <p>&nbsp;</p>
                                <big>20<span>%<sup>(5)</sup></span></big>
                                <p>de descuento</p>
                            </div>
                            <div class="bnf-card-data bnf-3-lines">
                                <p><strong>Beneficio exclusivo Patagonia Plus Plan Sueldos.</strong></p>
                                <p>Con TC.</p>
                                <p>Tope $500.</p>
                            </div>
                        </div>
                        <p>&nbsp;</p>
						<div class="row">
							<div class="col-md-12 text-center"><img src="../../personas/cuentas/images/club-patagonia.svg" width="155" height="27" alt=""/></div>
							<div class="col-md-12">
								<div class="highlight-bar-2">
									<div class="inner">
										<a href="https://www.clubpatagonia.com.ar/" target="_blank">
											<p>Sumá puntos con tus compras y canjealos por premios. <span>IR A CATÁLOGO</span></p>
										</a>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="row consulta">
						<div class="col-md-12 col-sm-12 col-xs-12">
							<h4>Solicitalo en</h4>
						</div>
						<div class="col-md-4 col-sm-4 col-xs-12">
							<a href="../patagonia-ebank-empresas.php" target="_blank" class="lnk">PATAGONIA E-BANK</a>
						</div>
						<div class="col-md-4 col-sm-4 col-xs-12">
							<a href="tel:08109996655" class="lnk lnk-2-lines phone">Telefónicamente<br>
							0810 888 8500<br />
							</a>
						</div>
						<div class="col-md-4 col-sm-4 col-xs-12">
							<a href="http://sucursalesycajeros.bancopatagonia.com.ar/sucursales.html" target="_blank" class="lnk last">EN LA SUCURSAL</a>
						</div>
					</div>
					<div class="row legal-int">
						<div class="col-md-12 col-sm-12 col-xs-12">
							<p>PROMOCIONES VÁLIDAS EN LA REPÚBLICA ARGENTINA DESDE EL 01/06/2021 AL 30/06/2023. EL IMPORTE BONIFICADO SERÁ ACREDITADO EN EL MISMO RESUMEN EN QUE INGRESE EL CONSUMO (O PRIMER CUOTA) O BIEN EN EL INMEDIATO POSTERIOR. BANCO PATAGONIA NO SE RESPONSABILIZA POR LOS CUPONES PRESENTADOS FUERA DE TÉRMINO DE LA VIGENCIA DE LA PROMOCIÓN. SE EXCLUYEN TARJETAS CORPORATIVAS. PROMOCIÓN NO ACUMULABLE CON OTRAS PROMOCIONES. LAS CUENTAS NO DEBERÁN REGISTRAR MORA. BANCO PATAGONIA S.A. NO SE RESPONSABILIZA POR LOS CUPONES PRESENTADOS FUERA DE LA FECHA DE VIGENCIA DE LA PROMOCIÓN. (1) LOS CLIENTES QUE ACREDITEN EL SUELDO EN BANCO PATAGONIA RECIBIRÁN TODOS LOS MIERCOLES UN 20% DE DESCUENTO EN LOS LOCALES HIPERMERCADOS CARREFOUR, CARREFOUR MARKET, CARREFOUR EXPRESS Y TAMBIÉN PROMOCIÓN VALIDA PARA WWW.CARREFOUR.COM.AR EN COMPRAS EN 1 PAGO Y PROGRAMANDO LA ENTREGA DE TU PEDIDO PARA LOS MIÉRCOLES, CON TAJETA DE DEBITO PATAGONIA 24 Y TARJETAS DE CREDITO VISA Y AMERICAN EXPRESS. SE EXCLUYE ELECTRÓNICA, ELECTRODOMÉSTICOS Y TELEFONÍA CELULAR. SE EXCLUYEN ADICIONALES DE TARJETA DE DÉBITO. PROMOCIÓN NO ACUMULABLE CON OTRAS PROMOCIONES. TOPE DE DEVOLUCIÓN $1000 POR MES Y POR CUENTA. NO PARTICIPA CARREFOUR MAXI. NO INCLUYE MOTOS, CUATRICICLOS, BICICLETAS MOTORIZADAS, TRACTORES, BODEGAS CHANDON, LEONCIO ARIZU, TERRAZAS DE LOS ANDES, TRUMPETER, LA RURAL, RUTINI WINES, LATITUD 33, CLOS DE LOS SIETE, CATENA ZAPATA, NI PRODUCTOS DE CONVENIO DE PRECIOS CUIDADOS, LECHES INFANTILES Y MATERNIZADAS ETAPA 1 Y 2 NI CARNICERÍA: CARNE VACUNA, POLLO, CORTES DE CERDOS Y EMBUTIDOS. NO INCLUYE PRODUCTOS DE LA MARCA CARREFOUR DE ALIMENTOS, LÁCTEOS, QUESOS, FIAMBRES, BEBIDAS, PERFUMERÍA Y LIMPIEZA. NO ACUMULABLE CON OTRAS PROMOCIONES VIGENTES. (2) ABONANDO LOS MIÉRCOLES CON LA TARJETA DE DÉBITO PATAGONIA 24 EMITIDA POR BANCO PATAGONIA S.A., RECIBIRÁ UN 10% DE DESCUENTO EN LOS COMERCIOS REGISTRADOS BAJO EL RUBRO PELUQUERÍAS. TOPE DE DEVOLUCIÓN $300 POR MES Y POR CUENTA. (3) LOS CLIENTES TITULARES DE UN PRODUCTO PATAGONIA PLUS RECIBIRÁN UN 15% DE DESCUENTO EN LOS COMERCIOS REGISTRADOS BAJO EL RUBRO PELUQUERÍAS CON TARJETAS DE DEBITO Y CREDITO DE BANCO PATAGONIA. TOPE DE REINTEGRO: $500 POR MES Y POR CUENTA.(4) LOS CLIENTES QUE ACREDITEN EL SUELDO EN BANCO PATAGONIA Y TENGAN UN PAQUETE DE PRODUCTOS PATAGONIA PLUS ABONANDO LOS JUEVES CON TODAS LAS TARJETAS DE DÉBITO PATAGONIA 24 EMITIDAS POR BANCO PATAGONIA S.A RECIBIRÁN UN 20% DE DESCUENTO EN LOS COMERCIOS REGISTRADOS BAJO EL RUBRO COMBUSTIBLE. PROMOCIÓN NO ACUMULABLE CON OTRAS PROMOCIONES. TOPE DE DEVOLUCIÓN $500 POR MES Y POR CUENTA. (5) BENEFICIO EXCLUSIVO POR ACREDITAR EL SUELDO EN BANCO PATAGONIA Y PARA LOS CLIENTES TITULARES DE UN PRODUCTO PATAGONIA PLUS. ABONANDO LOS VIERNES CON LA TARJETAS DE CRÉDITO DE BANCO PATAGONIA S.A., RECIBIRÁ UN 20% DE DESCUENTO EN LOS COMERCIOS REGISTRADOS BAJO EL RUBRO RESTAURANTES. TOPE DE DEVOLUCIÓN $500 POR MES Y POR CUENTA. EL IMPORTE BONIFICADO POR LAS COMPRAS EFECTUADAS CON TARJETAS DE CRÉDITO SERÁ ACREDITADO EN EL MISMO RESUMEN EN QUE INGRESE EL CONSUMO O EN EL INMEDIATO POSTERIOR. PARA COMPRAS CON TARJETAS DE DÉBITO, LAS BONIFICACIONES SE ACREDITARÁN EN LA CUENTA DE DÉBITO DENTRO DE LOS 10 DÍAS HÁBILES DE REALIZADA LA OPERACIÓN. BANCO PATAGONIA NO SE RESPONSABILIZA POR LOS CUPONES PRESENTADOS FUERA DE LA FECHA DE VIGENCIA DE LA PROMOCIÓN. PROMOCIÓN NO ACUMULABLE CON OTRAS PROMOCIONES. CONSULTE ALCANCES, TÉRMINOS Y CONDICIONES DEL PROGRAMA EN ESTE SITIO WEB. LOS ACCIONISTAS DE BANCO PATAGONIA S.A. LIMITAN SU RESPONSABILIDAD A LA INTEGRACIÓN DE LAS ACCIONES SUSCRIPTAS. LEY 25.738. NO APLICA PARA AQUELLOS PAGOS Y/O CONSUMOS ABONADOS CON TARJETAS DE CRÉDITO EMITIDAS POR BANCO PATAGONIA S.A. A TRAVÉS DE BILLETERAS VIRTUALES, POS MÓVILES, PLATAFORMAS DE PAGO Y/O PORTALES DE PAGO ON LINE.</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
    -->
    <!-- -->
</section>	<div class="container-fluid footer-bar">
	<div class="row">
		<footer class="container">
			<div class="row">
				<div class="col-md-12">
					<p class="flnks"><a href="../../registro-nacional-base-datos.php">Registro Nacional de Base de Datos</a> <span>|</span>   <a href="../../codigo-practicas-bancarias.php">Código de Prácticas Bancarias</a> <span>|</span>   <a href="../../defensa-ley-consumidor.php">Defensa del Consumidor</a>
						<span>|</span>   <a href="https://www.argentina.gob.ar/produccion/defensadelconsumidor/formulario">Defensa de las y los consumidores. Para reclamos ingrese aquí</a><span>|</span> <br class="tbl"> <a href="../../persona-expuesta-politicamente.php">Persona Expuesta Políticamente</a> <span class="tbl">|</span> <br class="dsk">
						
					<a href="../../agencia-acceso-informacion-publica.php">Agencia de Acceso a la Información Pública</a> <span>|</span> <br class="tbl"> 
					<a href="../../cnv-advertencia-publico-inversor.php">CNV - Advertencia al Público Inversor</a> <span>|</span> <a href="../../docs/Idoneos.pdf" target="_blank"> Idóneos en Mercado de Capitales - CNV</a><span>|</span>   <a href="../../codigo-proteccion-inversor.php">Código de Protección al Inversor</a> <span>|</span>   <a href="../../clausulas-legales.php">Cláusulas Legales</a> <span>|</span> <a href="../../resolucion-022021.php">Resol. 02/21 Dir.Gral. Defensa del consumidor Córdoba</a></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<p class="redes">
                        <span>Seguinos en:</span>
                        <!-- -->
                        <a href="https://www.facebook.com/BancoPatagonia/" target="_blank"><img src="../../assets/images/layout/icon-facebook.svg" alt="Facebook"></a>
                        <a href="https://twitter.com/banco_patagonia" target="_blank"><img src="../../assets/images/layout/icon-twitter.svg" alt="Twitter"></a>
                        <a href="https://www.instagram.com/banco_patagonia/" target="_blank"><img src="../../assets/images/layout/icon-instagram.svg" alt="Instagram"></a>
                        <a href="https://www.youtube.com/user/bancopatagonia" target="_blank"><img src="../../assets/images/layout/icon-youtube.svg" alt="Youtube"></a>
                        <!-- -->
                        <!--
                        <a href="https://www.facebook.com/BancoPatagonia/" target="_blank"><i class="fa fa-facebook-square"></i></a>
                        <a href="https://twitter.com/banco_patagonia" target="_blank"><i class="fa fa-twitter"></i></a>
                        <a href="https://www.instagram.com/banco_patagonia/" target="_blank"><i class="fa fa-instagram"></i></a>
                        <a href="https://www.youtube.com/user/bancopatagonia" target="_blank"><i class="fa fa-youtube-play"></i></a>
                        -->
                    </p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					                    <!---->
				    <p class="flegal">BANCO PATAGONIA S.A. ES UNA SOCIEDAD ANÓNIMA CONSTITUIDA BAJO LAS LEYES DE LA REPÚBLICA ARGENTINA CUYOS ACCIONISTAS LIMITAN SU RESPONSABILIDAD A LA INTEGRACIÓN DE LAS ACCIONES SUSCRITAS DE ACUERDO A LA LEY 19.550. POR CONSIGUIENTE, Y EN CUMPLIMIENTO DE LA LEY 25.738, SE INFORMA QUE NI LOS ACCIONISTAS MAYORITARIOS DE CAPITAL EXTRANJERO NI LOS ACCIONISTAS LOCALES O EXTRANJEROS RESPONDEN, EN EXCESO DE LA CITADA INTEGRACIÓN ACCIONARIA, POR LAS OBLIGACIONES EMERGENTES DE LAS OPERACIONES CONCERTADAS POR LA ENTIDAD FINANCIERA.</p>
                    <p class="flegal" style="font-size:10px;">Banco Patagonia S.A. - Agente de Liquidacion y Compensacion y Agente de Negociacion Integral, inscripto en CNV bajo el N° 66</p>
					<p class="flegal">© 2025 Banco Patagonia . Todos los derechos reservados. Prohibida la duplicación , distribución o almacenamiento en cualquier medio.</p>
				</div>
			</div>
		</footer>
	</div>
</div>
<div class="tbl mbl placeholder-shortlinks">
	<div class="container shortlinks">
		<div class="row">
            <!--<php if ($home_personas == false) { ?>
                <div class="col-sm-3 col-xs-3">
                    <a href="#"><span class="icon icon-contacto"></span></a>
                </div>
            <php } ?>-->
            			<div class="col-sm-3 col-xs-3">
				<a href="http://sucursalesycajeros.bancopatagonia.com.ar/sucursales.html" target="_blank"><span class="icon icon-sucursales"></span>Sucursales y Cajeros</a>
			</div>
			<div class="col-sm-3 col-xs-3">
				<a href="../../preguntas-frecuentes/index.php"><span class="icon icon-contacto"></span>Ayuda</a>
			</div>
			<div class="col-sm-3 col-xs-3 last">
				<a href="../patagonia-ebank-empresas-mbl.php"><span class="icon icon-ebank"></span>Patagonia e-Bank</a>
			</div>
		</div>
	</div>
</div>	<script src="../../assets/js/jquery-3.5.1.min.js"></script>
<script src="../../assets/bootstrap/js/bootstrap.min.js"></script>
<script src="../../assets/js/slick/slick.min.js"></script>
<script src="../../assets/js/fancybox/jquery.fancybox.min.js"></script>
<script src="../../assets/js/mtabs/jquery.bootstrap-responsive-tabs.min.js"></script>
<script src="../../assets/js/funciones.js"></script>

<!-- Global site tag (gtag.js) - Google Analytics (original) -->
<!--
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-32588129-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-32588129-1');
</script>
-->

<!-- Google Analytics (version anterior / eventos ok)  -->
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');
  ga('create', 'UA-32588129-1', 'auto');
  ga('send', 'pageview');
</script>

<!-- GA4 - Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-C6LG1PT98X"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-C6LG1PT98X');
</script>
</body>
</html>