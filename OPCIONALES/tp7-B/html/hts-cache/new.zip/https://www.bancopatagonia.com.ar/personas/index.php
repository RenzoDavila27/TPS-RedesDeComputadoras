<!DOCTYPE html>
<html lang="es">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
		<meta http-equiv="Pragma" content="no-cache">
		<meta http-equiv="Expires" content="0">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Banco Patagonia | Vos y lo que querés</title>
		<meta name="description" content="Somos un banco comercial con casa central en la ciudad de Buenos Aires y 200 puntos de atención distribuidos en las principales ciudades de Argentina.">
		<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-NL73B44');</script>
<!-- End Google Tag Manager -->

<link rel="shortcut icon" href="../favicon.ico" type="image/x-icon"/>
<link href="../assets/fonts/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="../assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="../assets/js/mtabs/bootstrap-responsive-tabs.css" rel="stylesheet" type="text/css">
<link href="../assets/js/slick/slick.css" rel="stylesheet" type="text/css">
<link href="../assets/js/fancybox/jquery.fancybox.min.css" rel="stylesheet" type="text/css">
<link href="../assets/css/styles.css" rel="stylesheet" type="text/css">
<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->        <!-- BOTÓN PADI / CHATBOT (1/3)-->
        <link href="../assets/css/padi.css" rel="stylesheet" type="text/css">
        <!-- SNIFFER -->
        <style>
			.placeholder-top .topbanner { background:#eeeeee; height:59px; top: 77px;}
			.placeholder-top .topbanner p { color:#666666; font-size:10px; letter-spacing: 0.1px; margin-top:5px;}
			.placeholder-top .topbanner figure { float:left; margin-top: 5px;}
			.placeholder-top .topbanner figure.app-titulo { margin-left:8px; padding-top:10px;}
			.placeholder-top .topbanner .app-download { position:absolute; right:40px; top:14px; padding:8px 18px; background:#c1d42f; color:#004987; font-family: "Roboto-Bold"; font-size: 11px;}
            @media screen and (max-width: 767px) {
                .placeholder-top .topbanner { top: 59px;}
            }
		</style>
        <!-- BANNERS FIJOS (4) -->
        <style>
            .h-destacado figcaption { width: 100%; text-transform: none;}
            @media screen and (max-width: 380px) {
                .h-destacados .col-xs-6 { width: 100%;}
            }
        </style>
        <!-- BTN ANIMACION (AYUDA) -->
        <style>
            @keyframes btn-animado-2{
                0%{ background:#004987; }
                50%{ background:#c1d42f; }
                100%{ background:#004987; }
            }
            @-webkit-keyframes btn-animado-2{
                0%{ background:#004987; }
                50%{ background:#c1d42f; }
                100%{ background:#004987; }
            }
            .btn-animado-2 { animation:btn-animado-2 2s 1s infinite; -webkit-animation:btn-animado-2 2s 1s infinite;}
            .btn-animado-2:hover { animation: none; -webkit-animation: none; background:#c1d42f;}
        </style>
        <!-- SLIDES RESPONSIVE -->
        <style>
            /* DSK */
			#slide-temporada-verano-2025 { background-image: url(images/main-slider/slide-temporada-verano-2025-dsk.jpg); background-image: -webkit-image-set ( url("images/main-slider/slide-temporada-verano-2025-dsk.jpg") 1x, url("images/main-slider/slide-temporada-verano-2025-dsk@2x.jpg") 2x ); }
			
			#slide-pago-transporte { background-image: url(images/main-slider/slide-pago-transporte-dsk.png); background-image: -webkit-image-set ( url("images/main-slider/slide-pago-transporte-dsk.png") 1x, url("images/main-slider/slide-pago-transporte-dsk@2x.png") 2x ); }			
			
			#slide-patagonia-mix { background-image: url(../nyps/images/main-slider/slide-patagonia-mix-dsk.jpg); background-image: -webkit-image-set ( url("../nyps/images/main-slider/slide-patagonia-mix-dsk.jpg") 1x, url("../nyps/images/main-slider/slide-patagonia-mix-dsk@2x.jpg") 2x ); }
			#slide-prestamos-hipotecarios-uva { background-image: url(images/main-slider/slide-prestamos-hipotecarios-uva-dsk.jpg); background-image: -webkit-image-set ( url("images/main-slider/slide-prestamos-hipotecarios-uva-dsk.jpg") 1x, url("images/main-slider/slide-prestamos-hipotecarios-uva-dsk@2x.jpg") 2x ); }
			#slide-cuotifica-al-toque { background-image: url(images/main-slider/slide-cuotifica-al-toque-dsk.jpg); background-image: -webkit-image-set ( url("images/main-slider/slide-cuotifica-al-toque-dsk.jpg") 1x, url("images/main-slider/slide-cuotifica-al-toque-dsk@2x.jpg") 2x ); }
			#slide-patagonia-on {background-image: url(images/main-slider/slide-patagonia-on-dsk.jpg)}
			#slide-tarjeta-debito {background-image: url(images/main-slider/slide-tarjeta-debito-dsk.jpg)}
			#slide-google-pay {background-image: url(images/main-slider/slide-google-pay-dsk.jpg)}
			#slide-referidos { background-image: url(images/main-slider/slide-referidos-dsk.jpg); background-image: -webkit-image-set ( url("images/main-slider/slide-referidos-dsk.jpg") 1x, url("images/main-slider/slide-referidos-dsk@2x.jpg") 2x ); }
			/*#slide-raspa-y-gana { background-image: url(images/main-slider/slide-raspa-y-gana-dsk.jpg); background-image: -webkit-image-set ( url("images/main-slider/slide-raspa-y-gana-dsk.jpg") 1x, url("images/main-slider/slide-raspa-y-gana-dsk@2x.jpg") 2x ); }*/
			/*#slide-beneficios-wapa { background-image: url(images/main-slider/slide-wapa-dsk.jpg); background-image: -webkit-image-set ( url("images/main-slider/slide-wapa-dsk.jpg") 1x, url("images/main-slider/slide-wapa-dsk@2x.jpg") 2x ); }*/
			/*#slide-patagonia-mix-swiss-medical { background-image: url(../nyps/images/main-slider/slide-patagonia-mix-swiss-medical-dsk.jpg); background-image: -webkit-image-set ( url("../nyps/images/main-slider/slide-patagonia-mix-swiss-medical-dsk.jpg") 1x, url("../nyps/images/main-slider/slide-patagonia-mix-swiss-medical-dsk@2x.jpg") 2x ); }*/
			/*#slide-beneficios-diciembre { background-image: url(images/main-slider/slide-beneficios-diciembre-dsk.jpg); background-image: -webkit-image-set ( url("images/main-slider/slide-beneficios-diciembre-dsk.jpg") 1x, url("images/main-slider/slide-beneficios-diciembre-dsk@2x.jpg") 2x ); }*/
			/*#slide-club-patagonia { background-image: url(images/main-slider/slide-club-patagonia-dsk.jpg); background-image: -webkit-image-set ( url("images/main-slider/slide-club-patagonia-dsk.jpg") 1x, url("images/main-slider/slide-club-patagonia-dsk@2x.jpg") 2x ); }*/
			/*#slide-programa-referidos-anses { background-image: url(images/main-slider/slide-programa-referidos-anses-dsk.jpg); background-image: -webkit-image-set ( url("images/main-slider/slide-programa-referidos-anses-dsk.jpg") 1x, url("images/main-slider/slide-programa-referidos-anses-dsk@2x.jpg") 2x ); }*/
            
            @media screen and (max-width: 1200px) {
				/* TBT */
				#slide-temporada-verano-2025 { background-image: url(images/main-slider/slide-temporada-verano-2025-tbl.jpg); background-size: auto !important; background-image: -webkit-image-set ( url("images/main-slider/slide-temporada-verano-2025-tbl.jpg") 1x, url("images/main-slider/slide-temporada-verano-2025-tbl@2x.jpg") 2x ); }
				
				#slide-pago-transporte { background-image: url(images/main-slider/slide-pago-transporte-tbl.png); background-size: auto !important; background-image: -webkit-image-set ( url("images/main-slider/slide-pago-transporte-tbl.png") 1x, url("images/main-slider/slide-pago-transporte-tbl@2x.png") 2x ); }				
				
				#slide-patagonia-mix { background-image: url(../nyps/images/main-slider/slide-patagonia-mix-tbl.jpg); background-size: auto !important; background-image: -webkit-image-set ( url("../nyps/images/main-slider/slide-patagonia-mix-tbl.jpg") 1x, url("../nyps/images/main-slider/slide-patagonia-mix-tbl@2x.jpg") 2x ); }
				#slide-prestamos-hipotecarios-uva { background-image: url(images/main-slider/slide-prestamos-hipotecarios-uva-tbl.jpg); background-size: auto !important; background-image: -webkit-image-set ( url("images/main-slider/slide-prestamos-hipotecarios-uva-tbl.jpg") 1x, url("images/main-slider/slide-prestamos-hipotecarios-uva-tbl@2x.jpg") 2x ); }
				#slide-cuotifica-al-toque { background-image: url(images/main-slider/slide-cuotifica-al-toque-tbl.jpg); background-size: auto !important; background-image: -webkit-image-set ( url("images/main-slider/slide-cuotifica-al-toque-tbl.jpg") 1x, url("images/main-slider/slide-cuotifica-al-toque-tbl@2x.jpg") 2x ); }
				#slide-patagonia-on {background-image: url(images/main-slider/slide-patagonia-on-tbl.jpg); background-size: auto !important ;}
				#slide-tarjeta-debito {background-image: url(images/main-slider/slide-tarjeta-debito-tbl.jpg); background-size: auto !important ;}
				#slide-google-pay {background-image: url(images/main-slider/slide-google-pay-tbl.jpg); background-size: auto !important ;}
				#slide-referidos { background-image: url(images/main-slider/slide-referidos-tbl.jpg); background-size: auto !important; background-image: -webkit-image-set ( url("images/main-slider/slide-referidos-tbl.jpg") 1x, url("images/main-slider/slide-referidos-tbl@2x.jpg") 2x ); }
				/*#slide-raspa-y-gana { background-image: url(images/main-slider/slide-raspa-y-gana-tbl.jpg); background-size: auto !important; background-image: -webkit-image-set ( url("images/main-slider/slide-raspa-y-gana-tbl.jpg") 1x, url("images/main-slider/slide-raspa-y-gana-tbl@2x.jpg") 2x ); }*/
				/*#slide-beneficios-wapa { background-image: url(images/main-slider/slide-wapa-tbl.jpg); background-size: auto !important; background-image: -webkit-image-set ( url("images/main-slider/slide-wapa-tbl.jpg") 1x, url("images/main-slider/slide-wapa-tbl@2x.jpg") 2x ); }*/
				/*#slide-patagonia-mix-swiss-medical { background-image: url(../nyps/images/main-slider/slide-patagonia-mix-swiss-medical-tbl.jpg); background-size: auto !important; background-image: -webkit-image-set ( url("../nyps/images/main-slider/slide-patagonia-mix-swiss-medical-tbl.jpg") 1x, url("../nyps/images/main-slider/slide-patagonia-mix-swiss-medical-tbl@2x.jpg") 2x ); }*/
				/*#slide-beneficios-diciembre { background-image: url(images/main-slider/slide-beneficios-diciembre-tbl.jpg); background-size: auto !important; background-image: -webkit-image-set ( url("images/main-slider/slide-beneficios-diciembre-tbl.jpg") 1x, url("images/main-slider/slide-beneficios-diciembre-tbl@2x.jpg") 2x ); }*/
				/*#slide-club-patagonia { background-image: url(images/main-slider/slide-club-patagonia-tbl.jpg); background-size: auto !important; background-image: -webkit-image-set ( url("images/main-slider/slide-club-patagonia-tbl.jpg") 1x, url("images/main-slider/slide-club-patagonia-tbl@2x.jpg") 2x ); }*/
				/*#slide-programa-referidos-anses { background-image: url(images/main-slider/slide-programa-referidos-anses-tbl.jpg); background-size: auto !important; background-image: -webkit-image-set ( url("images/main-slider/slide-programa-referidos-anses-tbl.jpg") 1x, url("images/main-slider/slide-programa-referidos-anses-tbl@2x.jpg") 2x ); }*/
            }
            
            @media screen and (max-width: 560px) {
				/* MBL */
				#slide-temporada-verano-2025 { background-image: url(images/main-slider/slide-temporada-verano-2025-mbl.jpg); background-image: -webkit-image-set ( url("images/main-slider/slide-temporada-verano-2025-mbl.jpg") 1x, url("images/main-slider/slide-temporada-verano-2025-mbl@2x.jpg") 2x ); }
				
				#slide-pago-transporte { background-image: url(images/main-slider/slide-pago-transporte-mbl.png); background-image: -webkit-image-set ( url("images/slide-pago-transporte-mbl.png") 1x, url("images/main-slider/slide-pago-transporte-mbl@2x.png") 2x ); }
				
				#slide-patagonia-mix { background-image: url(../nyps/images/main-slider/slide-patagonia-mix-mbl.jpg); background-image: -webkit-image-set ( url("../nyps/images/main-slider/slide-patagonia-mix-mbl.jpg") 1x, url("../nyps/images/main-slider/slide-patagonia-mix-mbl@2x.jpg") 2x ); }
				#slide-prestamos-hipotecarios-uva { background-image: url(images/main-slider/slide-prestamos-hipotecarios-uva-mbl.jpg); background-image: -webkit-image-set ( url("images/main-slider/slide-prestamos-hipotecarios-uva-mbl.jpg") 1x, url("images/main-slider/slide-prestamos-hipotecarios-uva-mbl@2x.jpg") 2x ); }
				#slide-cuotifica-al-toque { background-image: url(images/main-slider/slide-cuotifica-al-toque-mbl.jpg); background-image: -webkit-image-set ( url("images/main-slider/slide-cuotifica-al-toque-mbl.jpg") 1x, url("images/main-slider/slide-cuotifica-al-toque-mbl@2x.jpg") 2x ); }
				#slide-patagonia-on {background-image: url(images/main-slider/slide-patagonia-on-mbl.jpg)}
				#slide-tarjeta-debito {background-image: url(images/main-slider/slide-tarjeta-debito-mbl.jpg)}
				#slide-google-pay {background-image: url(images/main-slider/slide-google-pay-mbl.jpg)}
				#slide-referidos { background-image: url(images/main-slider/slide-referidos-mbl.jpg); background-image: -webkit-image-set ( url("images/main-slider/slide-referidos-mbl.jpg") 1x, url("images/main-slider/slide-referidos-mbl@2x.jpg") 2x ); }
				/*#slide-raspa-y-gana { background-image: url(images/main-slider/slide-raspa-y-gana-mbl.jpg); background-image: -webkit-image-set ( url("images/main-slider/slide-raspa-y-gana-mbl.jpg") 1x, url("images/main-slider/slide-raspa-y-gana-mbl@2x.jpg") 2x ); }*/
				/*#slide-beneficios-wapa { background-image: url(images/main-slider/slide-wapa-mbl.jpg); background-image: -webkit-image-set ( url("images/main-slider/slide-wapa-mbl.jpg") 1x, url("images/main-slider/slide-wapa-mbl@2x.jpg") 2x ); }*/
				/*#slide-patagonia-mix-swiss-medical { background-image: url(../nyps/images/main-slider/slide-patagonia-mix-swiss-medical-mbl.jpg); background-image: -webkit-image-set ( url("../nyps/images/main-slider/slide-patagonia-mix-swiss-medical-mbl.jpg") 1x, url("../nyps/images/main-slider/slide-patagonia-mix-swiss-medical-mbl@2x.jpg") 2x ); }*/
				/*#slide-beneficios-diciembre { background-image: url(images/main-slider/slide-beneficios-diciembre-mbl.jpg); background-image: -webkit-image-set ( url("images/main-slider/slide-beneficios-diciembre-mbl.jpg") 1x, url("images/main-slider/slide-beneficios-diciembre-mbl@2x.jpg") 2x ); }*/
				/*#slide-club-patagonia { background-image: url(images/main-slider/slide-club-patagonia-mbl.jpg); background-image: -webkit-image-set ( url("images/main-slider/slide-club-patagonia-mbl.jpg") 1x, url("images/main-slider/slide-club-patagonia-mbl@2x.jpg") 2x ); }*/
				/*#slide-programa-referidos-anses { background-image: url(images/main-slider/slide-programa-referidos-anses-mbl.jpg); background-image: -webkit-image-set ( url("images/main-slider/slide-programa-referidos-anses-mbl.jpg") 1x, url("images/main-slider/slide-programa-referidos-anses-mbl@2x.jpg") 2x ); }*/
            }
            
        </style>
		
        <!-- VIDEO "VOS" (popup 1/3)-->
        <!--
        <style>
            #popup-lateral { position: fixed; z-index: 9999; bottom: 0; right: 0; width: 30%;}
            #popup-lateral button { position: absolute; right: 15px; top: 15px; color: #fff; z-index: 9999; }
            #popup-lateral video { width: 100%;}
            @media screen and (orientation: landscape) and (max-width: 1198px) {
                #popup-lateral { display: none;}
            }
            @media screen and (max-width: 1198px) {
                #popup-lateral { width: 40%; bottom: 62px; }
            }
            @media screen and (max-width: 500px) {
                #popup-lateral { width: 100%; padding-left: 15px; padding-right: 15px; }
                #popup-lateral button { right: 25px; }
                /*.footer-bar { padding-bottom: 55%; }*/
            }
        </style>
        -->
        <!-- -->
	</head>
<body>
	
	<!--<php include($path . "includes/header_inc(bkp-nueva-botonera).php"); ?>-->
	<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NL73B44"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

<div class="placeholder-bar">
	<div class="container-fluid header-bar">
		<div class="row">
			<header class="container">
				<div class="row">
					<div class="col-md-3 col-dsk-6 col-sm-6">
						<span class="c-hamburger c-hamburger--htx">
							<span>toggle menu</span>
						</span>
                        <!-- -->
                        <!--<img style="position: absolute; width: 42px; top: 20px; right: 40px;" class="dsk" src="<php echo $path ?>assets/images/layout/icon-verano-2022.svg">-->
                        <!-- -->
						<h1>
                            <!--<img style="position: absolute; width: 32px; top: 12px; left: 102px;" class="dsk" src="<php echo $path ?>assets/images/layout/icon-navidad-2021.svg">-->
                            <a href="index.php" class="main-logo">Banco Patagonia</a>
                        </h1>
					</div>
					<div class="col-md-9 col-dsk-6 col-sm-6">
						<div class="general-links">
							<ul class="list-unstyled">
                                <li id="btn-hacete-cliente"><a href="https://tunuevacuenta.bancopatagonia.com.ar/?utm_source=sitiowebbp&utm_medium=sitiowebbp%20banner%20home&utm_campaign=onboarding_sitiowebp_bannerhome" target="_blank"><strong>Hacete cliente <i class="fa fa-angle-right"></i></strong></a></li>								<li><a href="../preguntas-frecuentes/index.php" class="">Ayuda</a></li>
								<!--<li><a href="<php echo $folder_canales ?>index.php" class="<php echo $canales ?>">Canales de atención</a></li>-->
								<!--<li><a href="http://sucursalesycajeros.bancopatagonia.com.ar/sucursales.html" target="_blank">Sucursales y cajeros</a></li>-->
								<!--<li><a href="<php echo $folder_contactenos ?>index.php" class="<php echo $contactenos ?>">Contactanos</a></li>-->
                                <!--<li><a href="<php echo $path ?>ayuda/index.php" class="<php echo $ayuda ?>">Ayuda</a></li>-->
							</ul>
						</div>
						<div class="top-links">
							<ul class="list-unstyled">
								<li><a href="index.php" class="active">PERSONAS</a></li>
								<li><a href="../nyps/index.php" class="">PROFESIONALES Y COMERCIOS</a></li>
								<li><a href="../pyme/index.php" class="">PYME</a></li>
								<li><a href="../agro/index.php" class="">AGRO</a></li>
								<li><a href="../empresas/index.php" class="">EMPRESAS</a></li>
								<li><a href="../sector-publico/index.php" class="">SECTOR PÚBLICO</a></li>
								<li><a href="../institucional/index.php" class="">INSTITUCIONAL</a></li>
							</ul>
							<div class="ebank">
                            <!-- antes href: <php echo $folder_empresas ?><php echo $url_ebank ?>-->
															<a href="https://ebankpersonas.bancopatagonia.com.ar/eBanking/usuarios/login.htm" class="patagonia-ebank" target="_blank">Patagonia e-Bank</a>
														</div>
						</div>
					</div>
				</div>
			</header>
		</div>
	</div>
</div>

<div class="container-fluid nav-bar">
	<div class="row">
		<nav class="container">
			<div class="row">
				<!--<div class="col-md-9 col-md-offset-3">-->
                <div class="col-md-10 col-md-offset-3"><!-- ajuste agro -->
					<ul class="list-unstyled sub-navbar">
						
												<!-- PERSONAS -->
                        <li class="nav-item"><a href="#" class="nav-lnk ">PATAGONIA CLÁSICA</a>
							<ul class="list-unstyled submenu">
                                <li><a href="../personas/patagonia-clasica/patagonia-ahorro/productos.php">Patagonia Ahorro</a></li>
                                <li><a href="../personas/patagonia-clasica/paquete/productos.php">Patagonia Clásica</a></li>
                                <!--<li><a href="<php echo $path ?>personas/patagonia-clasica/mas/productos.php">Patagonia Clásica Más</a></li>-->
                                <li><a href="../personas/patagonia-clasica/premium/productos.php">Patagonia Clásica Premium</a></li>
                                <li><a href="../personas/patagonia-clasica/patagonia-sueldo/productos.php">Patagonia Sueldo</a></li>
							</ul>
						</li>
						<li class="nav-item"><a href="#" class="nav-lnk ">PATAGONIA PLUS</a>
							<ul class="list-unstyled submenu">
                                <li><a href="../personas/patagonia-plus/productos.php">Patagonia Plus</a></li>
                                <li><a href="../personas/patagonia-plus/premium/productos.php">Patagonia Plus Premium</a></li>
							</ul>						
						</li>
						<li class="nav-item"><a href="#" class="nav-lnk ">PATAGONIA SINGULAR</a>
							<ul class="list-unstyled submenu">
								<li><a href="../personas/patagonia-singular/paquete/propuesta.php">Patagonia Singular</a></li>
                                <li><a href="../personas/patagonia-singular/beneficios-exclusivos.php">Beneficios Exclusivos</a></li>
                                <!--<li><a href="<php echo $path ?>personas/patagonia-singular/atencion-exclusiva/index.php">Atención Exclusiva</a></li>-->
                                <!--<li><a href="<php echo $path ?>personas/patagonia-singular/eventos-y-novedades/index.php">Eventos y Novedades</a></li>-->
							</ul>
						</li>
						<!--<li class="nav-item"><a href="<php echo $path ?>patagoniaon/index.php" target="_blank" class="nav-lnk">PATAGONIA ON</a></li>-->
						<li class="nav-item"><a href="#" class="nav-lnk ">PATAGONIA ON</a>
							<ul class="list-unstyled submenu">
                                <li><a href="../patagoniaon/index.php" target="_blank">Patagonia ON</a></li>
								<li><a href="../personas/productos-y-servicios/patagonia-universitaria.php">Patagonia ON Universitaria</a></li>
							</ul>
						</li>
						<li class="nav-item"><a href="#" class="nav-lnk ">PRODUCTOS Y SERVICIOS</a>
							<ul class="list-unstyled submenu">
                                <li><a href="../personas/apple-pay.php">Apple Pay</a></li>
                                <li><a href="../personas/productos-y-servicios/caja-de-seguridad.php">Caja de Seguridad</a></li>
                                <li><a href="../personas/productos-y-servicios/comercio-exterior/productos.php">Comercio exterior</a></li>
								<!--<li><a href="<php echo $path ?>personas/productos-y-servicios/beneficios-wapa.php">Comercios WAPA</a></li>-->
								<li><a href="../personas/cuotifica-al-toque.php">Cuotificá al Toque</a></li>
								<li><a href="../personas/google-pay.php">Google Pay</a></li>
                                <li><a href="../personas/productos-y-servicios/inversiones.php">Inversiones</a></li>
                                <li><a href="../personas/jubilados/index.php">Jubilados</a></li>
                                <li><a href="../personas/productos-y-servicios/patagonia-para-menores.php">Patagonia para Menores</a></li>
                                <!--<li><a href="<php echo $path ?>personas/productos-y-servicios/patagonia-universitaria.php">Patagonia Universitaria</a></li>-->
                                <li><a href="../personas/productos-y-servicios/prestamos.php">Prestamos</a></li>
                                <li><a href="../personas/seguros/index.php">Seguros</a></li>
                                <li><a href="../personas/productos-y-servicios/tarjetas-de-credito/visa.php">Tarjetas de crédito</a></li>
								<li><a href="../personas/productos-y-servicios/tarjetas-de-debito/patagonia-24.php">Tarjetas de débito</a></li>
							</ul>
						</li>
						<!-- FIN PERSONAS -->
						                        
                                                
                                                
                        						
												
												
						
											</ul>
				</div>
			</div>
		</nav>
	</div>
</div>

<div class="mobile-nav-bar">
	<ul class="list-unstyled">
        
        <!-- PERSONAS -->
		<li class="nav-main-item"><a href="#" class="has-sub-items active">PERSONAS <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="index.php" class="active">HOME</a></li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA CLÁSICA</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../personas/patagonia-clasica/patagonia-ahorro/productos.php">Patagonia Ahorro</a></li>
                        <li><a href="../personas/patagonia-clasica/paquete/productos.php">Patagonia Clásica</a></li>
                        <!--<li><a href="<php echo $path ?>personas/patagonia-clasica/mas/productos.php">Patagonia Clásica Más</a></li>-->
                        <li><a href="../personas/patagonia-clasica/premium/productos.php">Patagonia Clásica Premium</a></li>
                        <li><a href="../personas/patagonia-clasica/patagonia-sueldo/productos.php">Patagonia Sueldo</a></li>
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA PLUS</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../personas/patagonia-plus/productos.php">Patagonia Plus</a></li>
                        <li><a href="../personas/patagonia-plus/premium/productos.php">Patagonia Plus Premium</a></li>
                    </ul>						
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA SINGULAR</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../personas/patagonia-singular/paquete/propuesta.php">Patagonia Singular</a></li>
                        <li><a href="../personas/patagonia-singular/beneficios-exclusivos.php">Beneficios Exclusivos</a></li>
                        <!--<li><a href="<php echo $path ?>personas/patagonia-singular/atencion-exclusiva/index.php">Atención Exclusiva</a></li>-->
                        <!--<li><a href="<php echo $path ?>personas/patagonia-singular/eventos-y-novedades/index.php">Eventos y Novedades</a></li>-->
                    </ul>
                </li>
				<!--<li class="nav-sub-item"><a href="<php echo $path ?>patagoniaon/index.php" target="_blank">PATAGONIA ON</a></li>-->
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA ON</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../patagoniaon/index.php" target="_blank">Patagonia ON</a></li>
						<li><a href="../personas/productos-y-servicios/patagonia-universitaria.php">Patagonia ON Universitaria</a></li>
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PRODUCTOS Y SERVICIOS</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../personas/apple-pay.php">Apple Pay</a></li>
                        <li><a href="../personas/productos-y-servicios/caja-de-seguridad.php">Caja de Seguridad</a></li>
                        <li><a href="../personas/productos-y-servicios/comercio-exterior/productos.php">Comercio exterior</a></li>
						<!--<li><a href="<php echo $path ?>personas/productos-y-servicios/beneficios-wapa.php">Comercios WAPA</a></li>-->
						<li><a href="../personas/cuotifica-al-toque.php">Cuotificá al Toque</a></li>
						<li><a href="../personas/google-pay.php">Google Pay</a></li>
                        <li><a href="../personas/productos-y-servicios/inversiones.php">Inversiones</a></li>
                        <li><a href="../personas/jubilados/index.php">Jubilados</a></li>
                        <li><a href="../personas/productos-y-servicios/patagonia-para-menores.php">Patagonia para Menores</a></li>
                        <!--<li><a href="<php echo $path ?>personas/productos-y-servicios/patagonia-universitaria.php">Patagonia Universitaria</a></li>-->
                        <li><a href="../personas/productos-y-servicios/prestamos.php">Prestamos</a></li>
                        <li><a href="../personas/seguros/index.php">Seguros</a></li>
                        <li><a href="../personas/productos-y-servicios/tarjetas-de-credito/visa.php">Tarjetas de crédito</a></li>
                        <li><a href="../personas/productos-y-servicios/tarjetas-de-debito/patagonia-24.php">Tarjetas de débito</a></li>
                    </ul>
                </li>
			</ul>
		</li>
        <!-- FIN PERSONAS -->
        
        <!-- NYPS -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">PROFESIONALES Y COMERCIOS <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../nyps/index.php" class="">HOME</a></li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA CLÁSICA</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../nyps/patagonia-clasica/premium/productos.php">Patagonia Clásica Premium</a></li>
                        <li><a href="../nyps/patagonia-clasica/patagonia-emprendimiento/productos.php">Patagonia Emprendimiento</a></li>
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA PLUS</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../nyps/patagonia-plus/productos.php">Patagonia Plus</a></li>
                        <li><a href="../nyps/patagonia-plus/premium/productos.php">Patagonia Plus Premium</a></li>
                    </ul>						
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA SINGULAR</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../nyps/patagonia-singular/paquete/propuesta.php">Patagonia Singular</a></li>
                        <li><a href="../nyps/patagonia-singular/beneficios-exclusivos.php">Beneficios Exclusivos</a></li>
                        <!--<li><a href="<php echo $path ?>nyps/patagonia-singular/eventos-y-novedades/index.php">Eventos y Novedades</a></li>-->
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PRODUCTOS Y SERVICIOS</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../nyps/productos-y-servicios/tarjetas-de-debito/patagonia-24.php">Tarjetas de débito</a></li>
                        <li><a href="../nyps/productos-y-servicios/tarjetas-de-credito/visa.php">Tarjetas de crédito</a></li>
                        <li><a href="../nyps/productos-y-servicios/prestamos.php">Prestamos</a></li>
                        <li><a href="../nyps/seguros/index.php">Seguros</a></li>
                        <li><a href="../nyps/productos-y-servicios/inversiones.php">Inversiones</a></li>
                        <li><a href="../nyps/productos-y-servicios/comercio-exterior/productos.php">Comercio exterior</a></li>
                        <li><a href="../nyps/productos-y-servicios/caja-de-seguridad.php">Caja de Seguridad</a></li>
                        <li><a href="../nyps/productos-y-servicios/factura-electronica.php">Factura electrónica</a></li>
                        <li><a href="../nyps/productos-y-servicios/pagos-afip.php">Pagos AFIP</a></li>
                        <!--<li><a href="<php echo $path ?>nyps/productos-y-servicios/soluciones-para-tu-empresa.php">Soluciones para tu empresa</a></li>-->
                        <!--<li><a href="<php echo $path ?>nyps/productos-y-servicios/comercios-patagonia.php">Comercios Patagonia</a></li>-->
						<li><a href="../nyps/productos-y-servicios/wapa.php">WAPA</a></li>
                    </ul>
                </li>
			</ul>		
		</li>
        <!-- FIN NYPS -->
        
        <!-- PYME -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">PYME <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../pyme/index.php" class="">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">CUENTAS</a>
					<ul class="list-unstyled submenu">
                        <li><a href="../pyme/cuentas/pequenas-empresas.php">Pyme Pequeñas Empresas</a></li>
				        <li><a href="../pyme/cuentas/medianas-empresas.php">Pyme Medianas Empresas</a></li>
                        <!--
						<li><a href="../pyme/cuentas/patagonia-empresario.php">Patagonia Empresario</a></li>
						<li><a href="../pyme/cuentas/patagonia-empresario-premier.php">Patagonia Empresario Premier</a></li>
						<li><a href="../pyme/cuentas/patagonia-empresa.php">Patagonia Empresa</a></li>
                        -->
                        <!--<li><a href="../pyme/cuentas/patagonia-comercio.php">Patagonia Comercio</a></li>-->
                        <li><a href="../pyme/cuentas/patagonia-consorcio.php">Patagonia Consorcio</a></li>
						<li><a href="../pyme/cuentas/cuenta-corriente.php">Cuenta Corriente</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA SUELDO</a>
					<ul class="list-unstyled submenu">
						<li><a href="../pyme/patagonia-sueldo/servicios.php">Servicios</a></li>
						<li><a href="../pyme/patagonia-sueldo/preguntas-frecuentes.php">Preguntas Frecuentes</a></li>
						<li><a href="../pyme/patagonia-sueldo/guia-implementacion.php">Guía de Implementación</a></li>
					</ul>
				</li>						
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">COMERCIO EXTERIOR</a>
					<ul class="list-unstyled submenu">
						<li><a href="../pyme/comercio-exterior/solicitud-electronica.php">Solicitud Electrónica</a></li>
						<li><a href="../pyme/comercio-exterior/productos.php">Productos</a></li>
						<li><a href="../pyme/comercio-exterior/otros-servicios.php">Servicios</a></li>
						<!--<li><a href="<php echo $folder_pymeCexterior ?>financiaciones.php">Financiaciones</a></li>-->
                        <li><a href="../pyme/comercio-exterior/herramientas-para-exportar.php">Herramientas para Exportar</a></li>
						<li><a href="../pyme/comercio-exterior/marco-regulatorio/normas-y-regulaciones.php">Marco Regulatorio</a></li>
					</ul>
				</li>						
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">FINANCIACIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../pyme/financiacion/patagonia-leasing.php">Patagonia Leasing</a></li>
						<li><a href="../pyme/financiacion/mercado-capitales.php">Mercado de Capitales</a></li>
						<li><a href="../pyme/financiacion/alternativas-de-financiacion.php">Alternativas de Financiación</a></li>
					</ul>
				</li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">SEGUROS</a>
					<ul class="list-unstyled submenu">
						<li><a href="../pyme/seguros/protege-tus-bienes/integral-comercio.php">Protegé tus Bienes</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">INVERSIONES</a>
					<ul class="list-unstyled submenu">
						<li><a href="../pyme/inversiones/plazo-fijo.php">Plazo Fijo</a></li>
						<li><a href="../pyme/inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
						<li><a href="../pyme/inversiones/fidecomisos-financieros.php">Fidecomisos Financieros</a></li>
					</ul>
				</li>						
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">SERVICIOS</a>
					<ul class="list-unstyled submenu">
						<li><a href="../pyme/servicios/recaudaciones.php">Recaudaciones</a></li>
						<li><a href="../pyme/servicios/pagos.php">Pagos</a></li>
						<li><a href="../pyme/servicios/tarjetas-comerciales.php">Tarjetas Comerciales</a></li>
						<li><a href="../pyme/servicios/comercios-patagonia.php">Comercios Patagonia</a></li>
                        <li><a href="../pyme/servicios/pago-de-servicios.php">Pago de Servicios</a></li>
						<li><a href="../pyme/servicios/interbanking.php">Interbanking</a></li>
						<li><a href="../pyme/servicios/interfacturas.php">Interfacturas</a></li>
						<li><a href="../pyme/servicios/pagos-afip.php">Pagos AFIP</a></li>
						<li><a href="../pyme/servicios/wapa.php">WAPA</a></li>
					</ul>
				</li>
			</ul>		
		</li>
        <!-- FIN PYME -->
        
        <!-- AGRO -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">AGRO <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../agro/index.php" class="">HOME</a></li>
                <!-- -->
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">OFERTA AGRO</a>
					<ul class="list-unstyled submenu">
                    	<!--<li><a href="<php echo $folder_agroFinanciacion ?>insumos.php">Insumos en USD</a></li>-->
                        <li><a href="../agro/convenios/acuerdos-y-beneficios.php">Acuerdos y convenios</a></li>
						<li><a href="../agro/financiacion/maquinaria-agricola.php">Financiación Maquinaria Agrícola</a></li>
						<li><a href="../agro/seguros/campo.php">Seguros para tu campo</a></li>
					</ul>
				</li>
                <!-- -->
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">TARJETA PATAGONIA AGRO</a>
					<ul class="list-unstyled submenu">
						<li><a href="../agro/tarjeta-patagonia-agro/para-usuarios.php">Para Usuarios</a></li>
						<li><a href="../agro/tarjeta-patagonia-agro/para-comercios.php">Para Comercios</a></li>
						<li><a href="../agro/tarjeta-patagonia-agro/acuerdo-tasa-0.php">Tarjetas Agro Convenios Preferenciales</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="../agro/cuenta-agro/cuenta-agro.php" class="">CUENTA AGRO</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">FINANCIACIÓN</a>
					<ul class="list-unstyled submenu">
                        <li><a href="../agro/insumos/index.php">Insumos</a></li>
                        <li><a href="../agro/financiacion/maquinaria-agricola.php">Maquinarias</a></li>
                        <li><a href="../empresas/financiacion/convenios-de-financiacion.php">Camiones</a></li>
						<!--<li><a href="<php echo $folder_agroFinanciacion ?>capital-de-trabajo.php">Capital de Trabajo</a></li>-->
						<!--<li><a href="<php echo $folder_agroFinanciacion ?>proyectos-de-inversion.php">Proyectos de Inversión</a></li>-->
						<!--<li><a href="<php echo $folder_agroFinanciacion ?>creditos-para-hacienda.php">Créditos para Hacienda</a></li>-->
						<!--<li><a href="<php echo $folder_agroFinanciacion ?>leasing-y-prendarios.php">Leasing y Prendarios</a></li>-->
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">INVERSIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../agro/inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
						<li><a href="../agro/inversiones/fidecomisos-financieros.php">Fidecomisos Financieros</a></li>
						<li><a href="../agro/inversiones/plazos-fijos.php">Plazos Fijos</a></li>
					</ul>
				</li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">COMERCIO EXTERIOR</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../agro/comercio-exterior/solicitud-electronica.php">Solicitud Electrónica</a></li>
                        <li><a href="../agro/comercio-exterior/productos.php">Productos</a></li>
                        <li><a href="../agro/comercio-exterior/otros-servicios.php">Servicios</a></li>
                        <li><a href="../agro/comercio-exterior/herramientas-para-exportar.php">Herramientas para Exportar</a></li>
                        <li><a href="../agro/comercio-exterior/marco-regulatorio/normas-y-regulaciones.php">Marco Regulatorio</a></li>
                    </ul>
                </li>
                <!--
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">SERVICIOS</a>
					<ul class="list-unstyled submenu">
						<li><a href="../agro/servicios/centro-atencion-empresas.php">Centro de Atención para Empresas</a></li>
					</ul>
				</li>
                -->
                <!-- -->
                <li class="nav-sub-item"><a href="../agro/seguros/campo.php" class="">SEGUROS</a></li>
                <!-- -->
			</ul>
		</li>
        <!-- FIN AGRO -->
        
        <!-- EMPRESAS -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">EMPRESAS <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../empresas/index.php" class="">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA SUELDO</a>
					<ul class="list-unstyled submenu">
						<li><a href="../empresas/patagonia-sueldo/servicios.php">Servicios</a></li>
						<li><a href="../empresas/patagonia-sueldo/preguntas-frecuentes.php">Preguntas Frecuentes</a></li>
						<li><a href="../empresas/patagonia-sueldo/guia-implementacion.php">Guía de Implementación</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">COMERCIO EXTERIOR</a>
					<ul class="list-unstyled submenu">
						<li><a href="../empresas/comercio-exterior/solicitud-electronica.php">Solicitud Electrónica</a></li>
						<li><a href="../empresas/comercio-exterior/productos.php">Productos</a></li>
						<li><a href="../empresas/comercio-exterior/otros-servicios.php">Servicios</a></li>
						<!--<li><a href="<php echo $folder_Cexterior ?>financiaciones.php">Financiaciones</a></li>-->
                        <li><a href="../empresas/comercio-exterior/herramientas-para-exportar.php">Herramientas para Exportar</a></li>
						<li><a href="../empresas/comercio-exterior/marco-regulatorio/normas-y-regulaciones.php">Marco Regulatorio</a></li>
					</ul>
				</li>
                <!-- -->
				<!--<li class="nav-sub-item"><a href="../empresas/comunidades-de-negocios/index.php" class="">COMUNIDADES DE NEGOCIOS</a></li>-->
                <!-- -->
				<li class="nav-sub-item"><a href="index.php" class="nav-lnk ">COMERCIOS PATAGONIA</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">FINANCIACIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../empresas/financiacion/patagonia-leasing.php">Patagonia Leasing</a></li>
						<li><a href="../empresas/financiacion/mercado-capitales.php">Mercado Capitales</a></li>
						<li><a href="../empresas/financiacion/alternativas-de-financiacion.php">Alternativas de Financiación</a></li>
                        <li><a href="../empresas/financiacion/convenios-de-financiacion.php">Convenios de Financiación</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">INVERSIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../empresas/inversiones/plazos-fijos.php">Plazos Fijos</a></li>
						<li><a href="../empresas/inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
						<li><a href="../empresas/inversiones/compra-venta-titulos-acciones.php">Compra - Venta de Títulos y Acciones</a></li>
						<li><a href="../empresas/inversiones/custodia-de-titulos.php">Custodia de Títulos</a></li>
						<li><a href="../empresas/inversiones/fidecomisos-financieros.php">Fidecomisos Financieros</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">SERVICIOS</a>
					<ul class="list-unstyled submenu">
                        <li><a href="../empresas/patagonia-movil-empresas.php">Patagonia Móvil Empresas</a></li>
						<li><a href="../empresas/servicios/pagos.php">Pagos</a></li>
						<li><a href="../empresas/servicios/recaudaciones.php">Recuadaciones</a></li>
						<li><a href="../empresas/servicios/pago-de-servicios.php">Pago de Servicios</a></li>
						<li><a href="../empresas/servicios/interbanking.php">Interbanking</a></li>
						<li><a href="../empresas/servicios/interfacturas.php">Interfacturas</a></li>
						<li><a href="../empresas/servicios/tarjetas-comerciales.php">Tarjetas Comerciales</a></li>
                        <!-- -->
						<!--<li><a href="../empresas/servicios/comercios-patagonia.php">Comercios Patagonia</a></li>-->
                        <!-- -->
                        <li><a href="../empresas/servicios/centro-atencion-empresas.php">Centro de Atención para Empresas</a></li>
					</ul>
				</li>
			</ul>
		</li>
        <!-- FIN EMPRESAS -->
        
        <!-- SECTOR PÚBLICO -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">SECTOR PÚBLICO <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../sector-publico/index.php" class="">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">INVERSIONES</a>
					<ul class="list-unstyled submenu">
						<li><a href="../sector-publico/inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
						<li><a href="../sector-publico/inversiones/plazo-fijo.php">Plazo Fijo</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">SERVICIOS</a>
					<ul class="list-unstyled submenu">
						<li><a href="../sector-publico/servicios/servicio-de-recaudacion.php">Servicio de Recaudación</a></li>
						<li><a href="../sector-publico/servicios/servicio-de-pagos.php">Servicio de Pagos</a></li>
						<li><a href="../sector-publico/servicios/servicios-para-personal.php">Servicios para el Personal</a></li>
						<li><a href="../sector-publico/servicios/financiacion.php">Financiación</a></li>
						<li><a href="../sector-publico/servicios/otros-servicios.php">Servicios</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">PROGRAMA UNIVERSIDADES</a>
					<ul class="list-unstyled submenu">
						<li><a href="../sector-publico/programa-universidades/relacion-institucional.php">Relación Institucional</a></li>
						<li><a href="../sector-publico/programa-universidades/docentes-yno-docentes.php">Docentes y No Docentes</a></li>
						<li><a href="../sector-publico/programa-universidades/alumnos.php">Alumnos</a></li>
						<li><a href="../sector-publico/programa-universidades/graduados.php">Graduados</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">BENEFICIOS RÍO NEGRO</a>
					<ul class="list-unstyled submenu">
						<li><a href="../sector-publico/rio-negro/presencia.php">Presencia en Río Negro</a></li>
                        <li><a href="../sector-publico/rio-negro/propuesta-valor.php">Propuesta de valor exclusiva</a></li>
					</ul>
				</li>
			</ul>
		</li>
        <!-- FIN SECTOR PUBLICO -->
        
        <!-- INSTITUCIONAL -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">INSTITUCIONAL <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../institucional/index.php" class="">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">BANCO PATAGONIA</a>
					<ul class="list-unstyled submenu">
						<li><a href="../institucional/banco-patagonia/historia.php">Historia</a></li>
						<li><a href="../institucional/banco-patagonia/mercado-de-capitales.php">Mercado de Capitales</a></li>
						<li><a href="../institucional/banco-patagonia/patagonia-inversora.php">Patagonia Inversora</a></li>
						<li><a href="../institucional/banco-patagonia/patagonia-valores-sa.php">Patagonia Valores S.A</a></li>
						<li><a href="https://bp.bancopatagonia.com.ar/relacion-con-inversores/es/institucional" target="_blank">Relación con Inversores</a></li>
						<li><a href="../institucional/banco-patagonia/desarrollo-humano.php">Desarrollo Humano</a></li>
						<li><a href="../institucional/banco-patagonia/sustentabilidad.php">Sustentabilidad</a></li>
						<li><a href="../institucional/banco-patagonia/politicas-aml-cft.php">Póliticas AML/CFT</a></li>
						<li><a href="../institucional/banco-patagonia/disciplina-del-mercado.php">Disciplina de Mercado</a></li>
                        <li><a href="../institucional/banco-patagonia/asistencia-a-vinculados.php">Asistencia a vinculados</a></li>
                        <li><a href="../institucional/banco-patagonia/etica-e-integridad.php">Ética e Integridad</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">ORGANIZACIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../institucional/organizacion/accionistas.php">Accionistas</a></li>
						<li><a href="../institucional/organizacion/autoridades.php">Autoridades</a></li>
                        <li><a href="../institucional/organizacion/comites.php">Comités</a></li>
						<li><a href="../institucional/organizacion/sector-financiero.php">Sector Financiero</a></li>
					</ul>
				</li>
			</ul>
		</li>
        <!-- FIN INSTITUCIONAL -->
        
        <li class="nav-main-item"><a href="https://tunuevacuenta.bancopatagonia.com.ar/?utm_source=sitiowebbp&utm_medium=sitiowebbp%20banner%20home&utm_campaign=onboarding_sitiowebp_bannerhome" target="_blank" style="text-transform: none;">Hacete cliente</a></li>		<li class="nav-main-item"><a href="../preguntas-frecuentes/index.php" class="" style="text-transform: none;">Ayuda</a></li>
		<!--<li class="nav-main-item"><a href="<php echo $folder_canales ?>index.php" class="<php echo $canales ?>" style="text-transform: none;">Canales de Atención</a></li>-->
		<!--<li class="nav-main-item"><a href="http://sucursalesycajeros.bancopatagonia.com.ar/sucursales.html" target="_blank" style="text-transform: none;">Sucursales y Cajeros</a></li>-->
		<!--<li class="nav-main-item"><a href="<php echo $folder_contactenos ?>index.php" class="<php echo $contactenos ?>" style="text-transform: none;">Contactanos</a></li>-->
        <!--<li class="nav-main-item"><a href="<php echo $path ?>ayuda/index.php" class="<php echo $ayuda ?>" style="text-transform: none;">Ayuda</a></li>-->
	</ul>
</div>    
    <!-- BOTÓN PADI / CHATBOT (2/3)-->
    <div class="jq-btn-padi btn-padi-dsk" padi-env="prod" padi-iframe="#jq-ifr-padi iframe">
    </div>
    <div id="jq-ifr-padi" class="ifr-padi-xy">
    <nav>
        <i></i>
        Padi
        <button class="close"><span>X</span></button>
    </nav>
    <iframe src=""></iframe>
</div>    
    <!-- VIDEO "VOS" (popup 2/3)-->
    <!--
    <div id="popup-lateral">
        <button class="close"><span>X</span></button>
        <video controls autoplay muted>
            <source src="videos/video-vos-y-lo-que-queres.mp4" type="video/mp4">
        </video>
    </div>
    -->
    
    <!--SNIFFER-->
    <div class="placeholder-top" id="banner-content" style="display:none;">
        <div class="topbanner">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12 col-xs-12">
                    	<!-- -->
                    	<figure class="app-logo"><img src="../assets/images/layout/icon-app.jpg" srcset="../assets/images/layout/icon-app.jpg 1x, ../assets/images/layout/icon-app@2x.jpg 2x" width="45" height="45" class="img-responsive"/></figure>
                        <figure class="app-titulo">
                        	<img src="../empresas/images/logo-patagonia-movil.svg" height="12" alt=""/>
							<p>Operá desde donde estés</p>
                        </figure>
                        <!-- -->
                        <a href="#" class="app-download" id="btn-app-download">Descargala</a>
                        <!-- -->
                        <span class="close-this-banner"></span>
                        <!-- -->
                    </div>
                </div>
            </div>
        </div>
	</div>
    
	<!--BANNERS SUBHOMES ORIGINALES-->
	<div class="main-slider">
		<div class="home-slider">
			<div>
				<div class="home-slide" id="slide-temporada-verano-2025">
                    <a href="tarjetas/temporada-verano.php"></a>
				</div>
			</div>
			<div>
				<div class="home-slide" id="slide-pago-transporte">
                    <a href="pago-de-transporte.php"></a>
				</div>
			</div>
			<div>
				<div class="home-slide" id="slide-patagonia-mix">
                    <a href="../nyps/patagonia-mix/index.php"></a>
				</div>
			</div>
			<div>
				<div class="home-slide" id="slide-prestamos-hipotecarios-uva">
                    <a href="prestamos/prestamos-hipotecarios-uva.php"></a>
				</div>
			</div>
			<div>
				<div class="home-slide" id="slide-cuotifica-al-toque">
                    <a href="cuotifica-al-toque.php"></a>
				</div>
			</div>
			<div>
				<div class="home-slide" id="slide-patagonia-on">
                    <a href="../patagoniaon/index.php" target="_blank"></a>
				</div>
			</div>
			<div>
				<div class="home-slide" id="slide-google-pay">
                    <a href="google-pay.php"></a>
				</div>
			</div>
			<div>
				<div class="home-slide" id="slide-referidos">
                    <a href="referidos.php"></a>
				</div>
			</div>
            <!--<div>
				<div class="home-slide" id="slide-raspa-y-gana">
                    <a href="../landings/raspa-y-gana-tyc.php" target="_blank"></a>
				</div>
			</div>-->
			<!--<div>
				<div class="home-slide" id="slide-beneficios-wapa">
                    <a href="productos-y-servicios/beneficios-wapa.php"></a>
				</div>
			</div>-->
			<!--<div>
				<div class="home-slide" id="slide-patagonia-mix-swiss-medical">
                    <a href="../nyps/patagonia-mix/index.php"></a>
				</div>
			</div>-->
			<!--<div>
				<div class="home-slide" id="slide-beneficios-diciembre">
                    <a href="tarjetas/beneficios.php"></a>
				</div>
			</div>-->
			<!--<div>
				<div class="home-slide" id="slide-club-patagonia">
                    <a href="https://www.clubpatagonia.com.ar/" target="_blank"></a>
				</div>
			</div>-->
			<!--<div>
				<div class="home-slide" id="slide-programa-referidos-anses">
                    <a href="referidos-anses/programa.php"></a>
				</div>
			</div>-->
		</div>
	</div>
	<!--FIN BANNERS SUB HOMES-->
    
    <section class="container mb40-h">
		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
				<a href="nueva-operatoria-sucursales.php">
					<div class="h-aviso" style="background: #00b9ad;">
						<!--<h4>Conocé la nueva operatoria en sucursales</h4>-->
                        <h4>Solicitá tu turno en sucursal acá</h4>
						<!--<span><em>+</em> turno</span>-->
					</div>
				</a>
			</div>
		</div>
	</section>

	<section class="container mb60-h h-destacados">
		<div class="row">
            <div class="col-md-4 col-sm-4 col-xs-4">
				<a href="../preguntas-frecuentes/index.php">
					<div class="h-destacado">
						<figure><img src="images/dest-cuenta-al-toque.jpg" width="359" height="148" alt="Si ya sacaste tu cuenta 100% online y tenés dudas ingresá acá" class="img-responsive"/></figure>
						<figcaption>#BancoPatagoniaAlToque</figcaption>
					</div>
				</a>
			</div>
            <div class="col-md-4 col-sm-4 col-xs-4">
				<a href="https://ahorrosybeneficios.bancopatagonia.com.ar/ahorrosybeneficios/">
					<div class="h-destacado">
                        <figure><img src="images/dest-beneficios-patagonia.jpg" width="359" height="148" alt="Beneficios Patagonia" class="img-responsive"/></figure>
						<figcaption>Beneficios Patagonia</figcaption>
					</div>
				</a>
			</div>
			<!--<div class="col-md-3 col-sm-3 col-xs-6">
				<a href="tarjetas/beneficios-clasica-y-plus.php">
					<div class="h-destacado">
                        <figure><img src="images/dest-beneficios-clasica-y-plus.jpg" width="359" height="148" alt="Beneficios Clásica y Plus" class="img-responsive"/></figure>
						<figcaption>Beneficios Clásica y Plus</figcaption>
					</div>
				</a>
			</div>-->
            <!--<div class="col-md-3 col-sm-3 col-xs-6">
				<a href="patagonia-singular/beneficios-exclusivos.php">
					<div class="h-destacado">
						<figure><img src="images/dest-beneficios-singular.jpg" width="359" height="148" alt="Beneficios Singular" class="img-responsive"/></figure>
						<figcaption>Beneficios Singular</figcaption>
					</div>
				</a>
			</div>-->
            <div class="col-md-4 col-sm-4 col-xs-4">
                <a href="http://www.clubpatagonia.com.ar/" target="_blank">
					<div class="h-destacado">
						<figure><img src="images/dest-club-patagonia.jpg" width="359" height="148" alt="Club Patagonia" class="img-responsive"/></figure>
						<figcaption><img src="images/new-club-patagonia.svg" height="16" alt="Club Patagonia" class="logo-club"/></figcaption>
					</div>
				</a>
			</div>
            <!--
            <div class="col-md-3 col-sm-3 col-xs-6">
                <a href="tarjetas/beneficios-modo.php">
					<div class="h-destacado">
						<figure><img src="images/modo.jpg" width="359" height="148" alt="Modo" class="img-responsive"/></figure>
						<figcaption>MODO</figcaption>
					</div>
				</a>
			</div>
            -->
            <!--
            <div class="col-md-3 col-sm-3 col-xs-6">
				<a href="http://ahorrosybeneficios.bancopatagonia.com.ar/" target="_blank">
					<div class="h-destacado">
						<figure><img src="images/ahorro-y-beneficios.jpg" width="359" height="148" alt="Ahorros y Beneficios" class="img-responsive"/></figure>
						<figcaption>Ahorros y beneficios</figcaption>
					</div>
				</a>
			</div>
            -->
            <!--
            <div class="col-md-3 col-sm-3 col-xs-6">
				<a href="tarjetas/beneficios-verano.php">
					<div class="h-destacado">
						<figure><img src="images/verano.jpg" width="359" height="148" alt="¡Temporada de promos!" class="img-responsive"/></figure>
						<figcaption>¡Temporada de promos!</figcaption>
					</div>
				</a>
			</div>
            -->
            <!--
            <div class="col-md-3 col-sm-3 col-xs-6">
				<a href="../canales-de-atencion/index.php">
					<div class="h-destacado">
						<figure><img src="images/canales-atencion.jpg" width="359" height="148" alt="Canales de atención" class="img-responsive"/></figure>
						<figcaption>Canales de atención</figcaption>
					</div>
				</a>
			</div>
            -->
            <!--
            <div class="col-md-4 col-sm-4 col-xs-4">
				<a href="echeq.php">
					<div class="h-destacado">
						<figure><img src="images/echeq.jpg" width="359" height="148" alt="" class="img-responsive"/></figure>
						<figcaption>ECHEQ</figcaption>
					</div>
				</a>
			</div>
            -->
            <!--
            <div class="col-md-4 col-sm-4 col-xs-4">
				<a href="comercio-exterior/exporta-simple.php">
					<div class="h-destacado">
						<figure><img src="images/exporta-simple.jpg" width="359" height="148" alt="" class="img-responsive"/></figure>
						<figcaption>EXPORTA SIMPLE</figcaption>
					</div>
				</a>
			</div>
            -->
            <!--
            <div class="col-md-4 col-sm-4 col-xs-4">
				<a href="../canales-de-atencion/patagonia-movil.php">
					<div class="h-destacado">
						<figure><img src="images/patagonia-movil.jpg" width="359" height="148" alt="" class="img-responsive"/></figure>
						<figcaption>PATAGONIA MÓVIL</figcaption>
					</div>
				</a>
			</div>
            -->
			<!--
            <div class="col-md-4 col-sm-4 col-xs-4">
				<a href="../ebank/personas/seguridad/index.shtml" target="_blank">
					<div class="h-destacado">
						<figure><img src="images/seguridad-en-internet.jpg" width="359" height="148" alt="SEGURIDAD EN INTERNET" class="img-responsive"/></figure>
						<figcaption>SEGURIDAD EN INTERNET</figcaption>
					</div>
				</a>
			</div>
            -->
		</div>
	</section>
	
    
    <section class="container mb50-h h-destacado-2s">
		<div class="row equal-height">
			<!--<div class="col-md-3 col-sm-3 col-xs-6">
				<a href="http://ahorrosybeneficios.bancopatagonia.com.ar/" target="_blank">
					<div class="h-destacado-2">					
						<h3>Ahorros y beneficios</h3>
						<span class="lnk"><em>+</em> <span>info</span></span>				
					</div>
				</a>
			</div>-->
			<div class="col-md-3 col-sm-3 col-xs-6">
				<a href="../ebank/personas/seguridad/index.php">
					<div class="h-destacado-2">					
						<h3>Seguridad en Internet</h3>
						<span class="lnk"><em>+</em> <span>info</span></span>
					</div>
				</a>
			</div>
			<div class="col-md-3 col-sm-3 col-xs-6">
				<a href="jubilaciones-italianas.php">
					<div class="h-destacado-2 h-destacado-bot">					
						<h3>Jubilaciones Italianas</h3>
						<span class="lnk"><em>+</em> <span>info</span></span>
					</div>
				</a>
			</div>
            <!--
            <div class="col-md-3 col-sm-3 col-xs-6">
				<a href="fe-de-vida.php">
					<div class="h-destacado-2 h-destacado-bot">					
						<h3>Fe de vida</h3>
						<span class="lnk"><em>+</em> <span>info</span></span>				
					</div>
				</a>
			</div>
            -->
            <!--
            <div class="col-md-3 col-sm-3 col-xs-6">
				<a href="../ayuda/index.php">
					<div class="h-destacado-2 h-destacado-bot">
                        <p class="dsk">&nbsp;</p><p class="tbl">&nbsp;</p>
						<h3>Contáctanos</h3>
						<span class="lnk"><em>+</em> <span>info</span></span>				
					</div>
				</a>
			</div>
            -->
		</div>
	</section>
    
    <section class="container mb40-h">
		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
				<a href="../ayuda/index.php">
					<div class="h-aviso btn-animado-2">
						<h4>AYUDA</h4>
						<span><em>+</em> info</span>
					</div>
				</a>
			</div>
		</div>
	</section>
    
	<section class="container mb40-h">
		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
				<a href="precios-productos-individuales.php">
					<div class="h-aviso">
						<h4>PRECIOS DE PRODUCTOS INDIVIDUALES PARA PERSONAS HUMANAS</h4>
						<span><em>+</em> info</span>
					</div>
				</a>
			</div>
		</div>
	</section>
    
	<section class="container mb40-h">
		<div class="row">
        	<div class="col-md-12 col-sm-12 col-xs-12">
            	<a href="cuentas/regularizacion-activos.php" class="btn-lnk-block">
                	<h3><strong>Cuenta Especial para Regularización de Activos (C.E.R.A.)</strong> - Ley 27.743</h3>
                    <i class="icon icon-more"></i>
                </a>
            </div>
    	</div>
    	<!--
		<div class="row">
        	<div class="col-md-12 col-sm-12 col-xs-12">
            	<a href="cuentas/construccion-argentina.php" class="btn-lnk-block">
                	<h3><strong>Cuentas especiales para la Construcción Argentina</strong> Com. A 7269 BCRA</h3>
                    <i class="icon icon-more"></i>
                </a>
            </div>
    	</div>
		-->
		<!--
		<div class="row">
        	<div class="col-md-12 col-sm-12 col-xs-12">
            	<a href="cuentas/caja-ahorros-repatriacion-fondos.php" target="" class="btn-lnk-block">
                	<h3><strong>Caja de Ahorros de Repatriación de Fondos</strong> Com. A 6893 BCRA</h3>
                    <i class="icon icon-more"></i>
                </a>
            </div>
    	</div>
		-->
		<div class="row">
        	<div class="col-md-12 col-sm-12 col-xs-12">
            	<a href="cuentas/cuenta-gratuita-universal.php" target="" class="btn-lnk-block">
                	<h3><strong>Cuenta Gratuita Universal</strong> Com A 6876 BCRA</h3>
                    <i class="icon icon-more"></i>
                </a>
            </div>
    	</div>
	</section>
	
	<section class="container mb40-h h-info-boxes">
		<div class="row equal-height">
			<div class="col-md-3 col-sm-3 col-xs-6">
				<a href="agentes-de-cobranza-extrajudicial.php">
					<div class="h-info-box">
						<p>Agentes de cobranza<br> extrajudicial</p>
						<span class="lnk"><em>+</em> <span>info</span></span>
					</div>
				</a>
			</div>
			<div class="col-md-3 col-sm-3 col-xs-6">
				<a href="informacion-al-usuario-financiero.php">
					<div class="h-info-box">
						<p>Información al usuario<br> financiero</p>
						<span class="lnk"><em>+</em> <span>info</span></span>
					</div>
				</a>
			</div>
			<div class="col-md-3 col-sm-3 col-xs-6 h-info-box-bot">
				<a href="http://www.bcra.gov.ar/BCRAyVos/Comparacion_de_Comisiones.asp" target="_blank">
					<div class="h-info-box">
						<p>Tabla comparativa de comisiones<br> en el Sistema Financiero<br> Argentino.com “A” 5928 BCRA</p>
						<span class="lnk"><em>+</em> <span>info</span></span>
					</div>
				</a>
			</div>
			<div class="col-md-3 col-sm-3 col-xs-6 h-info-box-bot">
				<a href="http://www.bcra.gob.ar/BCRAyVos/Usuarios_Financieros.asp" target="_blank">
					<div class="h-info-box-img"><img src="images/usuarios-financieros.png" width="261" height="125" alt="Usuarios Financieros. Visitá nuestra web www.usuariosfinancieros.gob.ar. Banco Central de la República Argentina" class="img-responsive"/></div>
				</a>
			</div>
		</div>
	</section>
	<section class="container" style="margin-bottom: 20px;">
		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
				<a href="alta-productos-personas-humanas.php">
					<div class="h-aviso-2">
						<h4>Contratos de adhesión - Ley N° 24.240 de Defensa del Consumidor<!--FORMULARIO DE ALTA DE PRODUCTOS PARA PERSONAS HUMANAS--></h4>
						<span><em>+</em> info</span>
					</div>
				</a>
			</div>
		</div>
	</section>
    <section class="container" style="margin-bottom: 20px;">
		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
				<a href="boton-de-arrepentimiento.php">
					<div class="h-aviso-2">
						<h4>Botón de arrepentimiento</h4>
						<span><em>+</em> info</span>
					</div>
				</a>
			</div>
		</div>
	</section>
    <!--
    <section class="container" style="margin-bottom: 20px;">
		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
				<a href="formulario-prestamos-hipotecarios.php">
					<div class="h-aviso-2">
						<h4>Información importante para clientes con préstamos hipotecarios vigentes para vivienda única, familiar y permanente</h4>
						<span><em>+</em> info</span>
					</div>
				</a>
			</div>
		</div>
	</section>
    -->
    <section class="container mb40-h">
		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
				<a href="https://bancopatagonia.hiringroom.com/jobs" target="_blank">
					<div class="h-aviso-2">
						<h4>Oportunidades Laborales</h4>
						<span><em>+</em> info</span>
					</div>
				</a>
			</div>
		</div>
	</section>
    <!-- -->
    <!--
    <section class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <a href="aduc.php" class="btn-lnk-block">
                    <h5>Se pone en conocimiento la existencia del juicio: "Asociación por la Defensa de Usuarios y Consumidores (ADUC) c/ Banco Patagonia S.A. s/ Ordinario" (Expte. 797/2016) de trámite ante el Juzgado Nacional de Primera Instancia en lo Comercial N° 22 Secretaría N° 43.</h5>
                    <i class="icon icon-more"></i>
                </a>
            </div>
        </div>
	</section>
    -->
    <!--
    <section class="container mb40-h">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <a href="aduc-2.php" class="btn-lnk-block">
                    <h5>Se pone en conocimiento la existencia del juicio Asociación por la Defensa de Usuarios y Consumidores (ADUC) c/ Banco Patagonia S.A.FIirst Data ConoSur SRL, Prisma Medios de Pago SA y American Express Argentina S.A s/ Ordinario Expte Nro 35447/2015 en tramite ante el Juzgado de Primera Instancia en lo Comercial Nro.26 Secretaria 52.</h5>
                    <i class="icon icon-more"></i>
                </a>
            </div>
        </div>
	</section>
    -->
    
	<script src="../lib/js/mdetect.js"></script>

	<script type="text/javascript">
	 // loaded anywhere on the page asynchronously.
	 (function jqIsReady() {

			 if (typeof jQuery === "undefined"){
					 setTimeout(jqIsReady,10);
					 return ;
			 }

			 $( function(){
					if ( MobileEsp.isMobilePhone || MobileEsp.isTierTablet || MobileEsp.isTierIphone ){
						loadBanner();
					}

					$("body").on("click", "#btn-app-download", function(e){						
						if ( MobileEsp.DetectAndroid() ) {
							ga('send', 'event', 'PatagoniaMovil', 'Descargar', 'Android');
						}
						else if (MobileEsp.DetectIos) {
							ga('send', 'event', 'PatagoniaMovil', 'Descargar', 'iOS');
						}

					});
			 });

			 function loadBanner(){

				 var link = "#",
						 btn = document.getElementById("btn-app-download"),
						 today = new Date(),
						 next_month = new Date();

				 if ( MobileEsp.DetectAndroid() ) {
					 link = "https://play.google.com/store/apps/details?id=ar.com.bcopatagonia.android";
				 }
				 else if (MobileEsp.DetectIos) {
					 link= "https://apps.apple.com/ar/app/patagonia-m%C3%B3vil/id1178757002";
				 }

				 btn.href = link;

				 next_month.setDate(1);
				 next_month.setMonth(today.getMonth()+1);

				 var banner_count = getCookie('banner_count');
				 var banner_date = getCookie('banner_date');

				 if ( banner_count == "") {
					 banner_count = 1;
				 }

				 if ( banner_date !== "" ) {
					 banner_date = new Date(banner_date);
				 }
				 else{
					 banner_date = next_month;
				 }

				 if ( banner_count <= 5 ) {
					 banner_count++;
					 $("#banner-content").fadeIn();
					 setCookie('banner_count',banner_count,35);
					 setCookie('banner_date',next_month.toJSON(),35);
				 }

				 if( today >= banner_date ) {
					 setCookie('banner_date',next_month.toJSON(),35);
					 setCookie('banner_count',1,35);
				 }
			 }

	 		function setCookie(cname, cvalue, exdays) {
			  	var d = new Date();
			  d.setTime(d.getTime() + (exdays*24*60*60*1000));
			  var expires = "expires="+ d.toUTCString();
			  document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
			}

			function getCookie(cname) {
			  var name = cname + "=";
			  var decodedCookie = decodeURIComponent(document.cookie);
			  var ca = decodedCookie.split(';');
			  for(var i = 0; i <ca.length; i++) {
			    var c = ca[i];
			    while (c.charAt(0) == ' ') {
			      c = c.substring(1);
			    }
			    if (c.indexOf(name) == 0) {
			      return c.substring(name.length, c.length);
			    }
			  }
			  return "";
			}


	 })();
	</script>
    
	<div class="container-fluid footer-bar">
	<div class="row">
		<footer class="container">
			<div class="row">
				<div class="col-md-12">
					<p class="flnks"><a href="../registro-nacional-base-datos.php">Registro Nacional de Base de Datos</a> <span>|</span>   <a href="../codigo-practicas-bancarias.php">Código de Prácticas Bancarias</a> <span>|</span>   <a href="../defensa-ley-consumidor.php">Defensa del Consumidor</a>
						<span>|</span>   <a href="https://www.argentina.gob.ar/produccion/defensadelconsumidor/formulario">Defensa de las y los consumidores. Para reclamos ingrese aquí</a><span>|</span> <br class="tbl"> <a href="../persona-expuesta-politicamente.php">Persona Expuesta Políticamente</a> <span class="tbl">|</span> <br class="dsk">
						
					<a href="../agencia-acceso-informacion-publica.php">Agencia de Acceso a la Información Pública</a> <span>|</span> <br class="tbl"> 
					<a href="../cnv-advertencia-publico-inversor.php">CNV - Advertencia al Público Inversor</a> <span>|</span> <a href="../docs/Idoneos.pdf" target="_blank"> Idóneos en Mercado de Capitales - CNV</a><span>|</span>   <a href="../codigo-proteccion-inversor.php">Código de Protección al Inversor</a> <span>|</span>   <a href="../clausulas-legales.php">Cláusulas Legales</a> <span>|</span> <a href="../resolucion-022021.php">Resol. 02/21 Dir.Gral. Defensa del consumidor Córdoba</a></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<p class="redes">
                        <span>Seguinos en:</span>
                        <!-- -->
                        <a href="https://www.facebook.com/BancoPatagonia/" target="_blank"><img src="../assets/images/layout/icon-facebook.svg" alt="Facebook"></a>
                        <a href="https://twitter.com/banco_patagonia" target="_blank"><img src="../assets/images/layout/icon-twitter.svg" alt="Twitter"></a>
                        <a href="https://www.instagram.com/banco_patagonia/" target="_blank"><img src="../assets/images/layout/icon-instagram.svg" alt="Instagram"></a>
                        <a href="https://www.youtube.com/user/bancopatagonia" target="_blank"><img src="../assets/images/layout/icon-youtube.svg" alt="Youtube"></a>
                        <!-- -->
                        <!--
                        <a href="https://www.facebook.com/BancoPatagonia/" target="_blank"><i class="fa fa-facebook-square"></i></a>
                        <a href="https://twitter.com/banco_patagonia" target="_blank"><i class="fa fa-twitter"></i></a>
                        <a href="https://www.instagram.com/banco_patagonia/" target="_blank"><i class="fa fa-instagram"></i></a>
                        <a href="https://www.youtube.com/user/bancopatagonia" target="_blank"><i class="fa fa-youtube-play"></i></a>
                        -->
                    </p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					                    <!-- -->
                    <p class="flegal">Espacio publicitario cedido por Banco Patagonia S.A. a GPAT Compañía Financiera S.A.U. (CUIT 30-67856482-2) con domicilio en Av. de Mayo 701 - Piso 18 (1084); sociedad anónima unipersonal según ley argentina.<br class="dsk"> El accionista limita su responsabilidad a la integración de las acciones suscriptas, por lo que no responde en exceso de la citada integración accionaria. Banco Patagonia S.A. no se responsabiliza por los productos y servicios financieros brindados por GPAT Compañía Financiera S.A.U.</p>
                    <!-- -->
					<p class="flegal">MOVIMIENTOS POR CANAL: CAJEROS AUTOMÁTICOS RED PATAGONIA 24: SIN CARGO - ATM´S OTROS BANCOS RED BANELCO: $1.936,00 (*) - RED LINK: $2.057,00 (*)- POR CAJA: SIN CARGO<br>
					MANTENIMIENTO MENSUAL CUENTAS: CUENTA CORRIENTE: $15.972,00- CAJA DE AHORROS PESOS: SIN CARGO<br>
					TARJETAS DE CRÉDITO INTERNACIONAL: COMISIÓN POR MANTENIMIENTO DE CUENTA MENSUAL: $5.929,00 - COMISIÓN ANUAL POR SERVICIO: $111.320,00. IVA INCLUIDO.</p>
					<p class="flegal">
					(*) El uso de la red de cajeros automáticos seguirá siendo gratuito para las personas usuarias con cuentas sueldo, jubilaciones y beneficiarias/os de planes sociales,<br class="dsk"> por decisión del Directorio del Banco Central de la República Argentina.
					</p>
					                    <!--					<p class="flegal">Conforme lo dispuesto por la Com. "A" 7181 del Banco Central de la República Argentina, los cargos y comisiones por operaciones de depósito, extracciones, consultas, etc., efectuadas en cajeros automáticos de la República Argentina, no serán percibidos hasta el 31/03/21. Dichas operaciones serán sin límites de importe –salvo los expresamente convenidos por razones de seguridad y/o aquellos que resulten de restricciones operativas del equipo– ni de cantidad de extracciones, ni distinción entre clientes y no clientes, independientemente del tipo de cuenta a la vista sobre la cual se efectúe la operación.</p>
                    <p class="flegal">Asimismo, en virtud de lo dispuesto por el Decreto N° 312/20 del Poder Ejecutivo Nacional y sus normas modificatorias y/o complementarias, las comisiones por devolución de cheques sin fondos y multas por cheques rechazados sin fondos o por fallas formales, no serán percibidas hasta el 31/12/2020.</p>
					-->
				    <p class="flegal">BANCO PATAGONIA S.A. ES UNA SOCIEDAD ANÓNIMA CONSTITUIDA BAJO LAS LEYES DE LA REPÚBLICA ARGENTINA CUYOS ACCIONISTAS LIMITAN SU RESPONSABILIDAD A LA INTEGRACIÓN DE LAS ACCIONES SUSCRITAS DE ACUERDO A LA LEY 19.550. POR CONSIGUIENTE, Y EN CUMPLIMIENTO DE LA LEY 25.738, SE INFORMA QUE NI LOS ACCIONISTAS MAYORITARIOS DE CAPITAL EXTRANJERO NI LOS ACCIONISTAS LOCALES O EXTRANJEROS RESPONDEN, EN EXCESO DE LA CITADA INTEGRACIÓN ACCIONARIA, POR LAS OBLIGACIONES EMERGENTES DE LAS OPERACIONES CONCERTADAS POR LA ENTIDAD FINANCIERA.</p>
                    <p class="flegal" style="font-size:10px;">Banco Patagonia S.A. - Agente de Liquidacion y Compensacion y Agente de Negociacion Integral, inscripto en CNV bajo el N° 66</p>
					<p class="flegal">© 2025 Banco Patagonia . Todos los derechos reservados. Prohibida la duplicación , distribución o almacenamiento en cualquier medio.</p>
				</div>
			</div>
		</footer>
	</div>
</div>
<div class="tbl mbl placeholder-shortlinks">
	<div class="container shortlinks">
		<div class="row">
            <!--<php if ($home_personas == false) { ?>
                <div class="col-sm-3 col-xs-3">
                    <a href="#"><span class="icon icon-contacto"></span></a>
                </div>
            <php } ?>-->
                            <div class="col-sm-3 col-xs-3">
                    <a class="jq-btn-padi" padi-env="prod" padi-iframe="#jq-ifr-padi iframe"><span class="icon icon-padi"></span>Chateá con PADI</a>
                </div>
            			<div class="col-sm-3 col-xs-3">
				<a href="http://sucursalesycajeros.bancopatagonia.com.ar/sucursales.html" target="_blank"><span class="icon icon-sucursales"></span>Sucursales y Cajeros</a>
			</div>
			<div class="col-sm-3 col-xs-3">
				<a href="../preguntas-frecuentes/index.php"><span class="icon icon-contacto"></span>Ayuda</a>
			</div>
			<div class="col-sm-3 col-xs-3 last">
				<a href="../empresas/patagonia-ebank-empresas-mbl.php"><span class="icon icon-ebank"></span>Patagonia e-Bank</a>
			</div>
		</div>
	</div>
</div>	<script src="../assets/js/jquery-3.5.1.min.js"></script>
<script src="../assets/bootstrap/js/bootstrap.min.js"></script>
<script src="../assets/js/slick/slick.min.js"></script>
<script src="../assets/js/fancybox/jquery.fancybox.min.js"></script>
<script src="../assets/js/mtabs/jquery.bootstrap-responsive-tabs.min.js"></script>
<script src="../assets/js/funciones.js"></script>

<!-- Global site tag (gtag.js) - Google Analytics (original) -->
<!--
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-32588129-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-32588129-1');
</script>
-->

<!-- Google Analytics (version anterior / eventos ok)  -->
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');
  ga('create', 'UA-32588129-1', 'auto');
  ga('send', 'pageview');
</script>

<!-- GA4 - Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-C6LG1PT98X"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-C6LG1PT98X');
</script>
    
    <!-- BOTÓN PADI / CHATBOT (3/3)-->
    <script>
    var btnPadi=$('.jq-btn-padi');
    var ifrPadi=$('#jq-ifr-padi');
    var ifrPadiButton=$('#jq-ifr-padi button');
    btnPadi.click(openPADI);
    function openPADI(){
        //btnPadi.css('display','none');
        ifrPadi.fadeIn();//ifrPadi.css('display','block');
    }
    ifrPadiButton.click(closePADI);
    function closePADI(){
        ifrPadi.fadeOut();//ifrPadi.css('display','none');
        //btnPadi.css('display','block');
    }
</script>
<script src="../js/padi.js"></script>    
    <!-- VIDEO "VOS" (popup 3/3)-->
    <!--
    <script type="text/javascript">
        var popuplateral=$('#popup-lateral');
        var popuplateralbutton=$('#popup-lateral button');
        //
        popuplateralbutton.click(desaparece);
        function desaparece(){
            popuplateral.css('display','none');
        }
    </script>
    -->
    
    <!-- EXTERNAL LNK -->
    <div class="modal fade" id="taylorswift">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal"><span>X</span></button>
                    <h4 class="modal-title"><img src="../assets/images/layout/logo.svg" width="206" height="22" alt=""/></h4>
                </div>
                <div class="modal-body">
                    <div class="external-legend">
                        <p>Estás abandonado el sitio de Banco Patagonia S.A. El usuario reconoce que las hiperconexiones con otro medios de Internet son a tu propio riesgo. Banco Patagonia no investiga, verifica, controla ni responde el contenido, la exactitud, las opiniones expresada y otras conexiones suministradas por estos medios. </p>
                    </div>
                </div>
                <div class="modal-footer">
                    <a href="https://www.allaccess.com.ar/event/taylor-swift-the-eras-tour" class="cta-btn">Aceptar</a>
                    <a href="#" class="cta-btn-cancel" data-dismiss="modal">Cancelar</a>
                </div>
            </div>
        </div>
    </div>
    <!-- FIN EXTERNAL LNK -->
    
    <!-- EXTERNAL LNK (SOLO PARA GPAT) -->
    <div class="modal fade" id="gpat">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal"><span>X</span></button>
                    <h4 class="modal-title"><img src="../assets/images/layout/logo.svg" width="206" height="22" alt=""/></h4>
                </div>
                <div class="modal-body">
                    <div class="external-legend">
                        <p>Estás abandonando el sitio de Banco Patagonia S.A. para ingresar al sitio de Gpat Compañía Financiera.</p>
                    </div>
                </div>
                <div class="modal-footer">
                    <a href="https://concesionarios.gpat.com.ar/landing?token=43;86;115;105;107;105;115;67;51;107;49;55;99;84;116;78;105;106;85;77;82;117;71;68;49;116;50;112;98;85;113;57;79;52;54;102;115;48;82;101;71;121;111;61" class="cta-btn">Aceptar</a>
                    <a href="#" class="cta-btn-cancel" data-dismiss="modal">Cancelar</a>
                </div>
            </div>
        </div>
    </div>
    <!-- FIN EXTERNAL LNK -->
    
    <!-- POPUP PROGRAMADO -->
    <!--
    <div class="modal fade" id="modalProgramado">
        !--<div class="modal-dialog modal-lg">--
        <div class="modal-dialog">
			<div class="modal-content" style="padding: 0; border: 0; line-height: 0; background: no-repeat; box-shadow: none;">
				<div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal"><span style="color: #fff;">X</span></button>
                </div>
				<div class="modal-body">
                    <video style="width: 100%;" controls autoplay muted>
                        <source src="videos/video-yo-vivire.mp4" type="video/mp4">
                    </video>
				</div>
			</div>
		</div>
	</div>
    <script type="text/javascript">
        $(window).on('load',function(){
            var start_show_modal = new Date("2020-01-01 00:00:00");
            var end_show_modal = new Date("2030-01-01 00:00:00");
            
            var today = new Date();
            var today_str = today.getFullYear() + '_' + today.getMonth() + '_' + today.getDate()
            var cont_show_modal = localStorage.getItem(today_str+'_contShowModal') || 0;

            if ( today >= start_show_modal && today <=  end_show_modal &&  cont_show_modal < 500 ) {
                cont_show_modal++;
                localStorage.setItem(today_str+'_contShowModal', cont_show_modal);
                $('#modalProgramado').modal('show');
            }
        });
	</script>
    -->
    <!-- -->
    
</body>
</html>
