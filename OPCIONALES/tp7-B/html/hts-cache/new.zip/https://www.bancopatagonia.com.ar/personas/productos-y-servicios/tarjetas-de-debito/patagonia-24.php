<!DOCTYPE html>
<html lang="es">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
		<meta http-equiv="Pragma" content="no-cache">
		<meta http-equiv="Expires" content="0">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Tarjetas de débito | Banco Patagonia</title>
		<meta name="description" content="Patagonia 24 te permite contar con dinero las 24 hs y abonar tus compras de manera sencilla.">
		<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-NL73B44');</script>
<!-- End Google Tag Manager -->

<link rel="shortcut icon" href="../../../favicon.ico" type="image/x-icon"/>
<link href="../../../assets/fonts/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="../../../assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="../../../assets/js/mtabs/bootstrap-responsive-tabs.css" rel="stylesheet" type="text/css">
<link href="../../../assets/js/slick/slick.css" rel="stylesheet" type="text/css">
<link href="../../../assets/js/fancybox/jquery.fancybox.min.css" rel="stylesheet" type="text/css">
<link href="../../../assets/css/styles.css" rel="stylesheet" type="text/css">
<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->        
        <!-- CSS (Productos y Servicios) -->
        <link href="../../../assets/css/productos-y-servicios.css" rel="stylesheet" type="text/css">
        
	</head>
<body>
	<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NL73B44"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

<div class="placeholder-bar">
	<div class="container-fluid header-bar">
		<div class="row">
			<header class="container">
				<div class="row">
					<div class="col-md-3 col-dsk-6 col-sm-6">
						<span class="c-hamburger c-hamburger--htx">
							<span>toggle menu</span>
						</span>
                        <!-- -->
                        <!--<img style="position: absolute; width: 42px; top: 20px; right: 40px;" class="dsk" src="<php echo $path ?>assets/images/layout/icon-verano-2022.svg">-->
                        <!-- -->
						<h1>
                            <!--<img style="position: absolute; width: 32px; top: 12px; left: 102px;" class="dsk" src="<php echo $path ?>assets/images/layout/icon-navidad-2021.svg">-->
                            <a href="../../index.php" class="main-logo">Banco Patagonia</a>
                        </h1>
					</div>
					<div class="col-md-9 col-dsk-6 col-sm-6">
						<div class="general-links">
							<ul class="list-unstyled">
                                <li id="btn-hacete-cliente"><a href="https://tunuevacuenta.bancopatagonia.com.ar/?utm_source=sitiowebbp&utm_medium=sitiowebbp%20banner%20home&utm_campaign=onboarding_sitiowebp_bannerhome" target="_blank"><strong>Hacete cliente <i class="fa fa-angle-right"></i></strong></a></li>								<li><a href="../../../preguntas-frecuentes/index.php" class="">Ayuda</a></li>
								<!--<li><a href="<php echo $folder_canales ?>index.php" class="<php echo $canales ?>">Canales de atención</a></li>-->
								<!--<li><a href="http://sucursalesycajeros.bancopatagonia.com.ar/sucursales.html" target="_blank">Sucursales y cajeros</a></li>-->
								<!--<li><a href="<php echo $folder_contactenos ?>index.php" class="<php echo $contactenos ?>">Contactanos</a></li>-->
                                <!--<li><a href="<php echo $path ?>ayuda/index.php" class="<php echo $ayuda ?>">Ayuda</a></li>-->
							</ul>
						</div>
						<div class="top-links">
							<ul class="list-unstyled">
								<li><a href="../../index.php" class="active">PERSONAS</a></li>
								<li><a href="../../../nyps/index.php" class="">PROFESIONALES Y COMERCIOS</a></li>
								<li><a href="../../../pyme/index.php" class="">PYME</a></li>
								<li><a href="../../../agro/index.php" class="">AGRO</a></li>
								<li><a href="../../../empresas/index.php" class="">EMPRESAS</a></li>
								<li><a href="../../../sector-publico/index.php" class="">SECTOR PÚBLICO</a></li>
								<li><a href="../../../institucional/index.php" class="">INSTITUCIONAL</a></li>
							</ul>
							<div class="ebank">
                            <!-- antes href: <php echo $folder_empresas ?><php echo $url_ebank ?>-->
															<a href="https://ebankpersonas.bancopatagonia.com.ar/eBanking/usuarios/login.htm" class="patagonia-ebank" target="_blank">Patagonia e-Bank</a>
														</div>
						</div>
					</div>
				</div>
			</header>
		</div>
	</div>
</div>

<div class="container-fluid nav-bar">
	<div class="row">
		<nav class="container">
			<div class="row">
				<!--<div class="col-md-9 col-md-offset-3">-->
                <div class="col-md-10 col-md-offset-3"><!-- ajuste agro -->
					<ul class="list-unstyled sub-navbar">
						
												<!-- PERSONAS -->
                        <li class="nav-item"><a href="#" class="nav-lnk ">PATAGONIA CLÁSICA</a>
							<ul class="list-unstyled submenu">
                                <li><a href="../../../personas/patagonia-clasica/patagonia-ahorro/productos.php">Patagonia Ahorro</a></li>
                                <li><a href="../../../personas/patagonia-clasica/paquete/productos.php">Patagonia Clásica</a></li>
                                <!--<li><a href="<php echo $path ?>personas/patagonia-clasica/mas/productos.php">Patagonia Clásica Más</a></li>-->
                                <li><a href="../../../personas/patagonia-clasica/premium/productos.php">Patagonia Clásica Premium</a></li>
                                <li><a href="../../../personas/patagonia-clasica/patagonia-sueldo/productos.php">Patagonia Sueldo</a></li>
							</ul>
						</li>
						<li class="nav-item"><a href="#" class="nav-lnk ">PATAGONIA PLUS</a>
							<ul class="list-unstyled submenu">
                                <li><a href="../../../personas/patagonia-plus/productos.php">Patagonia Plus</a></li>
                                <li><a href="../../../personas/patagonia-plus/premium/productos.php">Patagonia Plus Premium</a></li>
							</ul>						
						</li>
						<li class="nav-item"><a href="#" class="nav-lnk ">PATAGONIA SINGULAR</a>
							<ul class="list-unstyled submenu">
								<li><a href="../../../personas/patagonia-singular/paquete/propuesta.php">Patagonia Singular</a></li>
                                <li><a href="../../../personas/patagonia-singular/beneficios-exclusivos.php">Beneficios Exclusivos</a></li>
                                <!--<li><a href="<php echo $path ?>personas/patagonia-singular/atencion-exclusiva/index.php">Atención Exclusiva</a></li>-->
                                <!--<li><a href="<php echo $path ?>personas/patagonia-singular/eventos-y-novedades/index.php">Eventos y Novedades</a></li>-->
							</ul>
						</li>
						<!--<li class="nav-item"><a href="<php echo $path ?>patagoniaon/index.php" target="_blank" class="nav-lnk">PATAGONIA ON</a></li>-->
						<li class="nav-item"><a href="#" class="nav-lnk ">PATAGONIA ON</a>
							<ul class="list-unstyled submenu">
                                <li><a href="../../../patagoniaon/index.php" target="_blank">Patagonia ON</a></li>
								<li><a href="../../../personas/productos-y-servicios/patagonia-universitaria.php">Patagonia ON Universitaria</a></li>
							</ul>
						</li>
						<li class="nav-item"><a href="#" class="nav-lnk active">PRODUCTOS Y SERVICIOS</a>
							<ul class="list-unstyled submenu">
                                <li><a href="../../../personas/apple-pay.php">Apple Pay</a></li>
                                <li><a href="../../../personas/productos-y-servicios/caja-de-seguridad.php">Caja de Seguridad</a></li>
                                <li><a href="../../../personas/productos-y-servicios/comercio-exterior/productos.php">Comercio exterior</a></li>
								<!--<li><a href="<php echo $path ?>personas/productos-y-servicios/beneficios-wapa.php">Comercios WAPA</a></li>-->
								<li><a href="../../../personas/cuotifica-al-toque.php">Cuotificá al Toque</a></li>
								<li><a href="../../../personas/google-pay.php">Google Pay</a></li>
                                <li><a href="../../../personas/productos-y-servicios/inversiones.php">Inversiones</a></li>
                                <li><a href="../../../personas/jubilados/index.php">Jubilados</a></li>
                                <li><a href="../../../personas/productos-y-servicios/patagonia-para-menores.php">Patagonia para Menores</a></li>
                                <!--<li><a href="<php echo $path ?>personas/productos-y-servicios/patagonia-universitaria.php">Patagonia Universitaria</a></li>-->
                                <li><a href="../../../personas/productos-y-servicios/prestamos.php">Prestamos</a></li>
                                <li><a href="../../../personas/seguros/index.php">Seguros</a></li>
                                <li><a href="../../../personas/productos-y-servicios/tarjetas-de-credito/visa.php">Tarjetas de crédito</a></li>
								<li><a href="../../../personas/productos-y-servicios/tarjetas-de-debito/patagonia-24.php">Tarjetas de débito</a></li>
							</ul>
						</li>
						<!-- FIN PERSONAS -->
						                        
                                                
                                                
                        						
												
												
						
											</ul>
				</div>
			</div>
		</nav>
	</div>
</div>

<div class="mobile-nav-bar">
	<ul class="list-unstyled">
        
        <!-- PERSONAS -->
		<li class="nav-main-item"><a href="#" class="has-sub-items active">PERSONAS <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../index.php" class="active">HOME</a></li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA CLÁSICA</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../../personas/patagonia-clasica/patagonia-ahorro/productos.php">Patagonia Ahorro</a></li>
                        <li><a href="../../../personas/patagonia-clasica/paquete/productos.php">Patagonia Clásica</a></li>
                        <!--<li><a href="<php echo $path ?>personas/patagonia-clasica/mas/productos.php">Patagonia Clásica Más</a></li>-->
                        <li><a href="../../../personas/patagonia-clasica/premium/productos.php">Patagonia Clásica Premium</a></li>
                        <li><a href="../../../personas/patagonia-clasica/patagonia-sueldo/productos.php">Patagonia Sueldo</a></li>
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA PLUS</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../../personas/patagonia-plus/productos.php">Patagonia Plus</a></li>
                        <li><a href="../../../personas/patagonia-plus/premium/productos.php">Patagonia Plus Premium</a></li>
                    </ul>						
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA SINGULAR</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../../personas/patagonia-singular/paquete/propuesta.php">Patagonia Singular</a></li>
                        <li><a href="../../../personas/patagonia-singular/beneficios-exclusivos.php">Beneficios Exclusivos</a></li>
                        <!--<li><a href="<php echo $path ?>personas/patagonia-singular/atencion-exclusiva/index.php">Atención Exclusiva</a></li>-->
                        <!--<li><a href="<php echo $path ?>personas/patagonia-singular/eventos-y-novedades/index.php">Eventos y Novedades</a></li>-->
                    </ul>
                </li>
				<!--<li class="nav-sub-item"><a href="<php echo $path ?>patagoniaon/index.php" target="_blank">PATAGONIA ON</a></li>-->
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA ON</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../../patagoniaon/index.php" target="_blank">Patagonia ON</a></li>
						<li><a href="../../../personas/productos-y-servicios/patagonia-universitaria.php">Patagonia ON Universitaria</a></li>
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu active">PRODUCTOS Y SERVICIOS</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../../personas/apple-pay.php">Apple Pay</a></li>
                        <li><a href="../../../personas/productos-y-servicios/caja-de-seguridad.php">Caja de Seguridad</a></li>
                        <li><a href="../../../personas/productos-y-servicios/comercio-exterior/productos.php">Comercio exterior</a></li>
						<!--<li><a href="<php echo $path ?>personas/productos-y-servicios/beneficios-wapa.php">Comercios WAPA</a></li>-->
						<li><a href="../../../personas/cuotifica-al-toque.php">Cuotificá al Toque</a></li>
						<li><a href="../../../personas/google-pay.php">Google Pay</a></li>
                        <li><a href="../../../personas/productos-y-servicios/inversiones.php">Inversiones</a></li>
                        <li><a href="../../../personas/jubilados/index.php">Jubilados</a></li>
                        <li><a href="../../../personas/productos-y-servicios/patagonia-para-menores.php">Patagonia para Menores</a></li>
                        <!--<li><a href="<php echo $path ?>personas/productos-y-servicios/patagonia-universitaria.php">Patagonia Universitaria</a></li>-->
                        <li><a href="../../../personas/productos-y-servicios/prestamos.php">Prestamos</a></li>
                        <li><a href="../../../personas/seguros/index.php">Seguros</a></li>
                        <li><a href="../../../personas/productos-y-servicios/tarjetas-de-credito/visa.php">Tarjetas de crédito</a></li>
                        <li><a href="../../../personas/productos-y-servicios/tarjetas-de-debito/patagonia-24.php">Tarjetas de débito</a></li>
                    </ul>
                </li>
			</ul>
		</li>
        <!-- FIN PERSONAS -->
        
        <!-- NYPS -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">PROFESIONALES Y COMERCIOS <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../../nyps/index.php" class="">HOME</a></li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA CLÁSICA</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../../nyps/patagonia-clasica/premium/productos.php">Patagonia Clásica Premium</a></li>
                        <li><a href="../../../nyps/patagonia-clasica/patagonia-emprendimiento/productos.php">Patagonia Emprendimiento</a></li>
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA PLUS</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../../nyps/patagonia-plus/productos.php">Patagonia Plus</a></li>
                        <li><a href="../../../nyps/patagonia-plus/premium/productos.php">Patagonia Plus Premium</a></li>
                    </ul>						
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA SINGULAR</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../../nyps/patagonia-singular/paquete/propuesta.php">Patagonia Singular</a></li>
                        <li><a href="../../../nyps/patagonia-singular/beneficios-exclusivos.php">Beneficios Exclusivos</a></li>
                        <!--<li><a href="<php echo $path ?>nyps/patagonia-singular/eventos-y-novedades/index.php">Eventos y Novedades</a></li>-->
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PRODUCTOS Y SERVICIOS</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../../nyps/productos-y-servicios/tarjetas-de-debito/patagonia-24.php">Tarjetas de débito</a></li>
                        <li><a href="../../../nyps/productos-y-servicios/tarjetas-de-credito/visa.php">Tarjetas de crédito</a></li>
                        <li><a href="../../../nyps/productos-y-servicios/prestamos.php">Prestamos</a></li>
                        <li><a href="../../../nyps/seguros/index.php">Seguros</a></li>
                        <li><a href="../../../nyps/productos-y-servicios/inversiones.php">Inversiones</a></li>
                        <li><a href="../../../nyps/productos-y-servicios/comercio-exterior/productos.php">Comercio exterior</a></li>
                        <li><a href="../../../nyps/productos-y-servicios/caja-de-seguridad.php">Caja de Seguridad</a></li>
                        <li><a href="../../../nyps/productos-y-servicios/factura-electronica.php">Factura electrónica</a></li>
                        <li><a href="../../../nyps/productos-y-servicios/pagos-afip.php">Pagos AFIP</a></li>
                        <!--<li><a href="<php echo $path ?>nyps/productos-y-servicios/soluciones-para-tu-empresa.php">Soluciones para tu empresa</a></li>-->
                        <!--<li><a href="<php echo $path ?>nyps/productos-y-servicios/comercios-patagonia.php">Comercios Patagonia</a></li>-->
						<li><a href="../../../nyps/productos-y-servicios/wapa.php">WAPA</a></li>
                    </ul>
                </li>
			</ul>		
		</li>
        <!-- FIN NYPS -->
        
        <!-- PYME -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">PYME <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../../pyme/index.php" class="">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">CUENTAS</a>
					<ul class="list-unstyled submenu">
                        <li><a href="../../../pyme/cuentas/pequenas-empresas.php">Pyme Pequeñas Empresas</a></li>
				        <li><a href="../../../pyme/cuentas/medianas-empresas.php">Pyme Medianas Empresas</a></li>
                        <!--
						<li><a href="../../../pyme/cuentas/patagonia-empresario.php">Patagonia Empresario</a></li>
						<li><a href="../../../pyme/cuentas/patagonia-empresario-premier.php">Patagonia Empresario Premier</a></li>
						<li><a href="../../../pyme/cuentas/patagonia-empresa.php">Patagonia Empresa</a></li>
                        -->
                        <!--<li><a href="../../../pyme/cuentas/patagonia-comercio.php">Patagonia Comercio</a></li>-->
                        <li><a href="../../../pyme/cuentas/patagonia-consorcio.php">Patagonia Consorcio</a></li>
						<li><a href="../../../pyme/cuentas/cuenta-corriente.php">Cuenta Corriente</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA SUELDO</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../../pyme/patagonia-sueldo/servicios.php">Servicios</a></li>
						<li><a href="../../../pyme/patagonia-sueldo/preguntas-frecuentes.php">Preguntas Frecuentes</a></li>
						<li><a href="../../../pyme/patagonia-sueldo/guia-implementacion.php">Guía de Implementación</a></li>
					</ul>
				</li>						
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">COMERCIO EXTERIOR</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../../pyme/comercio-exterior/solicitud-electronica.php">Solicitud Electrónica</a></li>
						<li><a href="../../../pyme/comercio-exterior/productos.php">Productos</a></li>
						<li><a href="../../../pyme/comercio-exterior/otros-servicios.php">Servicios</a></li>
						<!--<li><a href="<php echo $folder_pymeCexterior ?>financiaciones.php">Financiaciones</a></li>-->
                        <li><a href="../../../pyme/comercio-exterior/herramientas-para-exportar.php">Herramientas para Exportar</a></li>
						<li><a href="../../../pyme/comercio-exterior/marco-regulatorio/normas-y-regulaciones.php">Marco Regulatorio</a></li>
					</ul>
				</li>						
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">FINANCIACIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../../pyme/financiacion/patagonia-leasing.php">Patagonia Leasing</a></li>
						<li><a href="../../../pyme/financiacion/mercado-capitales.php">Mercado de Capitales</a></li>
						<li><a href="../../../pyme/financiacion/alternativas-de-financiacion.php">Alternativas de Financiación</a></li>
					</ul>
				</li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">SEGUROS</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../../pyme/seguros/protege-tus-bienes/integral-comercio.php">Protegé tus Bienes</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">INVERSIONES</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../../pyme/inversiones/plazo-fijo.php">Plazo Fijo</a></li>
						<li><a href="../../../pyme/inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
						<li><a href="../../../pyme/inversiones/fidecomisos-financieros.php">Fidecomisos Financieros</a></li>
					</ul>
				</li>						
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">SERVICIOS</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../../pyme/servicios/recaudaciones.php">Recaudaciones</a></li>
						<li><a href="../../../pyme/servicios/pagos.php">Pagos</a></li>
						<li><a href="../../../pyme/servicios/tarjetas-comerciales.php">Tarjetas Comerciales</a></li>
						<li><a href="../../../pyme/servicios/comercios-patagonia.php">Comercios Patagonia</a></li>
                        <li><a href="../../../pyme/servicios/pago-de-servicios.php">Pago de Servicios</a></li>
						<li><a href="../../../pyme/servicios/interbanking.php">Interbanking</a></li>
						<li><a href="../../../pyme/servicios/interfacturas.php">Interfacturas</a></li>
						<li><a href="../../../pyme/servicios/pagos-afip.php">Pagos AFIP</a></li>
						<li><a href="../../../pyme/servicios/wapa.php">WAPA</a></li>
					</ul>
				</li>
			</ul>		
		</li>
        <!-- FIN PYME -->
        
        <!-- AGRO -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">AGRO <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../../agro/index.php" class="">HOME</a></li>
                <!-- -->
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">OFERTA AGRO</a>
					<ul class="list-unstyled submenu">
                    	<!--<li><a href="<php echo $folder_agroFinanciacion ?>insumos.php">Insumos en USD</a></li>-->
                        <li><a href="../../../agro/convenios/acuerdos-y-beneficios.php">Acuerdos y convenios</a></li>
						<li><a href="../../../agro/financiacion/maquinaria-agricola.php">Financiación Maquinaria Agrícola</a></li>
						<li><a href="../../../agro/seguros/campo.php">Seguros para tu campo</a></li>
					</ul>
				</li>
                <!-- -->
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">TARJETA PATAGONIA AGRO</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../../agro/tarjeta-patagonia-agro/para-usuarios.php">Para Usuarios</a></li>
						<li><a href="../../../agro/tarjeta-patagonia-agro/para-comercios.php">Para Comercios</a></li>
						<li><a href="../../../agro/tarjeta-patagonia-agro/acuerdo-tasa-0.php">Tarjetas Agro Convenios Preferenciales</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="../../../agro/cuenta-agro/cuenta-agro.php" class="">CUENTA AGRO</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">FINANCIACIÓN</a>
					<ul class="list-unstyled submenu">
                        <li><a href="../../../agro/insumos/index.php">Insumos</a></li>
                        <li><a href="../../../agro/financiacion/maquinaria-agricola.php">Maquinarias</a></li>
                        <li><a href="../../../empresas/financiacion/convenios-de-financiacion.php">Camiones</a></li>
						<!--<li><a href="<php echo $folder_agroFinanciacion ?>capital-de-trabajo.php">Capital de Trabajo</a></li>-->
						<!--<li><a href="<php echo $folder_agroFinanciacion ?>proyectos-de-inversion.php">Proyectos de Inversión</a></li>-->
						<!--<li><a href="<php echo $folder_agroFinanciacion ?>creditos-para-hacienda.php">Créditos para Hacienda</a></li>-->
						<!--<li><a href="<php echo $folder_agroFinanciacion ?>leasing-y-prendarios.php">Leasing y Prendarios</a></li>-->
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">INVERSIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../../agro/inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
						<li><a href="../../../agro/inversiones/fidecomisos-financieros.php">Fidecomisos Financieros</a></li>
						<li><a href="../../../agro/inversiones/plazos-fijos.php">Plazos Fijos</a></li>
					</ul>
				</li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">COMERCIO EXTERIOR</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../../agro/comercio-exterior/solicitud-electronica.php">Solicitud Electrónica</a></li>
                        <li><a href="../../../agro/comercio-exterior/productos.php">Productos</a></li>
                        <li><a href="../../../agro/comercio-exterior/otros-servicios.php">Servicios</a></li>
                        <li><a href="../../../agro/comercio-exterior/herramientas-para-exportar.php">Herramientas para Exportar</a></li>
                        <li><a href="../../../agro/comercio-exterior/marco-regulatorio/normas-y-regulaciones.php">Marco Regulatorio</a></li>
                    </ul>
                </li>
                <!--
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">SERVICIOS</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../../agro/servicios/centro-atencion-empresas.php">Centro de Atención para Empresas</a></li>
					</ul>
				</li>
                -->
                <!-- -->
                <li class="nav-sub-item"><a href="../../../agro/seguros/campo.php" class="">SEGUROS</a></li>
                <!-- -->
			</ul>
		</li>
        <!-- FIN AGRO -->
        
        <!-- EMPRESAS -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">EMPRESAS <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../../empresas/index.php" class="">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA SUELDO</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../../empresas/patagonia-sueldo/servicios.php">Servicios</a></li>
						<li><a href="../../../empresas/patagonia-sueldo/preguntas-frecuentes.php">Preguntas Frecuentes</a></li>
						<li><a href="../../../empresas/patagonia-sueldo/guia-implementacion.php">Guía de Implementación</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">COMERCIO EXTERIOR</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../../empresas/comercio-exterior/solicitud-electronica.php">Solicitud Electrónica</a></li>
						<li><a href="../../../empresas/comercio-exterior/productos.php">Productos</a></li>
						<li><a href="../../../empresas/comercio-exterior/otros-servicios.php">Servicios</a></li>
						<!--<li><a href="<php echo $folder_Cexterior ?>financiaciones.php">Financiaciones</a></li>-->
                        <li><a href="../../../empresas/comercio-exterior/herramientas-para-exportar.php">Herramientas para Exportar</a></li>
						<li><a href="../../../empresas/comercio-exterior/marco-regulatorio/normas-y-regulaciones.php">Marco Regulatorio</a></li>
					</ul>
				</li>
                <!-- -->
				<!--<li class="nav-sub-item"><a href="../../../empresas/comunidades-de-negocios/index.php" class="">COMUNIDADES DE NEGOCIOS</a></li>-->
                <!-- -->
				<li class="nav-sub-item"><a href="index.php" class="nav-lnk ">COMERCIOS PATAGONIA</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">FINANCIACIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../../empresas/financiacion/patagonia-leasing.php">Patagonia Leasing</a></li>
						<li><a href="../../../empresas/financiacion/mercado-capitales.php">Mercado Capitales</a></li>
						<li><a href="../../../empresas/financiacion/alternativas-de-financiacion.php">Alternativas de Financiación</a></li>
                        <li><a href="../../../empresas/financiacion/convenios-de-financiacion.php">Convenios de Financiación</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">INVERSIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../../empresas/inversiones/plazos-fijos.php">Plazos Fijos</a></li>
						<li><a href="../../../empresas/inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
						<li><a href="../../../empresas/inversiones/compra-venta-titulos-acciones.php">Compra - Venta de Títulos y Acciones</a></li>
						<li><a href="../../../empresas/inversiones/custodia-de-titulos.php">Custodia de Títulos</a></li>
						<li><a href="../../../empresas/inversiones/fidecomisos-financieros.php">Fidecomisos Financieros</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">SERVICIOS</a>
					<ul class="list-unstyled submenu">
                        <li><a href="../../../empresas/patagonia-movil-empresas.php">Patagonia Móvil Empresas</a></li>
						<li><a href="../../../empresas/servicios/pagos.php">Pagos</a></li>
						<li><a href="../../../empresas/servicios/recaudaciones.php">Recuadaciones</a></li>
						<li><a href="../../../empresas/servicios/pago-de-servicios.php">Pago de Servicios</a></li>
						<li><a href="../../../empresas/servicios/interbanking.php">Interbanking</a></li>
						<li><a href="../../../empresas/servicios/interfacturas.php">Interfacturas</a></li>
						<li><a href="../../../empresas/servicios/tarjetas-comerciales.php">Tarjetas Comerciales</a></li>
                        <!-- -->
						<!--<li><a href="../../../empresas/servicios/comercios-patagonia.php">Comercios Patagonia</a></li>-->
                        <!-- -->
                        <li><a href="../../../empresas/servicios/centro-atencion-empresas.php">Centro de Atención para Empresas</a></li>
					</ul>
				</li>
			</ul>
		</li>
        <!-- FIN EMPRESAS -->
        
        <!-- SECTOR PÚBLICO -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">SECTOR PÚBLICO <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../../sector-publico/index.php" class="">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">INVERSIONES</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../../sector-publico/inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
						<li><a href="../../../sector-publico/inversiones/plazo-fijo.php">Plazo Fijo</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">SERVICIOS</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../../sector-publico/servicios/servicio-de-recaudacion.php">Servicio de Recaudación</a></li>
						<li><a href="../../../sector-publico/servicios/servicio-de-pagos.php">Servicio de Pagos</a></li>
						<li><a href="../../../sector-publico/servicios/servicios-para-personal.php">Servicios para el Personal</a></li>
						<li><a href="../../../sector-publico/servicios/financiacion.php">Financiación</a></li>
						<li><a href="../../../sector-publico/servicios/otros-servicios.php">Servicios</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">PROGRAMA UNIVERSIDADES</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../../sector-publico/programa-universidades/relacion-institucional.php">Relación Institucional</a></li>
						<li><a href="../../../sector-publico/programa-universidades/docentes-yno-docentes.php">Docentes y No Docentes</a></li>
						<li><a href="../../../sector-publico/programa-universidades/alumnos.php">Alumnos</a></li>
						<li><a href="../../../sector-publico/programa-universidades/graduados.php">Graduados</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">BENEFICIOS RÍO NEGRO</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../../sector-publico/rio-negro/presencia.php">Presencia en Río Negro</a></li>
                        <li><a href="../../../sector-publico/rio-negro/propuesta-valor.php">Propuesta de valor exclusiva</a></li>
					</ul>
				</li>
			</ul>
		</li>
        <!-- FIN SECTOR PUBLICO -->
        
        <!-- INSTITUCIONAL -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">INSTITUCIONAL <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../../institucional/index.php" class="">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">BANCO PATAGONIA</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../../institucional/banco-patagonia/historia.php">Historia</a></li>
						<li><a href="../../../institucional/banco-patagonia/mercado-de-capitales.php">Mercado de Capitales</a></li>
						<li><a href="../../../institucional/banco-patagonia/patagonia-inversora.php">Patagonia Inversora</a></li>
						<li><a href="../../../institucional/banco-patagonia/patagonia-valores-sa.php">Patagonia Valores S.A</a></li>
						<li><a href="https://bp.bancopatagonia.com.ar/relacion-con-inversores/es/institucional" target="_blank">Relación con Inversores</a></li>
						<li><a href="../../../institucional/banco-patagonia/desarrollo-humano.php">Desarrollo Humano</a></li>
						<li><a href="../../../institucional/banco-patagonia/sustentabilidad.php">Sustentabilidad</a></li>
						<li><a href="../../../institucional/banco-patagonia/politicas-aml-cft.php">Póliticas AML/CFT</a></li>
						<li><a href="../../../institucional/banco-patagonia/disciplina-del-mercado.php">Disciplina de Mercado</a></li>
                        <li><a href="../../../institucional/banco-patagonia/asistencia-a-vinculados.php">Asistencia a vinculados</a></li>
                        <li><a href="../../../institucional/banco-patagonia/etica-e-integridad.php">Ética e Integridad</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">ORGANIZACIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../../institucional/organizacion/accionistas.php">Accionistas</a></li>
						<li><a href="../../../institucional/organizacion/autoridades.php">Autoridades</a></li>
                        <li><a href="../../../institucional/organizacion/comites.php">Comités</a></li>
						<li><a href="../../../institucional/organizacion/sector-financiero.php">Sector Financiero</a></li>
					</ul>
				</li>
			</ul>
		</li>
        <!-- FIN INSTITUCIONAL -->
        
        <li class="nav-main-item"><a href="https://tunuevacuenta.bancopatagonia.com.ar/?utm_source=sitiowebbp&utm_medium=sitiowebbp%20banner%20home&utm_campaign=onboarding_sitiowebp_bannerhome" target="_blank" style="text-transform: none;">Hacete cliente</a></li>		<li class="nav-main-item"><a href="../../../preguntas-frecuentes/index.php" class="" style="text-transform: none;">Ayuda</a></li>
		<!--<li class="nav-main-item"><a href="<php echo $folder_canales ?>index.php" class="<php echo $canales ?>" style="text-transform: none;">Canales de Atención</a></li>-->
		<!--<li class="nav-main-item"><a href="http://sucursalesycajeros.bancopatagonia.com.ar/sucursales.html" target="_blank" style="text-transform: none;">Sucursales y Cajeros</a></li>-->
		<!--<li class="nav-main-item"><a href="<php echo $folder_contactenos ?>index.php" class="<php echo $contactenos ?>" style="text-transform: none;">Contactanos</a></li>-->
        <!--<li class="nav-main-item"><a href="<php echo $path ?>ayuda/index.php" class="<php echo $ayuda ?>" style="text-transform: none;">Ayuda</a></li>-->
	</ul>
</div>    <!-- -->
    <section class="sec-head" title="Tarjetas de débito. Detrás de lo que querés, está la tarjeta que necesitás">
    <!--<div class="sec-pic-head xs-head-position-x-60" style="background-image: url(<php echo $pathfile ?>images/head-tarjetas-de-debito.jpg);">-->
    <div class="sec-pic-head" id="head-tarjetas-de-debito">
        <!--
        <div class="container">
            <div class="row">
                <div class="col-md-4 col-sm-6 col-xs-12 sec-pic-area">
                    <div class="sec-head-card">
                        <h2 class="with-border">Patagonia 24</h2>
                        <p>La tarjeta de débito que te brinda acceso a tus cuentas bancarias a través de nuestra red de cajeros.</p>
                    </div>
                </div>
            </div>
        </div>
        -->
    </div>
</section>    <!-- -->
    <section class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <ol class="breadcrumb">
                    <li><a href="../../index.php">Personas</a></li>
                    <li>Productos y Servicios</li>
                    <li class="active">Tarjetas de débito</li>
                </ol>
            </div>
        </div>
    </section>
    <!-- -->
    <section class="container">
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">			
            <div class="text-data">
				<!-- -->
				<div class="row">
                    <div class="col-md-4 col-sm-6 col-xs-12">
                        <figure><img src="../../../assets/images/layout/tarjetas/visa-debito.png" width="200" alt="Tarjeta Visa Débito" class="img-responsive"/></figure>
                    </div>
                </div>
				<!-- -->
				<h1>Tu Tarjeta de Débito te permite contar con dinero las 24 hs y abonar tus compras de manera sencilla.</h1>
				<!-- -->
				<h3>¡A partir de ahora ya podés visualizar tu Tarjeta de Débito virtual a través de Patagonia Móvil!. Te contamos como hacerlo:</h3>
				<ul>
                    <li>Ingresá a Patagonia Móvil &gt; Tarjetas &gt; Visa Débito.</li>
                    <li>Seleccioná la opción &ldquo;Mostrar datos&rdquo;.</li>
                    <li>¡Listo! Ya podrás visualizar los datos para realizar compras on line o incluirlo en tus billeteras digitales.</li>
                    <li>En el caso que prefieras que no se muestren los datos, podrás seleccionar &ldquo;Ocultar datos&rdquo; las veces que necesites.</li>
                </ul>
				<p>Recordá que para acceder a esta funcionalidad es necesario tener activo el Token Patagonia. Podrás visualizar el paso a paso de activación ingresando <a href="../../../preguntas-frecuentes/token/como-asocio.php">acá.</a></p>
				<hr>
				<!-- -->
                <h3>Cómo visualizar y editar los límites de tus tarjetas de débito</h3>
                <p><strong>Por Patagonia Móvil:</strong></p>
                <ul>
					<li>Ingresá con tu usuario y clave.</li>
					<li>En la pantalla de inicio, seleccioná la opción Tarjeta de Débito en MIS TARJETAS y elegí la Tarjeta que quieras consultar o modificar.</li>
					<li>Elegí la opción &ldquo;Límites&rdquo;. Allí visualizarás los límites actuales de tu tarjeta de débito, para extraer efectivo en cajeros automáticos de Banco Patagonia, realizar compras y pagar servicios por los canales digitales.</li>
					<li>Hacé click en &ldquo;Editar límite&rdquo; (*), y luego elegí tu nuevo límite entre las opciones disponibles. Para finalizar, confirmá la operación.</li>
					<li>Finalmente recibirás un mail de confirmación de la operación, y tus nuevos límites estarán disponibles a partir de las siguiente 24 horas hábiles.</li>
                </ul>
                <p><strong>Por Patagonia eBank:</strong></p>
                <ul>
					<li>Ingresá con tu usuario y clave.</li>
					<li>Dentro del menú principal, seleccioná la opción &ldquo;Tarjetas&rdquo;, y desde Patagonia 24, elegí la opción &ldquo;Límites&rdquo;. Vas a visualizar los límites actuales de tu tarjeta de débito para extraer efectivo en cajeros automáticos de Banco Patagonia, realizar compras y pagar servicios por los canales digitales.</li>
					<li>Elegí la opción &ldquo;Editar límite&rdquo; (*), allí visualizarás las opciones disponibles para realizar la modificación. Elegí la opción que prefieras y confirmá la operación.</li>
					<li>Finalmente recibirás un mail de confirmación de la operación, y tus nuevos límites estarán disponibles a partir de las siguiente 24 horas hábiles.</li>
                </ul>
                <p><em>(*) Esta opción no incluye todos los beneficios sociales ANSES.</em></p>
              	<hr>
                <!-- -->
                <h3>Ventajas</h3>
                <p>Acceso a tus cuentas bancarias a través de nuestros 600 cajeros automáticos, más todos los de la red Banelco en el país y desde el exterior a través de Visa Plus, las 24 hs. del día.</p>
                <ul>
                    <li><strong>Extracciones y depósitos.</strong></li>
                    <li><strong>Transferencia de fondos entre cuentas.</strong></li>
                    <li><strong>Pago electrónico de servicios.</strong></li>
                    <li><strong>Consultas de saldos y movimientos.</strong></li>
                    <li><strong>Compra de dólares.</strong></li>
                </ul>
                <p>Visa Débito es aceptada en 29  millones de comercios en todo el mundo, para abonar sus compras  como si lo hiciera en efectivo, sin  usar efectivo, debitando el importe de las mismas directamente de su cuenta.</p>
                <ul>
                    <li><strong>Las  compras son debitadas en el día, en forma automática, de tu cuenta bancaria. </strong></li>
                    <li><strong>Sólo  debes presentar tu tarjeta y documento y firmar el comprobante. Recordá  guardar la copia del mismo.</strong></li>
                </ul>
                <!-- -->
                <hr>
                <h3>Cómo operar con tus tarjetas de débito en el exterior</h3>
                <p>Te recordamos que podés seleccionar sobre qué cuenta operar en el exterior con tu tarjeta de débito Patagonia 24.</p>
                <ul>
                    <li>Ingresá a Patagonia E-bank <sup>(1)</sup>.</li>
                    <li>Seleccioná Tarjetas.</li>
                    <li>Ingresá en Cuentas Vinculadas de tu Patagonia 24.</li>
                    <li>Y elegí la opción que prefieras.</li>
                </ul>
                <p>De no seleccionar cuenta para operar en el exterior, se priorizará el débito en cuentas en dólares.</p>
                <p>Para más información hacé <a href="../../../ayuda/preguntas-frecuentes.php">click acá</a></p>
                <p>&nbsp;</p>
                <!--
                <hr>
                <h3>Cuentas vinculadas</h3>
                <p>Te recordamos que podés seleccionar en qué cuenta se realizarán los débitos de compras y extracciones en el exterior con tu tarjeta de débito Patagonia 24.</p>
                <ol>
                    <li><strong>  Ingresá a Patagonia E-bank (1).</strong></li>
                    <li><strong> Seleccioná Tarjetas.</strong></li>
                    <li><strong> Ingresá en Cuentas Vinculadas de tu Patagonia 24.</strong></li>
                </ol>
                <p> Y elegí la opción que prefieras.</p>
                <p>Tené en cuenta que para realizar  extracciones en cajeros automáticos del exterior, necesariamente la cuenta  preferida debe ser en dólares (2). Caso contrario, no se podrá realizar el  retiro de efectivo.</p>
                <p>Por lo tanto, si elegiste una  cuenta preferida en pesos, podrás realizar consumos pero NO  extracciones.</p>
                <p>En caso de no contar con  saldo en la cuenta seleccionada, las compras se  debitarán automáticamente de otra cuenta vinculada en dólares y seguirá con la  de pesos hasta encontrar saldo.</p>
                -->
                <div class="highlight-bar">
                    <h3>Línea VISA para Robo o extravío de Tarjetas de Débito: (011) 4320-2500</h3>
                    <p>Cobertura automática en caso de pérdida o robo, desde las 0 horas del día en que se realiza la denuncia.</p>
                </div>
            </div>
            <!-- PRE FOOTER -->
            <div class="row consulta">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <h4>Solicitalo en</h4>
                </div>
                <div class="col-md-4 col-sm-4 col-xs-12">
                    <a href="https://ebankpersonas.bancopatagonia.com.ar/eBanking/usuarios/login.htm" class="lnk">PATAGONIA E-BANK</a>
                </div>
                <div class="col-md-4 col-sm-4 col-xs-12">
                    <a href="tel:0800-777-8500" class="lnk lnk-2-lines phone">Telefónicamente<br><span>0800-777-8500</span></a>
                </div>
                <div class="col-md-4 col-sm-4 col-xs-12">
                    <a href="http://sucursalesycajeros.bancopatagonia.com.ar/sucursales.html" target="_blank" class="lnk last">EN LA SUCURSAL</a>
                </div>
            </div>
            <div class="row legal-int">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <p>LOS ACCIONISTAS DE BANCO PATAGONIA S.A. LIMITAN SU RESPONSABILIDAD A LA INTEGRACIÓN DE LAS ACCIONES SUSCRIPTAS. EN VIRTUD DE ELLO, NI LOS ACCIONISTAS MAYORITARIOS DE CAPITAL EXTRANJERO NI LOS ACCIONISTAS LOCALES O EXTRANJEROS, RESPONDEN EN EXCESO DE LA CITADA INTEGRACIÓN ACCIONARIA POR LAS OBLIGACIONES EMERGENTES DE LAS OPERACIONES CONCERTADAS POR LA ENTIDAD FINANCIERA. LEY 25.738.</p>
                    <p>(1) EL USO DE PATAGONIA E-BANK  REQUIERE LA ACEPTACIÓN PREVIA DE SUS TÉRMINOS Y CONDICIONES, LOS CUALES PODRÁN  SER CONSULTADOS EN WWW.BANCOPATAGONIA.COM.AR O EN CUALQUIERA DE NUESTRAS  SUCURSALES.<br>
                    (2) CONFORME LO DISPUESTO POR LA COMUNICACIÓN A 6882 DEL BANCO CENTRAL DE LA REPUBLICA ARGENTINA.<br>
                    (3) SOBRE LOS MISMOS SE APLICARÁ EL IMPUESTO PARA UNA ARGENTINA INCLUSIVA Y SOLIDARIA (PAIS), LEY 27.541 Y SU DECRETO REGLAMENTARIO 99/2019.</p>
                </div>
            </div>
            <!-- FIN PRE FOOTER -->
        </div>
    </div>
</section>    <!-- -->
	<div class="container-fluid footer-bar">
	<div class="row">
		<footer class="container">
			<div class="row">
				<div class="col-md-12">
					<p class="flnks"><a href="../../../registro-nacional-base-datos.php">Registro Nacional de Base de Datos</a> <span>|</span>   <a href="../../../codigo-practicas-bancarias.php">Código de Prácticas Bancarias</a> <span>|</span>   <a href="../../../defensa-ley-consumidor.php">Defensa del Consumidor</a>
						<span>|</span>   <a href="https://www.argentina.gob.ar/produccion/defensadelconsumidor/formulario">Defensa de las y los consumidores. Para reclamos ingrese aquí</a><span>|</span> <br class="tbl"> <a href="../../../persona-expuesta-politicamente.php">Persona Expuesta Políticamente</a> <span class="tbl">|</span> <br class="dsk">
						
					<a href="../../../agencia-acceso-informacion-publica.php">Agencia de Acceso a la Información Pública</a> <span>|</span> <br class="tbl"> 
					<a href="../../../cnv-advertencia-publico-inversor.php">CNV - Advertencia al Público Inversor</a> <span>|</span> <a href="../../../docs/Idoneos.pdf" target="_blank"> Idóneos en Mercado de Capitales - CNV</a><span>|</span>   <a href="../../../codigo-proteccion-inversor.php">Código de Protección al Inversor</a> <span>|</span>   <a href="../../../clausulas-legales.php">Cláusulas Legales</a> <span>|</span> <a href="../../../resolucion-022021.php">Resol. 02/21 Dir.Gral. Defensa del consumidor Córdoba</a></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<p class="redes">
                        <span>Seguinos en:</span>
                        <!-- -->
                        <a href="https://www.facebook.com/BancoPatagonia/" target="_blank"><img src="../../../assets/images/layout/icon-facebook.svg" alt="Facebook"></a>
                        <a href="https://twitter.com/banco_patagonia" target="_blank"><img src="../../../assets/images/layout/icon-twitter.svg" alt="Twitter"></a>
                        <a href="https://www.instagram.com/banco_patagonia/" target="_blank"><img src="../../../assets/images/layout/icon-instagram.svg" alt="Instagram"></a>
                        <a href="https://www.youtube.com/user/bancopatagonia" target="_blank"><img src="../../../assets/images/layout/icon-youtube.svg" alt="Youtube"></a>
                        <!-- -->
                        <!--
                        <a href="https://www.facebook.com/BancoPatagonia/" target="_blank"><i class="fa fa-facebook-square"></i></a>
                        <a href="https://twitter.com/banco_patagonia" target="_blank"><i class="fa fa-twitter"></i></a>
                        <a href="https://www.instagram.com/banco_patagonia/" target="_blank"><i class="fa fa-instagram"></i></a>
                        <a href="https://www.youtube.com/user/bancopatagonia" target="_blank"><i class="fa fa-youtube-play"></i></a>
                        -->
                    </p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					                    <!---->
				    <p class="flegal">BANCO PATAGONIA S.A. ES UNA SOCIEDAD ANÓNIMA CONSTITUIDA BAJO LAS LEYES DE LA REPÚBLICA ARGENTINA CUYOS ACCIONISTAS LIMITAN SU RESPONSABILIDAD A LA INTEGRACIÓN DE LAS ACCIONES SUSCRITAS DE ACUERDO A LA LEY 19.550. POR CONSIGUIENTE, Y EN CUMPLIMIENTO DE LA LEY 25.738, SE INFORMA QUE NI LOS ACCIONISTAS MAYORITARIOS DE CAPITAL EXTRANJERO NI LOS ACCIONISTAS LOCALES O EXTRANJEROS RESPONDEN, EN EXCESO DE LA CITADA INTEGRACIÓN ACCIONARIA, POR LAS OBLIGACIONES EMERGENTES DE LAS OPERACIONES CONCERTADAS POR LA ENTIDAD FINANCIERA.</p>
                    <p class="flegal" style="font-size:10px;">Banco Patagonia S.A. - Agente de Liquidacion y Compensacion y Agente de Negociacion Integral, inscripto en CNV bajo el N° 66</p>
					<p class="flegal">© 2025 Banco Patagonia . Todos los derechos reservados. Prohibida la duplicación , distribución o almacenamiento en cualquier medio.</p>
				</div>
			</div>
		</footer>
	</div>
</div>
<div class="tbl mbl placeholder-shortlinks">
	<div class="container shortlinks">
		<div class="row">
            <!--<php if ($home_personas == false) { ?>
                <div class="col-sm-3 col-xs-3">
                    <a href="#"><span class="icon icon-contacto"></span></a>
                </div>
            <php } ?>-->
            			<div class="col-sm-3 col-xs-3">
				<a href="http://sucursalesycajeros.bancopatagonia.com.ar/sucursales.html" target="_blank"><span class="icon icon-sucursales"></span>Sucursales y Cajeros</a>
			</div>
			<div class="col-sm-3 col-xs-3">
				<a href="../../../preguntas-frecuentes/index.php"><span class="icon icon-contacto"></span>Ayuda</a>
			</div>
			<div class="col-sm-3 col-xs-3 last">
				<a href="../../../empresas/patagonia-ebank-empresas-mbl.php"><span class="icon icon-ebank"></span>Patagonia e-Bank</a>
			</div>
		</div>
	</div>
</div>	<script src="../../../assets/js/jquery-3.5.1.min.js"></script>
<script src="../../../assets/bootstrap/js/bootstrap.min.js"></script>
<script src="../../../assets/js/slick/slick.min.js"></script>
<script src="../../../assets/js/fancybox/jquery.fancybox.min.js"></script>
<script src="../../../assets/js/mtabs/jquery.bootstrap-responsive-tabs.min.js"></script>
<script src="../../../assets/js/funciones.js"></script>

<!-- Global site tag (gtag.js) - Google Analytics (original) -->
<!--
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-32588129-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-32588129-1');
</script>
-->

<!-- Google Analytics (version anterior / eventos ok)  -->
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');
  ga('create', 'UA-32588129-1', 'auto');
  ga('send', 'pageview');
</script>

<!-- GA4 - Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-C6LG1PT98X"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-C6LG1PT98X');
</script>
</body>
</html>