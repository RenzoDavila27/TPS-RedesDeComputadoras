<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
	<meta http-equiv="Pragma" content="no-cache">
	<meta http-equiv="Expires" content="0">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-NL73B44');</script>
<!-- End Google Tag Manager -->

<link rel="shortcut icon" href="../../favicon.ico" type="image/x-icon"/>
<link href="../../assets/fonts/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="../../assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="../../assets/js/mtabs/bootstrap-responsive-tabs.css" rel="stylesheet" type="text/css">
<link href="../../assets/js/slick/slick.css" rel="stylesheet" type="text/css">
<link href="../../assets/js/fancybox/jquery.fancybox.min.css" rel="stylesheet" type="text/css">
<link href="../../assets/css/styles.css" rel="stylesheet" type="text/css">
<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->	
	<!-- METATAGS -->
	<title>Elegí Banco Patagonia para cobrar tu jubilación | Banco Patagonia</title>
	<meta name="description" content="Acompañamos a los más grandes con muchos beneficios.">	
	
	<!-- Google -->
	<meta name="thumbnail" content="https://www.bancopatagonia.com.ar/personas/jubilados/images/head-jubilados-mbl.jpg" />

	<!-- Open Graph / Facebook -->
	<meta property="og:type" content="website">
	<meta property="og:url" content="">
	<meta property="og:title" content="Elegí Banco Patagonia para cobrar tu jubilación">
	<meta property="og:description" content="Acompañamos a los más grandes con muchos beneficios.">
	<meta property="og:image" content="https://www.bancopatagonia.com.ar/personas/jubilados/images/head-jubilados-mbl.jpg">

	<!-- Twitter -->
	<meta property="twitter:card" content="summary_large_image">
	<meta property="twitter:url" content="">
	<meta property="twitter:title" content="Elegí Banco Patagonia para cobrar tu jubilación">
	<meta property="twitter:description" content="Acompañamos a los más grandes con muchos beneficios.">
	<meta property="twitter:image" content="https://www.bancopatagonia.com.ar/personas/jubilados/images/head-jubilados-mbl.jpg">
    
	<!-- SLIDES RESPONSIVE -->
    <style>
        /* DSK */
        #head-jubilados { background-image: url(images/head-jubilados-dsk.jpg); background-image: -webkit-image-set ( url("images/head-jubilados-dsk.jpg") 1x, url("images/head-jubilados-dsk@2x.jpg") 2x ); }

        @media screen and (max-width: 1200px) {
            /* TBT */
            #head-jubilados { background-image: url(images/head-jubilados-tbl.jpg); background-size: auto !important; background-image: -webkit-image-set ( url("images/head-jubilados-tbl.jpg") 1x, url("images/head-jubilados-tbl@2x.jpg") 2x ); }
        }
        @media screen and (max-width: 560px) {
            /* MBL */
            #head-jubilados { background-image: url(images/head-jubilados-mbl.jpg); background-image: -webkit-image-set ( url("images/head-jubilados-mbl.jpg") 1x, url("images/head-jubilados-mbl@2x.jpg") 2x ); }
        }
    </style>
    <!-- -->
	
	<!-- CSS (JUBILADOS) -->
    <style>
       .tmpl-jubi-ref { background-image: url(images/bgd-referir.png); background-image: -webkit-image-set ( url("images/bgd-referir.png") 1x, url("images/bgd-referir@2x.png") 2x ); }
    </style>
    <!-- -->
	
</head>

<body>
	<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NL73B44"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

<div class="placeholder-bar">
	<div class="container-fluid header-bar">
		<div class="row">
			<header class="container">
				<div class="row">
					<div class="col-md-3 col-dsk-6 col-sm-6">
						<span class="c-hamburger c-hamburger--htx">
							<span>toggle menu</span>
						</span>
                        <!-- -->
                        <!--<img style="position: absolute; width: 42px; top: 20px; right: 40px;" class="dsk" src="<php echo $path ?>assets/images/layout/icon-verano-2022.svg">-->
                        <!-- -->
						<h1>
                            <!--<img style="position: absolute; width: 32px; top: 12px; left: 102px;" class="dsk" src="<php echo $path ?>assets/images/layout/icon-navidad-2021.svg">-->
                            <a href="../index.php" class="main-logo">Banco Patagonia</a>
                        </h1>
					</div>
					<div class="col-md-9 col-dsk-6 col-sm-6">
						<div class="general-links">
							<ul class="list-unstyled">
                                <li id="btn-hacete-cliente"><a href="https://tunuevacuenta.bancopatagonia.com.ar/?utm_source=sitiowebbp&utm_medium=sitiowebbp%20banner%20home&utm_campaign=onboarding_sitiowebp_bannerhome" target="_blank"><strong>Hacete cliente <i class="fa fa-angle-right"></i></strong></a></li>								<li><a href="../../preguntas-frecuentes/index.php" class="">Ayuda</a></li>
								<!--<li><a href="<php echo $folder_canales ?>index.php" class="<php echo $canales ?>">Canales de atención</a></li>-->
								<!--<li><a href="http://sucursalesycajeros.bancopatagonia.com.ar/sucursales.html" target="_blank">Sucursales y cajeros</a></li>-->
								<!--<li><a href="<php echo $folder_contactenos ?>index.php" class="<php echo $contactenos ?>">Contactanos</a></li>-->
                                <!--<li><a href="<php echo $path ?>ayuda/index.php" class="<php echo $ayuda ?>">Ayuda</a></li>-->
							</ul>
						</div>
						<div class="top-links">
							<ul class="list-unstyled">
								<li><a href="../index.php" class="active">PERSONAS</a></li>
								<li><a href="../../nyps/index.php" class="">PROFESIONALES Y COMERCIOS</a></li>
								<li><a href="../../pyme/index.php" class="">PYME</a></li>
								<li><a href="../../agro/index.php" class="">AGRO</a></li>
								<li><a href="../../empresas/index.php" class="">EMPRESAS</a></li>
								<li><a href="../../sector-publico/index.php" class="">SECTOR PÚBLICO</a></li>
								<li><a href="../../institucional/index.php" class="">INSTITUCIONAL</a></li>
							</ul>
							<div class="ebank">
                            <!-- antes href: <php echo $folder_empresas ?><php echo $url_ebank ?>-->
															<a href="https://ebankpersonas.bancopatagonia.com.ar/eBanking/usuarios/login.htm" class="patagonia-ebank" target="_blank">Patagonia e-Bank</a>
														</div>
						</div>
					</div>
				</div>
			</header>
		</div>
	</div>
</div>

<div class="container-fluid nav-bar">
	<div class="row">
		<nav class="container">
			<div class="row">
				<!--<div class="col-md-9 col-md-offset-3">-->
                <div class="col-md-10 col-md-offset-3"><!-- ajuste agro -->
					<ul class="list-unstyled sub-navbar">
						
												<!-- PERSONAS -->
                        <li class="nav-item"><a href="#" class="nav-lnk ">PATAGONIA CLÁSICA</a>
							<ul class="list-unstyled submenu">
                                <li><a href="../../personas/patagonia-clasica/patagonia-ahorro/productos.php">Patagonia Ahorro</a></li>
                                <li><a href="../../personas/patagonia-clasica/paquete/productos.php">Patagonia Clásica</a></li>
                                <!--<li><a href="<php echo $path ?>personas/patagonia-clasica/mas/productos.php">Patagonia Clásica Más</a></li>-->
                                <li><a href="../../personas/patagonia-clasica/premium/productos.php">Patagonia Clásica Premium</a></li>
                                <li><a href="../../personas/patagonia-clasica/patagonia-sueldo/productos.php">Patagonia Sueldo</a></li>
							</ul>
						</li>
						<li class="nav-item"><a href="#" class="nav-lnk ">PATAGONIA PLUS</a>
							<ul class="list-unstyled submenu">
                                <li><a href="../../personas/patagonia-plus/productos.php">Patagonia Plus</a></li>
                                <li><a href="../../personas/patagonia-plus/premium/productos.php">Patagonia Plus Premium</a></li>
							</ul>						
						</li>
						<li class="nav-item"><a href="#" class="nav-lnk ">PATAGONIA SINGULAR</a>
							<ul class="list-unstyled submenu">
								<li><a href="../../personas/patagonia-singular/paquete/propuesta.php">Patagonia Singular</a></li>
                                <li><a href="../../personas/patagonia-singular/beneficios-exclusivos.php">Beneficios Exclusivos</a></li>
                                <!--<li><a href="<php echo $path ?>personas/patagonia-singular/atencion-exclusiva/index.php">Atención Exclusiva</a></li>-->
                                <!--<li><a href="<php echo $path ?>personas/patagonia-singular/eventos-y-novedades/index.php">Eventos y Novedades</a></li>-->
							</ul>
						</li>
						<!--<li class="nav-item"><a href="<php echo $path ?>patagoniaon/index.php" target="_blank" class="nav-lnk">PATAGONIA ON</a></li>-->
						<li class="nav-item"><a href="#" class="nav-lnk ">PATAGONIA ON</a>
							<ul class="list-unstyled submenu">
                                <li><a href="../../patagoniaon/index.php" target="_blank">Patagonia ON</a></li>
								<li><a href="../../personas/productos-y-servicios/patagonia-universitaria.php">Patagonia ON Universitaria</a></li>
							</ul>
						</li>
						<li class="nav-item"><a href="#" class="nav-lnk ">PRODUCTOS Y SERVICIOS</a>
							<ul class="list-unstyled submenu">
                                <li><a href="../../personas/apple-pay.php">Apple Pay</a></li>
                                <li><a href="../../personas/productos-y-servicios/caja-de-seguridad.php">Caja de Seguridad</a></li>
                                <li><a href="../../personas/productos-y-servicios/comercio-exterior/productos.php">Comercio exterior</a></li>
								<!--<li><a href="<php echo $path ?>personas/productos-y-servicios/beneficios-wapa.php">Comercios WAPA</a></li>-->
								<li><a href="../../personas/cuotifica-al-toque.php">Cuotificá al Toque</a></li>
								<li><a href="../../personas/google-pay.php">Google Pay</a></li>
                                <li><a href="../../personas/productos-y-servicios/inversiones.php">Inversiones</a></li>
                                <li><a href="../../personas/jubilados/index.php">Jubilados</a></li>
                                <li><a href="../../personas/productos-y-servicios/patagonia-para-menores.php">Patagonia para Menores</a></li>
                                <!--<li><a href="<php echo $path ?>personas/productos-y-servicios/patagonia-universitaria.php">Patagonia Universitaria</a></li>-->
                                <li><a href="../../personas/productos-y-servicios/prestamos.php">Prestamos</a></li>
                                <li><a href="../../personas/seguros/index.php">Seguros</a></li>
                                <li><a href="../../personas/productos-y-servicios/tarjetas-de-credito/visa.php">Tarjetas de crédito</a></li>
								<li><a href="../../personas/productos-y-servicios/tarjetas-de-debito/patagonia-24.php">Tarjetas de débito</a></li>
							</ul>
						</li>
						<!-- FIN PERSONAS -->
						                        
                                                
                                                
                        						
												
												
						
											</ul>
				</div>
			</div>
		</nav>
	</div>
</div>

<div class="mobile-nav-bar">
	<ul class="list-unstyled">
        
        <!-- PERSONAS -->
		<li class="nav-main-item"><a href="#" class="has-sub-items active">PERSONAS <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../index.php" class="active">HOME</a></li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA CLÁSICA</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../personas/patagonia-clasica/patagonia-ahorro/productos.php">Patagonia Ahorro</a></li>
                        <li><a href="../../personas/patagonia-clasica/paquete/productos.php">Patagonia Clásica</a></li>
                        <!--<li><a href="<php echo $path ?>personas/patagonia-clasica/mas/productos.php">Patagonia Clásica Más</a></li>-->
                        <li><a href="../../personas/patagonia-clasica/premium/productos.php">Patagonia Clásica Premium</a></li>
                        <li><a href="../../personas/patagonia-clasica/patagonia-sueldo/productos.php">Patagonia Sueldo</a></li>
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA PLUS</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../personas/patagonia-plus/productos.php">Patagonia Plus</a></li>
                        <li><a href="../../personas/patagonia-plus/premium/productos.php">Patagonia Plus Premium</a></li>
                    </ul>						
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA SINGULAR</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../personas/patagonia-singular/paquete/propuesta.php">Patagonia Singular</a></li>
                        <li><a href="../../personas/patagonia-singular/beneficios-exclusivos.php">Beneficios Exclusivos</a></li>
                        <!--<li><a href="<php echo $path ?>personas/patagonia-singular/atencion-exclusiva/index.php">Atención Exclusiva</a></li>-->
                        <!--<li><a href="<php echo $path ?>personas/patagonia-singular/eventos-y-novedades/index.php">Eventos y Novedades</a></li>-->
                    </ul>
                </li>
				<!--<li class="nav-sub-item"><a href="<php echo $path ?>patagoniaon/index.php" target="_blank">PATAGONIA ON</a></li>-->
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA ON</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../patagoniaon/index.php" target="_blank">Patagonia ON</a></li>
						<li><a href="../../personas/productos-y-servicios/patagonia-universitaria.php">Patagonia ON Universitaria</a></li>
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PRODUCTOS Y SERVICIOS</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../personas/apple-pay.php">Apple Pay</a></li>
                        <li><a href="../../personas/productos-y-servicios/caja-de-seguridad.php">Caja de Seguridad</a></li>
                        <li><a href="../../personas/productos-y-servicios/comercio-exterior/productos.php">Comercio exterior</a></li>
						<!--<li><a href="<php echo $path ?>personas/productos-y-servicios/beneficios-wapa.php">Comercios WAPA</a></li>-->
						<li><a href="../../personas/cuotifica-al-toque.php">Cuotificá al Toque</a></li>
						<li><a href="../../personas/google-pay.php">Google Pay</a></li>
                        <li><a href="../../personas/productos-y-servicios/inversiones.php">Inversiones</a></li>
                        <li><a href="../../personas/jubilados/index.php">Jubilados</a></li>
                        <li><a href="../../personas/productos-y-servicios/patagonia-para-menores.php">Patagonia para Menores</a></li>
                        <!--<li><a href="<php echo $path ?>personas/productos-y-servicios/patagonia-universitaria.php">Patagonia Universitaria</a></li>-->
                        <li><a href="../../personas/productos-y-servicios/prestamos.php">Prestamos</a></li>
                        <li><a href="../../personas/seguros/index.php">Seguros</a></li>
                        <li><a href="../../personas/productos-y-servicios/tarjetas-de-credito/visa.php">Tarjetas de crédito</a></li>
                        <li><a href="../../personas/productos-y-servicios/tarjetas-de-debito/patagonia-24.php">Tarjetas de débito</a></li>
                    </ul>
                </li>
			</ul>
		</li>
        <!-- FIN PERSONAS -->
        
        <!-- NYPS -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">PROFESIONALES Y COMERCIOS <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../nyps/index.php" class="">HOME</a></li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA CLÁSICA</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../nyps/patagonia-clasica/premium/productos.php">Patagonia Clásica Premium</a></li>
                        <li><a href="../../nyps/patagonia-clasica/patagonia-emprendimiento/productos.php">Patagonia Emprendimiento</a></li>
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA PLUS</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../nyps/patagonia-plus/productos.php">Patagonia Plus</a></li>
                        <li><a href="../../nyps/patagonia-plus/premium/productos.php">Patagonia Plus Premium</a></li>
                    </ul>						
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA SINGULAR</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../nyps/patagonia-singular/paquete/propuesta.php">Patagonia Singular</a></li>
                        <li><a href="../../nyps/patagonia-singular/beneficios-exclusivos.php">Beneficios Exclusivos</a></li>
                        <!--<li><a href="<php echo $path ?>nyps/patagonia-singular/eventos-y-novedades/index.php">Eventos y Novedades</a></li>-->
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PRODUCTOS Y SERVICIOS</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../nyps/productos-y-servicios/tarjetas-de-debito/patagonia-24.php">Tarjetas de débito</a></li>
                        <li><a href="../../nyps/productos-y-servicios/tarjetas-de-credito/visa.php">Tarjetas de crédito</a></li>
                        <li><a href="../../nyps/productos-y-servicios/prestamos.php">Prestamos</a></li>
                        <li><a href="../../nyps/seguros/index.php">Seguros</a></li>
                        <li><a href="../../nyps/productos-y-servicios/inversiones.php">Inversiones</a></li>
                        <li><a href="../../nyps/productos-y-servicios/comercio-exterior/productos.php">Comercio exterior</a></li>
                        <li><a href="../../nyps/productos-y-servicios/caja-de-seguridad.php">Caja de Seguridad</a></li>
                        <li><a href="../../nyps/productos-y-servicios/factura-electronica.php">Factura electrónica</a></li>
                        <li><a href="../../nyps/productos-y-servicios/pagos-afip.php">Pagos AFIP</a></li>
                        <!--<li><a href="<php echo $path ?>nyps/productos-y-servicios/soluciones-para-tu-empresa.php">Soluciones para tu empresa</a></li>-->
                        <!--<li><a href="<php echo $path ?>nyps/productos-y-servicios/comercios-patagonia.php">Comercios Patagonia</a></li>-->
						<li><a href="../../nyps/productos-y-servicios/wapa.php">WAPA</a></li>
                    </ul>
                </li>
			</ul>		
		</li>
        <!-- FIN NYPS -->
        
        <!-- PYME -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">PYME <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../pyme/index.php" class="">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">CUENTAS</a>
					<ul class="list-unstyled submenu">
                        <li><a href="../../pyme/cuentas/pequenas-empresas.php">Pyme Pequeñas Empresas</a></li>
				        <li><a href="../../pyme/cuentas/medianas-empresas.php">Pyme Medianas Empresas</a></li>
                        <!--
						<li><a href="../../pyme/cuentas/patagonia-empresario.php">Patagonia Empresario</a></li>
						<li><a href="../../pyme/cuentas/patagonia-empresario-premier.php">Patagonia Empresario Premier</a></li>
						<li><a href="../../pyme/cuentas/patagonia-empresa.php">Patagonia Empresa</a></li>
                        -->
                        <!--<li><a href="../../pyme/cuentas/patagonia-comercio.php">Patagonia Comercio</a></li>-->
                        <li><a href="../../pyme/cuentas/patagonia-consorcio.php">Patagonia Consorcio</a></li>
						<li><a href="../../pyme/cuentas/cuenta-corriente.php">Cuenta Corriente</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA SUELDO</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../pyme/patagonia-sueldo/servicios.php">Servicios</a></li>
						<li><a href="../../pyme/patagonia-sueldo/preguntas-frecuentes.php">Preguntas Frecuentes</a></li>
						<li><a href="../../pyme/patagonia-sueldo/guia-implementacion.php">Guía de Implementación</a></li>
					</ul>
				</li>						
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">COMERCIO EXTERIOR</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../pyme/comercio-exterior/solicitud-electronica.php">Solicitud Electrónica</a></li>
						<li><a href="../../pyme/comercio-exterior/productos.php">Productos</a></li>
						<li><a href="../../pyme/comercio-exterior/otros-servicios.php">Servicios</a></li>
						<!--<li><a href="<php echo $folder_pymeCexterior ?>financiaciones.php">Financiaciones</a></li>-->
                        <li><a href="../../pyme/comercio-exterior/herramientas-para-exportar.php">Herramientas para Exportar</a></li>
						<li><a href="../../pyme/comercio-exterior/marco-regulatorio/normas-y-regulaciones.php">Marco Regulatorio</a></li>
					</ul>
				</li>						
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">FINANCIACIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../pyme/financiacion/patagonia-leasing.php">Patagonia Leasing</a></li>
						<li><a href="../../pyme/financiacion/mercado-capitales.php">Mercado de Capitales</a></li>
						<li><a href="../../pyme/financiacion/alternativas-de-financiacion.php">Alternativas de Financiación</a></li>
					</ul>
				</li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">SEGUROS</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../pyme/seguros/protege-tus-bienes/integral-comercio.php">Protegé tus Bienes</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">INVERSIONES</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../pyme/inversiones/plazo-fijo.php">Plazo Fijo</a></li>
						<li><a href="../../pyme/inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
						<li><a href="../../pyme/inversiones/fidecomisos-financieros.php">Fidecomisos Financieros</a></li>
					</ul>
				</li>						
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">SERVICIOS</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../pyme/servicios/recaudaciones.php">Recaudaciones</a></li>
						<li><a href="../../pyme/servicios/pagos.php">Pagos</a></li>
						<li><a href="../../pyme/servicios/tarjetas-comerciales.php">Tarjetas Comerciales</a></li>
						<li><a href="../../pyme/servicios/comercios-patagonia.php">Comercios Patagonia</a></li>
                        <li><a href="../../pyme/servicios/pago-de-servicios.php">Pago de Servicios</a></li>
						<li><a href="../../pyme/servicios/interbanking.php">Interbanking</a></li>
						<li><a href="../../pyme/servicios/interfacturas.php">Interfacturas</a></li>
						<li><a href="../../pyme/servicios/pagos-afip.php">Pagos AFIP</a></li>
						<li><a href="../../pyme/servicios/wapa.php">WAPA</a></li>
					</ul>
				</li>
			</ul>		
		</li>
        <!-- FIN PYME -->
        
        <!-- AGRO -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">AGRO <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../agro/index.php" class="">HOME</a></li>
                <!-- -->
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">OFERTA AGRO</a>
					<ul class="list-unstyled submenu">
                    	<!--<li><a href="<php echo $folder_agroFinanciacion ?>insumos.php">Insumos en USD</a></li>-->
                        <li><a href="../../agro/convenios/acuerdos-y-beneficios.php">Acuerdos y convenios</a></li>
						<li><a href="../../agro/financiacion/maquinaria-agricola.php">Financiación Maquinaria Agrícola</a></li>
						<li><a href="../../agro/seguros/campo.php">Seguros para tu campo</a></li>
					</ul>
				</li>
                <!-- -->
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">TARJETA PATAGONIA AGRO</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../agro/tarjeta-patagonia-agro/para-usuarios.php">Para Usuarios</a></li>
						<li><a href="../../agro/tarjeta-patagonia-agro/para-comercios.php">Para Comercios</a></li>
						<li><a href="../../agro/tarjeta-patagonia-agro/acuerdo-tasa-0.php">Tarjetas Agro Convenios Preferenciales</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="../../agro/cuenta-agro/cuenta-agro.php" class="">CUENTA AGRO</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">FINANCIACIÓN</a>
					<ul class="list-unstyled submenu">
                        <li><a href="../../agro/insumos/index.php">Insumos</a></li>
                        <li><a href="../../agro/financiacion/maquinaria-agricola.php">Maquinarias</a></li>
                        <li><a href="../../empresas/financiacion/convenios-de-financiacion.php">Camiones</a></li>
						<!--<li><a href="<php echo $folder_agroFinanciacion ?>capital-de-trabajo.php">Capital de Trabajo</a></li>-->
						<!--<li><a href="<php echo $folder_agroFinanciacion ?>proyectos-de-inversion.php">Proyectos de Inversión</a></li>-->
						<!--<li><a href="<php echo $folder_agroFinanciacion ?>creditos-para-hacienda.php">Créditos para Hacienda</a></li>-->
						<!--<li><a href="<php echo $folder_agroFinanciacion ?>leasing-y-prendarios.php">Leasing y Prendarios</a></li>-->
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">INVERSIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../agro/inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
						<li><a href="../../agro/inversiones/fidecomisos-financieros.php">Fidecomisos Financieros</a></li>
						<li><a href="../../agro/inversiones/plazos-fijos.php">Plazos Fijos</a></li>
					</ul>
				</li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">COMERCIO EXTERIOR</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../agro/comercio-exterior/solicitud-electronica.php">Solicitud Electrónica</a></li>
                        <li><a href="../../agro/comercio-exterior/productos.php">Productos</a></li>
                        <li><a href="../../agro/comercio-exterior/otros-servicios.php">Servicios</a></li>
                        <li><a href="../../agro/comercio-exterior/herramientas-para-exportar.php">Herramientas para Exportar</a></li>
                        <li><a href="../../agro/comercio-exterior/marco-regulatorio/normas-y-regulaciones.php">Marco Regulatorio</a></li>
                    </ul>
                </li>
                <!--
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">SERVICIOS</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../agro/servicios/centro-atencion-empresas.php">Centro de Atención para Empresas</a></li>
					</ul>
				</li>
                -->
                <!-- -->
                <li class="nav-sub-item"><a href="../../agro/seguros/campo.php" class="">SEGUROS</a></li>
                <!-- -->
			</ul>
		</li>
        <!-- FIN AGRO -->
        
        <!-- EMPRESAS -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">EMPRESAS <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../empresas/index.php" class="">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA SUELDO</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../empresas/patagonia-sueldo/servicios.php">Servicios</a></li>
						<li><a href="../../empresas/patagonia-sueldo/preguntas-frecuentes.php">Preguntas Frecuentes</a></li>
						<li><a href="../../empresas/patagonia-sueldo/guia-implementacion.php">Guía de Implementación</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">COMERCIO EXTERIOR</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../empresas/comercio-exterior/solicitud-electronica.php">Solicitud Electrónica</a></li>
						<li><a href="../../empresas/comercio-exterior/productos.php">Productos</a></li>
						<li><a href="../../empresas/comercio-exterior/otros-servicios.php">Servicios</a></li>
						<!--<li><a href="<php echo $folder_Cexterior ?>financiaciones.php">Financiaciones</a></li>-->
                        <li><a href="../../empresas/comercio-exterior/herramientas-para-exportar.php">Herramientas para Exportar</a></li>
						<li><a href="../../empresas/comercio-exterior/marco-regulatorio/normas-y-regulaciones.php">Marco Regulatorio</a></li>
					</ul>
				</li>
                <!-- -->
				<!--<li class="nav-sub-item"><a href="../../empresas/comunidades-de-negocios/index.php" class="">COMUNIDADES DE NEGOCIOS</a></li>-->
                <!-- -->
				<li class="nav-sub-item"><a href="index.php" class="nav-lnk ">COMERCIOS PATAGONIA</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">FINANCIACIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../empresas/financiacion/patagonia-leasing.php">Patagonia Leasing</a></li>
						<li><a href="../../empresas/financiacion/mercado-capitales.php">Mercado Capitales</a></li>
						<li><a href="../../empresas/financiacion/alternativas-de-financiacion.php">Alternativas de Financiación</a></li>
                        <li><a href="../../empresas/financiacion/convenios-de-financiacion.php">Convenios de Financiación</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">INVERSIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../empresas/inversiones/plazos-fijos.php">Plazos Fijos</a></li>
						<li><a href="../../empresas/inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
						<li><a href="../../empresas/inversiones/compra-venta-titulos-acciones.php">Compra - Venta de Títulos y Acciones</a></li>
						<li><a href="../../empresas/inversiones/custodia-de-titulos.php">Custodia de Títulos</a></li>
						<li><a href="../../empresas/inversiones/fidecomisos-financieros.php">Fidecomisos Financieros</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">SERVICIOS</a>
					<ul class="list-unstyled submenu">
                        <li><a href="../../empresas/patagonia-movil-empresas.php">Patagonia Móvil Empresas</a></li>
						<li><a href="../../empresas/servicios/pagos.php">Pagos</a></li>
						<li><a href="../../empresas/servicios/recaudaciones.php">Recuadaciones</a></li>
						<li><a href="../../empresas/servicios/pago-de-servicios.php">Pago de Servicios</a></li>
						<li><a href="../../empresas/servicios/interbanking.php">Interbanking</a></li>
						<li><a href="../../empresas/servicios/interfacturas.php">Interfacturas</a></li>
						<li><a href="../../empresas/servicios/tarjetas-comerciales.php">Tarjetas Comerciales</a></li>
                        <!-- -->
						<!--<li><a href="../../empresas/servicios/comercios-patagonia.php">Comercios Patagonia</a></li>-->
                        <!-- -->
                        <li><a href="../../empresas/servicios/centro-atencion-empresas.php">Centro de Atención para Empresas</a></li>
					</ul>
				</li>
			</ul>
		</li>
        <!-- FIN EMPRESAS -->
        
        <!-- SECTOR PÚBLICO -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">SECTOR PÚBLICO <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../sector-publico/index.php" class="">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">INVERSIONES</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../sector-publico/inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
						<li><a href="../../sector-publico/inversiones/plazo-fijo.php">Plazo Fijo</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">SERVICIOS</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../sector-publico/servicios/servicio-de-recaudacion.php">Servicio de Recaudación</a></li>
						<li><a href="../../sector-publico/servicios/servicio-de-pagos.php">Servicio de Pagos</a></li>
						<li><a href="../../sector-publico/servicios/servicios-para-personal.php">Servicios para el Personal</a></li>
						<li><a href="../../sector-publico/servicios/financiacion.php">Financiación</a></li>
						<li><a href="../../sector-publico/servicios/otros-servicios.php">Servicios</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">PROGRAMA UNIVERSIDADES</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../sector-publico/programa-universidades/relacion-institucional.php">Relación Institucional</a></li>
						<li><a href="../../sector-publico/programa-universidades/docentes-yno-docentes.php">Docentes y No Docentes</a></li>
						<li><a href="../../sector-publico/programa-universidades/alumnos.php">Alumnos</a></li>
						<li><a href="../../sector-publico/programa-universidades/graduados.php">Graduados</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">BENEFICIOS RÍO NEGRO</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../sector-publico/rio-negro/presencia.php">Presencia en Río Negro</a></li>
                        <li><a href="../../sector-publico/rio-negro/propuesta-valor.php">Propuesta de valor exclusiva</a></li>
					</ul>
				</li>
			</ul>
		</li>
        <!-- FIN SECTOR PUBLICO -->
        
        <!-- INSTITUCIONAL -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">INSTITUCIONAL <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../institucional/index.php" class="">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">BANCO PATAGONIA</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../institucional/banco-patagonia/historia.php">Historia</a></li>
						<li><a href="../../institucional/banco-patagonia/mercado-de-capitales.php">Mercado de Capitales</a></li>
						<li><a href="../../institucional/banco-patagonia/patagonia-inversora.php">Patagonia Inversora</a></li>
						<li><a href="../../institucional/banco-patagonia/patagonia-valores-sa.php">Patagonia Valores S.A</a></li>
						<li><a href="https://bp.bancopatagonia.com.ar/relacion-con-inversores/es/institucional" target="_blank">Relación con Inversores</a></li>
						<li><a href="../../institucional/banco-patagonia/desarrollo-humano.php">Desarrollo Humano</a></li>
						<li><a href="../../institucional/banco-patagonia/sustentabilidad.php">Sustentabilidad</a></li>
						<li><a href="../../institucional/banco-patagonia/politicas-aml-cft.php">Póliticas AML/CFT</a></li>
						<li><a href="../../institucional/banco-patagonia/disciplina-del-mercado.php">Disciplina de Mercado</a></li>
                        <li><a href="../../institucional/banco-patagonia/asistencia-a-vinculados.php">Asistencia a vinculados</a></li>
                        <li><a href="../../institucional/banco-patagonia/etica-e-integridad.php">Ética e Integridad</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">ORGANIZACIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../institucional/organizacion/accionistas.php">Accionistas</a></li>
						<li><a href="../../institucional/organizacion/autoridades.php">Autoridades</a></li>
                        <li><a href="../../institucional/organizacion/comites.php">Comités</a></li>
						<li><a href="../../institucional/organizacion/sector-financiero.php">Sector Financiero</a></li>
					</ul>
				</li>
			</ul>
		</li>
        <!-- FIN INSTITUCIONAL -->
        
        <li class="nav-main-item"><a href="https://tunuevacuenta.bancopatagonia.com.ar/?utm_source=sitiowebbp&utm_medium=sitiowebbp%20banner%20home&utm_campaign=onboarding_sitiowebp_bannerhome" target="_blank" style="text-transform: none;">Hacete cliente</a></li>		<li class="nav-main-item"><a href="../../preguntas-frecuentes/index.php" class="" style="text-transform: none;">Ayuda</a></li>
		<!--<li class="nav-main-item"><a href="<php echo $folder_canales ?>index.php" class="<php echo $canales ?>" style="text-transform: none;">Canales de Atención</a></li>-->
		<!--<li class="nav-main-item"><a href="http://sucursalesycajeros.bancopatagonia.com.ar/sucursales.html" target="_blank" style="text-transform: none;">Sucursales y Cajeros</a></li>-->
		<!--<li class="nav-main-item"><a href="<php echo $folder_contactenos ?>index.php" class="<php echo $contactenos ?>" style="text-transform: none;">Contactanos</a></li>-->
        <!--<li class="nav-main-item"><a href="<php echo $path ?>ayuda/index.php" class="<php echo $ayuda ?>" style="text-transform: none;">Ayuda</a></li>-->
	</ul>
</div>    <section class="sec-head" title="Elegí Banco Patagonia para cobrar tu jubilación y llevate hasta $160.000">
        <div class="sec-pic-head" id="head-jubilados">
        </div>
	</section>
	<section class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
				<ol class="breadcrumb">
					<li><a href="../index.php">Personas</a></li>
                    <li class="active">Jubilados</li>
				</ol>
			</div>
		</div>
	</section>
	<section class="container" id="tmpl-jubi">
		<div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="text-data">
					<!-- ------ -->
					<!-- TITULO -->
					<!-- ------ -->
					<h1 class="tmpl-jubi-title tmpl-jubi-title-dest"><strong><span>Bienvenida exclusiva</span> y los mejores beneficios</strong></h1>
					
					<!-- --------- -->
					<!-- SEGMENTOS -->
					<!-- --------- -->
					<div class="row">
						<div class="col-md-4 col-sm-6 col-xs-12">
							<!-- -->
							<div class="tmpl-jubi-segm" id="tmpl-jubi-segm-singular">
								<img class="tmpl-jubi-segm-logo" src="../../assets/images/layout/logo-patagonia-singular.svg" alt="Patagonia Singular">
								<div>
									<div class="tmpl-jubi-segm-hasta">
										<p>Hasta</p>
										<big><strong>$160.000.</strong><sup>(1)</sup></big>
									</div>
									<!--<div class="row tmpl-jubi-segm-rubros">
										<div class="col-md-6 col-sm-6 col-xs-6">
                                            <img src="../../assets/images/layout/icons/jubilados/icon-supermercados.svg" alt="Supermercados">
                                            <p>Supermercados</p>
										</div>
										<div class="col-md-6 col-sm-6 col-xs-6">
                                            <img src="../../assets/images/layout/icons/jubilados/icon-restaurantes.svg" alt="Restaurantes">
                                            <p>Restaurantes</p>
										</div>
									</div>-->
								</div>
							</div>
							<!-- -->
						</div>
						<div class="col-md-4 col-sm-6 col-xs-12">
							<!-- -->
							<div class="tmpl-jubi-segm" id="tmpl-jubi-segm-plus">
								<img class="tmpl-jubi-segm-logo" src="../../assets/images/layout/logo-patagonia-plus.svg" alt="Patagonia Plus">
								<div>
									<div class="tmpl-jubi-segm-hasta">
										<p>Hasta</p>
										<big><strong>$85.000.</strong><sup>(1)</sup></big>
									</div>
									<!--<div class="row tmpl-jubi-segm-rubros">
										<div class="col-md-12 col-sm-12 col-xs-12">
                                            <img src="../../assets/images/layout/icons/jubilados/icon-supermercados.svg" alt="Supermercados">
                                            <p>Supermercados</p>
										</div>
									</div>-->
								</div>
							</div>
							<!-- -->
						</div>
						<div class="col-md-4 col-sm-6 col-xs-12">
							<!-- -->
							<div class="tmpl-jubi-segm" id="tmpl-jubi-segm-clasica">
								<img class="tmpl-jubi-segm-logo" src="../../assets/images/layout/logo-patagonia-clasica.svg" alt="Patagonia Clásica">
								<div>
									<div class="tmpl-jubi-segm-hasta">
										<p>Hasta</p>
										<big><strong>$20.000.</strong><sup>(1)</sup></big>
									</div>
									<!--<div class="row tmpl-jubi-segm-rubros">
										<div class="col-md-12 col-sm-12 col-xs-12">
                                            <img src="../../assets/images/layout/icons/jubilados/icon-supermercados.svg" alt="Supermercados">
                                            <p>Supermercados</p>
										</div>
									</div>-->
								</div>
							</div>
							<!-- -->
						</div>
					</div>
					
					<!-- ------- -->
					<!-- PAQUETE -->
					<!-- ------- -->
					<hr>
					<h2 class="tmpl-jubi-title">¡Un paquete de productos <strong>perfecto para vos, elegilo!</strong></h2>
                    <div class="tmpl-jubi-paq">
                        <h2>Costo de mantenimiento</h2>
                        <div class="tmpl-jubi-paq-meses">
                            <big><strong><span>100%</span> bonificado</strong></big> 
                        </div>
                    </div>
                    <h3 class="text-center"><strong>mientras acredites tu jubilación.<sup>(2)</sup></strong></h3>
					
					<!-- -------- -->
					<!-- TARJETAS -->
					<!-- -------- -->
					<div class="row">
						<div class="col-md-8 col-sm-12 col-xs-12 col-md-offset-2">
							<div class="tmpl-jubi-cards tmpl-jubi-cont-grey">
                                <figure>
                                    <img class="tmpl-jubi-card-visa" src="../../assets/images/layout/tarjetas/visa-signature.png" alt="Tarjeta Visa Signature"/>
                                    <img class="tmpl-jubi-card-master" src="../../assets/images/layout/tarjetas/master-black.png" alt="Tarjeta Mastercard Black"/>
                                </figure>
                                <img class="tmpl-jubi-card-segm" src="../../assets/images/layout/logo-patagonia-singular.svg" alt="Patagonia Singular">
                                <div class="tmpl-jubi-card-line">
                                    <ul>
                                        <li>Tarjetas Black.</li>
                                        <li>Cajas de ahorro en pesos, dólares y euros.</li>
                                        <li>Acceso en salas VIP en aeropuertos.</li>
                                        <li>Cuenta corriente.</li>
                                    </ul>
                                    <a href="../patagonia-singular/paquete/propuesta.php">Ver más</a>
                                </div>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-8 col-sm-12 col-xs-12 col-md-offset-2">
							<div class="tmpl-jubi-cards tmpl-jubi-cont-grey">
                                <figure>
                                    <img class="tmpl-jubi-card-visa" src="../../assets/images/layout/tarjetas/visa-platinum.png" alt="Tarjeta Visa Platinum"/>
                                    <img class="tmpl-jubi-card-master" src="../../assets/images/layout/tarjetas/master-platinum.png" alt="Tarjeta Mastercard Platinum"/>
                                </figure>
                                <img class="tmpl-jubi-card-segm" src="../../assets/images/layout/logo-patagonia-plus.svg" alt="Patagonia Plus">
                                <div class="tmpl-jubi-card-line">
                                    <ul>
                                        <li>Tarjetas Platinum / Gold.</li>
                                        <li>Cajas de ahorro en pesos, dólares y euros.</li>
                                        <!--<li>Acceso en salas VIP en aeropuertos.</li>-->
                                    </ul>
                                    <a href="../patagonia-plus/productos.php">Ver más</a>
                                </div>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-8 col-sm-12 col-xs-12 col-md-offset-2">
							<div class="tmpl-jubi-cards tmpl-jubi-cont-grey">
                                <figure>
                                    <img class="tmpl-jubi-card-visa" src="../../assets/images/layout/tarjetas/visa-clasica.png" alt="Tarjeta Visa Classic"/>
                                    <img class="tmpl-jubi-card-master" src="../../assets/images/layout/tarjetas/master-clasica.png" alt="Tarjeta Mastercard Internacional"/>
                                </figure>
                                <img class="tmpl-jubi-card-segm" src="../../assets/images/layout/logo-patagonia-clasica.svg" alt="Patagonia Clásica">
                                <div class="tmpl-jubi-card-line">
                                    <ul>
                                        <li>Tarjetas Internacionales.</li>
                                        <li>Cajas de ahorro en pesos, dólares y euros.</li>
                                        <!--<li>Acceso en salas VIP en aeropuertos.</li>-->
                                    </ul>
                                    <a href="../patagonia-clasica/premium/productos.php">Ver más</a>
                                </div>
							</div>
						</div>
					</div>
					
					<!-- --------------- -->
					<!-- CARACTERISTICAS -->
					<!-- --------------- -->
                    <div class="tmpl-jubi-caract tmpl-jubi-cont-grey tmpl-jubi-mrg-60">
                        <div class="row">
                            <div class="col-md-4 col-sm-4 col-xs-12">
                                <img src="../../assets/images/layout/icons/jubilados/icon-cuenta.svg" alt="Una cuenta completa que se adapta a tus necesidades">
                                <h3>Una cuenta completa que se adapta<br class="dsk"> <strong>a tus necesidades</strong>.</h3>
                            </div>
                            <div class="col-md-4 col-sm-4 col-xs-12">
                                <img src="../../assets/images/layout/icons/jubilados/icon-sucursales.svg" alt="Más de 170 Sucursales para asesorarte">
                                <h3>Más de <strong>170 Sucursales</strong> para asesorarte.</h3>
                            </div>
                            <div class="col-md-4 col-sm-4 col-xs-12">
                                <img src="../../assets/images/layout/icons/jubilados/icon-transacciones.svg" alt="Transacciones 100% bonificadas en cajeros Link y Banelco">
                                <h3>Transacciones <strong>100% bonificadas</strong><br class="dsk"> en cajeros Link y Banelco.</h3>
                            </div>
                        </div>
                    </div>
					
					<!-- ------- -->
					<!-- AHORROS -->
					<!-- ------- -->
					<div class="row tmpl-jubi-ahor">
						<div class="col-md-12 col-sm-12 col-xs-12">
							<!-- -->
							<h2 class="tmpl-jubi-title tmpl-jubi-title-dest"><strong><span>Ahorros</span> en tus compras semanales</strong></h2>
							<!-- -->
							<div class="row">
								<div class="col-md-4 col-sm-4 col-xs-6">
									<div class="tmpl-jubi-ahor-box">
										<img src="../../assets/images/layout/logos/logo-pedidos-ya.svg" alt="Pedidos Ya">
									</div>
								</div>
								<div class="col-md-4 col-sm-4 col-xs-6">
									<div class="tmpl-jubi-ahor-box">
										<p><strong>RESTAURANTES</strong></p>
									</div>
								</div>
								<div class="col-md-4 col-sm-4 col-xs-6">
									<div class="tmpl-jubi-ahor-box">
										<p><strong>COMBUSTIBLES</strong></p>
									</div>
								</div>
								<div class="col-md-4 col-sm-4 col-xs-6">
									<div class="tmpl-jubi-ahor-box">
										<img class="tmpl-jubi-ahor-img-xxs" src="../../assets/images/layout/logos/logo-havanna.svg" alt="Havanna">
									</div>
								</div>
								<div class="col-md-4 col-sm-4 col-xs-6">
									<div class="tmpl-jubi-ahor-box">
										<img class="tmpl-jubi-ahor-img-xs" src="../../assets/images/layout/logos/logo-carrefour.svg" alt="Carrefour">
									</div>
								</div>
								<div class="col-md-4 col-sm-4 col-xs-6">
									<div class="tmpl-jubi-ahor-box">
										<img src="../../assets/images/layout/logos/logo-chango-mas.svg" alt="Chango Más">
									</div>
								</div>
								<div class="col-md-4 col-sm-4 col-xs-6">
									<div class="tmpl-jubi-ahor-box">
										<img class="tmpl-jubi-ahor-img-xs" src="../../assets/images/layout/logos/logo-dexter.svg" alt="Dexter">
									</div>
								</div>
								<div class="col-md-4 col-sm-4 col-xs-6">
									<div class="tmpl-jubi-ahor-box">
										<img src="../../assets/images/layout/logos/logo-stock-center.svg" alt="Stock Center">
									</div>
								</div>
								<div class="col-md-4 col-sm-4 col-xs-6">
									<div class="tmpl-jubi-ahor-box">
										<img class="tmpl-jubi-ahor-img-xxs" src="../../assets/images/layout/logos/logo-moov.svg" alt="Moov">
									</div>
								</div>
							</div>
							<!-- -->
						</div>
					</div>
					<div class="tmpl-jubi-btns tmpl-jubi-mrg-30">
						<div class="row">
							<div class="col-md-4 col-sm-12 col-xs-12 col-md-offset-4">
								<a href="https://ahorrosybeneficios.bancopatagonia.com.ar/ahorrosybeneficios/" target="_blank" class="tmpl-jubi-btn">
									Conocé todos los beneficios
									<!--<span><em>+</em> info</span>-->
								</a>
							</div>
						</div>
					</div>
					
					<!-- --------- -->
					<!-- SERVICIOS -->
					<!-- --------- -->
					<hr>
					<!-- -->
					<h2 class="tmpl-jubi-title"><strong>Además, muchos servicios para tu vida diaria</strong></h2>
                    <div class="row tmpl-jubi-mrg-30">
                        <div class="col-md-6 col-sm-6 col-xs-12">
							<div class="tmpl-jubi-serv-box bgd-azul-2 tmpl-jubi-serv-box-esq3">
								<img src="../../assets/images/layout/icons/jubilados/icon-prestamos.svg" alt="Préstamos" height="45">
								<h3><strong>PRÉSTAMOS AL INSTANTE</strong><br class="dsk"> con tasa preferencial</h3>
							</div>
                        </div>
                        <div class="col-md-6 col-sm-6 col-xs-12">
							<div class="tmpl-jubi-serv-box bgd-gris-2 tmpl-jubi-serv-box-esq2">
								<img src="../../assets/images/layout/icons/jubilados/icon-caja-seguridad.svg" alt="Cajas de Seguridad" height="50">
								<h3><strong>CAJAS DE SEGURIDAD</strong><br class="dsk"> para resguardar tus bienes</h3>
							</div>
                        </div>
                        <div class="col-md-6 col-sm-6 col-xs-12">
							<div class="tmpl-jubi-serv-box bgd-gris-2 tmpl-jubi-serv-box-esq1">
								<img src="../../assets/images/layout/icons/jubilados/icon-anticipo.svg" alt="Adelanto de sueldo" height="35">
								<h3>Adelanto de sueldo <br class="dsk"><strong>PATAGONIA ANTICIPO</strong></h3>
							</div>
                        </div>
                        <div class="col-md-6 col-sm-6 col-xs-12">
							<div class="tmpl-jubi-serv-box bgd-azul-2 tmpl-jubi-serv-box-esq4">
								<img src="../../assets/images/layout/icons/jubilados/icon-inversiones.svg" alt="Inversiones" height="30">
								<h3><strong>PLAZOS FIJOS Y FONDOS LOMBARD</strong><br class="dsk"> para invertir tus ahorros</h3>
							</div>
                        </div>
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="tmpl-jubi-serv-box bgd-naranja tmpl-jubi-serv-box-esq4" id="tmpl-jubi-serv-box-club">
                                <img src="../../assets/images/layout/logo-club-patagonia-2.svg" alt="Club Patagonia" height="20">
                                <div>
                                    <big><strong>Cuotas sin interés</strong><sup>(3)</sup></big>
                                    <h3>todos los días para comprarte lo que quieras. <a href="https://www.clubpatagonia.com.ar/" target="_blank">Conocé más</a>.</h3>
                                </div>
                            </div>
                        </div>
                    </div>
					
					<!-- ----------------------- -->
					<!-- CARACTERISTICAS (ANSES) -->
					<!-- ----------------------- -->
					<div class="tmpl-jubi-caract tmpl-jubi-cont-grey tmpl-jubi-mrg-60">
						<h2 class="tmpl-jubi-title tmpl-jubi-title-dest"><strong><span>Elegí</span> cobrar con nosotros</strong></h2>
						<h2 class="text-center"><strong>Solicitá el cambio de Banco en ANSES</strong></h2>
						<div class="row">
							<div class="col-md-4 col-sm-4 col-xs-12">
								<img class="tmpl-jubi-icon-circle" src="../../assets/images/layout/icons/jubilados/icon-telefono-circle.svg" alt="Llamando al 130, opción 4 Jubilados, opción 2 Cambio de Banco">
								<h3>Llamando al <strong>130</strong>, opción 4 <strong>Jubilados</strong>,<br class="dsk"> opción 2 <strong>Cambio de Banco</strong>.</h3>
							</div>
							<div class="col-md-4 col-sm-4 col-xs-12">
								<img class="tmpl-jubi-icon-circle" src="../../assets/images/layout/icons/jubilados/icon-anses-circle.svg" alt="A través de Mi ANSES www.anses.gob.ar">
								<h3>A través de Mi ANSES<br class="dsk"> <strong>www.anses.gob.ar</strong></h3>
							</div>
							<div class="col-md-4 col-sm-4 col-xs-12">
								<img class="tmpl-jubi-icon-circle" src="../../assets/images/layout/icons/jubilados/icon-cuenta-circle.svg" alt="En cualquier oficina de ANSES">
								<h3>En cualquier <strong>oficina de ANSES</strong>.</h3>
							</div>
						</div>
					</div>
					
					<!-- ---- -->
					<!-- GUÍA -->
					<!-- ---- -->
					<div class="tmpl-jubi-btns">
						<h2 class="tmpl-jubi-title"><strong>Te compartimos una guía práctica para hacer el cambio de banco</strong></h2>
						<div class="row">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<a href="docs/Instructivo_Jubilados.pdf" target="_blank" class="tmpl-jubi-btn">
									Guía de pasos a seguir para cobrar la jubilación en Banco Patagonia
									<span><em>+</em> info</span>
								</a>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<a href="../productos-y-servicios/docs/Listado_sucursales_BP_ANSES.pdf" target="_blank" class="tmpl-jubi-btn tmpl-jubi-btn-clr-2">
									Listado de Sucursales Banco Patagonia con código de agencia ANSES
									<span><em>+</em> info</span>
								</a>
							</div>
						</div>
					</div>
					
					<!-- ------------- -->
					<!-- REFERÍ Y GANÁ -->
					<!-- ------------- -->
                    <div class="tmpl-jubi-ref">
                        <div class="tmpl-jubi-ref-box">
                            <h2><strong>Referí y ganá.</strong></h2>
                            <p>Referí jubilados y pensionados para que cobren en banco Patagonia.</p>
                            <!--<p><strong>¡Vos podés ganar hasta $50.000 y tu referido $100.000!</strong></p>-->
                        </div>
                        <a href="../referidos-anses/programa.php" class="tmpl-jubi-btn">
                            ¡Conocé más!
                            <!--<span><em>+</em> info</span>-->
                        </a>
                    </div>
					
					<!-- ---- -->
					<!-- GUÍA -->
					<!-- ---- -->
					<hr>
					<!-- -->
					<div class="tmpl-jubi-btns">
						<h2 class="tmpl-jubi-title"><strong>¡Te brindamos asesoramiento!</strong></h2>
						<p class="text-center"><strong>Si necesitás ayuda dejanos tus datos y te llamamos</strong> para asesorarte en el trámite ANSES para cobrar tu jubilación y/o pensión en Banco Patagonia.</p>
						<br>
						<div class="row">
							<div class="col-md-4 col-sm-12 col-xs-12 col-md-offset-4">
								<a href="https://bp.bancopatagonia.com.ar/solicitud-de-contacto" target="_blank" class="tmpl-jubi-btn">
									Quiero que me contacten
								</a>
							</div>
						</div>
					</div>

					<!-- ---- -->
					<!-- FAQS -->
					<!-- ---- -->
					<hr>
					<!-- -->
					<h2 class="tmpl-jubi-title"><strong>Preguntas Frecuentes</strong></h2>
					<div class="row">
						<!-- -- -->
						<!-- 01 -->
						<!-- -- -->
						<!-- botón -->
						<div class="col-md-12 col-sm-12 col-xs-12">
							<a href="#faqs-jubilados-01" class="btn-faqs-dspl" data-toggle="modal"><i></i>¿Qué debo hacer si estoy iniciando el trámite de jubilación?</a>
						</div>
						<!-- modal -->
						<div class="modal fade" id="faqs-jubilados-01">
							<div class="modal-dialog modal-lg">
								<div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal"><span>X</span></button>
									</div>
									<div class="modal-body">
										<div class="text-data">
											<!-- -->
											<h3><strong>¿Qué debo hacer si estoy iniciando el trámite de jubilación?</strong></h3>
											<ul>
												<li>Deberás realizar el trámite en una agencia de ANSES y concurrir con el Formulario de ANSES completo.
												<li>Descargar y completar el Formulario de ANSES PS. 6.18 “Solicitud de prestaciones previsionales”.</li>
												<li>Recordá indicar que te acrediten la jubilación en Banco Patagonia.</li>
												<li>Solicitar turno.</li>
												<li>El trámite se hace en una oficina de ANSES, necesitás sacar turno.</li>
											</ul>
											<!-- -->
										</div>
									</div>
								</div>
							</div>
						</div>
						<!-- -- -->
						<!-- 02 -->
						<!-- -- -->
						<!-- botón -->
						<div class="col-md-12 col-sm-12 col-xs-12">
							<a href="#faqs-jubilados-02" class="btn-faqs-dspl" data-toggle="modal"><i></i>¿Cómo solicito el cambio de banco para cobrar mi jubilación en Banco Patagonia?</a>
						</div>
						<!-- modal -->
						<div class="modal fade" id="faqs-jubilados-02">
							<div class="modal-dialog modal-lg">
								<div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal"><span>X</span></button>
									</div>
									<div class="modal-body">
									  <div class="text-data">
											<!-- -->
											<h3><strong>¿Cómo solicito el cambio de banco para cobrar mi jubilación en Banco Patagonia?</strong></h3>
										  	<p>Debés solicitar el cambio en ANSES y podés  hacerlo en forma <strong>on line</strong> a través de la web MIAnses, <strong>presencial</strong> en una agencia ANSES (con turno previo) o <strong>telefónica</strong> llamando al 130  (opción 4 Jubilaciones, opción 2 cambio de banco). Descargá el instructivo de  cambio de banco en esta web.</p>
										  	<p><strong>Recordá pedir que te acrediten la  jubilación en Banco Patagonia.</strong></p>
											<!-- -->
										</div>
									</div>
								</div>
							</div>
						</div>
						<!-- -- -->
						<!-- 03 -->
						<!-- -- -->
						<!-- botón -->
						<div class="col-md-12 col-sm-12 col-xs-12">
							<a href="#faqs-jubilados-03" class="btn-faqs-dspl" data-toggle="modal"><i></i>¿Qué requisitos debo cumplir para jubilarme?</a>
						</div>
						<!-- modal -->
						<div class="modal fade" id="faqs-jubilados-03">
							<div class="modal-dialog modal-lg">
								<div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal"><span>X</span></button>
									</div>
									<div class="modal-body">
										<div class="text-data">
											<!-- -->
											<h3><strong>¿Qué requisitos debo cumplir para jubilarme?</strong></h3>
											<p>Debes cumplir con los requisitos de edad y años de aportes registrados en ANSES.</p>
											<ul>
												<li>60 años o más si sos mujer; 65 años o más si sos varón.</li>
												<li>30 años de aportes registrados.</li>
											</ul>
											<p>Para conocer si tus aportes están registrados correctamente, ingresá con tu CUIL y Clave de Seguridad Social a a Mi ANSES > Trabajo > Consultar historia laboral.</p>
											<!-- -->
										</div>
									</div>
								</div>
							</div>
						</div>
						<!-- -- -->
						<!-- 04 -->
						<!-- -- -->
						<!-- botón -->
						<div class="col-md-12 col-sm-12 col-xs-12">
							<a href="#faqs-jubilados-04" class="btn-faqs-dspl" data-toggle="modal"><i></i>¿Debo abrir una cuenta una vez que tramité la elección de Banco Patagonia?</a>
						</div>
						<!-- modal -->
						<div class="modal fade" id="faqs-jubilados-04">
							<div class="modal-dialog modal-lg">
								<div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal"><span>X</span></button>
									</div>
									<div class="modal-body">
										<div class="text-data">
											<!-- -->
											<h3><strong>¿Debo abrir una cuenta una vez que tramité la elección de Banco Patagonia?</strong></h3>
											<p>No será necesario porque una vez realizado el trámite nosotros abriremos en el Banco una cuenta de la seguridad social a tu nombre y te emitimos una tarjeta de débito Patagonia 24.</p>
											<!-- -->
										</div>
									</div>
								</div>
							</div>
						</div>
						<!-- -- -->
						<!-- 05 -->
						<!-- -- -->
						<!-- botón -->
						<div class="col-md-12 col-sm-12 col-xs-12">
							<a href="#faqs-jubilados-05" class="btn-faqs-dspl" data-toggle="modal"><i></i>¿Mi cuenta tiene costo?</a>
						</div>
						<!-- modal -->
						<div class="modal fade" id="faqs-jubilados-05">
							<div class="modal-dialog modal-lg">
								<div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal"><span>X</span></button>
									</div>
									<div class="modal-body">
										<div class="text-data">
											<!-- -->
											<h3><strong>¿Mi cuenta tiene costo?</strong></h3>
											<p>Tu cuenta de la seguridad social no tiene costo de mantenimiento, es gratuita, mientras acredites tu jubilación. </p>
											<!-- -->
										</div>
									</div>
								</div>
							</div>
						</div>
						<!-- -- -->
						<!-- 06 -->
						<!-- -- -->
						<!-- botón -->
						<div class="col-md-12 col-sm-12 col-xs-12">
							<a href="#faqs-jubilados-06" class="btn-faqs-dspl" data-toggle="modal"><i></i>¿Cómo hace un apoderado ante ANSES para cobrar el beneficio?</a>
						</div>
						<!-- modal -->
						<div class="modal fade" id="faqs-jubilados-06">
							<div class="modal-dialog modal-lg">
								<div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal"><span>X</span></button>
									</div>
									<div class="modal-body">
										<div class="text-data">
											<!-- -->
											<h3><strong>¿Cómo hace un apoderado ante ANSES para cobrar el beneficio?</strong></h3>
											<p>La cuenta se abrirá a nombre del beneficiario. Si dicho beneficio fuese percibido habitualmente por el apoderado ante ANSES, informado por el Organismo ante el Banco, deberá incluirse como APODERADO en la cuenta, y esta quedará a la orden del beneficiario y del apoderado para el cobro de haberes, en forma indistinta, de manera que él mismo podrá efectuar extracciones de la cuenta. En este sentido el apoderado también tendrá a su disposición una tarjeta de débito sin cargo.</p>
											<!-- -->
										</div>
									</div>
								</div>
							</div>
						</div>
						<!-- -- -->
						<!-- 07 -->
						<!-- -- -->
						<!-- botón -->
						<div class="col-md-12 col-sm-12 col-xs-12">
							<a href="#faqs-jubilados-07" class="btn-faqs-dspl" data-toggle="modal"><i></i>¿Cómo sacás turno?</a>
						</div>
						<!-- modal -->
						<div class="modal fade" id="faqs-jubilados-07">
							<div class="modal-dialog modal-lg">
								<div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal"><span>X</span></button>
									</div>
									<div class="modal-body">
										<div class="text-data">
											<!-- -->
											<h3><strong>¿Cómo sacás turno?</strong></h3>
											<p><strong>Por la web de ANSES:</strong></p>
											<ul>
												<li>Debés ingresar en TURNOS.</li>
												<li>Después en Trámites Jubilados y Pensionados.</li>
												<li>Seleccionar Cambio de banco y continuar los pasos:
													<ul>
														<li>Ir a Agencia ANSES, día y horario.</li>
														<li>Ahí tendrás un Nro. de Solicitud para hacer el trámite (Debés concurrir con DNI).</li>
														<li>Acá dejamos el paso a paso para jubilación o pensión en Banco Patagonia.</li>
													</ul>
												</li>
											</ul>
											<p>Para realizar el trámite en una oficina de ANSES tenés que concurrir con el Formulario de ANSES PS.6.37 completo.</p>
											<p>Ingresá a Información personal, después a mis turnos.</p>
											<!-- -->
										</div>
									</div>
								</div>
							</div>
						</div>
						<!-- -- -->
						<!-- 08 -->
						<!-- -- -->
						<!-- botón -->
						<div class="col-md-12 col-sm-12 col-xs-12">
							<a href="#faqs-jubilados-08" class="btn-faqs-dspl" data-toggle="modal"><i></i>¿Cómo funciona el beneficio de bienvenida, y que monto me corresponde?</a>
						</div>
						<!-- modal -->
						<div class="modal fade" id="faqs-jubilados-08">
							<div class="modal-dialog modal-lg">
								<div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal"><span>X</span></button>
									</div>
									<div class="modal-body">
										<div class="text-data">
											<!-- -->
											<h3><strong>¿Cómo funciona el beneficio de bienvenida, y que monto me corresponde?</strong></h3>
											<p>El premio de bienvenida lo recibirás en tu cuenta por única vez. El crédito se efectuará al mes siguiente de la segunda acreditación del haber jubilatorio dentro de los primeros 10 días hábiles. El premio estará condicionado de acuerdo con el producto Patagonia contratado:</p>
											<ul>
												<li><strong>Singular:</strong> $160.000 de Bienvenida.</li>
												<li><strong>Plus Premium:</strong> $85.000 de Bienvenida.</li>
												<li><strong>Plus:</strong> $40.000 de Bienvenida</li>
												<li><strong>Clásica:</strong> $20.000 de Bienvenida.</li>
											</ul>
											<!-- -->
										</div>
									</div>
								</div>
							</div>
						</div>
						<!-- -- -->
						<!-- 09 -->
						<!-- -- -->
						<!-- botón -->
						<div class="col-md-12 col-sm-12 col-xs-12">
							<a href="#faqs-jubilados-09" class="btn-faqs-dspl" data-toggle="modal"><i></i>¿Cuáles son los requisitos para recibir la bienvenida?</a>
						</div>
						<!-- modal -->
						<div class="modal fade" id="faqs-jubilados-09">
							<div class="modal-dialog modal-lg">
								<div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal"><span>X</span></button>
									</div>
									<div class="modal-body">
										<div class="text-data">
											<!-- -->
											<h3><strong>¿Cuáles son los requisitos para recibir la bienvenida?</strong></h3>
                                            <ul>
												<li>Ser titular de un paquete de productos: Patagonia Singular, Plus Premium, Plus o Clásica.</li>
												<li>Acreditar por primera vez tus haberes jubilatorios en Banco Patagonia.</li>
												<li>Las acreditaciones mensuales deberán ser iguales o superiores a $180.000.</li>
												<li>No haber recibido un premio de bienvenida de características similares en los últimos 12 meses.</li>
                                            </ul>
											<!-- -->
										</div>
									</div>
								</div>
							</div>
						</div>
						<!-- -- -->
						<!-- 10 -->
						<!-- -- -->
						<!-- botón -->
						<div class="col-md-12 col-sm-12 col-xs-12">
							<a href="#faqs-jubilados-10" class="btn-faqs-dspl" data-toggle="modal"><i></i>¿Cuándo se acredita la bienvenida?</a>
						</div>
						<!-- modal -->
						<div class="modal fade" id="faqs-jubilados-10">
							<div class="modal-dialog modal-lg">
								<div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal"><span>X</span></button>
									</div>
									<div class="modal-body">
										<div class="text-data">
											<!-- -->
											<h3><strong>¿Cuándo se acredita la bienvenida?</strong></h3>
											<p>El premio se acreditará en tu caja de ahorro en pesos, abierta en Banco Patagonia, dentro de los primeros 10 días hábiles del mes siguiente a la segunda acreditación de tu jubilación en el banco.</p>
											<!-- -->
										</div>
									</div>
								</div>
							</div>
						</div>
						<!-- -->
					</div>
					<!-- -->
					<hr>
					<h3>Recordá que podés realizar la denuncia correspondiente ante ANSES por cobros de comisiones indebidas y gastos por apertura o mantenimiento de la Cuenta Sueldo. Para más información ingresá en www.anses.gob.ar o telefónicamente al 130, de lunes a viernes de 8 a 20 hs.</h3>
					
					<!-- ----------- -->
					<!-- CONTACTANOS -->
					<!-- ----------- -->
					<hr>
					<h2 class="tmpl-jubi-title"><strong>Contactanos</strong></h2>
					<!---->
					<div class="row">
						<div class="col-md-4 col-sm-6 col-xs-12">
							<!-- -->
							<div class="tmpl-jubi-contact" id="tmpl-jubi-contact-padi">
								<img class="tmpl-jubi-icon-circle" src="../../assets/images/layout/icons/jubilados/icon-padi-circle.svg" alt="PADI">
								<h3><strong>Asistente Virtual PADI</strong></h3>
							</div>
							<!-- -->
						</div>
						<div class="col-md-4 col-sm-6 col-xs-12">
							<!-- -->
							<div class="tmpl-jubi-contact" id="tmpl-jubi-contact-telefono">
								<img class="tmpl-jubi-icon-circle" src="../../assets/images/layout/icons/jubilados/icon-telefono-circle.svg" alt="Teléfono">
								<h3><strong>Telefónicamente<br> 0800-777-8500</strong></h3>
							</div>
							<!-- -->
						</div>
						<div class="col-md-4 col-sm-6 col-xs-12">
							<!-- -->
							<div class="tmpl-jubi-contact" id="tmpl-jubi-contact-sucursales">
								<img class="tmpl-jubi-icon-circle" src="../../assets/images/layout/icons/jubilados/icon-sucursales-circle.svg" alt="Sucursales">
								<h3><strong>Sucursales</strong></h3>
							</div>
							<!-- -->
						</div>
					</div>
					<!-- -->
                </div>
            </div>
		</div>
		
	</section>
	<!-- PRE FOOTER -->
    <section class="container">
        <div class="row legal-int">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <p>CARTERA DE CONSUMO - PROMOCIÓN VÁLIDA EN LA REPÚBLICA ARGENTINA DESDE EL 01/03/2025 HASTA EL 30/06/2025, AMBAS FECHAS INCLUÍDAS,
				EL OTORGAMIENTO DE LOS PRODUCTOS, SERVICIOS Y BENEFICIOS DE BANCO PATAGONIA S.A. SE ENCUENTRA SUJETO A LA APROBACIÓN DE LAS CONDICIONES CREDITICIAS Y DE CONTRATACIÓN DEL BANCO.</p>
				<p>(1) EL PREMIO BIENVENIDA CONSISTE EN LA ACREDITACIÓN POR UNICA VEZ EN SU CUENTA Y CONFORME LOS SIGUIENTES TOPES POR PRODUCTO PATAGONIA CONTRATADO: SINGULAR $160.000; PLUS PREMIUM $85.000; PLUS H $40.000 Y CLÁSICA $20.000. ASIMISMO, EL CLIENTE DEBE CUMPLIR CON LOS SIGUIENTES REQUISITOS: (I) SER TITULAR DE UN PAQUETE DE PRODUCTOS PATAGONIA SINGULAR, PLUS PREMIUM, PLUS O CLÁSICA (II) ACREDITAR POR PRIMERA VEZ JUBILACIÓN EN ESTE BANCO; (III) HABER MENSUAL IGUAL O SUPERIOR A $180.000 AL MOMENTO DE LA ACREDITACIÓN; (VI) NO HABER RECIBIDO UN REGALO/CASHBACK DE BIENVENIDA EN LOS ÚLTIMOS 12 MESES; (V) ACREDITAR HABERES DOS MESES CONSECUTIVOS. EL PREMIO SERÁ ACREDITADO EN LA CAJA DE AHORRO EN PESOS ABIERTA EN BANCO PATAGONIA DENTRO DE LOS PRIMEROS 10 DÍAS HÁBILES DEL MES SIGUIENTE DE LA SEGUNDA ACREDITACIÓN. DE NO CUMPLIR LOS REQUISITOS EN UN PLAZO MÁXIMO DE 120 DIAS CORRIDOS Y CONTADOS A PARTIR DE LA PRIMERA ACREDITACIÓN, SE PERDERÁ EL DERECHO AL BENEFICIO INDICADO SIN QUE ELLO GENERE DERECHO A INDEMNIZACIÓN A FAVOR DEL CLIENTE.</p>
				<p>(2) SE BONIFICARÁ EL 100% DE LA COMISIÓN DE MANTENIMIENTO MENSUAL DEL PRODUCTO PATAGONIA CONTRATADO DESDE EL PRIMER MES DE ACREDITACIÓN DE HABERES Y EN TANTO MANTENGA EN ESE PLAZO LA ACREDITACIÓN DE HABERES EN FORMA MENSUAL. TRANSCURRIDO DICHO PLAZO, EL CLIENTE DEBERÁ ABONAR LOS VALORES CORRESPONDIENTES A LAS COMISIONES VIGENTES DE SU PRODUCTO, LAS CUALES PODRÁN SER CONSULTADAS EN Banco Patagonia | Vos y lo que querés  Y EN CUALQUIERA DE NUESTRAS SUCURSALES.</p>
				<p>(3) CLUB PATAGONIA. PARA MÁS INFORMACIÓN CONSULTE EL REGLAMENTO DE CLUB PATAGONIA EN http://www.clubpatagonia.com.ar/ O ACERQUESE A CUALQUIERA DE NUESTRAS SUCURSALES.</p>
				<p>LOS ACCIONISTAS DE BANCO PATAGONIA S.A (CUIT 30-50000661-3, AV. DE MAYO 701, PISO 24, CABA), LIMITAN SU RESPONSABILIDAD A LA INTEGRACIÓN DE LAS ACCIONES SUSCRIPTAS. EN VIRTUD DE ELLO, NI LOS ACCIONISTAS MAYORITARIOS DE CAPITAL EXTRANJERO NI LOS ACCIONISTAS LOCALES O EXTRANJEROS, RESPONDEN EN EXCESO DE LA CITADA INTEGRACIÓN ACCIONARIA POR LAS OBLIGACIONES EMERGENTES DE LAS OPERACIONES CONCERTADAS POR LA ENTIDAD FINANCIERA. LEY 25.738.</p>
            </div>
        </div>
	</section>
    <!-- FIN PRE FOOTER -->	
	<div class="container-fluid footer-bar">
	<div class="row">
		<footer class="container">
			<div class="row">
				<div class="col-md-12">
					<p class="flnks"><a href="../../registro-nacional-base-datos.php">Registro Nacional de Base de Datos</a> <span>|</span>   <a href="../../codigo-practicas-bancarias.php">Código de Prácticas Bancarias</a> <span>|</span>   <a href="../../defensa-ley-consumidor.php">Defensa del Consumidor</a>
						<span>|</span>   <a href="https://www.argentina.gob.ar/produccion/defensadelconsumidor/formulario">Defensa de las y los consumidores. Para reclamos ingrese aquí</a><span>|</span> <br class="tbl"> <a href="../../persona-expuesta-politicamente.php">Persona Expuesta Políticamente</a> <span class="tbl">|</span> <br class="dsk">
						
					<a href="../../agencia-acceso-informacion-publica.php">Agencia de Acceso a la Información Pública</a> <span>|</span> <br class="tbl"> 
					<a href="../../cnv-advertencia-publico-inversor.php">CNV - Advertencia al Público Inversor</a> <span>|</span> <a href="../../docs/Idoneos.pdf" target="_blank"> Idóneos en Mercado de Capitales - CNV</a><span>|</span>   <a href="../../codigo-proteccion-inversor.php">Código de Protección al Inversor</a> <span>|</span>   <a href="../../clausulas-legales.php">Cláusulas Legales</a> <span>|</span> <a href="../../resolucion-022021.php">Resol. 02/21 Dir.Gral. Defensa del consumidor Córdoba</a></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<p class="redes">
                        <span>Seguinos en:</span>
                        <!-- -->
                        <a href="https://www.facebook.com/BancoPatagonia/" target="_blank"><img src="../../assets/images/layout/icon-facebook.svg" alt="Facebook"></a>
                        <a href="https://twitter.com/banco_patagonia" target="_blank"><img src="../../assets/images/layout/icon-twitter.svg" alt="Twitter"></a>
                        <a href="https://www.instagram.com/banco_patagonia/" target="_blank"><img src="../../assets/images/layout/icon-instagram.svg" alt="Instagram"></a>
                        <a href="https://www.youtube.com/user/bancopatagonia" target="_blank"><img src="../../assets/images/layout/icon-youtube.svg" alt="Youtube"></a>
                        <!-- -->
                        <!--
                        <a href="https://www.facebook.com/BancoPatagonia/" target="_blank"><i class="fa fa-facebook-square"></i></a>
                        <a href="https://twitter.com/banco_patagonia" target="_blank"><i class="fa fa-twitter"></i></a>
                        <a href="https://www.instagram.com/banco_patagonia/" target="_blank"><i class="fa fa-instagram"></i></a>
                        <a href="https://www.youtube.com/user/bancopatagonia" target="_blank"><i class="fa fa-youtube-play"></i></a>
                        -->
                    </p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					                    <!---->
				    <p class="flegal">BANCO PATAGONIA S.A. ES UNA SOCIEDAD ANÓNIMA CONSTITUIDA BAJO LAS LEYES DE LA REPÚBLICA ARGENTINA CUYOS ACCIONISTAS LIMITAN SU RESPONSABILIDAD A LA INTEGRACIÓN DE LAS ACCIONES SUSCRITAS DE ACUERDO A LA LEY 19.550. POR CONSIGUIENTE, Y EN CUMPLIMIENTO DE LA LEY 25.738, SE INFORMA QUE NI LOS ACCIONISTAS MAYORITARIOS DE CAPITAL EXTRANJERO NI LOS ACCIONISTAS LOCALES O EXTRANJEROS RESPONDEN, EN EXCESO DE LA CITADA INTEGRACIÓN ACCIONARIA, POR LAS OBLIGACIONES EMERGENTES DE LAS OPERACIONES CONCERTADAS POR LA ENTIDAD FINANCIERA.</p>
                    <p class="flegal" style="font-size:10px;">Banco Patagonia S.A. - Agente de Liquidacion y Compensacion y Agente de Negociacion Integral, inscripto en CNV bajo el N° 66</p>
					<p class="flegal">© 2025 Banco Patagonia . Todos los derechos reservados. Prohibida la duplicación , distribución o almacenamiento en cualquier medio.</p>
				</div>
			</div>
		</footer>
	</div>
</div>
<div class="tbl mbl placeholder-shortlinks">
	<div class="container shortlinks">
		<div class="row">
            <!--<php if ($home_personas == false) { ?>
                <div class="col-sm-3 col-xs-3">
                    <a href="#"><span class="icon icon-contacto"></span></a>
                </div>
            <php } ?>-->
            			<div class="col-sm-3 col-xs-3">
				<a href="http://sucursalesycajeros.bancopatagonia.com.ar/sucursales.html" target="_blank"><span class="icon icon-sucursales"></span>Sucursales y Cajeros</a>
			</div>
			<div class="col-sm-3 col-xs-3">
				<a href="../../preguntas-frecuentes/index.php"><span class="icon icon-contacto"></span>Ayuda</a>
			</div>
			<div class="col-sm-3 col-xs-3 last">
				<a href="../../empresas/patagonia-ebank-empresas-mbl.php"><span class="icon icon-ebank"></span>Patagonia e-Bank</a>
			</div>
		</div>
	</div>
</div>	<script src="../../assets/js/jquery-3.5.1.min.js"></script>
<script src="../../assets/bootstrap/js/bootstrap.min.js"></script>
<script src="../../assets/js/slick/slick.min.js"></script>
<script src="../../assets/js/fancybox/jquery.fancybox.min.js"></script>
<script src="../../assets/js/mtabs/jquery.bootstrap-responsive-tabs.min.js"></script>
<script src="../../assets/js/funciones.js"></script>

<!-- Global site tag (gtag.js) - Google Analytics (original) -->
<!--
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-32588129-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-32588129-1');
</script>
-->

<!-- Google Analytics (version anterior / eventos ok)  -->
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');
  ga('create', 'UA-32588129-1', 'auto');
  ga('send', 'pageview');
</script>

<!-- GA4 - Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-C6LG1PT98X"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-C6LG1PT98X');
</script>
</body>
</html>