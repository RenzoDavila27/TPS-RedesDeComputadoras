<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
	<meta http-equiv="Pragma" content="no-cache">
	<meta http-equiv="Expires" content="0">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Temporada Patagonia | Banco Patagonia</title>
	<meta name="description" content="Conocé todos los beneficios.">
	<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-NL73B44');</script>
<!-- End Google Tag Manager -->

<link rel="shortcut icon" href="../../favicon.ico" type="image/x-icon"/>
<link href="../../assets/fonts/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="../../assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="../../assets/js/mtabs/bootstrap-responsive-tabs.css" rel="stylesheet" type="text/css">
<link href="../../assets/js/slick/slick.css" rel="stylesheet" type="text/css">
<link href="../../assets/js/fancybox/jquery.fancybox.min.css" rel="stylesheet" type="text/css">
<link href="../../assets/css/styles.css" rel="stylesheet" type="text/css">
<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->    <!-- SLIDES RESPONSIVE -->
    <style>
        /* DSK */
        #head-temporada-verano-2025 { background-image: url(images/verano/2025/head-temporada-verano-2025-dsk.jpg); background-image: -webkit-image-set ( url("images/verano/2025/head-temporada-verano-2025-dsk.jpg") 1x, url("images/verano/2025/head-temporada-verano-2025-dsk@2x.jpg") 2x ); }

        @media screen and (max-width: 1200px) {
            /* TBT */
            #head-temporada-verano-2025 { background-image: url(images/verano/2025/head-temporada-verano-2025-tbl.jpg); background-size: auto !important; background-image: -webkit-image-set ( url("images/verano/2025/head-temporada-verano-2025-tbl.jpg") 1x, url("images/verano/2025/head-temporada-verano-2025-tbl@2x.jpg") 2x ); }
        }
        @media screen and (max-width: 560px) {
            /* MBL */
            #head-temporada-verano-2025 { background-image: url(images/verano/2025/head-temporada-verano-2025-mbl.jpg); background-image: -webkit-image-set ( url("images/verano/2025/head-temporada-verano-2025-mbl.jpg") 1x, url("images/verano/2025/head-temporada-verano-2025-mbl@2x.jpg") 2x ); }
        }
    </style>
    <!-- -->
    <style>
		h1 { line-height: 1.2em; }
		/**/
		.bnf-box { margin-top: 15px; }
        .bnf-clasica .bnf-card, .bnf-plus .bnf-card, .bnf-singular .bnf-card { color: #FFF !important;}
		.bnf-box .bnf-card i.bnf-misc { display: none; }/* en 3 segmentos */
		/*.bnf-box p { letter-spacing: -0.5px; }*/
		.bnf-box .bnf-card { border-radius: 0; background-color: transparent; background-repeat: no-repeat; }
		.bnf-box .bnf-card big span.tv25-cuotas { font-size: 26px; }
		/**/
		.bnf-logo-segm { padding: 8px 18px; box-sizing: content-box; border-radius: 20px; border: 1px solid; position: absolute; left: -20px; top: -20px; background: #fff;}
		/**/
		.bnf-generico { margin-top: 0; }
		.bnf-generico .bnf-card { background-image: url(images/verano/2025/tv25-cont-generico.svg); }
		.bnf-generico .bnf-card-data { color: #002d5a !important; }
		.bor-generico { border-color: #002d5a !important; }
		.bnf-clasica .bnf-card { background-image: url(images/verano/2025/tv25-cont-clasica.svg); }
		.bor-clasica { border-color: #B8DE1A !important; }
        .bnf-plus .bnf-card { background-image: url(images/verano/2025/tv25-cont-plus.svg); }
		.bor-plus { border-color: #06D2BE !important; }
        .bnf-singular .bnf-card { background-image: url(images/verano/2025/tv25-cont-singular.svg); }
        .bor-singular { border-color: #001641 !important; }
		.bnf-on .bnf-card { background-image: url(images/verano/2025/tv25-cont-on.svg); }
		.bnf-on .bnf-card-data { color: #7763F9 !important; }
        .bor-on { border-color: #7763F9 !important; padding-left: 22px; padding-right: 22px; }
		/*.bnf-club .bnf-card { background-image: url(images/verano/2025/tv25-cont-club.svg); }*/
        /*.bor-club { border-color: #f89c33 !important; }*/
		/**/
		#tv25-shows img { border-radius: 30px; }
		/**/
		.bnf-box .bnf-card i.bnf-icon { top: 44px; }
		.bnf-icon-cart { background-image: url(../../assets/images/layout/icons/verano/2025/icon-cart.svg); left: 26px; width: 36px; height: 36px; }
		.bnf-icon-shop { background-image: url(../../assets/images/layout/icons/verano/2025/icon-shop.svg); left: 30px; width: 30px; height: 38px; }
		.bnf-icon-food { background-image: url(../../assets/images/layout/icons/verano/2025/icon-food.svg); left: 28px; width: 37px; height: 35px; }
		.bnf-icon-tent-parador { background-image: url(../../assets/images/layout/icons/verano/2025/icon-umbrella.svg); left: 28px; width: 36px; height: 35px; }
		
		@media screen and (max-width: 1200px) {
			.bnf-box { display: block; }
			.bnf-box .bnf-card { margin-bottom: 10px; }
			.bnf-box .bnf-card-data { margin-bottom: 30px; margin-left: 0; }
			.bnf-box .bnf-card-data { padding-top: 0 !important; }
        }
		
		@media screen and (max-width: 767px) {
			/*.bnf-generico { margin-top: 0; }*/
			/**/
			.bnf-box .bnf-card-data { margin-bottom: 10px !important; }
        }
		
    </style>
    <!-- -->
</head>

<body>
	<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NL73B44"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

<div class="placeholder-bar">
	<div class="container-fluid header-bar">
		<div class="row">
			<header class="container">
				<div class="row">
					<div class="col-md-3 col-dsk-6 col-sm-6">
						<span class="c-hamburger c-hamburger--htx">
							<span>toggle menu</span>
						</span>
                        <!-- -->
                        <!--<img style="position: absolute; width: 42px; top: 20px; right: 40px;" class="dsk" src="<php echo $path ?>assets/images/layout/icon-verano-2022.svg">-->
                        <!-- -->
						<h1>
                            <!--<img style="position: absolute; width: 32px; top: 12px; left: 102px;" class="dsk" src="<php echo $path ?>assets/images/layout/icon-navidad-2021.svg">-->
                            <a href="../index.php" class="main-logo">Banco Patagonia</a>
                        </h1>
					</div>
					<div class="col-md-9 col-dsk-6 col-sm-6">
						<div class="general-links">
							<ul class="list-unstyled">
                                <li id="btn-hacete-cliente"><a href="https://tunuevacuenta.bancopatagonia.com.ar/?utm_source=sitiowebbp&utm_medium=sitiowebbp%20banner%20home&utm_campaign=onboarding_sitiowebp_bannerhome" target="_blank"><strong>Hacete cliente <i class="fa fa-angle-right"></i></strong></a></li>								<li><a href="../../preguntas-frecuentes/index.php" class="">Ayuda</a></li>
								<!--<li><a href="<php echo $folder_canales ?>index.php" class="<php echo $canales ?>">Canales de atención</a></li>-->
								<!--<li><a href="http://sucursalesycajeros.bancopatagonia.com.ar/sucursales.html" target="_blank">Sucursales y cajeros</a></li>-->
								<!--<li><a href="<php echo $folder_contactenos ?>index.php" class="<php echo $contactenos ?>">Contactanos</a></li>-->
                                <!--<li><a href="<php echo $path ?>ayuda/index.php" class="<php echo $ayuda ?>">Ayuda</a></li>-->
							</ul>
						</div>
						<div class="top-links">
							<ul class="list-unstyled">
								<li><a href="../index.php" class="active">PERSONAS</a></li>
								<li><a href="../../nyps/index.php" class="">PROFESIONALES Y COMERCIOS</a></li>
								<li><a href="../../pyme/index.php" class="">PYME</a></li>
								<li><a href="../../agro/index.php" class="">AGRO</a></li>
								<li><a href="../../empresas/index.php" class="">EMPRESAS</a></li>
								<li><a href="../../sector-publico/index.php" class="">SECTOR PÚBLICO</a></li>
								<li><a href="../../institucional/index.php" class="">INSTITUCIONAL</a></li>
							</ul>
							<div class="ebank">
                            <!-- antes href: <php echo $folder_empresas ?><php echo $url_ebank ?>-->
															<a href="https://ebankpersonas.bancopatagonia.com.ar/eBanking/usuarios/login.htm" class="patagonia-ebank" target="_blank">Patagonia e-Bank</a>
														</div>
						</div>
					</div>
				</div>
			</header>
		</div>
	</div>
</div>

<div class="container-fluid nav-bar">
	<div class="row">
		<nav class="container">
			<div class="row">
				<!--<div class="col-md-9 col-md-offset-3">-->
                <div class="col-md-10 col-md-offset-3"><!-- ajuste agro -->
					<ul class="list-unstyled sub-navbar">
						
												<!-- PERSONAS -->
                        <li class="nav-item"><a href="#" class="nav-lnk ">PATAGONIA CLÁSICA</a>
							<ul class="list-unstyled submenu">
                                <li><a href="../../personas/patagonia-clasica/patagonia-ahorro/productos.php">Patagonia Ahorro</a></li>
                                <li><a href="../../personas/patagonia-clasica/paquete/productos.php">Patagonia Clásica</a></li>
                                <!--<li><a href="<php echo $path ?>personas/patagonia-clasica/mas/productos.php">Patagonia Clásica Más</a></li>-->
                                <li><a href="../../personas/patagonia-clasica/premium/productos.php">Patagonia Clásica Premium</a></li>
                                <li><a href="../../personas/patagonia-clasica/patagonia-sueldo/productos.php">Patagonia Sueldo</a></li>
							</ul>
						</li>
						<li class="nav-item"><a href="#" class="nav-lnk ">PATAGONIA PLUS</a>
							<ul class="list-unstyled submenu">
                                <li><a href="../../personas/patagonia-plus/productos.php">Patagonia Plus</a></li>
                                <li><a href="../../personas/patagonia-plus/premium/productos.php">Patagonia Plus Premium</a></li>
							</ul>						
						</li>
						<li class="nav-item"><a href="#" class="nav-lnk ">PATAGONIA SINGULAR</a>
							<ul class="list-unstyled submenu">
								<li><a href="../../personas/patagonia-singular/paquete/propuesta.php">Patagonia Singular</a></li>
                                <li><a href="../../personas/patagonia-singular/beneficios-exclusivos.php">Beneficios Exclusivos</a></li>
                                <!--<li><a href="<php echo $path ?>personas/patagonia-singular/atencion-exclusiva/index.php">Atención Exclusiva</a></li>-->
                                <!--<li><a href="<php echo $path ?>personas/patagonia-singular/eventos-y-novedades/index.php">Eventos y Novedades</a></li>-->
							</ul>
						</li>
						<!--<li class="nav-item"><a href="<php echo $path ?>patagoniaon/index.php" target="_blank" class="nav-lnk">PATAGONIA ON</a></li>-->
						<li class="nav-item"><a href="#" class="nav-lnk ">PATAGONIA ON</a>
							<ul class="list-unstyled submenu">
                                <li><a href="../../patagoniaon/index.php" target="_blank">Patagonia ON</a></li>
								<li><a href="../../personas/productos-y-servicios/patagonia-universitaria.php">Patagonia ON Universitaria</a></li>
							</ul>
						</li>
						<li class="nav-item"><a href="#" class="nav-lnk ">PRODUCTOS Y SERVICIOS</a>
							<ul class="list-unstyled submenu">
                                <li><a href="../../personas/apple-pay.php">Apple Pay</a></li>
                                <li><a href="../../personas/productos-y-servicios/caja-de-seguridad.php">Caja de Seguridad</a></li>
                                <li><a href="../../personas/productos-y-servicios/comercio-exterior/productos.php">Comercio exterior</a></li>
								<!--<li><a href="<php echo $path ?>personas/productos-y-servicios/beneficios-wapa.php">Comercios WAPA</a></li>-->
								<li><a href="../../personas/cuotifica-al-toque.php">Cuotificá al Toque</a></li>
								<li><a href="../../personas/google-pay.php">Google Pay</a></li>
                                <li><a href="../../personas/productos-y-servicios/inversiones.php">Inversiones</a></li>
                                <li><a href="../../personas/jubilados/index.php">Jubilados</a></li>
                                <li><a href="../../personas/productos-y-servicios/patagonia-para-menores.php">Patagonia para Menores</a></li>
                                <!--<li><a href="<php echo $path ?>personas/productos-y-servicios/patagonia-universitaria.php">Patagonia Universitaria</a></li>-->
                                <li><a href="../../personas/productos-y-servicios/prestamos.php">Prestamos</a></li>
                                <li><a href="../../personas/seguros/index.php">Seguros</a></li>
                                <li><a href="../../personas/productos-y-servicios/tarjetas-de-credito/visa.php">Tarjetas de crédito</a></li>
								<li><a href="../../personas/productos-y-servicios/tarjetas-de-debito/patagonia-24.php">Tarjetas de débito</a></li>
							</ul>
						</li>
						<!-- FIN PERSONAS -->
						                        
                                                
                                                
                        						
												
												
						
											</ul>
				</div>
			</div>
		</nav>
	</div>
</div>

<div class="mobile-nav-bar">
	<ul class="list-unstyled">
        
        <!-- PERSONAS -->
		<li class="nav-main-item"><a href="#" class="has-sub-items active">PERSONAS <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../index.php" class="active">HOME</a></li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA CLÁSICA</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../personas/patagonia-clasica/patagonia-ahorro/productos.php">Patagonia Ahorro</a></li>
                        <li><a href="../../personas/patagonia-clasica/paquete/productos.php">Patagonia Clásica</a></li>
                        <!--<li><a href="<php echo $path ?>personas/patagonia-clasica/mas/productos.php">Patagonia Clásica Más</a></li>-->
                        <li><a href="../../personas/patagonia-clasica/premium/productos.php">Patagonia Clásica Premium</a></li>
                        <li><a href="../../personas/patagonia-clasica/patagonia-sueldo/productos.php">Patagonia Sueldo</a></li>
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA PLUS</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../personas/patagonia-plus/productos.php">Patagonia Plus</a></li>
                        <li><a href="../../personas/patagonia-plus/premium/productos.php">Patagonia Plus Premium</a></li>
                    </ul>						
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA SINGULAR</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../personas/patagonia-singular/paquete/propuesta.php">Patagonia Singular</a></li>
                        <li><a href="../../personas/patagonia-singular/beneficios-exclusivos.php">Beneficios Exclusivos</a></li>
                        <!--<li><a href="<php echo $path ?>personas/patagonia-singular/atencion-exclusiva/index.php">Atención Exclusiva</a></li>-->
                        <!--<li><a href="<php echo $path ?>personas/patagonia-singular/eventos-y-novedades/index.php">Eventos y Novedades</a></li>-->
                    </ul>
                </li>
				<!--<li class="nav-sub-item"><a href="<php echo $path ?>patagoniaon/index.php" target="_blank">PATAGONIA ON</a></li>-->
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA ON</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../patagoniaon/index.php" target="_blank">Patagonia ON</a></li>
						<li><a href="../../personas/productos-y-servicios/patagonia-universitaria.php">Patagonia ON Universitaria</a></li>
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PRODUCTOS Y SERVICIOS</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../personas/apple-pay.php">Apple Pay</a></li>
                        <li><a href="../../personas/productos-y-servicios/caja-de-seguridad.php">Caja de Seguridad</a></li>
                        <li><a href="../../personas/productos-y-servicios/comercio-exterior/productos.php">Comercio exterior</a></li>
						<!--<li><a href="<php echo $path ?>personas/productos-y-servicios/beneficios-wapa.php">Comercios WAPA</a></li>-->
						<li><a href="../../personas/cuotifica-al-toque.php">Cuotificá al Toque</a></li>
						<li><a href="../../personas/google-pay.php">Google Pay</a></li>
                        <li><a href="../../personas/productos-y-servicios/inversiones.php">Inversiones</a></li>
                        <li><a href="../../personas/jubilados/index.php">Jubilados</a></li>
                        <li><a href="../../personas/productos-y-servicios/patagonia-para-menores.php">Patagonia para Menores</a></li>
                        <!--<li><a href="<php echo $path ?>personas/productos-y-servicios/patagonia-universitaria.php">Patagonia Universitaria</a></li>-->
                        <li><a href="../../personas/productos-y-servicios/prestamos.php">Prestamos</a></li>
                        <li><a href="../../personas/seguros/index.php">Seguros</a></li>
                        <li><a href="../../personas/productos-y-servicios/tarjetas-de-credito/visa.php">Tarjetas de crédito</a></li>
                        <li><a href="../../personas/productos-y-servicios/tarjetas-de-debito/patagonia-24.php">Tarjetas de débito</a></li>
                    </ul>
                </li>
			</ul>
		</li>
        <!-- FIN PERSONAS -->
        
        <!-- NYPS -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">PROFESIONALES Y COMERCIOS <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../nyps/index.php" class="">HOME</a></li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA CLÁSICA</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../nyps/patagonia-clasica/premium/productos.php">Patagonia Clásica Premium</a></li>
                        <li><a href="../../nyps/patagonia-clasica/patagonia-emprendimiento/productos.php">Patagonia Emprendimiento</a></li>
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA PLUS</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../nyps/patagonia-plus/productos.php">Patagonia Plus</a></li>
                        <li><a href="../../nyps/patagonia-plus/premium/productos.php">Patagonia Plus Premium</a></li>
                    </ul>						
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA SINGULAR</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../nyps/patagonia-singular/paquete/propuesta.php">Patagonia Singular</a></li>
                        <li><a href="../../nyps/patagonia-singular/beneficios-exclusivos.php">Beneficios Exclusivos</a></li>
                        <!--<li><a href="<php echo $path ?>nyps/patagonia-singular/eventos-y-novedades/index.php">Eventos y Novedades</a></li>-->
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PRODUCTOS Y SERVICIOS</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../nyps/productos-y-servicios/tarjetas-de-debito/patagonia-24.php">Tarjetas de débito</a></li>
                        <li><a href="../../nyps/productos-y-servicios/tarjetas-de-credito/visa.php">Tarjetas de crédito</a></li>
                        <li><a href="../../nyps/productos-y-servicios/prestamos.php">Prestamos</a></li>
                        <li><a href="../../nyps/seguros/index.php">Seguros</a></li>
                        <li><a href="../../nyps/productos-y-servicios/inversiones.php">Inversiones</a></li>
                        <li><a href="../../nyps/productos-y-servicios/comercio-exterior/productos.php">Comercio exterior</a></li>
                        <li><a href="../../nyps/productos-y-servicios/caja-de-seguridad.php">Caja de Seguridad</a></li>
                        <li><a href="../../nyps/productos-y-servicios/factura-electronica.php">Factura electrónica</a></li>
                        <li><a href="../../nyps/productos-y-servicios/pagos-afip.php">Pagos AFIP</a></li>
                        <!--<li><a href="<php echo $path ?>nyps/productos-y-servicios/soluciones-para-tu-empresa.php">Soluciones para tu empresa</a></li>-->
                        <!--<li><a href="<php echo $path ?>nyps/productos-y-servicios/comercios-patagonia.php">Comercios Patagonia</a></li>-->
						<li><a href="../../nyps/productos-y-servicios/wapa.php">WAPA</a></li>
                    </ul>
                </li>
			</ul>		
		</li>
        <!-- FIN NYPS -->
        
        <!-- PYME -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">PYME <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../pyme/index.php" class="">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">CUENTAS</a>
					<ul class="list-unstyled submenu">
                        <li><a href="../../pyme/cuentas/pequenas-empresas.php">Pyme Pequeñas Empresas</a></li>
				        <li><a href="../../pyme/cuentas/medianas-empresas.php">Pyme Medianas Empresas</a></li>
                        <!--
						<li><a href="../../pyme/cuentas/patagonia-empresario.php">Patagonia Empresario</a></li>
						<li><a href="../../pyme/cuentas/patagonia-empresario-premier.php">Patagonia Empresario Premier</a></li>
						<li><a href="../../pyme/cuentas/patagonia-empresa.php">Patagonia Empresa</a></li>
                        -->
                        <!--<li><a href="../../pyme/cuentas/patagonia-comercio.php">Patagonia Comercio</a></li>-->
                        <li><a href="../../pyme/cuentas/patagonia-consorcio.php">Patagonia Consorcio</a></li>
						<li><a href="../../pyme/cuentas/cuenta-corriente.php">Cuenta Corriente</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA SUELDO</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../pyme/patagonia-sueldo/servicios.php">Servicios</a></li>
						<li><a href="../../pyme/patagonia-sueldo/preguntas-frecuentes.php">Preguntas Frecuentes</a></li>
						<li><a href="../../pyme/patagonia-sueldo/guia-implementacion.php">Guía de Implementación</a></li>
					</ul>
				</li>						
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">COMERCIO EXTERIOR</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../pyme/comercio-exterior/solicitud-electronica.php">Solicitud Electrónica</a></li>
						<li><a href="../../pyme/comercio-exterior/productos.php">Productos</a></li>
						<li><a href="../../pyme/comercio-exterior/otros-servicios.php">Servicios</a></li>
						<!--<li><a href="<php echo $folder_pymeCexterior ?>financiaciones.php">Financiaciones</a></li>-->
                        <li><a href="../../pyme/comercio-exterior/herramientas-para-exportar.php">Herramientas para Exportar</a></li>
						<li><a href="../../pyme/comercio-exterior/marco-regulatorio/normas-y-regulaciones.php">Marco Regulatorio</a></li>
					</ul>
				</li>						
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">FINANCIACIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../pyme/financiacion/patagonia-leasing.php">Patagonia Leasing</a></li>
						<li><a href="../../pyme/financiacion/mercado-capitales.php">Mercado de Capitales</a></li>
						<li><a href="../../pyme/financiacion/alternativas-de-financiacion.php">Alternativas de Financiación</a></li>
					</ul>
				</li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">SEGUROS</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../pyme/seguros/protege-tus-bienes/integral-comercio.php">Protegé tus Bienes</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">INVERSIONES</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../pyme/inversiones/plazo-fijo.php">Plazo Fijo</a></li>
						<li><a href="../../pyme/inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
						<li><a href="../../pyme/inversiones/fidecomisos-financieros.php">Fidecomisos Financieros</a></li>
					</ul>
				</li>						
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">SERVICIOS</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../pyme/servicios/recaudaciones.php">Recaudaciones</a></li>
						<li><a href="../../pyme/servicios/pagos.php">Pagos</a></li>
						<li><a href="../../pyme/servicios/tarjetas-comerciales.php">Tarjetas Comerciales</a></li>
						<li><a href="../../pyme/servicios/comercios-patagonia.php">Comercios Patagonia</a></li>
                        <li><a href="../../pyme/servicios/pago-de-servicios.php">Pago de Servicios</a></li>
						<li><a href="../../pyme/servicios/interbanking.php">Interbanking</a></li>
						<li><a href="../../pyme/servicios/interfacturas.php">Interfacturas</a></li>
						<li><a href="../../pyme/servicios/pagos-afip.php">Pagos AFIP</a></li>
						<li><a href="../../pyme/servicios/wapa.php">WAPA</a></li>
					</ul>
				</li>
			</ul>		
		</li>
        <!-- FIN PYME -->
        
        <!-- AGRO -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">AGRO <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../agro/index.php" class="">HOME</a></li>
                <!-- -->
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">OFERTA AGRO</a>
					<ul class="list-unstyled submenu">
                    	<!--<li><a href="<php echo $folder_agroFinanciacion ?>insumos.php">Insumos en USD</a></li>-->
                        <li><a href="../../agro/convenios/acuerdos-y-beneficios.php">Acuerdos y convenios</a></li>
						<li><a href="../../agro/financiacion/maquinaria-agricola.php">Financiación Maquinaria Agrícola</a></li>
						<li><a href="../../agro/seguros/campo.php">Seguros para tu campo</a></li>
					</ul>
				</li>
                <!-- -->
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">TARJETA PATAGONIA AGRO</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../agro/tarjeta-patagonia-agro/para-usuarios.php">Para Usuarios</a></li>
						<li><a href="../../agro/tarjeta-patagonia-agro/para-comercios.php">Para Comercios</a></li>
						<li><a href="../../agro/tarjeta-patagonia-agro/acuerdo-tasa-0.php">Tarjetas Agro Convenios Preferenciales</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="../../agro/cuenta-agro/cuenta-agro.php" class="">CUENTA AGRO</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">FINANCIACIÓN</a>
					<ul class="list-unstyled submenu">
                        <li><a href="../../agro/insumos/index.php">Insumos</a></li>
                        <li><a href="../../agro/financiacion/maquinaria-agricola.php">Maquinarias</a></li>
                        <li><a href="../../empresas/financiacion/convenios-de-financiacion.php">Camiones</a></li>
						<!--<li><a href="<php echo $folder_agroFinanciacion ?>capital-de-trabajo.php">Capital de Trabajo</a></li>-->
						<!--<li><a href="<php echo $folder_agroFinanciacion ?>proyectos-de-inversion.php">Proyectos de Inversión</a></li>-->
						<!--<li><a href="<php echo $folder_agroFinanciacion ?>creditos-para-hacienda.php">Créditos para Hacienda</a></li>-->
						<!--<li><a href="<php echo $folder_agroFinanciacion ?>leasing-y-prendarios.php">Leasing y Prendarios</a></li>-->
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">INVERSIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../agro/inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
						<li><a href="../../agro/inversiones/fidecomisos-financieros.php">Fidecomisos Financieros</a></li>
						<li><a href="../../agro/inversiones/plazos-fijos.php">Plazos Fijos</a></li>
					</ul>
				</li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">COMERCIO EXTERIOR</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../agro/comercio-exterior/solicitud-electronica.php">Solicitud Electrónica</a></li>
                        <li><a href="../../agro/comercio-exterior/productos.php">Productos</a></li>
                        <li><a href="../../agro/comercio-exterior/otros-servicios.php">Servicios</a></li>
                        <li><a href="../../agro/comercio-exterior/herramientas-para-exportar.php">Herramientas para Exportar</a></li>
                        <li><a href="../../agro/comercio-exterior/marco-regulatorio/normas-y-regulaciones.php">Marco Regulatorio</a></li>
                    </ul>
                </li>
                <!--
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">SERVICIOS</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../agro/servicios/centro-atencion-empresas.php">Centro de Atención para Empresas</a></li>
					</ul>
				</li>
                -->
                <!-- -->
                <li class="nav-sub-item"><a href="../../agro/seguros/campo.php" class="">SEGUROS</a></li>
                <!-- -->
			</ul>
		</li>
        <!-- FIN AGRO -->
        
        <!-- EMPRESAS -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">EMPRESAS <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../empresas/index.php" class="">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA SUELDO</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../empresas/patagonia-sueldo/servicios.php">Servicios</a></li>
						<li><a href="../../empresas/patagonia-sueldo/preguntas-frecuentes.php">Preguntas Frecuentes</a></li>
						<li><a href="../../empresas/patagonia-sueldo/guia-implementacion.php">Guía de Implementación</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">COMERCIO EXTERIOR</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../empresas/comercio-exterior/solicitud-electronica.php">Solicitud Electrónica</a></li>
						<li><a href="../../empresas/comercio-exterior/productos.php">Productos</a></li>
						<li><a href="../../empresas/comercio-exterior/otros-servicios.php">Servicios</a></li>
						<!--<li><a href="<php echo $folder_Cexterior ?>financiaciones.php">Financiaciones</a></li>-->
                        <li><a href="../../empresas/comercio-exterior/herramientas-para-exportar.php">Herramientas para Exportar</a></li>
						<li><a href="../../empresas/comercio-exterior/marco-regulatorio/normas-y-regulaciones.php">Marco Regulatorio</a></li>
					</ul>
				</li>
                <!-- -->
				<!--<li class="nav-sub-item"><a href="index.php" class="">COMUNIDADES DE NEGOCIOS</a></li>-->
                <!-- -->
				<li class="nav-sub-item"><a href="../../empresas/comercios-patagonia/index.php" class="nav-lnk ">COMERCIOS PATAGONIA</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">FINANCIACIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../empresas/financiacion/patagonia-leasing.php">Patagonia Leasing</a></li>
						<li><a href="../../empresas/financiacion/mercado-capitales.php">Mercado Capitales</a></li>
						<li><a href="../../empresas/financiacion/alternativas-de-financiacion.php">Alternativas de Financiación</a></li>
                        <li><a href="../../empresas/financiacion/convenios-de-financiacion.php">Convenios de Financiación</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">INVERSIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../empresas/inversiones/plazos-fijos.php">Plazos Fijos</a></li>
						<li><a href="../../empresas/inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
						<li><a href="../../empresas/inversiones/compra-venta-titulos-acciones.php">Compra - Venta de Títulos y Acciones</a></li>
						<li><a href="../../empresas/inversiones/custodia-de-titulos.php">Custodia de Títulos</a></li>
						<li><a href="../../empresas/inversiones/fidecomisos-financieros.php">Fidecomisos Financieros</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">SERVICIOS</a>
					<ul class="list-unstyled submenu">
                        <li><a href="../../empresas/patagonia-movil-empresas.php">Patagonia Móvil Empresas</a></li>
						<li><a href="../../empresas/servicios/pagos.php">Pagos</a></li>
						<li><a href="../../empresas/servicios/recaudaciones.php">Recuadaciones</a></li>
						<li><a href="../../empresas/servicios/pago-de-servicios.php">Pago de Servicios</a></li>
						<li><a href="../../empresas/servicios/interbanking.php">Interbanking</a></li>
						<li><a href="../../empresas/servicios/interfacturas.php">Interfacturas</a></li>
						<li><a href="../../empresas/servicios/tarjetas-comerciales.php">Tarjetas Comerciales</a></li>
                        <!-- -->
						<!--<li><a href="../../empresas/servicios/comercios-patagonia.php">Comercios Patagonia</a></li>-->
                        <!-- -->
                        <li><a href="../../empresas/servicios/centro-atencion-empresas.php">Centro de Atención para Empresas</a></li>
					</ul>
				</li>
			</ul>
		</li>
        <!-- FIN EMPRESAS -->
        
        <!-- SECTOR PÚBLICO -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">SECTOR PÚBLICO <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../sector-publico/index.php" class="">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">INVERSIONES</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../sector-publico/inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
						<li><a href="../../sector-publico/inversiones/plazo-fijo.php">Plazo Fijo</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">SERVICIOS</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../sector-publico/servicios/servicio-de-recaudacion.php">Servicio de Recaudación</a></li>
						<li><a href="../../sector-publico/servicios/servicio-de-pagos.php">Servicio de Pagos</a></li>
						<li><a href="../../sector-publico/servicios/servicios-para-personal.php">Servicios para el Personal</a></li>
						<li><a href="../../sector-publico/servicios/financiacion.php">Financiación</a></li>
						<li><a href="../../sector-publico/servicios/otros-servicios.php">Servicios</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">PROGRAMA UNIVERSIDADES</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../sector-publico/programa-universidades/relacion-institucional.php">Relación Institucional</a></li>
						<li><a href="../../sector-publico/programa-universidades/docentes-yno-docentes.php">Docentes y No Docentes</a></li>
						<li><a href="../../sector-publico/programa-universidades/alumnos.php">Alumnos</a></li>
						<li><a href="../../sector-publico/programa-universidades/graduados.php">Graduados</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">BENEFICIOS RÍO NEGRO</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../sector-publico/rio-negro/presencia.php">Presencia en Río Negro</a></li>
                        <li><a href="../../sector-publico/rio-negro/propuesta-valor.php">Propuesta de valor exclusiva</a></li>
					</ul>
				</li>
			</ul>
		</li>
        <!-- FIN SECTOR PUBLICO -->
        
        <!-- INSTITUCIONAL -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">INSTITUCIONAL <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../institucional/index.php" class="">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">BANCO PATAGONIA</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../institucional/banco-patagonia/historia.php">Historia</a></li>
						<li><a href="../../institucional/banco-patagonia/mercado-de-capitales.php">Mercado de Capitales</a></li>
						<li><a href="../../institucional/banco-patagonia/patagonia-inversora.php">Patagonia Inversora</a></li>
						<li><a href="../../institucional/banco-patagonia/patagonia-valores-sa.php">Patagonia Valores S.A</a></li>
						<li><a href="https://bp.bancopatagonia.com.ar/relacion-con-inversores/es/institucional" target="_blank">Relación con Inversores</a></li>
						<li><a href="../../institucional/banco-patagonia/desarrollo-humano.php">Desarrollo Humano</a></li>
						<li><a href="../../institucional/banco-patagonia/sustentabilidad.php">Sustentabilidad</a></li>
						<li><a href="../../institucional/banco-patagonia/politicas-aml-cft.php">Póliticas AML/CFT</a></li>
						<li><a href="../../institucional/banco-patagonia/disciplina-del-mercado.php">Disciplina de Mercado</a></li>
                        <li><a href="../../institucional/banco-patagonia/asistencia-a-vinculados.php">Asistencia a vinculados</a></li>
                        <li><a href="../../institucional/banco-patagonia/etica-e-integridad.php">Ética e Integridad</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">ORGANIZACIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../institucional/organizacion/accionistas.php">Accionistas</a></li>
						<li><a href="../../institucional/organizacion/autoridades.php">Autoridades</a></li>
                        <li><a href="../../institucional/organizacion/comites.php">Comités</a></li>
						<li><a href="../../institucional/organizacion/sector-financiero.php">Sector Financiero</a></li>
					</ul>
				</li>
			</ul>
		</li>
        <!-- FIN INSTITUCIONAL -->
        
        <li class="nav-main-item"><a href="https://tunuevacuenta.bancopatagonia.com.ar/?utm_source=sitiowebbp&utm_medium=sitiowebbp%20banner%20home&utm_campaign=onboarding_sitiowebp_bannerhome" target="_blank" style="text-transform: none;">Hacete cliente</a></li>		<li class="nav-main-item"><a href="../../preguntas-frecuentes/index.php" class="" style="text-transform: none;">Ayuda</a></li>
		<!--<li class="nav-main-item"><a href="<php echo $folder_canales ?>index.php" class="<php echo $canales ?>" style="text-transform: none;">Canales de Atención</a></li>-->
		<!--<li class="nav-main-item"><a href="http://sucursalesycajeros.bancopatagonia.com.ar/sucursales.html" target="_blank" style="text-transform: none;">Sucursales y Cajeros</a></li>-->
		<!--<li class="nav-main-item"><a href="<php echo $folder_contactenos ?>index.php" class="<php echo $contactenos ?>" style="text-transform: none;">Contactanos</a></li>-->
        <!--<li class="nav-main-item"><a href="<php echo $path ?>ayuda/index.php" class="<php echo $ayuda ?>" style="text-transform: none;">Ayuda</a></li>-->
	</ul>
</div>	<section class="sec-head" title="Vos el verano que querés, nosotros los beneficios">
        <div class="sec-pic-head" id="head-temporada-verano-2025">
        </div>
	</section>
	<section class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
				<ol class="breadcrumb">
					<li><a href="../index.php">Personas</a></li>
                    <li>Tarjetas</li>
					<li class="active">Beneficios Verano</li>
				</ol>
			</div>
		</div>
	</section>
	<section class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
				<div class="text-data">
                    <h1>Disfrutá al máximo de tu verano con beneficios exclusivos, propuestas únicas y experiencias diseñadas especialmente para vos.</h1>
                </div>
            </div>
        </div>
    </section>
	<section class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
				<ul class="nav nav-tabs tabs-x2">
					<li class="active"><a href="#tab1" data-toggle="tab">MAR DEL PLATA</a></li>
					<li><a href="#tab2" data-toggle="tab">LAS GRUTAS</a></li>
				</ul>
				<div class="tab-content">
					<div class="tab-pane fade in active" id="tab1">
						
						<div class="tab-data">
							<!-- -->
							<div>
								<!-- ------ -->
								<!-- HELENA -->
								<!-- ------ -->
								<!-- TITULO -->
								<h1>Helena Beach</h1>
								<h2><strong>Activá tu lado ON en el espacio exclusivo de Banco Patagonia en el parador Helena Beach</strong></h2>
								<div id="tv25-shows" class="row">
									<div class="col-md-12 col-sm-12 col-xs-12" title="Disfrutá los mejores shows en HELENA beach">
										<img class="dsk img-responsive" src="images/verano/2025/tv25-shows-dsk.jpg" srcset="images/verano/2025/tv25-shows-dsk.jpg 1x, images/verano/2025/tv25-shows-dsk@2x.jpg 2x" alt="Disfrutá los mejores shows en HELENA beach">
										<img class="tbl img-responsive" src="images/verano/2025/tv25-shows-tbl.jpg" srcset="images/verano/2025/tv25-shows-tbl.jpg 1x, images/verano/2025/tv25-shows-tbl@2x.jpg 2x" alt="Disfrutá los mejores shows en HELENA beach">
										<img class="mbl img-responsive" src="images/verano/2025/tv25-shows-mbl.jpg" srcset="images/verano/2025/tv25-shows-mbl.jpg 1x, images/verano/2025/tv25-shows-mbl@2x.jpg 2x" alt="Disfrutá los mejores shows en HELENA beach">
									</div>
								</div>
								<!-- -->
								<p>&nbsp;</p>
								<!-- GASTRONOMÍA -->
								<!-- TITULO -->
								<h2><strong>Gastronomía</strong></h2>
								<!-- PROMOCION -->
								<div class="row">
									<!-- COLUMNA -->
									<div class="col-md-6 col-sm-6 col-xs-12">
										<!-- singular -->
										<div class="bnf-box bnf-singular">
											<div class="bnf-card">
												<img class="bnf-logo-segm bor-singular" src="../../assets/images/layout/logo-patagonia-singular.svg" alt="Patagonia Singular">
												<i class="bnf-icon bnf-icon-food"></i>
												<i class="bnf-misc"></i>
												<p>&nbsp;</p>
												<big>30<span>%<sup>(3)</sup></span></big>
												<p>de descuento</p>
											</div>
											<div class="bnf-card-data bnf-2-lines">
												<p>Con Tarjetas de Crédito y Débito.</p>
												<p>Tope $30.000.</p>
											</div>
										</div>
										<!-- -->
									</div>
									<!-- -->
									<div class="col-md-0 col-sm-0 col-xs-12 mbl">
										<br>
									</div>
									<!-- COLUMNA -->
									<div class="col-md-6 col-sm-6 col-xs-12">
										<!-- plus -->
										<div class="bnf-box bnf-plus">
											<div class="bnf-card">
												<img class="bnf-logo-segm bor-plus" src="../../assets/images/layout/logo-patagonia-plus.svg" alt="Patagonia Plus">
												<i class="bnf-icon bnf-icon-food"></i>
												<i class="bnf-misc"></i>
												<p>&nbsp;</p>
												<big>25<span>%<sup>(4)</sup></span></big>
												<p>de descuento</p>
											</div>
											<div class="bnf-card-data bnf-2-lines">
												<p>Con Tarjetas de Crédito y Débito.</p>
												<p>Tope $15.000.</p>
											</div>
										</div>
										<!-- -->
									</div>
									<!-- -->
									<div class="col-md-0 col-sm-0 col-xs-12 mbl">
										<br>
									</div>
									<!-- COLUMNA -->
									<div class="col-md-6 col-sm-6 col-xs-12">
										<!-- clasica -->
										<div class="bnf-box bnf-clasica">
											<div class="bnf-card">
												<img class="bnf-logo-segm bor-clasica" src="../../assets/images/layout/logo-patagonia-clasica.svg" alt="Patagonia Clásica">
												<i class="bnf-icon bnf-icon-food"></i>
												<i class="bnf-misc"></i>
												<p>&nbsp;</p>
												<big>25<span>%<sup>(5)</sup></span></big>
												<p>de descuento</p>
											</div>
											<div class="bnf-card-data bnf-2-lines">
												<p>Con Tarjetas de Crédito y Débito.</p>
												<p>Tope $10.000.</p>
											</div>
										</div>
										<!-- -->
									</div>
									<!-- -->
									<div class="col-md-0 col-sm-0 col-xs-12 mbl">
										<br>
									</div>
									<!-- COLUMNA -->
									<div class="col-md-6 col-sm-6 col-xs-12">
										<!-- on -->
										<div class="bnf-box bnf-on">
											<div class="bnf-card">
												<img class="bnf-logo-segm bor-on" src="../../assets/images/layout/logo-patagonia-on-3.svg" alt="Patagonia ON">
												<i class="bnf-icon bnf-icon-food"></i>
												<i class="bnf-misc"></i>
												<p>&nbsp;</p>
												<big>50<span>%<sup>(6)</sup></span></big>
												<p>de descuento</p>
											</div>
											<div class="bnf-card-data bnf-2-lines">
												<p>Con Tarjeta de Débito Visa.</p>
												<p>Tope $15.000.</p>
											</div>
										</div>
										<!-- -->
									</div>
									<!-- -->
								</div>
								<!-- -->
								<br>
								<!-- ALQUILER CARPAS/SOMBRILLAS -->
								<!-- TITULO -->
								<h2><strong>Alquiler de carpas y sombrillas</strong></h2>
								<!-- PROMOCION -->
								<div class="row">
									<!-- COLUMNA -->
									<div class="col-md-12 col-sm-12 col-xs-12">
										<div class="bnf-box bnf-generico">
											<div class="bnf-card">
												<i class="bnf-icon bnf-icon-tent-parador"></i>
												<!--<i class="bnf-misc"></i>-->
												<p>&nbsp;</p>
												<big>3<span class="tv25-cuotas">cuotas<sup>(7)</sup></span></big>
												<p>sin interés</p>
											</div>
											<div class="bnf-card-data bnf-1-lines">
												<p>Con Tarjetas de Crédito.</p>
											</div>
										</div>
									</div>
									<!-- -->
								</div>
								<!-- -->
							</div>
							<!-- -->
							<hr>
							<!-- -->
							<div>
								<!-- ------ -->
								<!-- ADEMÁS -->
								<!-- ------ -->
								<h2><strong>Además te esperamos con:</strong></h2>
								<h3>&bull; Espacio exclusivo con piscina y sombra</h3>
                                <h3>&bull; Juegos de playa</h3>
                                <h3>&bull; Música en vivo</h3>
                                <h3>&bull; Bebidas gratis para clientes Patagonia ON</h3>
								<!-- -->
							</div>
							<!-- -->
							<hr>
							<!-- -->
							<div>
								<!-- ---------- -->
								<!-- CABO LARGO -->
								<!-- ---------- -->
								<!-- TITULO -->
								<h1>Parador Cabo Largo</h1>
								<h2><strong>Gastronomía</strong></h2>
								<!-- PROMOCION -->
								<div class="row">
									<!-- COLUMNA -->
									<div class="col-md-6 col-sm-6 col-xs-12">
										<!-- clasica -->
										<div class="bnf-box bnf-clasica">
											<div class="bnf-card">
												<img class="bnf-logo-segm bor-clasica" src="../../assets/images/layout/logo-patagonia-clasica.svg" alt="Patagonia Clásica">
												<i class="bnf-icon bnf-icon-food"></i>
												<i class="bnf-misc"></i>
												<p>&nbsp;</p>
												<big>25<span>%<sup>(8)</sup></span></big>
												<p>de descuento</p>
											</div>
											<div class="bnf-card-data bnf-2-lines">
												<p>Con Tarjetas de Crédito y Débito.</p>
												<p>Tope $10.000.</p>
											</div>
										</div>
										<!-- -->
									</div>
									<!-- -->
									<div class="col-md-0 col-sm-0 col-xs-12 mbl">
										<br>
									</div>
									<!-- COLUMNA -->
									<div class="col-md-6 col-sm-6 col-xs-12">
										<!-- plus -->
										<div class="bnf-box bnf-plus">
											<div class="bnf-card">
												<img class="bnf-logo-segm bor-plus" src="../../assets/images/layout/logo-patagonia-plus.svg" alt="Patagonia Plus">
												<i class="bnf-icon bnf-icon-food"></i>
												<i class="bnf-misc"></i>
												<p>&nbsp;</p>
												<big>25<span>%<sup>(9)</sup></span></big>
												<p>de descuento</p>
											</div>
											<div class="bnf-card-data bnf-2-lines">
												<p>Con Tarjetas de Crédito y Débito.</p>
												<p>Tope $15.000.</p>
											</div>
										</div>
										<!-- -->
									</div>
									<!-- -->
									<div class="col-md-0 col-sm-0 col-xs-12 mbl">
										<br>
									</div>
									<!-- COLUMNA -->
									<div class="col-md-6 col-sm-6 col-xs-12">
										<!-- singular -->
										<div class="bnf-box bnf-singular">
											<div class="bnf-card">
												<img class="bnf-logo-segm bor-singular" src="../../assets/images/layout/logo-patagonia-singular.svg" alt="Patagonia Singular">
												<i class="bnf-icon bnf-icon-food"></i>
												<i class="bnf-misc"></i>
												<p>&nbsp;</p>
												<big>30<span>%<sup>(10)</sup></span></big>
												<p>de descuento</p>
											</div>
											<div class="bnf-card-data bnf-2-lines">
												<p>Con Tarjetas de Crédito y Débito.</p>
												<p>Tope $30.000.</p>
											</div>
										</div>
										<!-- -->
									</div>
									<!-- -->
								</div>
								<!-- -->
								<br>
								<!-- ALQUILER CARPAS/SOMBRILLAS -->
								<!-- TITULO -->
								<h2><strong>Alquiler de carpas y sombrillas</strong></h2>
								<!-- PROMOCION -->
								<div class="row">
									<!-- COLUMNA -->
									<div class="col-md-12 col-sm-12 col-xs-12">
										<div class="bnf-box bnf-generico">
											<div class="bnf-card">
												<i class="bnf-icon bnf-icon-tent-parador"></i>
												<!--<i class="bnf-misc"></i>-->
												<p>&nbsp;</p>
												<big>3<span class="tv25-cuotas">cuotas<sup>(11)</sup></span></big>
												<p>sin interés</p>
											</div>
											<div class="bnf-card-data bnf-1-lines">
												<p>Con Tarjetas de Crédito.</p>
											</div>
										</div>
									</div>
									<!-- -->
								</div>
								<!-- ADHERIDOS -->
								<div class="row">
									<div class="col-md-2 col-sm-3 col-xs-6">
										<img class="img-responsive" src="images/logos/logo_cabo_largo.jpg" alt="Parador Cabo Largo">
									</div>
								</div>							
								<!-- -->
							</div>
							<!-- -->
							<hr>
							<!-- -->
							<div>
								<!-- ------ -->
								<!-- ADEMÁS -->
								<!-- ------ -->
								<h2><strong>Además te esperamos con:</strong></h2>
								<h3>&bull; Servicio de toallas</h3>
                                <h3>&bull; Juegos y tótems para cargar celulares</h3>
                                <h3>&bull; Termo de agua caliente</h3>
                                <h3>&bull; Merchandising oficial para clientes American Express</h3>
								<br>
								<!-- -->
							</div>
							<!-- -->
						</div>
						
						<!-- PRE FOOTER -->
						<!-- FIN PRE FOOTER -->
						
					</div>
					<div class="tab-pane fade" id="tab2">
						
						<div class="tab-data">
							<div>
								<!-- --------- -->
								<!-- LA CUARTA -->
								<!-- --------- -->
								<!-- TITULO -->
								<h1>Parador La Cuarta</h1>
								<h2><strong>Te esperamos con un espacio exclusivo en el balcón del parador para clientes Banco Patagonia.</strong></h2>
								<br>
								<h2><strong>Gastronomía</strong></h2>
								<!-- PROMOCION -->
								<div class="row">
									<!-- COLUMNA -->
									<div class="col-md-6 col-sm-6 col-xs-12">
										<!-- clasica -->
										<div class="bnf-box bnf-clasica">
											<div class="bnf-card">
												<img class="bnf-logo-segm bor-clasica" src="../../assets/images/layout/logo-patagonia-clasica.svg" alt="Patagonia Clásica">
												<i class="bnf-icon bnf-icon-food"></i>
												<i class="bnf-misc"></i>
												<p>&nbsp;</p>
												<big>25<span>%<sup>(12)</sup></span></big>
												<p>de descuento</p>
											</div>
											<div class="bnf-card-data bnf-2-lines">
												<p>Con Tarjetas de Crédito y Débito.</p>
												<p>Tope $10.000.</p>
											</div>
										</div>
										<!-- -->
									</div>
									<!-- -->
									<div class="col-md-0 col-sm-0 col-xs-12 mbl">
										<br>
									</div>
									<!-- COLUMNA -->
									<div class="col-md-6 col-sm-6 col-xs-12">
										<!-- plus -->
										<div class="bnf-box bnf-plus">
											<div class="bnf-card">
												<img class="bnf-logo-segm bor-plus" src="../../assets/images/layout/logo-patagonia-plus.svg" alt="Patagonia Plus">
												<i class="bnf-icon bnf-icon-food"></i>
												<i class="bnf-misc"></i>
												<p>&nbsp;</p>
												<big>25<span>%<sup>(13)</sup></span></big>
												<p>de descuento</p>
											</div>
											<div class="bnf-card-data bnf-2-lines">
												<p>Con Tarjetas de Crédito y Débito.</p>
												<p>Tope $15.000.</p>
											</div>
										</div>
										<!-- -->
									</div>
									<!-- -->
									<div class="col-md-0 col-sm-0 col-xs-12 mbl">
										<br>
									</div>
									<!-- COLUMNA -->
									<div class="col-md-6 col-sm-6 col-xs-12">
										<!-- singular -->
										<div class="bnf-box bnf-singular">
											<div class="bnf-card">
												<img class="bnf-logo-segm bor-singular" src="../../assets/images/layout/logo-patagonia-singular.svg" alt="Patagonia Singular">
												<i class="bnf-icon bnf-icon-food"></i>
												<i class="bnf-misc"></i>
												<p>&nbsp;</p>
												<big>30<span>%<sup>(14)</sup></span></big>
												<p>de descuento</p>
											</div>
											<div class="bnf-card-data bnf-2-lines">
												<p>Con Tarjetas de Crédito y Débito.</p>
												<p>Tope $20.000.</p>
											</div>
										</div>
										<!-- -->
									</div>
									<!-- -->
									<div class="col-md-0 col-sm-0 col-xs-12 mbl">
										<br>
									</div>
									<!-- COLUMNA -->
									<div class="col-md-6 col-sm-6 col-xs-12">
										<!-- on -->
										<div class="bnf-box bnf-on">
											<div class="bnf-card">
												<img class="bnf-logo-segm bor-on" src="../../assets/images/layout/logo-patagonia-on-3.svg" alt="Patagonia ON">
												<i class="bnf-icon bnf-icon-food"></i>
												<i class="bnf-misc"></i>
												<p>&nbsp;</p>
												<big>50<span>%<sup>(15)</sup></span></big>
												<p>de descuento</p>
											</div>
											<div class="bnf-card-data bnf-2-lines">
												<p>Con Tarjeta de Débito Visa.</p>
												<p>Tope $15.000.</p>
											</div>
										</div>
										<!-- -->
									</div>
									<!-- -->
								</div>
								<!-- -->
								<br>
								<!-- ALQUILER CARPAS/SOMBRILLAS -->
                                <!-- TITULO -->
                                <h2><strong>Alquiler de carpas y sombrillas</strong></h2>
                                <!-- PROMOCION -->
                                <div class="row">
                                    <!-- COLUMNA -->
                                    <div class="col-md-12 col-sm-12 col-xs-12">
                                        <div class="bnf-box bnf-generico">
                                            <div class="bnf-card">
                                                <i class="bnf-icon bnf-icon-tent-parador"></i>
                                                <!--<i class="bnf-misc"></i>-->
                                                <p>&nbsp;</p>
                                                <big>3<span class="tv25-cuotas">cuotas<sup>(16)</sup></span></big>
                                                <p>sin interés</p>
                                            </div>
                                            <div class="bnf-card-data bnf-1-lines">
												<p>Con Tarjetas de Crédito.</p>
											</div>
                                        </div>
                                    </div>
                                    <!-- -->
                                </div>
                                <!-- ADHERIDOS -->
                                <div class="row">
                                    <div class="col-md-2 col-sm-3 col-xs-6">
                                        <img class="img-responsive" src="images/logos/logo_la_cuarta.jpg" alt="Parador La Cuarta">
                                    </div>  
                                </div>
								<!-- -->
							</div>
							<!-- -->
							<hr>
							<!-- -->
							<h1>Y con muchos beneficios más:</h1>
							<!-- -->
							<div>
								<!-- ------ -->
								<!-- EL SOL -->
								<!-- ------ -->
								<!-- TITULO -->
								<h2><strong>Supermercado Centro de Compras El Sol</strong> - Jueves</h2>
								<!-- PROMOCION -->
								<div class="row">
                                    <!-- COLUMNA -->
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <div class="bnf-box bnf-generico">
											<div class="bnf-card">
												<i class="bnf-icon bnf-icon-cart"></i>
												<!--<i class="bnf-misc"></i>-->
												<p>&nbsp;</p>
												<big>30<span>%<sup>(17)</sup></span></big>
												<p>de descuento</p>
											</div>
											<div class="bnf-card-data bnf-2-lines">
												<!--<p>Con Clásica, Plus y Singular.</p>-->
												<p>Con Tarjetas de Crédito y Débito.</p>
												<p>Tope $10.000.</p>
											</div>
										</div>
                                    </div>
									<!-- -->
									<div class="col-md-0 col-sm-0 col-xs-12 mbl">
										<br>
									</div>
									<!-- COLUMNA -->
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <!-- on -->
										<div class="bnf-box bnf-on">
											<div class="bnf-card">
												<img class="bnf-logo-segm bor-on" src="../../assets/images/layout/logo-patagonia-on-3.svg" alt="Patagonia ON">
												<i class="bnf-icon bnf-icon-cart"></i>
												<i class="bnf-misc"></i>
												<p>&nbsp;</p>
												<big>50<span>%<sup>(18)</sup></span></big>
												<p>de descuento</p>
											</div>
											<div class="bnf-card-data bnf-2-lines">
												<p>Con Tarjeta de Débito.</p>
												<p>Tope $15.000.</p>
											</div>
										</div>
										<!-- -->
                                    </div>
                                    <!-- -->
                                </div>
								<!-- ADHERIDOS -->
								<div class="row">
									<div class="col-md-2 col-sm-3 col-xs-6">
										<img class="img-responsive" src="images/logos/logo_el_sol.jpg" alt="Supermercado Centro de Compras El Sol">
									</div>  
								</div>
								<!-- -->
							</div>
							<!-- -->
							<hr>
							<!-- -->
							<div>
								<!-- -------- -->
								<!-- MICHELLI -->
								<!-- -------- -->
								<!-- TITULO -->
								<h2><strong>Farmacia Michelli</strong> - Todos los días</h2>
								<!-- PROMOCION -->
								<div class="bnf-box bnf-generico">
									<div class="bnf-card">
										<i class="bnf-icon bnf-icon-shop"></i>
										<!--<i class="bnf-misc"></i>-->
										<p>&nbsp;</p>
										<big>20<span>%<sup>(19)</sup></span></big>
										<p>de descuento</p>
									</div>
									<div class="bnf-card-data bnf-3-lines">
										<p>Con Tarjetas de Crédito Visa y Máster.</p>
										<p>+ 3 cuotas sin interés.</p> 
										<p>Tope $10.000.</p>
									</div>
								</div>
								<!-- ADHERIDOS -->
								<div class="row">
									<div class="col-md-2 col-sm-3 col-xs-6">
										<img class="img-responsive" src="images/logos/logo_michelli.jpg" alt="Farmacia Michelli">
									</div>  
								</div>
								<!-- -->
							</div>
							<!-- -->
							<hr>
							<!-- -->
							<div>
								<!-- ---------------- -->
								<!-- PASEO DE COMPRAS -->
								<!-- ---------------- -->
								<!-- TITULO -->
								<h2><strong>Paseo de Compras</strong> - Martes y Jueves</h2>
								<!-- PROMOCION -->
								<div class="row">
									<!-- COLUMNA -->
									<div class="col-md-6 col-sm-6 col-xs-12">
										<!-- clasica -->
										<div class="bnf-box bnf-clasica">
											<div class="bnf-card">
												<img class="bnf-logo-segm bor-clasica" src="../../assets/images/layout/logo-patagonia-clasica.svg" alt="Patagonia Clásica">
												<i class="bnf-icon bnf-icon-shop"></i>
												<i class="bnf-misc"></i>
												<p>&nbsp;</p>
												<big>15<span>%<sup>(20)</sup></span></big>
												<p>de descuento</p>
											</div>
											<div class="bnf-card-data bnf-3-lines">
												<p>Con Tarjetas de Crédito y Débito.</p>
												<p>+ 3 cuotas sin interés.</p>
												<p>Tope $10.000.</p>
											</div>
										</div>
										<!-- -->
									</div>
									<!-- -->
									<div class="col-md-0 col-sm-0 col-xs-12 mbl">
										<br>
									</div>
									<!-- COLUMNA -->
									<div class="col-md-6 col-sm-6 col-xs-12">
										<!-- plus -->
										<div class="bnf-box bnf-plus">
											<div class="bnf-card">
												<img class="bnf-logo-segm bor-plus" src="../../assets/images/layout/logo-patagonia-plus.svg" alt="Patagonia Plus">
												<i class="bnf-icon bnf-icon-shop"></i>
												<i class="bnf-misc"></i>
												<p>&nbsp;</p>
												<big>20<span>%<sup>(21)</sup></span></big>
												<p>de descuento</p>
											</div>
											<div class="bnf-card-data bnf-3-lines">
												<p>Con Tarjetas de Crédito y Débito.</p>
												<p>+ 3 cuotas sin interés.</p>
												<p>Tope $15.000.</p>
											</div>
										</div>
										<!-- -->
									</div>
									<!-- -->
									<div class="col-md-0 col-sm-0 col-xs-12 mbl">
										<br>
									</div>
									<!-- COLUMNA -->
									<div class="col-md-6 col-sm-6 col-xs-12">
										<!-- singular -->
										<div class="bnf-box bnf-singular">
											<div class="bnf-card">
												<img class="bnf-logo-segm bor-singular" src="../../assets/images/layout/logo-patagonia-singular.svg" alt="Patagonia Singular">
												<i class="bnf-icon bnf-icon-shop"></i>
												<i class="bnf-misc"></i>
												<p>&nbsp;</p>
												<big>25<span>%<sup>(22)</sup></span></big>
												<p>de descuento</p>
											</div>
											<div class="bnf-card-data bnf-3-lines">
												<p>Con Tarjetas de Crédito y Débito.</p>
												<p>+ 3 cuotas sin interés.</p>
												<p>Tope $20.000.</p>
											</div>
										</div>
										<!-- -->
									</div>
									<!-- COLUMNA -->
									<div class="col-md-6 col-sm-6 col-xs-12">
										<!-- on -->
										<div class="bnf-box bnf-on">
											<div class="bnf-card">
												<img class="bnf-logo-segm bor-on" src="../../assets/images/layout/logo-patagonia-on-3.svg" alt="Patagonia ON">
												<i class="bnf-icon bnf-icon-shop"></i>
												<i class="bnf-misc"></i>
												<p>&nbsp;</p>
												<big>50<span>%<sup>(23)</sup></span></big>
												<p>de descuento</p>
											</div>
											<div class="bnf-card-data bnf-2-lines">
												<p>Con Tarjeta de Débito.</p>
												<p>Tope $15.000.</p>
											</div>
										</div>
										<!-- -->
									</div>
									<!-- -->
								</div>
								<!-- -->
								<div>
									<!-- ADHERIDOS -->
									<!-- botón -->
									<div class="row">
										<div class="col-md-4 col-sm-6 col-xs-12">
											<a href="#tv25-paseos" class="btn-lnk-block" data-toggle="modal">
												<h4>Ver los comercios adheridos</h4>
												<i class="icon icon-more"></i>
											</a>
										</div>
									</div> 
									<!-- modal -->
									<div class="row">
										<div class="modal fade" id="tv25-paseos">
											<div class="modal-dialog modal-lg">
												<div class="modal-content">
													<div class="modal-header">
														<button type="button" class="close" data-dismiss="modal"><span>X</span></button>
													</div>
													<div class="modal-body">
														<div class="text-data">
															<h3><strong>Paseo de Compras</strong> - Martes y Jueves</h3>
															<table class="table table-bordered" style="text-align:center;">
																<thead>
																	<tr>
																		<th width="50%" bgcolor="#eeeeee" style="text-align:center;">Comercio</th>
																		<th width="50%" bgcolor="#eeeeee" style="text-align:center;">Domicilio</th>
																	</tr>
																</thead>
																<tr>
																  <td>SUNSET</td>
																  <td>Viedma 725</td>
                                                                </tr>
                                                                  <tr>
                                                                    <td>GIANNI</td>
                                                                    <td>Galeria casa Blanca s/n</td>
                                                                </tr>
                                                                  <tr>
                                                                    <td>Pais de    Patagones</td>
                                                                    <td>Viedma 770</td>
                                                                </tr>
                                                                  <tr>
                                                                    <td>OSADAS</td>
                                                                    <td>Villa Regina 29</td>
                                                                </tr>
                                                                  <tr>
                                                                    <td>LOCA MAREA</td>
                                                                    <td>Viedma 733</td>
                                                                </tr>
                                                                  <tr>
                                                                    <td>MARENA</td>
                                                                    <td>Viedma y Chimpay</td>
                                                                </tr>
																<tr>
																  <td>ITALO SPORT</td>
																  <td>Shopping Puertas del Sol</td>
															  	</tr>
																<tr>
																  <td>K-LIDOS</td>
																  <td>Peatonal Viedma y Allen s/n</td>
																</tr>
																<tr>
																  <td>OPTICA REYNALDO BERGOGLIO</td>
																  <td>Bariloche 517</td>
																</tr>
																<tr>
																  <td>CATANNA</td>
																  <td>Viedma 908</td>
																</tr>
																<tr>
																  <td>OLI</td>
																  <td>Viedma 844 - local 1</td>
																</tr>
																<tr>
																  <td>CHOCOLATE</td>
																  <td>Viedma 957 - local 6</td>
																</tr>
															</table>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
									<!-- -->
								</div>
								<!-- -->
							</div>
							<!-- -->
							<hr>
							<!-- -->
							<div>
								<!-- ------------ -->
								<!-- RESTAURANTES -->
								<!-- ------------ -->
								<!-- TITULO -->
								<h2><strong>Restaurantes</strong> - Lunes y Martes</h2>
								<!-- PROMOCION -->
								<div class="row">
									<!-- COLUMNA -->
									<div class="col-md-6 col-sm-6 col-xs-12">
										<!-- clasica -->
										<div class="bnf-box bnf-clasica">
											<div class="bnf-card">
												<img class="bnf-logo-segm bor-clasica" src="../../assets/images/layout/logo-patagonia-clasica.svg" alt="Patagonia Clásica">
												<i class="bnf-icon bnf-icon-food"></i>
												<i class="bnf-misc"></i>
												<p>&nbsp;</p>
												<big>15<span>%<sup>(24)</sup></span></big>
												<p>de descuento</p>
											</div>
											<div class="bnf-card-data bnf-2-lines">
												<p>Con Tarjetas de Crédito.</p>
												<p>Tope $6.000.</p>
											</div>
										</div>
										<!-- -->
									</div>
									<!-- -->
									<div class="col-md-0 col-sm-0 col-xs-12 mbl">
										<br>
									</div>
									<!-- COLUMNA -->
									<div class="col-md-6 col-sm-6 col-xs-12">
										<!-- plus -->
										<div class="bnf-box bnf-plus">
											<div class="bnf-card">
												<img class="bnf-logo-segm bor-plus" src="../../assets/images/layout/logo-patagonia-plus.svg" alt="Patagonia Plus">
												<i class="bnf-icon bnf-icon-food"></i>
												<i class="bnf-misc"></i>
												<p>&nbsp;</p>
												<big>20<span>%<sup>(25)</sup></span></big>
												<p>de descuento</p>
											</div>
											<div class="bnf-card-data bnf-2-lines">
												<p>Con Tarjetas de Crédito.</p>
												<p>Tope $8.000.</p>
											</div>
										</div>
										<!-- -->
									</div>
									<!-- -->
									<div class="col-md-0 col-sm-0 col-xs-12 mbl">
										<br>
									</div>
									<!-- COLUMNA -->
									<div class="col-md-6 col-sm-6 col-xs-12">
										<!-- singular -->
										<div class="bnf-box bnf-singular">
											<div class="bnf-card">
												<img class="bnf-logo-segm bor-singular" src="../../assets/images/layout/logo-patagonia-singular.svg" alt="Patagonia Singular">
												<i class="bnf-icon bnf-icon-food"></i>
												<i class="bnf-misc"></i>
												<p>&nbsp;</p>
												<big>25<span>%<sup>(26)</sup></span></big>
												<p>de descuento</p>
											</div>
											<div class="bnf-card-data bnf-2-lines">
												<p>Con Tarjetas de Crédito.</p>
												<p>Tope $12.000.</p>
											</div>
										</div>
										<!-- -->
									</div>
									<!-- COLUMNA -->
									<div class="col-md-6 col-sm-6 col-xs-12">
										<!-- on -->
										<div class="bnf-box bnf-on">
											<div class="bnf-card">
												<img class="bnf-logo-segm bor-on" src="../../assets/images/layout/logo-patagonia-on-3.svg" alt="Patagonia ON">
												<i class="bnf-icon bnf-icon-food"></i>
												<i class="bnf-misc"></i>
												<p>&nbsp;</p>
												<big>50<span>%<sup>(27)</sup></span></big>
												<p>de descuento</p>
											</div>
											<div class="bnf-card-data bnf-2-lines">
												<p>Con Tarjeta de Débito.</p>
												<p>Tope $15.000.</p>
											</div>
										</div>
										<!-- -->
									</div>
									<!-- -->
								</div>
								<div>
									<!-- ADHERIDOS -->
									<!-- botón -->
									<div class="row">
										<div class="col-md-4 col-sm-6 col-xs-12">
											<a href="#tv25-restaurantes" class="btn-lnk-block" data-toggle="modal">
												<h4>Ver los comercios adheridos</h4>
												<i class="icon icon-more"></i>
											</a>
										</div>
									</div> 
									<!-- modal -->
									<div class="row">
										<div class="modal fade" id="tv25-restaurantes">
											<div class="modal-dialog modal-lg">
												<div class="modal-content">
													<div class="modal-header">
														<button type="button" class="close" data-dismiss="modal"><span>X</span></button>
													</div>
													<div class="modal-body">
														<div class="text-data">
															<h3><strong>Restaurantes</strong> - Lunes y Martes</h3>
															<table class="table table-bordered" style="text-align:center;">
																<thead>
																	<tr>
																		<th width="100%" bgcolor="#eeeeee" style="text-align:center;">Comercios adheridos</th>
																	</tr>
																</thead>
																<tr>
																	<td>Astor</td>
																</tr>
																<tr>
																	<td>La Bianca</td>
																</tr>
																<tr>
																	<td>Bariloche</td>
																</tr>
																<tr>
																	<td>Hohlen Burguer</td>
																</tr>
															</table>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
									<!-- -->
								</div>
								<!-- -->
							</div>
							<!-- -->
						</div>
						
						<!-- PRE FOOTER -->
						<!-- FIN PRE FOOTER -->
						
					</div>
				</div>
			</div>
		</div>
		<!-- PRE FOOTER -->
		<div class="row legal-int">
			<div class="col-md-12 col-sm-12 col-xs-12">
				<p>CARTERA DE CONSUMO - PROMOCIÓNES VÁLIDAS EN LA REPÚBLICA ARGENTINA.  PARA TODAS LAS PROMOCIONES CONTENIDAS EN ESTA PIEZA, EL IMPORTE AHORRADO EN LAS COMPRAS REALIZADAS CON LAS TARJETAS DE DÉBITO DEL BANCO SERÁ ACREDITADO EN LA CUENTA DE DÉBITO, DENTRO DE LOS 10 DÍAS HÁBILES DE REALIZADA LA OPERACIÓN.  LOS REINTEGROS CORRESPONDIENTES A LAS COMPRAS EFECTUADAS EN CUOTAS -CON LAS TARJETAS DE CRÉDITO VISA, MASTERCARD Y AMERICAN EXPRESS DEL BANCO SE VISUALIZARÁN EN EL RESUMEN EN QUE INGRESE LA PRIMERA CUOTA Y/O EN EL INMEDIATO POSTERIOR. NO ACUMULABLES CON OTRAS PROMOCIONES Y NO VÁLIDAS PARA TARJETAS CORPORATIVAS. BANCO PATAGONIA NO SE RESPONSABILIZA POR LOS CUPONES PRESENTADOS FUERA DE LAS FECHAS DE VIGENCIA DE LAS PROMOCIONES. LAS CUENTAS NO DEBERÁN REGISTRAR MORA.  EL BENEFICIO NO APLICA PARA PAGOS EFECTUADOS A TRAVÉS DE BILLETERAS VIRTUALES NI EN COMERCIOS QUE COBREN CON POST MÓVILES/POSTNET DE PLATAFORMAS DE PAGO Y/O PORTALES DE PAGO ON LINE A EXCEPCION DE MODO, GOOGLE PAY Y APPLE PAY.</p>
				<p>(1) PROMOCIÓN VALIDA DESDE EL 07/01/2025 AL 31/03/2025 EN LOS CONSUMOS REALIZADOS EN LOS ESPECTÁCULOS A REALIZARSE EN EL PARADOR HELENA BEACH, ABONANDO TODOS LOS DIAS, CON TODAS LAS TARJETAS DE CRÉDITO DE BANCO PATAGONIA RECIBIRÁ UNA FINANCIACION EN HASTA TRES CUOTAS SIN INTERES. (2) CLIENTES PATAGONIA ON RECIBIRAN UN 50% DE DESCUENTO CON LA TARJETA DE DEBITO DE BANCO PATAGONIA. TOPE POR MES Y POR CUENTA $20.000. PROMOCIÓN VALIDA DESDE EL 10/01/2025 AL 31/03/2025 EN LOS CONSUMOS REALIZADOS EN EL PARADOR HELENA BEACH EN EL RUBRO GASTRONOMIA. (3) CLIENTES PATAGONIA CLASICA 25% DE DESCUENTO CON TODAS LAS TARJETAS DE CRÉDITO Y DEBITO DE BANCO PATAGONIA. TOPE POR MES Y POR CUENTA $10.000.  (4) CLIENTES PATAGONIA PLUS, 25% DE DESCUENTO  CON TODAS LAS TARJETAS DE CRÉDITO Y DEBITO DE BANCO PATAGONIA. TOPE POR MES Y POR CUENTA $15.000. (5) CLIENTES PATAGONIA SINGULAR, 30% DE DESCUENTO CON TODAS LAS TARJETAS DE CRÉDITO Y DEBITO DE BANCO PATAGONIA. TOPE POR PLAZO DE VIGENCIA $30.000.  (6) CLIENTES PATAGONIA ON 50% DE DESCUENTO CON TODAS LAS TARJETAS DE DEBITO DE BANCO PATAGONIA. TOPE POR MES Y POR CUENTA $15.000. (7) ABONANDO TODOS LOS DIAS EN EL PARADOR HELENA BEACH EN EL RUBRO SOMBRAS, CON TODAS LAS TARJETAS DE CRÉDITO DE BANCO PATAGONIA RECIBIRÁ UNA FINANCIACION EN HASTA TRES CUOTAS SIN INTERES.  PROMOCIÓN VALIDA DESDE EL 09/01/2025 AL 31/03/2025 EN LOS CONSUMOS REALIZADOS EN EL PARADOR CABO LARGO EN EL RUBRO GASTRONOMIA (8) CLIENTES PATAGONIA CLASICA 25% DE DESCUENTO CON TODAS LAS TARJETAS DE CRÉDITO Y DEBITO DE BANCO PATAGONIA. TOPE POR MES Y POR CUENTA $10.000. (9) CLIENTES PATAGONIA PLUS, 25% DE DESCUENTO  CON TODAS LAS TARJETAS DE CRÉDITO Y DEBITO DE BANCO PATAGONIA. TOPE POR MES Y POR CUENTA $15.000.  (10) CLIENTES PATAGONIA SINGULAR, 30% DE DESCUENTO CON TODAS LAS TARJETAS DE CRÉDITO Y DEBITO DE BANCO PATAGONIA. TOPE POR PLAZO DE VIGENCIA $30.000.  (11) ABONANDO TODOS LOS DIAS EN EL PARADOR CABO LARGO EN EL RUBRO SOMBRAS, CON TODAS LAS TARJETAS DE CRÉDITO DE BANCO PATAGONIA RECIBIRÁ UNA FINANCIACION EN HASTA TRES CUOTAS SIN INTERES.</p>
				<p>CARTERA DE CONSUMO - PROMOCIÓNES VÁLIDAS EN LA REPÚBLICA ARGENTINA, EN LA PROVINCIA DE RIO NEGRO, LAS GRUTAS. PROMOCIÓN VALIDA DESDE EL 09/01/2025 AL 31/03/2025 EN LOS CONSUMOS REALIZADOS EN EL PARADOR LA CUARTA. (12) CLIENTES PATAGONIA CLASICA 25% DE DESCUENTO CON TODAS LAS TARJETAS DE CRÉDITO Y DEBITO DE BANCO PATAGONIA. TOPE POR MES Y POR CUENTA $10.000.  (13) CLIENTES PATAGONIA PLUS, 25% DE DESCUENTO  CON TODAS LAS TARJETAS DE CRÉDITO Y DEBITO DE BANCO PATAGONIA. TOPE POR MES Y POR CUENTA $15.000.  (14) CLIENTES PATAGONIA SINGULAR, 30% DE DESCUENTO CON TODAS LAS TARJETAS DE CRÉDITO Y DEBITO DE BANCO PATAGONIA. TOPE POR PLAZO DE VIGENCIA $20.000.  (15) CLIENTES PATAGONIA ON 50% DE DESCUENTO CON TODAS LAS TARJETAS DE DEBITO DE BANCO PATAGONIA. TOPE POR MES Y POR CUENTA $15..000 (16) ABONANDO TODOS LOS DIAS EN EL PARADOR LA CUARTA EN EL RUBRO SOMBRAS, CON TODAS LAS TARJETAS DE CRÉDITO DE BANCO PATAGONIA RECIBIRÁ UNA FINANCIACION EN HASTA TRES CUOTAS SIN INTERES. (17)  BONIFICACIONES VIGENTES, EN LAS COMPRAS EN SUPERMERCADO CENTRO DE COMPRAS EL SOL, ABONANDO TODOS LOS JUEVES, CON TODAS LAS TARJETAS DE BANCO PATAGONIA RECIBIRÁ UN 30% DE DESCUENTO EN UN PAGO TOPE POR MES Y POR CUENTA: $30.000  (18) CLIENTES PATAGONIA ON 50% DE DESCUENTO CON TODAS LAS TARJETAS DE DEBITO DE BANCO PATAGONIA. TOPE POR MES Y POR CUENTA $15.000 (19) BONIFICACIONES VIGENTES, EN LAS COMPRAS PRESENCIALES EN FARMACIA MICHELLI, ABONANDO TODOS LOS DIAS, CON TODAS LAS TARJETAS DE CRÉDITO VISA Y MASTER DE BANCO PATAGONIA RECIBIRÁ UN 20% DE DESCUENTO Y FINANCIACION EN HASTA TRES CUOTAS SIN INTERES TOPE POR MES Y POR CUENTA: $10.000. BONIFICACIONES VIGENTES, EN LAS COMPRAS PRESENCIALES EN COMERCIOS ADHERIDOS “PASEO DE COMPRAS”. CONSULTALOS EN WWW.BANCOPATAGONIA.COM.AR.  (20) CLIENTES PATAGONIA CLASICA 15% DE DESCUENTO Y FINANCIACION EN HASTA TRES CUOTAS SIN INTERES CON TODAS LAS TARJETAS DE CRÉDITO Y DEBITO DE BANCO PATAGONIA. TOPE POR MES Y POR CUENTA $10.000. (21) CLIENTES VINGULADOS A UN PATAGONIA PLUS, 20% DE DESCUENTO Y FINANCIACION EN HASTA TRES CUOTAS SIN INTERES CON TODAS LAS TARJETAS DE CRÉDITO Y DEBITO DE BANCO PATAGONIA. TOPE POR MES Y POR CUENTA $15.000.  (22) CLIENTES VINGULADOS A UN PATAGONIA SINGULAR, 25% DE DESCUENTO Y FINANCIACION EN HASTA TRES CUOTAS SIN INTERES CON TODAS LAS TARJETAS DE CRÉDITO Y DEBITO DE BANCO PATAGONIA TOPE POR MES Y POR CUENTA $20.000.  (23) CLIENTES PATAGONIA ON 50% DE DESCUENTO CON TODAS LAS TARJETAS DE DEBITO DE BANCO PATAGONIA. TOPE POR MES Y POR CUENTA $15.000.   BONIFICACIONES VIGENTES, TODOS LOS LUNES Y MARTES EN LAS COMPRAS PRESENCIALES EN RESTAURANTES ADHERIDOS. CONSULTALOS EN WWW.BANCOPATAGONIA.COM.AR. (24) ABONANDO CON TODAS LAS TARJETAS DE CRÉDITO DE BANCO PATAGONIA RECIBIRÁ UN 15% DE DESCUENTO EN UN PAGO TOPE POR MES Y POR CUENTA: $6.000 (25) CLIENTES VINGULADOS A UN PATAGONIA PLUS, 20% DE DESCUENTO EN UN PAGO CON TODAS LAS TARJETAS DE CRÉDITO DE BANCO PATAGONIA. TOPE POR PLAZO DE VIGENCIA $8.000.  (26) CLIENTES VINGULADOS A UN PATAGONIA SINGULAR, 20% DE DESCUENTO EN UN PAGO CON TODAS LAS TARJETAS DE CRÉDITO DE BANCO PATAGONIA. TOPE POR PLAZO DE VIGENCIA $12.000. (27) CLIENTES PATAGONIA ON 50% DE DESCUENTO CON TODAS LAS TARJETAS DE DEBITO DE BANCO PATAGONIA. TOPE POR MES Y POR CUENTA $15..000.  
				<p style="font-size:50px;">C.F.T.N.A. CON Y SIN IVA: 0.00% (*); 4.34%(**).</p>
				<p>(*) PARA COMPRAS ABONADAS EN CUOTAS POR USUARIOS DE SERVICIOS FINANCIEROS - CARTERA DE CONSUMO - SE APLICARA: TASA NOMINAL ANUAL: 0% - TASA EFECTIVA ANUAL: 0% - COSTO SEGURO DE VIDA 0% - COSTO FINANCIERO TOTAL   (C.F.T. )  EXPRESADO EN T.E.A..(**) PARA COMPRAS ABONADAS EN CUOTAS POR CLIENTES DE CARTERA COMERCIAL, SE APLICARÁ: TASA NOMINAL ANUAL: 0% - TASA EFECTIVA ANUAL: 0% - COSTO SEGURO DE VIDA 0.35% - COSTO FINANCIERO TOTAL (C.F.T) EXPRESADO EN T.E.A.  LOS ACCIONISTAS DE BANCO PATAGONIA S.A. (CUIT: 30-50000661- 3, AV. DE MAYO 701 PISO 24 (C1084AAC), CIUDAD AUTÓNOMA DE BUENOS AIRES) LIMITAN SU RESPONSABILIDAD A LA INTEGRACIÓN DE LAS ACCIONES SUSCRIPTAS. EN VIRTUD DE ELLO, NI LOS ACCIONISTAS MAYORITARIOS DE CAPITAL EXTRANJERO NI LOS ACCIONISTAS LOCALES O EXTRANJEROS, RESPONDEN EN EXCESO DE LA CITADA INTEGRACIÓN ACCIONARIA POR LAS OBLIGACIONES EMERGENTES DE LAS OPERACIONES CONCERTADAS POR LA ENTIDAD FINANCIERA. LEY 25.738.</p>
			</div>
		</div>
		<!-- FIN PRE FOOTER -->
	</section>
    
	<div class="container-fluid footer-bar">
	<div class="row">
		<footer class="container">
			<div class="row">
				<div class="col-md-12">
					<p class="flnks"><a href="../../registro-nacional-base-datos.php">Registro Nacional de Base de Datos</a> <span>|</span>   <a href="../../codigo-practicas-bancarias.php">Código de Prácticas Bancarias</a> <span>|</span>   <a href="../../defensa-ley-consumidor.php">Defensa del Consumidor</a>
						<span>|</span>   <a href="https://www.argentina.gob.ar/produccion/defensadelconsumidor/formulario">Defensa de las y los consumidores. Para reclamos ingrese aquí</a><span>|</span> <br class="tbl"> <a href="../../persona-expuesta-politicamente.php">Persona Expuesta Políticamente</a> <span class="tbl">|</span> <br class="dsk">
						
					<a href="../../agencia-acceso-informacion-publica.php">Agencia de Acceso a la Información Pública</a> <span>|</span> <br class="tbl"> 
					<a href="../../cnv-advertencia-publico-inversor.php">CNV - Advertencia al Público Inversor</a> <span>|</span> <a href="../../docs/Idoneos.pdf" target="_blank"> Idóneos en Mercado de Capitales - CNV</a><span>|</span>   <a href="../../codigo-proteccion-inversor.php">Código de Protección al Inversor</a> <span>|</span>   <a href="../../clausulas-legales.php">Cláusulas Legales</a> <span>|</span> <a href="../../resolucion-022021.php">Resol. 02/21 Dir.Gral. Defensa del consumidor Córdoba</a></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<p class="redes">
                        <span>Seguinos en:</span>
                        <!-- -->
                        <a href="https://www.facebook.com/BancoPatagonia/" target="_blank"><img src="../../assets/images/layout/icon-facebook.svg" alt="Facebook"></a>
                        <a href="https://twitter.com/banco_patagonia" target="_blank"><img src="../../assets/images/layout/icon-twitter.svg" alt="Twitter"></a>
                        <a href="https://www.instagram.com/banco_patagonia/" target="_blank"><img src="../../assets/images/layout/icon-instagram.svg" alt="Instagram"></a>
                        <a href="https://www.youtube.com/user/bancopatagonia" target="_blank"><img src="../../assets/images/layout/icon-youtube.svg" alt="Youtube"></a>
                        <!-- -->
                        <!--
                        <a href="https://www.facebook.com/BancoPatagonia/" target="_blank"><i class="fa fa-facebook-square"></i></a>
                        <a href="https://twitter.com/banco_patagonia" target="_blank"><i class="fa fa-twitter"></i></a>
                        <a href="https://www.instagram.com/banco_patagonia/" target="_blank"><i class="fa fa-instagram"></i></a>
                        <a href="https://www.youtube.com/user/bancopatagonia" target="_blank"><i class="fa fa-youtube-play"></i></a>
                        -->
                    </p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					                    <!---->
				    <p class="flegal">BANCO PATAGONIA S.A. ES UNA SOCIEDAD ANÓNIMA CONSTITUIDA BAJO LAS LEYES DE LA REPÚBLICA ARGENTINA CUYOS ACCIONISTAS LIMITAN SU RESPONSABILIDAD A LA INTEGRACIÓN DE LAS ACCIONES SUSCRITAS DE ACUERDO A LA LEY 19.550. POR CONSIGUIENTE, Y EN CUMPLIMIENTO DE LA LEY 25.738, SE INFORMA QUE NI LOS ACCIONISTAS MAYORITARIOS DE CAPITAL EXTRANJERO NI LOS ACCIONISTAS LOCALES O EXTRANJEROS RESPONDEN, EN EXCESO DE LA CITADA INTEGRACIÓN ACCIONARIA, POR LAS OBLIGACIONES EMERGENTES DE LAS OPERACIONES CONCERTADAS POR LA ENTIDAD FINANCIERA.</p>
                    <p class="flegal" style="font-size:10px;">Banco Patagonia S.A. - Agente de Liquidacion y Compensacion y Agente de Negociacion Integral, inscripto en CNV bajo el N° 66</p>
					<p class="flegal">© 2025 Banco Patagonia . Todos los derechos reservados. Prohibida la duplicación , distribución o almacenamiento en cualquier medio.</p>
				</div>
			</div>
		</footer>
	</div>
</div>
<div class="tbl mbl placeholder-shortlinks">
	<div class="container shortlinks">
		<div class="row">
            <!--<php if ($home_personas == false) { ?>
                <div class="col-sm-3 col-xs-3">
                    <a href="#"><span class="icon icon-contacto"></span></a>
                </div>
            <php } ?>-->
            			<div class="col-sm-3 col-xs-3">
				<a href="http://sucursalesycajeros.bancopatagonia.com.ar/sucursales.html" target="_blank"><span class="icon icon-sucursales"></span>Sucursales y Cajeros</a>
			</div>
			<div class="col-sm-3 col-xs-3">
				<a href="../../preguntas-frecuentes/index.php"><span class="icon icon-contacto"></span>Ayuda</a>
			</div>
			<div class="col-sm-3 col-xs-3 last">
				<a href="../../empresas/patagonia-ebank-empresas-mbl.php"><span class="icon icon-ebank"></span>Patagonia e-Bank</a>
			</div>
		</div>
	</div>
</div>	<script src="../../assets/js/jquery-3.5.1.min.js"></script>
<script src="../../assets/bootstrap/js/bootstrap.min.js"></script>
<script src="../../assets/js/slick/slick.min.js"></script>
<script src="../../assets/js/fancybox/jquery.fancybox.min.js"></script>
<script src="../../assets/js/mtabs/jquery.bootstrap-responsive-tabs.min.js"></script>
<script src="../../assets/js/funciones.js"></script>

<!-- Global site tag (gtag.js) - Google Analytics (original) -->
<!--
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-32588129-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-32588129-1');
</script>
-->

<!-- Google Analytics (version anterior / eventos ok)  -->
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');
  ga('create', 'UA-32588129-1', 'auto');
  ga('send', 'pageview');
</script>

<!-- GA4 - Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-C6LG1PT98X"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-C6LG1PT98X');
</script>
</body>
</html>