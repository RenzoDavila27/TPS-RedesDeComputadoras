<!DOCTYPE html>
<html lang="es">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
		<meta http-equiv="Pragma" content="no-cache">
		<meta http-equiv="Expires" content="0">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Empresas | Banco Patagonia</title>
		<meta name="description" content="Descubrí en Banco Patagonia el aliado estratégico para potenciar tu empresa con soluciones financieras personalizadas y eficientes.">
		<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-NL73B44');</script>
<!-- End Google Tag Manager -->

<link rel="shortcut icon" href="../favicon.ico" type="image/x-icon"/>
<link href="../assets/fonts/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="../assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="../assets/js/mtabs/bootstrap-responsive-tabs.css" rel="stylesheet" type="text/css">
<link href="../assets/js/slick/slick.css" rel="stylesheet" type="text/css">
<link href="../assets/js/fancybox/jquery.fancybox.min.css" rel="stylesheet" type="text/css">
<link href="../assets/css/styles.css" rel="stylesheet" type="text/css">
<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->        <!-- BANNERS FIJOS (4) -->
        <style>
            .h-destacado figcaption { width: 100%; text-transform: none;}
            @media screen and (max-width: 380px) {
                .h-destacados .col-xs-6 { width: 100%;}
            }
        </style>
        <!-- SLIDES RESPONSIVE -->
        <style>
            /* DSK */
			#slide-expo-agro { background-image: url(../agro/images/main-slider/slide-expo-agro-dsk.jpg); background-image: -webkit-image-set ( url("../agro/images/main-slider/slide-expo-agro-dsk.jpg") 1x, url("../agro/images/main-slider/slide-expo-agro-dsk@2x.jpg") 2x ); }
			#slide-prestamo-comercial { background-image: url(images/main-slider/slide-prestamo-comercial-dsk.jpg); background-image: -webkit-image-set ( url("images/main-slider/slide-prestamo-comercial-dsk.jpg") 1x, url("images/main-slider/slide-prestamo-comercial-dsk@2x.jpg") 2x ); }
			#slide-rio-negro { background-image: url(../sector-publico/images/main-slider/slide-rio-negro-dsk.jpg); background-image: -webkit-image-set ( url("../sector-publico/images/main-slider/slide-rio-negro-dsk.jpg") 1x, url("../sector-publico/images/main-slider/slide-rio-negro-dsk@2x.jpg") 2x ); }
			#slide-alta-plazos-fijos {background-image: url(images/main-slider/slide-alta-plazos-fijos-dsk.jpg)}
            #slide-pago-servicios {background-image: url(images/main-slider/slide-pago-servicios-dsk.jpg)}
            #slide-descuento-echeq {background-image: url(images/main-slider/slide-descuento-echeq-dsk.jpg)}
            #slide-emision-masiva-echeq {background-image: url(images/main-slider/slide-emision-masiva-echeq-dsk.jpg)}
            #slide-opciones-de-fondos {background-image: url(../personas/images/main-slider/slide-opciones-de-fondos-dsk.jpg)}
			/*#slide-wapa {background-image: url(../personas/images/main-slider/slide-wapa-dsk.jpg)}*/
			/*#slide-cuenta-recaudadora {background-image: url(images/main-slider/slide-cuenta-recaudadora-dsk.jpg)}*/
            /*#slide-cobros-con-qr {background-image: url(../personas/images/main-slider/slide-cobros-con-qr-dsk.jpg)}*/
			/*#slide-patagonia-movil-empresas {background-image: url(images/main-slider/slide-patagonia-movil-empresas-dsk.jpg)}*/
            /*#slide-seguro-tecno-empresas {background-image: url(images/main-slider/slide-seguro-tecno-empresas-dsk.jpg)}*/
			/*#slide-patagonia-ebank-empresas {background-image: url(images/main-slider/slide-patagonia-ebank-empresas-dsk.jpg)}*/

            @media screen and (max-width: 1200px) {
                /* TBT */
				#slide-expo-agro { background-image: url(../agro/images/main-slider/slide-expo-agro-tbl.jpg); background-size: auto !important; background-image: -webkit-image-set ( url("../agro/images/main-slider/slide-expo-agro-tbl.jpg") 1x, url("../agro/images/main-slider/slide-expo-agro-tbl@2x.jpg") 2x ); }
				#slide-prestamo-comercial { background-image: url(images/main-slider/slide-prestamo-comercial-tbl.jpg); background-size: auto !important; background-image: -webkit-image-set ( url("images/main-slider/slide-prestamo-comercial-tbl.jpg") 1x, url("images/main-slider/slide-prestamo-comercial-tbl@2x.jpg") 2x ); }
				#slide-rio-negro { background-image: url(../sector-publico/images/main-slider/slide-rio-negro-tbl.jpg); background-size: auto !important; background-image: -webkit-image-set ( url("../sector-publico/images/main-slider/slide-rio-negro-tbl.jpg") 1x, url("../sector-publico/images/main-slider/slide-rio-negro-tbl@2x.jpg") 2x ); }
				#slide-alta-plazos-fijos {background-image: url(images/main-slider/slide-alta-plazos-fijos-tbl.jpg); background-size: auto !important ;}
                #slide-pago-servicios {background-image: url(images/main-slider/slide-pago-servicios-tbl.jpg); background-size: auto !important ;}
                #slide-descuento-echeq {background-image: url(images/main-slider/slide-descuento-echeq-tbl.jpg); background-size: auto !important ;}
                #slide-emision-masiva-echeq {background-image: url(images/main-slider/slide-emision-masiva-echeq-tbl.jpg); background-size: auto !important ;}
                #slide-opciones-de-fondos {background-image: url(../personas/images/main-slider/slide-opciones-de-fondos-tbl.jpg); background-size: auto !important ;}
				/*#slide-wapa {background-image: url(../personas/images/main-slider/slide-wapa-tbl.jpg); background-size: auto !important ;}*/
				/*#slide-cuenta-recaudadora {background-image: url(images/main-slider/slide-cuenta-recaudadora-tbl.jpg); background-size: auto !important ;}*/
                /*#slide-cobros-con-qr {background-image: url(../personas/images/main-slider/slide-cobros-con-qr-tbl.jpg); background-size: auto !important ;}*/
				/*#slide-patagonia-movil-empresas {background-image: url(images/main-slider/slide-patagonia-movil-empresas-tbl.jpg); background-size: auto !important ;}*/
                /*#slide-seguro-tecno-empresas {background-image: url(images/main-slider/slide-seguro-tecno-empresas-tbl.jpg); background-size: auto !important ;}*/
				/*#slide-patagonia-ebank-empresas {background-image: url(images/main-slider/slide-patagonia-ebank-empresas-tbl.jpg); background-size: auto !important ;}*/
            }
            @media screen and (max-width: 560px) {
                /* MBL */
				#slide-expo-agro { background-image: url(../agro/images/main-slider/slide-expo-agro-mbl.jpg); background-image: -webkit-image-set ( url("../agro/images/main-slider/slide-expo-agro-mbl.jpg") 1x, url("../agro/images/main-slider/slide-expo-agro-mbl@2x.jpg") 2x ); }
				#slide-prestamo-comercial { background-image: url(images/main-slider/slide-prestamo-comercial-mbl.jpg); background-image: -webkit-image-set ( url("images/main-slider/slide-prestamo-comercial-mbl.jpg") 1x, url("images/main-slider/slide-prestamo-comercial-mbl@2x.jpg") 2x ); }
				#slide-rio-negro { background-image: url(../sector-publico/images/main-slider/slide-rio-negro-mbl.jpg); background-image: -webkit-image-set ( url("../sector-publico/images/main-slider/slide-rio-negro-mbl.jpg") 1x, url("../sector-publico/images/main-slider/slide-rio-negro-mbl@2x.jpg") 2x ); }
				#slide-alta-plazos-fijos {background-image: url(images/main-slider/slide-alta-plazos-fijos-mbl.jpg)}
                #slide-pago-servicios {background-image: url(images/main-slider/slide-pago-servicios-mbl.jpg)}
                #slide-descuento-echeq {background-image: url(images/main-slider/slide-descuento-echeq-mbl.jpg)}
                #slide-emision-masiva-echeq {background-image: url(images/main-slider/slide-emision-masiva-echeq-mbl.jpg)}
                #slide-opciones-de-fondos {background-image: url(../personas/images/main-slider/slide-opciones-de-fondos-mbl.jpg)}
				/*#slide-wapa {background-image: url(../personas/images/main-slider/slide-wapa-mbl.jpg)}*/
				/*#slide-cuenta-recaudadora {background-image: url(images/main-slider/slide-cuenta-recaudadora-mbl.jpg)}*/
                /*#slide-cobros-con-qr {background-image: url(../personas/images/main-slider/slide-cobros-con-qr-mbl.jpg)}*/
				/*#slide-patagonia-movil-empresas {background-image: url(images/main-slider/slide-patagonia-movil-empresas-mbl.jpg)}*/
                /*#slide-seguro-tecno-empresas {background-image: url(images/main-slider/slide-seguro-tecno-empresas-mbl.jpg)}*/
				/*#slide-patagonia-ebank-empresas {background-image: url(images/main-slider/slide-patagonia-ebank-empresas-mbl.jpg)}*/
            }
        </style>
        <!-- -->
	</head>
<body>
	<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NL73B44"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

<div class="placeholder-bar">
	<div class="container-fluid header-bar">
		<div class="row">
			<header class="container">
				<div class="row">
					<div class="col-md-3 col-dsk-6 col-sm-6">
						<span class="c-hamburger c-hamburger--htx">
							<span>toggle menu</span>
						</span>
                        <!-- -->
                        <!--<img style="position: absolute; width: 42px; top: 20px; right: 40px;" class="dsk" src="<php echo $path ?>assets/images/layout/icon-verano-2022.svg">-->
                        <!-- -->
						<h1>
                            <!--<img style="position: absolute; width: 32px; top: 12px; left: 102px;" class="dsk" src="<php echo $path ?>assets/images/layout/icon-navidad-2021.svg">-->
                            <a href="../index.php" class="main-logo">Banco Patagonia</a>
                        </h1>
					</div>
					<div class="col-md-9 col-dsk-6 col-sm-6">
						<div class="general-links">
							<ul class="list-unstyled">
                                								<li><a href="../preguntas-frecuentes/index.php" class="">Ayuda</a></li>
								<!--<li><a href="<php echo $folder_canales ?>index.php" class="<php echo $canales ?>">Canales de atención</a></li>-->
								<!--<li><a href="http://sucursalesycajeros.bancopatagonia.com.ar/sucursales.html" target="_blank">Sucursales y cajeros</a></li>-->
								<!--<li><a href="<php echo $folder_contactenos ?>index.php" class="<php echo $contactenos ?>">Contactanos</a></li>-->
                                <!--<li><a href="<php echo $path ?>ayuda/index.php" class="<php echo $ayuda ?>">Ayuda</a></li>-->
							</ul>
						</div>
						<div class="top-links">
							<ul class="list-unstyled">
								<li><a href="../personas/index.php" class="">PERSONAS</a></li>
								<li><a href="../nyps/index.php" class="">PROFESIONALES Y COMERCIOS</a></li>
								<li><a href="../pyme/index.php" class="">PYME</a></li>
								<li><a href="../agro/index.php" class="">AGRO</a></li>
								<li><a href="index.php" class="active">EMPRESAS</a></li>
								<li><a href="../sector-publico/index.php" class="">SECTOR PÚBLICO</a></li>
								<li><a href="../institucional/index.php" class="">INSTITUCIONAL</a></li>
							</ul>
							<div class="ebank">
                            <!-- antes href: <php echo $folder_empresas ?><php echo $url_ebank ?>-->
														
								<a href="https://ebankempresas.bancopatagonia.com.ar/desktop-webserver/sso" target="_blank" class="patagonia-ebank-empresas">Patagonia e-Bank Empresas</a>
														</div>
						</div>
					</div>
				</div>
			</header>
		</div>
	</div>
</div>

<div class="container-fluid nav-bar">
	<div class="row">
		<nav class="container">
			<div class="row">
				<!--<div class="col-md-9 col-md-offset-3">-->
                <div class="col-md-10 col-md-offset-3"><!-- ajuste agro -->
					<ul class="list-unstyled sub-navbar">
						
						                        
                                                
                                                
                        						
												<!-- EMPRESAS -->
						<li class="nav-item"><a href="#" class="nav-lnk ">PATAGONIA SUELDO</a>
							<ul class="list-unstyled submenu">
								<li><a href="patagonia-sueldo/servicios.php">Servicios</a></li>
								<li><a href="patagonia-sueldo/preguntas-frecuentes.php">Preguntas Frecuentes</a></li>
								<li><a href="patagonia-sueldo/guia-implementacion.php">Guía de Implementación</a></li>
							</ul>
						</li>
						<li class="nav-item"><a href="#" class="nav-lnk ">COMERCIO EXTERIOR</a>
							<ul class="list-unstyled submenu">
								<li><a href="comercio-exterior/solicitud-electronica.php">Solicitud Electrónica</a></li>
								<li><a href="comercio-exterior/productos.php">Productos</a></li>
								<li><a href="comercio-exterior/otros-servicios.php">Servicios</a></li>
								<!--<li><a href="<php echo $folder_Cexterior ?>financiaciones.php">Financiaciones</a></li>-->
                                <li><a href="comercio-exterior/herramientas-para-exportar.php">Herramientas para Exportar</a></li>
								<li><a href="comercio-exterior/marco-regulatorio/normas-y-regulaciones.php">Marco Regulatorio</a></li>
							</ul>
						</li>
                        <!-- -->
						<!--<li class="nav-item"><a href="comunidades-de-negocios/index.php" class="nav-lnk ">COMUNIDADES DE NEGOCIOS</a></li>-->
                        <!-- -->
                        <li class="nav-item"><a href="comercios-patagonia/index.php" class="nav-lnk ">COMERCIOS PATAGONIA</a></li>
						<li class="nav-item"><a href="#" class="nav-lnk ">FINANCIACIÓN</a>
							<ul class="list-unstyled submenu">
								<li><a href="financiacion/patagonia-leasing.php">Patagonia Leasing</a></li>
								<li><a href="financiacion/mercado-capitales.php">Mercado de Capitales</a></li>
								<li><a href="financiacion/alternativas-de-financiacion.php">Alternativas de Financiación</a></li>
                                <li><a href="financiacion/convenios-de-financiacion.php">Convenios de Financiación</a></li>
							</ul>
						</li>
						<li class="nav-item"><a href="#" class="nav-lnk ">INVERSIONES</a>
							<ul class="list-unstyled submenu">
								<li><a href="inversiones/plazos-fijos.php">Plazos Fijos</a></li>
								<li><a href="inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
								<li><a href="inversiones/compra-venta-titulos-acciones.php">Compra - Venta de Títulos y Acciones</a></li>
								<li><a href="inversiones/custodia-de-titulos.php">Custodia de Títulos</a></li>
								<li><a href="inversiones/fidecomisos-financieros.php">Fidecomisos Financieros</a></li>
							</ul>
						</li>
						<li class="nav-item"><a href="#" class="nav-lnk ">SERVICIOS</a>
							<ul class="list-unstyled submenu">
                                <li><a href="patagonia-movil-empresas.php">Patagonia Móvil Empresas</a></li>
								<li><a href="servicios/pagos.php">Pagos</a></li>
								<li><a href="servicios/recaudaciones.php">Recaudaciones</a></li>
								<li><a href="servicios/pago-de-servicios.php">Pago de Servicios</a></li>
								<li><a href="servicios/interbanking.php">Interbanking</a></li>
								<li><a href="servicios/interfacturas.php">Interfacturas</a></li>
								<li><a href="servicios/tarjetas-comerciales.php">Tarjetas Comerciales</a></li>
								<!--<li><a href="servicios/comercios-patagonia.php">Comercios Patagonia</a></li>-->
                                <li><a href="servicios/centro-atencion-empresas.php">Centro de Atención para Empresas</a></li>
							</ul>
						</li>
						<!-- FIN EMPRESAS -->
												
												
						
											</ul>
				</div>
			</div>
		</nav>
	</div>
</div>

<div class="mobile-nav-bar">
	<ul class="list-unstyled">
        
        <!-- PERSONAS -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">PERSONAS <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../personas/index.php" class="">HOME</a></li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA CLÁSICA</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../personas/patagonia-clasica/patagonia-ahorro/productos.php">Patagonia Ahorro</a></li>
                        <li><a href="../personas/patagonia-clasica/paquete/productos.php">Patagonia Clásica</a></li>
                        <!--<li><a href="<php echo $path ?>personas/patagonia-clasica/mas/productos.php">Patagonia Clásica Más</a></li>-->
                        <li><a href="../personas/patagonia-clasica/premium/productos.php">Patagonia Clásica Premium</a></li>
                        <li><a href="../personas/patagonia-clasica/patagonia-sueldo/productos.php">Patagonia Sueldo</a></li>
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA PLUS</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../personas/patagonia-plus/productos.php">Patagonia Plus</a></li>
                        <li><a href="../personas/patagonia-plus/premium/productos.php">Patagonia Plus Premium</a></li>
                    </ul>						
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA SINGULAR</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../personas/patagonia-singular/paquete/propuesta.php">Patagonia Singular</a></li>
                        <li><a href="../personas/patagonia-singular/beneficios-exclusivos.php">Beneficios Exclusivos</a></li>
                        <!--<li><a href="<php echo $path ?>personas/patagonia-singular/atencion-exclusiva/index.php">Atención Exclusiva</a></li>-->
                        <!--<li><a href="<php echo $path ?>personas/patagonia-singular/eventos-y-novedades/index.php">Eventos y Novedades</a></li>-->
                    </ul>
                </li>
				<!--<li class="nav-sub-item"><a href="<php echo $path ?>patagoniaon/index.php" target="_blank">PATAGONIA ON</a></li>-->
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA ON</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../patagoniaon/index.php" target="_blank">Patagonia ON</a></li>
						<li><a href="../personas/productos-y-servicios/patagonia-universitaria.php">Patagonia ON Universitaria</a></li>
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PRODUCTOS Y SERVICIOS</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../personas/apple-pay.php">Apple Pay</a></li>
                        <li><a href="../personas/productos-y-servicios/caja-de-seguridad.php">Caja de Seguridad</a></li>
                        <li><a href="../personas/productos-y-servicios/comercio-exterior/productos.php">Comercio exterior</a></li>
						<!--<li><a href="<php echo $path ?>personas/productos-y-servicios/beneficios-wapa.php">Comercios WAPA</a></li>-->
						<li><a href="../personas/cuotifica-al-toque.php">Cuotificá al Toque</a></li>
						<li><a href="../personas/google-pay.php">Google Pay</a></li>
                        <li><a href="../personas/productos-y-servicios/inversiones.php">Inversiones</a></li>
                        <li><a href="../personas/jubilados/index.php">Jubilados</a></li>
                        <li><a href="../personas/productos-y-servicios/patagonia-para-menores.php">Patagonia para Menores</a></li>
                        <!--<li><a href="<php echo $path ?>personas/productos-y-servicios/patagonia-universitaria.php">Patagonia Universitaria</a></li>-->
                        <li><a href="../personas/productos-y-servicios/prestamos.php">Prestamos</a></li>
                        <li><a href="../personas/seguros/index.php">Seguros</a></li>
                        <li><a href="../personas/productos-y-servicios/tarjetas-de-credito/visa.php">Tarjetas de crédito</a></li>
                        <li><a href="../personas/productos-y-servicios/tarjetas-de-debito/patagonia-24.php">Tarjetas de débito</a></li>
                    </ul>
                </li>
			</ul>
		</li>
        <!-- FIN PERSONAS -->
        
        <!-- NYPS -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">PROFESIONALES Y COMERCIOS <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../nyps/index.php" class="">HOME</a></li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA CLÁSICA</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../nyps/patagonia-clasica/premium/productos.php">Patagonia Clásica Premium</a></li>
                        <li><a href="../nyps/patagonia-clasica/patagonia-emprendimiento/productos.php">Patagonia Emprendimiento</a></li>
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA PLUS</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../nyps/patagonia-plus/productos.php">Patagonia Plus</a></li>
                        <li><a href="../nyps/patagonia-plus/premium/productos.php">Patagonia Plus Premium</a></li>
                    </ul>						
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA SINGULAR</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../nyps/patagonia-singular/paquete/propuesta.php">Patagonia Singular</a></li>
                        <li><a href="../nyps/patagonia-singular/beneficios-exclusivos.php">Beneficios Exclusivos</a></li>
                        <!--<li><a href="<php echo $path ?>nyps/patagonia-singular/eventos-y-novedades/index.php">Eventos y Novedades</a></li>-->
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PRODUCTOS Y SERVICIOS</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../nyps/productos-y-servicios/tarjetas-de-debito/patagonia-24.php">Tarjetas de débito</a></li>
                        <li><a href="../nyps/productos-y-servicios/tarjetas-de-credito/visa.php">Tarjetas de crédito</a></li>
                        <li><a href="../nyps/productos-y-servicios/prestamos.php">Prestamos</a></li>
                        <li><a href="../nyps/seguros/index.php">Seguros</a></li>
                        <li><a href="../nyps/productos-y-servicios/inversiones.php">Inversiones</a></li>
                        <li><a href="../nyps/productos-y-servicios/comercio-exterior/productos.php">Comercio exterior</a></li>
                        <li><a href="../nyps/productos-y-servicios/caja-de-seguridad.php">Caja de Seguridad</a></li>
                        <li><a href="../nyps/productos-y-servicios/factura-electronica.php">Factura electrónica</a></li>
                        <li><a href="../nyps/productos-y-servicios/pagos-afip.php">Pagos AFIP</a></li>
                        <!--<li><a href="<php echo $path ?>nyps/productos-y-servicios/soluciones-para-tu-empresa.php">Soluciones para tu empresa</a></li>-->
                        <!--<li><a href="<php echo $path ?>nyps/productos-y-servicios/comercios-patagonia.php">Comercios Patagonia</a></li>-->
						<li><a href="../nyps/productos-y-servicios/wapa.php">WAPA</a></li>
                    </ul>
                </li>
			</ul>		
		</li>
        <!-- FIN NYPS -->
        
        <!-- PYME -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">PYME <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../pyme/index.php" class="">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">CUENTAS</a>
					<ul class="list-unstyled submenu">
                        <li><a href="../pyme/cuentas/pequenas-empresas.php">Pyme Pequeñas Empresas</a></li>
				        <li><a href="../pyme/cuentas/medianas-empresas.php">Pyme Medianas Empresas</a></li>
                        <!--
						<li><a href="../pyme/cuentas/patagonia-empresario.php">Patagonia Empresario</a></li>
						<li><a href="../pyme/cuentas/patagonia-empresario-premier.php">Patagonia Empresario Premier</a></li>
						<li><a href="../pyme/cuentas/patagonia-empresa.php">Patagonia Empresa</a></li>
                        -->
                        <!--<li><a href="../pyme/cuentas/patagonia-comercio.php">Patagonia Comercio</a></li>-->
                        <li><a href="../pyme/cuentas/patagonia-consorcio.php">Patagonia Consorcio</a></li>
						<li><a href="../pyme/cuentas/cuenta-corriente.php">Cuenta Corriente</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA SUELDO</a>
					<ul class="list-unstyled submenu">
						<li><a href="../pyme/patagonia-sueldo/servicios.php">Servicios</a></li>
						<li><a href="../pyme/patagonia-sueldo/preguntas-frecuentes.php">Preguntas Frecuentes</a></li>
						<li><a href="../pyme/patagonia-sueldo/guia-implementacion.php">Guía de Implementación</a></li>
					</ul>
				</li>						
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">COMERCIO EXTERIOR</a>
					<ul class="list-unstyled submenu">
						<li><a href="../pyme/comercio-exterior/solicitud-electronica.php">Solicitud Electrónica</a></li>
						<li><a href="../pyme/comercio-exterior/productos.php">Productos</a></li>
						<li><a href="../pyme/comercio-exterior/otros-servicios.php">Servicios</a></li>
						<!--<li><a href="<php echo $folder_pymeCexterior ?>financiaciones.php">Financiaciones</a></li>-->
                        <li><a href="../pyme/comercio-exterior/herramientas-para-exportar.php">Herramientas para Exportar</a></li>
						<li><a href="../pyme/comercio-exterior/marco-regulatorio/normas-y-regulaciones.php">Marco Regulatorio</a></li>
					</ul>
				</li>						
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">FINANCIACIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../pyme/financiacion/patagonia-leasing.php">Patagonia Leasing</a></li>
						<li><a href="../pyme/financiacion/mercado-capitales.php">Mercado de Capitales</a></li>
						<li><a href="../pyme/financiacion/alternativas-de-financiacion.php">Alternativas de Financiación</a></li>
					</ul>
				</li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">SEGUROS</a>
					<ul class="list-unstyled submenu">
						<li><a href="../pyme/seguros/protege-tus-bienes/integral-comercio.php">Protegé tus Bienes</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">INVERSIONES</a>
					<ul class="list-unstyled submenu">
						<li><a href="../pyme/inversiones/plazo-fijo.php">Plazo Fijo</a></li>
						<li><a href="../pyme/inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
						<li><a href="../pyme/inversiones/fidecomisos-financieros.php">Fidecomisos Financieros</a></li>
					</ul>
				</li>						
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">SERVICIOS</a>
					<ul class="list-unstyled submenu">
						<li><a href="../pyme/servicios/recaudaciones.php">Recaudaciones</a></li>
						<li><a href="../pyme/servicios/pagos.php">Pagos</a></li>
						<li><a href="../pyme/servicios/tarjetas-comerciales.php">Tarjetas Comerciales</a></li>
						<li><a href="../pyme/servicios/comercios-patagonia.php">Comercios Patagonia</a></li>
                        <li><a href="../pyme/servicios/pago-de-servicios.php">Pago de Servicios</a></li>
						<li><a href="../pyme/servicios/interbanking.php">Interbanking</a></li>
						<li><a href="../pyme/servicios/interfacturas.php">Interfacturas</a></li>
						<li><a href="../pyme/servicios/pagos-afip.php">Pagos AFIP</a></li>
						<li><a href="../pyme/servicios/wapa.php">WAPA</a></li>
					</ul>
				</li>
			</ul>		
		</li>
        <!-- FIN PYME -->
        
        <!-- AGRO -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">AGRO <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../agro/index.php" class="">HOME</a></li>
                <!-- -->
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">OFERTA AGRO</a>
					<ul class="list-unstyled submenu">
                    	<!--<li><a href="<php echo $folder_agroFinanciacion ?>insumos.php">Insumos en USD</a></li>-->
                        <li><a href="../agro/convenios/acuerdos-y-beneficios.php">Acuerdos y convenios</a></li>
						<li><a href="../agro/financiacion/maquinaria-agricola.php">Financiación Maquinaria Agrícola</a></li>
						<li><a href="../agro/seguros/campo.php">Seguros para tu campo</a></li>
					</ul>
				</li>
                <!-- -->
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">TARJETA PATAGONIA AGRO</a>
					<ul class="list-unstyled submenu">
						<li><a href="../agro/tarjeta-patagonia-agro/para-usuarios.php">Para Usuarios</a></li>
						<li><a href="../agro/tarjeta-patagonia-agro/para-comercios.php">Para Comercios</a></li>
						<li><a href="../agro/tarjeta-patagonia-agro/acuerdo-tasa-0.php">Tarjetas Agro Convenios Preferenciales</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="../agro/cuenta-agro/cuenta-agro.php" class="">CUENTA AGRO</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">FINANCIACIÓN</a>
					<ul class="list-unstyled submenu">
                        <li><a href="../agro/insumos/index.php">Insumos</a></li>
                        <li><a href="../agro/financiacion/maquinaria-agricola.php">Maquinarias</a></li>
                        <li><a href="financiacion/convenios-de-financiacion.php">Camiones</a></li>
						<!--<li><a href="<php echo $folder_agroFinanciacion ?>capital-de-trabajo.php">Capital de Trabajo</a></li>-->
						<!--<li><a href="<php echo $folder_agroFinanciacion ?>proyectos-de-inversion.php">Proyectos de Inversión</a></li>-->
						<!--<li><a href="<php echo $folder_agroFinanciacion ?>creditos-para-hacienda.php">Créditos para Hacienda</a></li>-->
						<!--<li><a href="<php echo $folder_agroFinanciacion ?>leasing-y-prendarios.php">Leasing y Prendarios</a></li>-->
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">INVERSIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../agro/inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
						<li><a href="../agro/inversiones/fidecomisos-financieros.php">Fidecomisos Financieros</a></li>
						<li><a href="../agro/inversiones/plazos-fijos.php">Plazos Fijos</a></li>
					</ul>
				</li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">COMERCIO EXTERIOR</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../agro/comercio-exterior/solicitud-electronica.php">Solicitud Electrónica</a></li>
                        <li><a href="../agro/comercio-exterior/productos.php">Productos</a></li>
                        <li><a href="../agro/comercio-exterior/otros-servicios.php">Servicios</a></li>
                        <li><a href="../agro/comercio-exterior/herramientas-para-exportar.php">Herramientas para Exportar</a></li>
                        <li><a href="../agro/comercio-exterior/marco-regulatorio/normas-y-regulaciones.php">Marco Regulatorio</a></li>
                    </ul>
                </li>
                <!--
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">SERVICIOS</a>
					<ul class="list-unstyled submenu">
						<li><a href="../agro/servicios/centro-atencion-empresas.php">Centro de Atención para Empresas</a></li>
					</ul>
				</li>
                -->
                <!-- -->
                <li class="nav-sub-item"><a href="../agro/seguros/campo.php" class="">SEGUROS</a></li>
                <!-- -->
			</ul>
		</li>
        <!-- FIN AGRO -->
        
        <!-- EMPRESAS -->
		<li class="nav-main-item"><a href="#" class="has-sub-items active">EMPRESAS <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="index.php" class="active">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA SUELDO</a>
					<ul class="list-unstyled submenu">
						<li><a href="patagonia-sueldo/servicios.php">Servicios</a></li>
						<li><a href="patagonia-sueldo/preguntas-frecuentes.php">Preguntas Frecuentes</a></li>
						<li><a href="patagonia-sueldo/guia-implementacion.php">Guía de Implementación</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">COMERCIO EXTERIOR</a>
					<ul class="list-unstyled submenu">
						<li><a href="comercio-exterior/solicitud-electronica.php">Solicitud Electrónica</a></li>
						<li><a href="comercio-exterior/productos.php">Productos</a></li>
						<li><a href="comercio-exterior/otros-servicios.php">Servicios</a></li>
						<!--<li><a href="<php echo $folder_Cexterior ?>financiaciones.php">Financiaciones</a></li>-->
                        <li><a href="comercio-exterior/herramientas-para-exportar.php">Herramientas para Exportar</a></li>
						<li><a href="comercio-exterior/marco-regulatorio/normas-y-regulaciones.php">Marco Regulatorio</a></li>
					</ul>
				</li>
                <!-- -->
				<!--<li class="nav-sub-item"><a href="comunidades-de-negocios/index.php" class="">COMUNIDADES DE NEGOCIOS</a></li>-->
                <!-- -->
				<li class="nav-sub-item"><a href="comercios-patagonia/index.php" class="nav-lnk ">COMERCIOS PATAGONIA</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">FINANCIACIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="financiacion/patagonia-leasing.php">Patagonia Leasing</a></li>
						<li><a href="financiacion/mercado-capitales.php">Mercado Capitales</a></li>
						<li><a href="financiacion/alternativas-de-financiacion.php">Alternativas de Financiación</a></li>
                        <li><a href="financiacion/convenios-de-financiacion.php">Convenios de Financiación</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">INVERSIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="inversiones/plazos-fijos.php">Plazos Fijos</a></li>
						<li><a href="inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
						<li><a href="inversiones/compra-venta-titulos-acciones.php">Compra - Venta de Títulos y Acciones</a></li>
						<li><a href="inversiones/custodia-de-titulos.php">Custodia de Títulos</a></li>
						<li><a href="inversiones/fidecomisos-financieros.php">Fidecomisos Financieros</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">SERVICIOS</a>
					<ul class="list-unstyled submenu">
                        <li><a href="patagonia-movil-empresas.php">Patagonia Móvil Empresas</a></li>
						<li><a href="servicios/pagos.php">Pagos</a></li>
						<li><a href="servicios/recaudaciones.php">Recuadaciones</a></li>
						<li><a href="servicios/pago-de-servicios.php">Pago de Servicios</a></li>
						<li><a href="servicios/interbanking.php">Interbanking</a></li>
						<li><a href="servicios/interfacturas.php">Interfacturas</a></li>
						<li><a href="servicios/tarjetas-comerciales.php">Tarjetas Comerciales</a></li>
                        <!-- -->
						<!--<li><a href="servicios/comercios-patagonia.php">Comercios Patagonia</a></li>-->
                        <!-- -->
                        <li><a href="servicios/centro-atencion-empresas.php">Centro de Atención para Empresas</a></li>
					</ul>
				</li>
			</ul>
		</li>
        <!-- FIN EMPRESAS -->
        
        <!-- SECTOR PÚBLICO -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">SECTOR PÚBLICO <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../sector-publico/index.php" class="">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">INVERSIONES</a>
					<ul class="list-unstyled submenu">
						<li><a href="../sector-publico/inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
						<li><a href="../sector-publico/inversiones/plazo-fijo.php">Plazo Fijo</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">SERVICIOS</a>
					<ul class="list-unstyled submenu">
						<li><a href="../sector-publico/servicios/servicio-de-recaudacion.php">Servicio de Recaudación</a></li>
						<li><a href="../sector-publico/servicios/servicio-de-pagos.php">Servicio de Pagos</a></li>
						<li><a href="../sector-publico/servicios/servicios-para-personal.php">Servicios para el Personal</a></li>
						<li><a href="../sector-publico/servicios/financiacion.php">Financiación</a></li>
						<li><a href="../sector-publico/servicios/otros-servicios.php">Servicios</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">PROGRAMA UNIVERSIDADES</a>
					<ul class="list-unstyled submenu">
						<li><a href="../sector-publico/programa-universidades/relacion-institucional.php">Relación Institucional</a></li>
						<li><a href="../sector-publico/programa-universidades/docentes-yno-docentes.php">Docentes y No Docentes</a></li>
						<li><a href="../sector-publico/programa-universidades/alumnos.php">Alumnos</a></li>
						<li><a href="../sector-publico/programa-universidades/graduados.php">Graduados</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">BENEFICIOS RÍO NEGRO</a>
					<ul class="list-unstyled submenu">
						<li><a href="../sector-publico/rio-negro/presencia.php">Presencia en Río Negro</a></li>
                        <li><a href="../sector-publico/rio-negro/propuesta-valor.php">Propuesta de valor exclusiva</a></li>
					</ul>
				</li>
			</ul>
		</li>
        <!-- FIN SECTOR PUBLICO -->
        
        <!-- INSTITUCIONAL -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">INSTITUCIONAL <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../institucional/index.php" class="">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">BANCO PATAGONIA</a>
					<ul class="list-unstyled submenu">
						<li><a href="../institucional/banco-patagonia/historia.php">Historia</a></li>
						<li><a href="../institucional/banco-patagonia/mercado-de-capitales.php">Mercado de Capitales</a></li>
						<li><a href="../institucional/banco-patagonia/patagonia-inversora.php">Patagonia Inversora</a></li>
						<li><a href="../institucional/banco-patagonia/patagonia-valores-sa.php">Patagonia Valores S.A</a></li>
						<li><a href="https://bp.bancopatagonia.com.ar/relacion-con-inversores/es/institucional" target="_blank">Relación con Inversores</a></li>
						<li><a href="../institucional/banco-patagonia/desarrollo-humano.php">Desarrollo Humano</a></li>
						<li><a href="../institucional/banco-patagonia/sustentabilidad.php">Sustentabilidad</a></li>
						<li><a href="../institucional/banco-patagonia/politicas-aml-cft.php">Póliticas AML/CFT</a></li>
						<li><a href="../institucional/banco-patagonia/disciplina-del-mercado.php">Disciplina de Mercado</a></li>
                        <li><a href="../institucional/banco-patagonia/asistencia-a-vinculados.php">Asistencia a vinculados</a></li>
                        <li><a href="../institucional/banco-patagonia/etica-e-integridad.php">Ética e Integridad</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">ORGANIZACIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../institucional/organizacion/accionistas.php">Accionistas</a></li>
						<li><a href="../institucional/organizacion/autoridades.php">Autoridades</a></li>
                        <li><a href="../institucional/organizacion/comites.php">Comités</a></li>
						<li><a href="../institucional/organizacion/sector-financiero.php">Sector Financiero</a></li>
					</ul>
				</li>
			</ul>
		</li>
        <!-- FIN INSTITUCIONAL -->
        
        		<li class="nav-main-item"><a href="../preguntas-frecuentes/index.php" class="" style="text-transform: none;">Ayuda</a></li>
		<!--<li class="nav-main-item"><a href="<php echo $folder_canales ?>index.php" class="<php echo $canales ?>" style="text-transform: none;">Canales de Atención</a></li>-->
		<!--<li class="nav-main-item"><a href="http://sucursalesycajeros.bancopatagonia.com.ar/sucursales.html" target="_blank" style="text-transform: none;">Sucursales y Cajeros</a></li>-->
		<!--<li class="nav-main-item"><a href="<php echo $folder_contactenos ?>index.php" class="<php echo $contactenos ?>" style="text-transform: none;">Contactanos</a></li>-->
        <!--<li class="nav-main-item"><a href="<php echo $path ?>ayuda/index.php" class="<php echo $ayuda ?>" style="text-transform: none;">Ayuda</a></li>-->
	</ul>
</div>	<div class="main-slider">
		<div class="home-slider">
			<div>
				<div class="home-slide" id="slide-expo-agro">
					<a href="../landings/expo-agro/index.php" target="_blank"></a>
				</div>
			</div>
			<div>
				<div class="home-slide" id="slide-prestamo-comercial">
                    <a href="financiacion/prestamo-comercial.php"></a>
				</div>
			</div>
			<div>
				<div class="home-slide" id="slide-rio-negro">
					<a href="../sector-publico/rio-negro/presencia.php"></a>
				</div>
			</div>
			<div>
				<div class="home-slide" id="slide-alta-plazos-fijos">
                    <a href="inversiones/alta-plazos-fijos.php"></a>
				</div>
			</div>
            <div>
				<div class="home-slide" id="slide-pago-servicios">
                    <a href="servicios/pago-de-servicios.php"></a>
				</div>
			</div>
            <div>
				<div class="home-slide" id="slide-descuento-echeq">
                    <a href="descuento-echeq.php"></a>
				</div>
			</div>
            <div>
				<div class="home-slide" id="slide-emision-masiva-echeq">
                    <a href="servicios/pago-proveedores.php"></a>
				</div>
			</div>
            <div>
				<div class="home-slide xs-head-position-x-85" style="background-image: url(images/main-slider/slide-interbanking.jpg)">
					<!--<a href="https://sib1.interbanking.com.ar/suscripcion/index.jsp" target="_blank">-->
                    <a href="interbanking.php">
                        <!-- oculto en DSK, visible en MBL -->
						<div class="container mbl">
							<div class="row">
								<div class="col-md-6 col-sm-6 col-xs-12">
									<div class="slide-card">
                                        <h4 class="with-border">Factura de Crédito Electrónica MiPyme (FCEM).<br class="dsk"> Sistema de Circulación Abierta (SCA).</h4>
							            <p>Gestionala a través del servicio de <strong>Interbanking S.A.</strong></p>
									</div>
								</div>
							</div>
						</div>
                        <!-- -->
					</a>
				</div>
			</div>
            <div>
				<div class="home-slide" id="slide-opciones-de-fondos">
                    <a href="inversiones/opciones-de-fondos.php"></a>
				</div>
			</div>
            <!--
            <div>
				<div class="home-slide" id="slide-wapa">
                    <a href="wapa.php"></a>
				</div>
			</div>
			-->
			<!--
            <div>
				<div class="home-slide" id="slide-cuenta-recaudadora">
                    <a href="servicios/cuenta-recaudadora.php"></a>
				</div>
			</div>
			-->
			<!--
            <div>
				<div class="home-slide" id="slide-cobros-con-qr">
                    <a href="cobros-con-qr.php"></a>
				</div>
			</div>
			-->
			<!--
            <div>
				<div class="home-slide" id="slide-patagonia-movil-empresas">
                    <a href="patagonia-movil-empresas.php"></a>
				</div>
			</div>
			-->
			<!--
            <div>
				<div class="home-slide" id="slide-seguro-tecno-empresas">
                    <a href="seguros/protege-tus-bienes/tecno.php"></a>
				</div>
			</div>
			-->
			<!--
            <div>
				<div class="home-slide" id="slide-patagonia-ebank-empresas">
                    <a href="https://ebankempresas.bancopatagonia.com.ar/desktop-webserver/sso" target="_blank"></a>
				</div>
			</div>
			-->
		</div>
	</div>
	<section class="container mb60-h h-destacados">
		<div class="row">
			<!--<div class="col-md-3 col-sm-3 col-xs-6">-->
			<div class="col-md-4 col-sm-4 col-xs-4">
				<a href="servicios/recaudaciones.php">
					<div class="h-destacado">
						<figure><img src="images/recaudaciones.jpg" width="359" height="148" alt="Recaudaciones" class="img-responsive"/></figure>
						<figcaption>Recaudaciones</figcaption>
					</div>
				</a>
			</div>
			<!--<div class="col-md-3 col-sm-3 col-xs-6">-->
			<div class="col-md-4 col-sm-4 col-xs-4">
				<a href="comercio-exterior/productos.php">
					<div class="h-destacado">
						<figure><img src="images/comercio-exterior.jpg" width="359" height="148" alt="Comercio Exterior" class="img-responsive"/></figure>
						<figcaption>Comercio Exterior</figcaption>
					</div>
				</a>
			</div>
            <!--<div class="col-md-3 col-sm-3 col-xs-6">-->
			<div class="col-md-4 col-sm-4 col-xs-4">
				<a href="patagonia-sueldo/servicios.php">
					<div class="h-destacado">					
						<figure><img src="images/patagonia-sueldo.jpg" width="359" height="148" alt="Patagonia Sueldo" class="img-responsive"/></figure>
						<figcaption>Patagonia Sueldo</figcaption>					
					</div>
				</a>
			</div>
            <!--<div class="col-md-3 col-sm-3 col-xs-6">
				<a href="lineas-financiamiento.php">
					<div class="h-destacado">
						<figure><img src="images/lineas-financiamiento.jpg" width="359" height="148" alt="Líneas de Financiamiento" class="img-responsive"/></figure>
						<figcaption>Líneas de Financiamiento</figcaption>
					</div>
				</a>
			</div>-->
		</div>
	</section>
	<section class="container mb50-h h-destacado-2s">
		<div class="row equal-height">
			<div class="col-md-3 col-sm-3 col-xs-6">
				<a href="servicios/tarjetas-comerciales.php">
					<div class="h-destacado-2">					
						<h3>Tarjetas comerciales</h3>
						<span class="lnk"><em>+</em> <span>info</span></span>					
					</div>
				</a>
			</div>
			<div class="col-md-3 col-sm-3 col-xs-6">
				<a href="financiacion/patagonia-leasing.php">
					<div class="h-destacado-2">					
						<h3>Leasing</h3>
						<span class="lnk"><em>+</em> <span>info</span></span>					
					</div>
				</a>
			</div>
			<div class="col-md-3 col-sm-3 col-xs-6">
				<a href="servicios/pago-proveedores.php">
					<div class="h-destacado-2 h-destacado-bot">					
						<h3>Pago a Proveedores </h3>
						<span class="lnk"><em>+</em> <span>info</span></span>					
					</div>
				</a>
			</div>
			<div class="col-md-3 col-sm-3 col-xs-6">
				<a href="servicios/pagos-afip.php">
					<div class="h-destacado-2 h-destacado-bot">					
						<h3>Pagos AFIP</h3>
						<span class="lnk"><em>+</em> <span>info</span></span>					
					</div>
				</a>
			</div>
		</div>
	</section>
    <section class="container mb40-h">
		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
				<a href="comisiones-y-cargos.php">
					<div class="h-aviso">
						<h4>COMISIONES Y CARGOS PARA PERSONAS JURÍDICAS</h4>
						<span><em>+</em> info</span>
					</div>
				</a>
			</div>
		</div>
	</section>
    <section class="container mb40-h">
		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
				<a href="condiciones-servicios-personas-juridicas.php">
					<div class="h-aviso">
						<h4>FORMULARIOS DE CONDICIONES DE LOS SERVICIOS PARA PERSONAS JURÍDICAS</h4>
						<span><em>+</em> info</span>
					</div>
				</a>
			</div>
		</div>
	</section>
	
    <section class="container mb40-h">
		<div class="row">
        	<div class="col-md-12 col-sm-12 col-xs-12">
            	<a href="cuentas/regularizacion-activos.php" class="btn-lnk-block">
                	<h3><strong>Cuenta Especial para Regularización de Activos (C.E.R.A.)</strong> - Ley 27.743</h3>
                    <i class="icon icon-more"></i>
                </a>
            </div>
    	</div>
        <!--
		<div class="row">
        	<div class="col-md-12 col-sm-12 col-xs-12">
            	<a href="cuentas/actividad-agricola.php" class="btn-lnk-block">
                	<h3><strong>Cuentas especiales para titulares con actividad agrícola</strong> - Com. A 7595</h3>
                    <i class="icon icon-more"></i>
                </a>
            </div>
    	</div>
		-->
	</section>
	
	<div class="container-fluid footer-bar">
	<div class="row">
		<footer class="container">
			<div class="row">
				<div class="col-md-12">
					<p class="flnks"><a href="../registro-nacional-base-datos.php">Registro Nacional de Base de Datos</a> <span>|</span>   <a href="../codigo-practicas-bancarias.php">Código de Prácticas Bancarias</a> <span>|</span>   <a href="../defensa-ley-consumidor.php">Defensa del Consumidor</a>
						<span>|</span>   <a href="https://www.argentina.gob.ar/produccion/defensadelconsumidor/formulario">Defensa de las y los consumidores. Para reclamos ingrese aquí</a><span>|</span> <br class="tbl"> <a href="../persona-expuesta-politicamente.php">Persona Expuesta Políticamente</a> <span class="tbl">|</span> <br class="dsk">
						
					<a href="../agencia-acceso-informacion-publica.php">Agencia de Acceso a la Información Pública</a> <span>|</span> <br class="tbl"> 
					<a href="../cnv-advertencia-publico-inversor.php">CNV - Advertencia al Público Inversor</a> <span>|</span> <a href="../docs/Idoneos.pdf" target="_blank"> Idóneos en Mercado de Capitales - CNV</a><span>|</span>   <a href="../codigo-proteccion-inversor.php">Código de Protección al Inversor</a> <span>|</span>   <a href="../clausulas-legales.php">Cláusulas Legales</a> <span>|</span> <a href="../resolucion-022021.php">Resol. 02/21 Dir.Gral. Defensa del consumidor Córdoba</a></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<p class="redes">
                        <span>Seguinos en:</span>
                        <!-- -->
                        <a href="https://www.facebook.com/BancoPatagonia/" target="_blank"><img src="../assets/images/layout/icon-facebook.svg" alt="Facebook"></a>
                        <a href="https://twitter.com/banco_patagonia" target="_blank"><img src="../assets/images/layout/icon-twitter.svg" alt="Twitter"></a>
                        <a href="https://www.instagram.com/banco_patagonia/" target="_blank"><img src="../assets/images/layout/icon-instagram.svg" alt="Instagram"></a>
                        <a href="https://www.youtube.com/user/bancopatagonia" target="_blank"><img src="../assets/images/layout/icon-youtube.svg" alt="Youtube"></a>
                        <!-- -->
                        <!--
                        <a href="https://www.facebook.com/BancoPatagonia/" target="_blank"><i class="fa fa-facebook-square"></i></a>
                        <a href="https://twitter.com/banco_patagonia" target="_blank"><i class="fa fa-twitter"></i></a>
                        <a href="https://www.instagram.com/banco_patagonia/" target="_blank"><i class="fa fa-instagram"></i></a>
                        <a href="https://www.youtube.com/user/bancopatagonia" target="_blank"><i class="fa fa-youtube-play"></i></a>
                        -->
                    </p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					                    <!---->
				    <p class="flegal">BANCO PATAGONIA S.A. ES UNA SOCIEDAD ANÓNIMA CONSTITUIDA BAJO LAS LEYES DE LA REPÚBLICA ARGENTINA CUYOS ACCIONISTAS LIMITAN SU RESPONSABILIDAD A LA INTEGRACIÓN DE LAS ACCIONES SUSCRITAS DE ACUERDO A LA LEY 19.550. POR CONSIGUIENTE, Y EN CUMPLIMIENTO DE LA LEY 25.738, SE INFORMA QUE NI LOS ACCIONISTAS MAYORITARIOS DE CAPITAL EXTRANJERO NI LOS ACCIONISTAS LOCALES O EXTRANJEROS RESPONDEN, EN EXCESO DE LA CITADA INTEGRACIÓN ACCIONARIA, POR LAS OBLIGACIONES EMERGENTES DE LAS OPERACIONES CONCERTADAS POR LA ENTIDAD FINANCIERA.</p>
                    <p class="flegal" style="font-size:10px;">Banco Patagonia S.A. - Agente de Liquidacion y Compensacion y Agente de Negociacion Integral, inscripto en CNV bajo el N° 66</p>
					<p class="flegal">© 2025 Banco Patagonia . Todos los derechos reservados. Prohibida la duplicación , distribución o almacenamiento en cualquier medio.</p>
				</div>
			</div>
		</footer>
	</div>
</div>
<div class="tbl mbl placeholder-shortlinks">
	<div class="container shortlinks">
		<div class="row">
            <!--<php if ($home_personas == false) { ?>
                <div class="col-sm-3 col-xs-3">
                    <a href="#"><span class="icon icon-contacto"></span></a>
                </div>
            <php } ?>-->
            			<div class="col-sm-3 col-xs-3">
				<a href="http://sucursalesycajeros.bancopatagonia.com.ar/sucursales.html" target="_blank"><span class="icon icon-sucursales"></span>Sucursales y Cajeros</a>
			</div>
			<div class="col-sm-3 col-xs-3">
				<a href="../preguntas-frecuentes/index.php"><span class="icon icon-contacto"></span>Ayuda</a>
			</div>
			<div class="col-sm-3 col-xs-3 last">
				<a href="patagonia-ebank-empresas-mbl.php"><span class="icon icon-ebank"></span>Patagonia e-Bank</a>
			</div>
		</div>
	</div>
</div>	<script src="../assets/js/jquery-3.5.1.min.js"></script>
<script src="../assets/bootstrap/js/bootstrap.min.js"></script>
<script src="../assets/js/slick/slick.min.js"></script>
<script src="../assets/js/fancybox/jquery.fancybox.min.js"></script>
<script src="../assets/js/mtabs/jquery.bootstrap-responsive-tabs.min.js"></script>
<script src="../assets/js/funciones.js"></script>

<!-- Global site tag (gtag.js) - Google Analytics (original) -->
<!--
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-32588129-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-32588129-1');
</script>
-->

<!-- Google Analytics (version anterior / eventos ok)  -->
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');
  ga('create', 'UA-32588129-1', 'auto');
  ga('send', 'pageview');
</script>

<!-- GA4 - Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-C6LG1PT98X"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-C6LG1PT98X');
</script>
</body>
</html>