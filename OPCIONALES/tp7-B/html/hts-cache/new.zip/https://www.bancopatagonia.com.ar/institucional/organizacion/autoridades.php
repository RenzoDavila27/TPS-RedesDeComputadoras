<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
	<meta http-equiv="Pragma" content="no-cache">
	<meta http-equiv="Expires" content="0">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Autoridades | Institucional | Banco Patagonia</title>
	<meta name="description" content="Conocé las autoridades de Banco Patagonia.">
	<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-NL73B44');</script>
<!-- End Google Tag Manager -->

<link rel="shortcut icon" href="../../favicon.ico" type="image/x-icon"/>
<link href="../../assets/fonts/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="../../assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="../../assets/js/mtabs/bootstrap-responsive-tabs.css" rel="stylesheet" type="text/css">
<link href="../../assets/js/slick/slick.css" rel="stylesheet" type="text/css">
<link href="../../assets/js/fancybox/jquery.fancybox.min.css" rel="stylesheet" type="text/css">
<link href="../../assets/css/styles.css" rel="stylesheet" type="text/css">
<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->    <!-- SLIDES RESPONSIVE -->
    <style>
        /* DSK */
        #head-autoridades {background-image: url(images/head-autoridades-dsk.jpg)}

        @media screen and (max-width: 1200px) {
            /* TBT */
            #head-autoridades {background-image: url(images/head-autoridades-tbl.jpg); background-size: auto !important ;}
        }
        @media screen and (max-width: 560px) {
            /* MBL */
            #head-autoridades {background-image: url(images/head-autoridades-mbl.jpg)}
        }
    </style>
    <!-- -->
</head>

<body>
	<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NL73B44"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

<div class="placeholder-bar">
	<div class="container-fluid header-bar">
		<div class="row">
			<header class="container">
				<div class="row">
					<div class="col-md-3 col-dsk-6 col-sm-6">
						<span class="c-hamburger c-hamburger--htx">
							<span>toggle menu</span>
						</span>
                        <!-- -->
                        <!--<img style="position: absolute; width: 42px; top: 20px; right: 40px;" class="dsk" src="<php echo $path ?>assets/images/layout/icon-verano-2022.svg">-->
                        <!-- -->
						<h1>
                            <!--<img style="position: absolute; width: 32px; top: 12px; left: 102px;" class="dsk" src="<php echo $path ?>assets/images/layout/icon-navidad-2021.svg">-->
                            <a href="../../index.php" class="main-logo">Banco Patagonia</a>
                        </h1>
					</div>
					<div class="col-md-9 col-dsk-6 col-sm-6">
						<div class="general-links">
							<ul class="list-unstyled">
                                								<li><a href="../../preguntas-frecuentes/index.php" class="">Ayuda</a></li>
								<!--<li><a href="<php echo $folder_canales ?>index.php" class="<php echo $canales ?>">Canales de atención</a></li>-->
								<!--<li><a href="http://sucursalesycajeros.bancopatagonia.com.ar/sucursales.html" target="_blank">Sucursales y cajeros</a></li>-->
								<!--<li><a href="<php echo $folder_contactenos ?>index.php" class="<php echo $contactenos ?>">Contactanos</a></li>-->
                                <!--<li><a href="<php echo $path ?>ayuda/index.php" class="<php echo $ayuda ?>">Ayuda</a></li>-->
							</ul>
						</div>
						<div class="top-links">
							<ul class="list-unstyled">
								<li><a href="../../personas/index.php" class="">PERSONAS</a></li>
								<li><a href="../../nyps/index.php" class="">PROFESIONALES Y COMERCIOS</a></li>
								<li><a href="../../pyme/index.php" class="">PYME</a></li>
								<li><a href="../../agro/index.php" class="">AGRO</a></li>
								<li><a href="../../empresas/index.php" class="">EMPRESAS</a></li>
								<li><a href="../../sector-publico/index.php" class="">SECTOR PÚBLICO</a></li>
								<li><a href="../index.php" class="active">INSTITUCIONAL</a></li>
							</ul>
							<div class="ebank">
                            <!-- antes href: <php echo $folder_empresas ?><php echo $url_ebank ?>-->
															<a href="https://ebankpersonas.bancopatagonia.com.ar/eBanking/usuarios/login.htm" class="patagonia-ebank" target="_blank">Patagonia e-Bank</a>
														</div>
						</div>
					</div>
				</div>
			</header>
		</div>
	</div>
</div>

<div class="container-fluid nav-bar">
	<div class="row">
		<nav class="container">
			<div class="row">
				<!--<div class="col-md-9 col-md-offset-3">-->
                <div class="col-md-10 col-md-offset-3"><!-- ajuste agro -->
					<ul class="list-unstyled sub-navbar">
						
						                        
                                                
                                                
                        						
												
												
												<!-- INSTITUCIONAL -->
						<li class="nav-item"><a href="#" class="nav-lnk ">BANCO PATAGONIA</a>
							<ul class="list-unstyled submenu">
								<li><a href="../banco-patagonia/historia.php">Historia</a></li>
								<li><a href="../banco-patagonia/mercado-de-capitales.php">Mercado de Capitales</a></li>
								<li><a href="../banco-patagonia/patagonia-inversora.php">Patagonia Inversora</a></li>
								<li><a href="../banco-patagonia/patagonia-valores-sa.php">Patagonia Valores S.A</a></li>
                                <li><a href="https://bp.bancopatagonia.com.ar/relacion-con-inversores/es/institucional" target="_blank">Relación con Inversores</a></li>
								<li><a href="../banco-patagonia/desarrollo-humano.php">Desarrollo Humano</a></li>
								<li><a href="../banco-patagonia/sustentabilidad.php">Sustentabilidad</a></li>
								<li><a href="../banco-patagonia/politicas-aml-cft.php">Póliticas AML/CFT</a></li>
								<li><a href="../banco-patagonia/disciplina-del-mercado.php">Disciplina de Mercado</a></li>
                                <li><a href="../banco-patagonia/asistencia-a-vinculados.php">Asistencia a vinculados</a></li>
                                <li><a href="../banco-patagonia/etica-e-integridad.php">Ética e Integridad</a></li>
							</ul>
						</li>
						<li class="nav-item"><a href="#" class="nav-lnk active">ORGANIZACIÓN</a>
							<ul class="list-unstyled submenu">
								<li><a href="accionistas.php">Accionistas</a></li>
								<li><a href="autoridades.php">Autoridades</a></li>
                                <li><a href="comites.php">Comités</a></li>
								<li><a href="sector-financiero.php">Sector Financiero</a></li>
							</ul>
						</li>
						<!-- FIN INSTITUCIONAL -->
						
											</ul>
				</div>
			</div>
		</nav>
	</div>
</div>

<div class="mobile-nav-bar">
	<ul class="list-unstyled">
        
        <!-- PERSONAS -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">PERSONAS <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../personas/index.php" class="">HOME</a></li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA CLÁSICA</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../personas/patagonia-clasica/patagonia-ahorro/productos.php">Patagonia Ahorro</a></li>
                        <li><a href="../../personas/patagonia-clasica/paquete/productos.php">Patagonia Clásica</a></li>
                        <!--<li><a href="<php echo $path ?>personas/patagonia-clasica/mas/productos.php">Patagonia Clásica Más</a></li>-->
                        <li><a href="../../personas/patagonia-clasica/premium/productos.php">Patagonia Clásica Premium</a></li>
                        <li><a href="../../personas/patagonia-clasica/patagonia-sueldo/productos.php">Patagonia Sueldo</a></li>
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA PLUS</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../personas/patagonia-plus/productos.php">Patagonia Plus</a></li>
                        <li><a href="../../personas/patagonia-plus/premium/productos.php">Patagonia Plus Premium</a></li>
                    </ul>						
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA SINGULAR</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../personas/patagonia-singular/paquete/propuesta.php">Patagonia Singular</a></li>
                        <li><a href="../../personas/patagonia-singular/beneficios-exclusivos.php">Beneficios Exclusivos</a></li>
                        <!--<li><a href="<php echo $path ?>personas/patagonia-singular/atencion-exclusiva/index.php">Atención Exclusiva</a></li>-->
                        <!--<li><a href="<php echo $path ?>personas/patagonia-singular/eventos-y-novedades/index.php">Eventos y Novedades</a></li>-->
                    </ul>
                </li>
				<!--<li class="nav-sub-item"><a href="<php echo $path ?>patagoniaon/index.php" target="_blank">PATAGONIA ON</a></li>-->
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA ON</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../patagoniaon/index.php" target="_blank">Patagonia ON</a></li>
						<li><a href="../../personas/productos-y-servicios/patagonia-universitaria.php">Patagonia ON Universitaria</a></li>
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PRODUCTOS Y SERVICIOS</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../personas/apple-pay.php">Apple Pay</a></li>
                        <li><a href="../../personas/productos-y-servicios/caja-de-seguridad.php">Caja de Seguridad</a></li>
                        <li><a href="../../personas/productos-y-servicios/comercio-exterior/productos.php">Comercio exterior</a></li>
						<!--<li><a href="<php echo $path ?>personas/productos-y-servicios/beneficios-wapa.php">Comercios WAPA</a></li>-->
						<li><a href="../../personas/cuotifica-al-toque.php">Cuotificá al Toque</a></li>
						<li><a href="../../personas/google-pay.php">Google Pay</a></li>
                        <li><a href="../../personas/productos-y-servicios/inversiones.php">Inversiones</a></li>
                        <li><a href="../../personas/jubilados/index.php">Jubilados</a></li>
                        <li><a href="../../personas/productos-y-servicios/patagonia-para-menores.php">Patagonia para Menores</a></li>
                        <!--<li><a href="<php echo $path ?>personas/productos-y-servicios/patagonia-universitaria.php">Patagonia Universitaria</a></li>-->
                        <li><a href="../../personas/productos-y-servicios/prestamos.php">Prestamos</a></li>
                        <li><a href="../../personas/seguros/index.php">Seguros</a></li>
                        <li><a href="../../personas/productos-y-servicios/tarjetas-de-credito/visa.php">Tarjetas de crédito</a></li>
                        <li><a href="../../personas/productos-y-servicios/tarjetas-de-debito/patagonia-24.php">Tarjetas de débito</a></li>
                    </ul>
                </li>
			</ul>
		</li>
        <!-- FIN PERSONAS -->
        
        <!-- NYPS -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">PROFESIONALES Y COMERCIOS <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../nyps/index.php" class="">HOME</a></li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA CLÁSICA</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../nyps/patagonia-clasica/premium/productos.php">Patagonia Clásica Premium</a></li>
                        <li><a href="../../nyps/patagonia-clasica/patagonia-emprendimiento/productos.php">Patagonia Emprendimiento</a></li>
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA PLUS</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../nyps/patagonia-plus/productos.php">Patagonia Plus</a></li>
                        <li><a href="../../nyps/patagonia-plus/premium/productos.php">Patagonia Plus Premium</a></li>
                    </ul>						
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA SINGULAR</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../nyps/patagonia-singular/paquete/propuesta.php">Patagonia Singular</a></li>
                        <li><a href="../../nyps/patagonia-singular/beneficios-exclusivos.php">Beneficios Exclusivos</a></li>
                        <!--<li><a href="<php echo $path ?>nyps/patagonia-singular/eventos-y-novedades/index.php">Eventos y Novedades</a></li>-->
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PRODUCTOS Y SERVICIOS</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../nyps/productos-y-servicios/tarjetas-de-debito/patagonia-24.php">Tarjetas de débito</a></li>
                        <li><a href="../../nyps/productos-y-servicios/tarjetas-de-credito/visa.php">Tarjetas de crédito</a></li>
                        <li><a href="../../nyps/productos-y-servicios/prestamos.php">Prestamos</a></li>
                        <li><a href="../../nyps/seguros/index.php">Seguros</a></li>
                        <li><a href="../../nyps/productos-y-servicios/inversiones.php">Inversiones</a></li>
                        <li><a href="../../nyps/productos-y-servicios/comercio-exterior/productos.php">Comercio exterior</a></li>
                        <li><a href="../../nyps/productos-y-servicios/caja-de-seguridad.php">Caja de Seguridad</a></li>
                        <li><a href="../../nyps/productos-y-servicios/factura-electronica.php">Factura electrónica</a></li>
                        <li><a href="../../nyps/productos-y-servicios/pagos-afip.php">Pagos AFIP</a></li>
                        <!--<li><a href="<php echo $path ?>nyps/productos-y-servicios/soluciones-para-tu-empresa.php">Soluciones para tu empresa</a></li>-->
                        <!--<li><a href="<php echo $path ?>nyps/productos-y-servicios/comercios-patagonia.php">Comercios Patagonia</a></li>-->
						<li><a href="../../nyps/productos-y-servicios/wapa.php">WAPA</a></li>
                    </ul>
                </li>
			</ul>		
		</li>
        <!-- FIN NYPS -->
        
        <!-- PYME -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">PYME <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../pyme/index.php" class="">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">CUENTAS</a>
					<ul class="list-unstyled submenu">
                        <li><a href="../../pyme/cuentas/pequenas-empresas.php">Pyme Pequeñas Empresas</a></li>
				        <li><a href="../../pyme/cuentas/medianas-empresas.php">Pyme Medianas Empresas</a></li>
                        <!--
						<li><a href="../../pyme/cuentas/patagonia-empresario.php">Patagonia Empresario</a></li>
						<li><a href="../../pyme/cuentas/patagonia-empresario-premier.php">Patagonia Empresario Premier</a></li>
						<li><a href="../../pyme/cuentas/patagonia-empresa.php">Patagonia Empresa</a></li>
                        -->
                        <!--<li><a href="../../pyme/cuentas/patagonia-comercio.php">Patagonia Comercio</a></li>-->
                        <li><a href="../../pyme/cuentas/patagonia-consorcio.php">Patagonia Consorcio</a></li>
						<li><a href="../../pyme/cuentas/cuenta-corriente.php">Cuenta Corriente</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA SUELDO</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../pyme/patagonia-sueldo/servicios.php">Servicios</a></li>
						<li><a href="../../pyme/patagonia-sueldo/preguntas-frecuentes.php">Preguntas Frecuentes</a></li>
						<li><a href="../../pyme/patagonia-sueldo/guia-implementacion.php">Guía de Implementación</a></li>
					</ul>
				</li>						
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">COMERCIO EXTERIOR</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../pyme/comercio-exterior/solicitud-electronica.php">Solicitud Electrónica</a></li>
						<li><a href="../../pyme/comercio-exterior/productos.php">Productos</a></li>
						<li><a href="../../pyme/comercio-exterior/otros-servicios.php">Servicios</a></li>
						<!--<li><a href="<php echo $folder_pymeCexterior ?>financiaciones.php">Financiaciones</a></li>-->
                        <li><a href="../../pyme/comercio-exterior/herramientas-para-exportar.php">Herramientas para Exportar</a></li>
						<li><a href="../../pyme/comercio-exterior/marco-regulatorio/normas-y-regulaciones.php">Marco Regulatorio</a></li>
					</ul>
				</li>						
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">FINANCIACIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../pyme/financiacion/patagonia-leasing.php">Patagonia Leasing</a></li>
						<li><a href="../../pyme/financiacion/mercado-capitales.php">Mercado de Capitales</a></li>
						<li><a href="../../pyme/financiacion/alternativas-de-financiacion.php">Alternativas de Financiación</a></li>
					</ul>
				</li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">SEGUROS</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../pyme/seguros/protege-tus-bienes/integral-comercio.php">Protegé tus Bienes</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">INVERSIONES</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../pyme/inversiones/plazo-fijo.php">Plazo Fijo</a></li>
						<li><a href="../../pyme/inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
						<li><a href="../../pyme/inversiones/fidecomisos-financieros.php">Fidecomisos Financieros</a></li>
					</ul>
				</li>						
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">SERVICIOS</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../pyme/servicios/recaudaciones.php">Recaudaciones</a></li>
						<li><a href="../../pyme/servicios/pagos.php">Pagos</a></li>
						<li><a href="../../pyme/servicios/tarjetas-comerciales.php">Tarjetas Comerciales</a></li>
						<li><a href="../../pyme/servicios/comercios-patagonia.php">Comercios Patagonia</a></li>
                        <li><a href="../../pyme/servicios/pago-de-servicios.php">Pago de Servicios</a></li>
						<li><a href="../../pyme/servicios/interbanking.php">Interbanking</a></li>
						<li><a href="../../pyme/servicios/interfacturas.php">Interfacturas</a></li>
						<li><a href="../../pyme/servicios/pagos-afip.php">Pagos AFIP</a></li>
						<li><a href="../../pyme/servicios/wapa.php">WAPA</a></li>
					</ul>
				</li>
			</ul>		
		</li>
        <!-- FIN PYME -->
        
        <!-- AGRO -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">AGRO <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../agro/index.php" class="">HOME</a></li>
                <!-- -->
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">OFERTA AGRO</a>
					<ul class="list-unstyled submenu">
                    	<!--<li><a href="<php echo $folder_agroFinanciacion ?>insumos.php">Insumos en USD</a></li>-->
                        <li><a href="../../agro/convenios/acuerdos-y-beneficios.php">Acuerdos y convenios</a></li>
						<li><a href="../../agro/financiacion/maquinaria-agricola.php">Financiación Maquinaria Agrícola</a></li>
						<li><a href="../../agro/seguros/campo.php">Seguros para tu campo</a></li>
					</ul>
				</li>
                <!-- -->
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">TARJETA PATAGONIA AGRO</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../agro/tarjeta-patagonia-agro/para-usuarios.php">Para Usuarios</a></li>
						<li><a href="../../agro/tarjeta-patagonia-agro/para-comercios.php">Para Comercios</a></li>
						<li><a href="../../agro/tarjeta-patagonia-agro/acuerdo-tasa-0.php">Tarjetas Agro Convenios Preferenciales</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="../../agro/cuenta-agro/cuenta-agro.php" class="">CUENTA AGRO</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">FINANCIACIÓN</a>
					<ul class="list-unstyled submenu">
                        <li><a href="../../agro/insumos/index.php">Insumos</a></li>
                        <li><a href="../../agro/financiacion/maquinaria-agricola.php">Maquinarias</a></li>
                        <li><a href="../../empresas/financiacion/convenios-de-financiacion.php">Camiones</a></li>
						<!--<li><a href="<php echo $folder_agroFinanciacion ?>capital-de-trabajo.php">Capital de Trabajo</a></li>-->
						<!--<li><a href="<php echo $folder_agroFinanciacion ?>proyectos-de-inversion.php">Proyectos de Inversión</a></li>-->
						<!--<li><a href="<php echo $folder_agroFinanciacion ?>creditos-para-hacienda.php">Créditos para Hacienda</a></li>-->
						<!--<li><a href="<php echo $folder_agroFinanciacion ?>leasing-y-prendarios.php">Leasing y Prendarios</a></li>-->
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">INVERSIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../agro/inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
						<li><a href="../../agro/inversiones/fidecomisos-financieros.php">Fidecomisos Financieros</a></li>
						<li><a href="../../agro/inversiones/plazos-fijos.php">Plazos Fijos</a></li>
					</ul>
				</li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">COMERCIO EXTERIOR</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../agro/comercio-exterior/solicitud-electronica.php">Solicitud Electrónica</a></li>
                        <li><a href="../../agro/comercio-exterior/productos.php">Productos</a></li>
                        <li><a href="../../agro/comercio-exterior/otros-servicios.php">Servicios</a></li>
                        <li><a href="../../agro/comercio-exterior/herramientas-para-exportar.php">Herramientas para Exportar</a></li>
                        <li><a href="../../agro/comercio-exterior/marco-regulatorio/normas-y-regulaciones.php">Marco Regulatorio</a></li>
                    </ul>
                </li>
                <!--
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">SERVICIOS</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../agro/servicios/centro-atencion-empresas.php">Centro de Atención para Empresas</a></li>
					</ul>
				</li>
                -->
                <!-- -->
                <li class="nav-sub-item"><a href="../../agro/seguros/campo.php" class="">SEGUROS</a></li>
                <!-- -->
			</ul>
		</li>
        <!-- FIN AGRO -->
        
        <!-- EMPRESAS -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">EMPRESAS <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../empresas/index.php" class="">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA SUELDO</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../empresas/patagonia-sueldo/servicios.php">Servicios</a></li>
						<li><a href="../../empresas/patagonia-sueldo/preguntas-frecuentes.php">Preguntas Frecuentes</a></li>
						<li><a href="../../empresas/patagonia-sueldo/guia-implementacion.php">Guía de Implementación</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">COMERCIO EXTERIOR</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../empresas/comercio-exterior/solicitud-electronica.php">Solicitud Electrónica</a></li>
						<li><a href="../../empresas/comercio-exterior/productos.php">Productos</a></li>
						<li><a href="../../empresas/comercio-exterior/otros-servicios.php">Servicios</a></li>
						<!--<li><a href="<php echo $folder_Cexterior ?>financiaciones.php">Financiaciones</a></li>-->
                        <li><a href="../../empresas/comercio-exterior/herramientas-para-exportar.php">Herramientas para Exportar</a></li>
						<li><a href="../../empresas/comercio-exterior/marco-regulatorio/normas-y-regulaciones.php">Marco Regulatorio</a></li>
					</ul>
				</li>
                <!-- -->
				<!--<li class="nav-sub-item"><a href="../../empresas/comunidades-de-negocios/index.php" class="">COMUNIDADES DE NEGOCIOS</a></li>-->
                <!-- -->
				<li class="nav-sub-item"><a href="index.php" class="nav-lnk ">COMERCIOS PATAGONIA</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">FINANCIACIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../empresas/financiacion/patagonia-leasing.php">Patagonia Leasing</a></li>
						<li><a href="../../empresas/financiacion/mercado-capitales.php">Mercado Capitales</a></li>
						<li><a href="../../empresas/financiacion/alternativas-de-financiacion.php">Alternativas de Financiación</a></li>
                        <li><a href="../../empresas/financiacion/convenios-de-financiacion.php">Convenios de Financiación</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">INVERSIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../empresas/inversiones/plazos-fijos.php">Plazos Fijos</a></li>
						<li><a href="../../empresas/inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
						<li><a href="../../empresas/inversiones/compra-venta-titulos-acciones.php">Compra - Venta de Títulos y Acciones</a></li>
						<li><a href="../../empresas/inversiones/custodia-de-titulos.php">Custodia de Títulos</a></li>
						<li><a href="../../empresas/inversiones/fidecomisos-financieros.php">Fidecomisos Financieros</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">SERVICIOS</a>
					<ul class="list-unstyled submenu">
                        <li><a href="../../empresas/patagonia-movil-empresas.php">Patagonia Móvil Empresas</a></li>
						<li><a href="../../empresas/servicios/pagos.php">Pagos</a></li>
						<li><a href="../../empresas/servicios/recaudaciones.php">Recuadaciones</a></li>
						<li><a href="../../empresas/servicios/pago-de-servicios.php">Pago de Servicios</a></li>
						<li><a href="../../empresas/servicios/interbanking.php">Interbanking</a></li>
						<li><a href="../../empresas/servicios/interfacturas.php">Interfacturas</a></li>
						<li><a href="../../empresas/servicios/tarjetas-comerciales.php">Tarjetas Comerciales</a></li>
                        <!-- -->
						<!--<li><a href="../../empresas/servicios/comercios-patagonia.php">Comercios Patagonia</a></li>-->
                        <!-- -->
                        <li><a href="../../empresas/servicios/centro-atencion-empresas.php">Centro de Atención para Empresas</a></li>
					</ul>
				</li>
			</ul>
		</li>
        <!-- FIN EMPRESAS -->
        
        <!-- SECTOR PÚBLICO -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">SECTOR PÚBLICO <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../sector-publico/index.php" class="">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">INVERSIONES</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../sector-publico/inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
						<li><a href="../../sector-publico/inversiones/plazo-fijo.php">Plazo Fijo</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">SERVICIOS</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../sector-publico/servicios/servicio-de-recaudacion.php">Servicio de Recaudación</a></li>
						<li><a href="../../sector-publico/servicios/servicio-de-pagos.php">Servicio de Pagos</a></li>
						<li><a href="../../sector-publico/servicios/servicios-para-personal.php">Servicios para el Personal</a></li>
						<li><a href="../../sector-publico/servicios/financiacion.php">Financiación</a></li>
						<li><a href="../../sector-publico/servicios/otros-servicios.php">Servicios</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">PROGRAMA UNIVERSIDADES</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../sector-publico/programa-universidades/relacion-institucional.php">Relación Institucional</a></li>
						<li><a href="../../sector-publico/programa-universidades/docentes-yno-docentes.php">Docentes y No Docentes</a></li>
						<li><a href="../../sector-publico/programa-universidades/alumnos.php">Alumnos</a></li>
						<li><a href="../../sector-publico/programa-universidades/graduados.php">Graduados</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">BENEFICIOS RÍO NEGRO</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../sector-publico/rio-negro/presencia.php">Presencia en Río Negro</a></li>
                        <li><a href="../../sector-publico/rio-negro/propuesta-valor.php">Propuesta de valor exclusiva</a></li>
					</ul>
				</li>
			</ul>
		</li>
        <!-- FIN SECTOR PUBLICO -->
        
        <!-- INSTITUCIONAL -->
		<li class="nav-main-item"><a href="#" class="has-sub-items active">INSTITUCIONAL <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../index.php" class="active">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">BANCO PATAGONIA</a>
					<ul class="list-unstyled submenu">
						<li><a href="../banco-patagonia/historia.php">Historia</a></li>
						<li><a href="../banco-patagonia/mercado-de-capitales.php">Mercado de Capitales</a></li>
						<li><a href="../banco-patagonia/patagonia-inversora.php">Patagonia Inversora</a></li>
						<li><a href="../banco-patagonia/patagonia-valores-sa.php">Patagonia Valores S.A</a></li>
						<li><a href="https://bp.bancopatagonia.com.ar/relacion-con-inversores/es/institucional" target="_blank">Relación con Inversores</a></li>
						<li><a href="../banco-patagonia/desarrollo-humano.php">Desarrollo Humano</a></li>
						<li><a href="../banco-patagonia/sustentabilidad.php">Sustentabilidad</a></li>
						<li><a href="../banco-patagonia/politicas-aml-cft.php">Póliticas AML/CFT</a></li>
						<li><a href="../banco-patagonia/disciplina-del-mercado.php">Disciplina de Mercado</a></li>
                        <li><a href="../banco-patagonia/asistencia-a-vinculados.php">Asistencia a vinculados</a></li>
                        <li><a href="../banco-patagonia/etica-e-integridad.php">Ética e Integridad</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu active">ORGANIZACIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="accionistas.php">Accionistas</a></li>
						<li><a href="autoridades.php">Autoridades</a></li>
                        <li><a href="comites.php">Comités</a></li>
						<li><a href="sector-financiero.php">Sector Financiero</a></li>
					</ul>
				</li>
			</ul>
		</li>
        <!-- FIN INSTITUCIONAL -->
        
        		<li class="nav-main-item"><a href="../../preguntas-frecuentes/index.php" class="" style="text-transform: none;">Ayuda</a></li>
		<!--<li class="nav-main-item"><a href="<php echo $folder_canales ?>index.php" class="<php echo $canales ?>" style="text-transform: none;">Canales de Atención</a></li>-->
		<!--<li class="nav-main-item"><a href="http://sucursalesycajeros.bancopatagonia.com.ar/sucursales.html" target="_blank" style="text-transform: none;">Sucursales y Cajeros</a></li>-->
		<!--<li class="nav-main-item"><a href="<php echo $folder_contactenos ?>index.php" class="<php echo $contactenos ?>" style="text-transform: none;">Contactanos</a></li>-->
        <!--<li class="nav-main-item"><a href="<php echo $path ?>ayuda/index.php" class="<php echo $ayuda ?>" style="text-transform: none;">Ayuda</a></li>-->
	</ul>
</div>	<section class="sec-head" title="Autoridades. Conocé las autoridades de Banco Patagonia">
        <div class="sec-pic-head" id="head-autoridades">
        </div>
	</section>
	<section class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
				<ol class="breadcrumb">
					<li>Institucional</li>
					<li>Organización</li>
					<li class="active">Autoridades</li>
				</ol>
			</div>
		</div>
	</section>
	<section class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
                <div class="text-data">
					<!-- ---------- -->
					<!-- DIRECTORIO -->
					<!-- ---------- -->
					<h1>Directorio<sup>*</sup></h1>
					<p><strong>Oswaldo Parré dos Santos</strong><br>
					Presidente</p>
					<p>El Sr. Oswaldo Parré dos Santos, brasileño, nacido el 14 de diciembre de 1969, es Presidente de Banco Patagonia desde abril de 2021. Anteriormente, se desempeñó como Vicepresidente a partir de febrero de 2017 y ocupó el cargo de Director Suplente desde abril del 2016. Es Vicepresidente en la Asociación de Bancos de la Argentina (ABA) y Delegado titular de la Asociación Civil Argentina de Empresas Brasileñas (Grupo Brasil) donde Banco Patagonia S.A. mantiene la Presidencia. Comenzó su carrera en Banco do Brasil en 1984, desempeñándose en varios cargos ejecutivos a partir del año 2000. Fue designado como Gerente General de la Agencia de Nueva York (Estados Unidos) en 2011 y anteriormente Gerente Adjunto en la Agencia de Frankfurt (Alemania) en 2008. Entre los años 2013 y 2016 actuó en las áreas de Crédito Large Corporate y Proyectos y Mercado de Capitales. Asimismo, se desempeñó como Presidente de GPAT Compañía Financiera S.A.U, Vicepresidente de Patagonia Valores S.A. y de Banco Patagonia (Uruguay) S.A. I.F.E. (en liquidación), y Director Titular de Play Digital S.A. Posee el título de Licenciado en Economía de la Universidad de Sao Judas Tadeu (Brasil) y cursó estudios de posgrado en Administración en la Fundación Dom Cabral (Brasil). También realizó cursos de Extensión Universitaria de Bank Management en la Universidad de Texas, Austin (USA), en la Universidad De Paul de Chicago (USA) y Northwestern Kellogg de Chicago (USA).</p>
					<br>
					<p><strong>Marvio Melo Freitas</strong><br>
					Vicepresidente</p>
					<p>Brasileño, nacido el 9 de noviembre  de 1977. Fue designado Vicepresidente de Banco Patagonia en abril de 2020,  habiendo sido reelegido para su mandato actual en abril de 2023. Anteriormente  ocupó el cargo de Director Titular desde abril de 2019. Asimismo, es Presidente  y Oficial de Cumplimiento titular ante la UIF por GPAT Compañía Financiera  S.A.U., Vicepresidente y Oficial de Cumplimiento Suplente por Patagonia Valores  S.A. y miembro de los Comité de Auditoría CNV y BCRA desde mayo de 2023.  También es Delegado Alterno en la Asociación de Bancos de la Argentina (ABA).  Comenzó su carrera en Banco do Brasil en el año 2000 y se desempeñó en  diferentes cargos como Gerente Ejecutivo de Control de Gestión y posteriormente  Director de dicha área. Luego ocupó el cargo de Director de Estrategia y  Organización, hasta mayo de 2022. El Sr. Freitas es graduado en Ciencias  Económicas egresado de la Universidad de Brasilia y graduado en Contabilidad en  la Universidad Católica de Brasilia. Asimismo, ha completado estudios de  posgrado en Controladoria en la Fundación del Instituto de Investigaciones  Contables, Actuariales y Financieras de la Universidad de San Pablo.</p>
					<br>
					<p><strong>Juan Manuel Trejo</strong><br>
					Vicepresidente</p>
					<p>Argentino, nacido el 1 de septiembre  de 1970. Asumió como Vicepresidente de Banco Patagonia en julio de 2022,  habiendo sido reelegido para su mandato actual en abril de 2023. En octubre de  2017 fue designado como Superintendente de Finanzas, Administración y Sector  Público, cargo que ocupó hasta su designación actual. Asimismo, es Presidente  de Patagonia Valores S.A. y Vicepresidente 1° en GPAT Compañía Financiera  S.A.U. También ocupa el cargo de Director Titular en Mercado Abierto  Electrónico S.A. y Argencontrol S.A.&nbsp; Se incorporó al Banco a través de  sus entidades predecesoras en 1993. Fue designado Gerente de Marketing en 2009  y en 2013 fue promovido a Gerente Ejecutivo de Planeamiento y Proyectos  Estratégicos, gerencia que en 2017 incorporó el área de Marca y Comunicación.  El Sr. Trejo posee el título de Licenciado en Comercialización expedido por la  Universidad de Ciencias Empresariales y Sociales y ha realizado un Master en  Finanzas con Orientación en Mercado de Capitales en UCEMA, un posgrado en  Planeamiento y Administración Estratégica en la Universidad de Buenos Aires y  un Programa de Desarrollo de Habilidades de Gestión en UdeSA.</p>
					<br>
					<p><strong>Otacílio Martins de Magalhães Filho</strong><br>
					Vicepresidente</p>
					<p>Brasileño, nacido el 30 de octubre de 1978. Fue designado Vicepresidente de Banco Patagonia en agosto de 2023. Desde febrero de 2019, estuvo a cargo de la Superintendencia de Tecnología y Negocios Digitales. Asimismo, se desempeña como Delegado Suplente del Grupo Brasil. Ingresó en Banco do Brasil en 1998 y desde 2014 fue designado como Gerente Ejecutivo de Gestión de Atención, Procesos, Gestión de Riesgos Operacionales y Concesiones de Infraestructura en la Dirección de Soluciones Empresariales. Se desempeña en Patagonia Valores S.A como Director Titular; y en agosto de 2023 fue designado como Director Titular y Vicepresidente 2° en GPAT Compañía Financiera S.A.U. Asimismo es miembro del Comité de Auditoría BCRA desde agosto de 2023. Posee el título de Licenciado en Administración de Empresas de la Pontificia Universidad Católica de Campinas. Realizó también una Maestría en Administración en la Universidad de Brasilia y un MBA en Gestión de Negocios.</p>
					<br>
					<p><strong>Felipe Guimaraes Geissler Prince</strong><br>
					Vicepresidente</p>
					<p>Brasileño, nacido el 25 de mayo de  1978. Fue designado Vicepresidente de Banco Patagonia en abril de 2023. Comenzó  su carrera en Banco do Brasil en el año 2000 y ocupó diferentes cargos como  Gerente de División, Gerente Ejecutivo Corporate, y Director en la Dirección de  Créditos. Desempeñándose actualmente como Vicepresidente de Controles Internos  y Gestión de Riesgo. Asimismo, es Miembro Titular del Consejo Fiscal en Cielo  S.A, Presidente del Consejo de Administración en BB Administradora de  Consorcios S.A. y Miembro del Consejo de Administración de BBAG (Austria). El  Sr. Guimaraes Geissler Prince es graduado en Derecho egresado de la Facultad de  Derecho de Varginha, Brasil. Asimismo, posee un MBA en Negocios Financieros  realizado en la Universidad de Brasília y un MBA en Gestión de Crédito  realizado en la Fundación Getulio Vargas.</p>
					<br>
					<p><strong>João Francisco Fruet Junior</strong><br>
					Vicepresidente</p>
					<p>Brasileño, nacido el 7 de febrero de  1971. Fue designado Vicepresidente en Abril de 2024, anteriormente ocupó el  cargo de Director Suplente desde abril de 2023. Comenzó su carrera en Banco do  Brasil en el año 1987 y ocupó distintos cargos ejecutivos como Gerente de la  Agencia de Nueva York (Estados Unidos), Gerente Ejecutivo de la Directoría  Comercial y Superintendente Corporate. También fue Director de Marketing y  Comercial de Brasilseg,&nbsp;Presidente de BB Americas Bank, Miami (Estados  Unidos). Actualmente se desempeña como Director Corporate y de Investment Bank  de Banco do &nbsp;Brasil S.A., Miembro del Consejo de Administración de BB  Securities LLC y de BB Securities LTD y miembro del Consejo BB Mapfre  Participações S.A. El Sr. Fruet es Licenciado en Administración de Empresas  egresado de la Universidad Federal de Rio Grande do Sul. Asimismo, posee un MBA  en Gestión de Negocios realizado en la Universidad Federal de Rio Grande do  Sul, un MBA en Gestión de Negocios Mayoristas realizado en la Universidad de  San Pablo y un MBA en liderazgo estratégico del Instituto de Enseñanza e  Investigación en Administración (Inepad), Universidad de Vale do Rio dos Sinos.</p>
					<br>
					<p><strong>Rodrigo Mulinari</strong><br>
					Director Titular</p>
					<p>Brasileño, nacido el 21 de abril de  1978. Fue designado Director Titular en agosto de 2023, habiendo sido  anteriormente designado como Director Suplente en abril de 2023. Comenzó su  carrera en Banco do Brasil en el año 2000 y ocupó distintos cargos ejecutivos  como Gerente de Soluciones, Gerente Ejecutivo de las áreas de canales de  atención y Gerente General del área de Construcción de Aplicaciones,  desempeñándose actualmente como Director de TI del Departamento de Tecnología.  Asimismo, es Director de la Comisión de Innovación y Tecnología de la  Federación Brasileña de Bancos (FEBRABAN), y miembro del Consejo de Febraban  Tech. Integra los Consejos de Administración de Cateno y Banco do Brasil  Tecnología y Servicios (BBTS), y el Consejo Fiscal de la Caja de Previsión de  los Empleados del Banco do Brasil (Previ). El Sr. Mulinari es graduado en  Informática egresado de la Universidad Regional Integrada (URI) – Estado de Río  Grande do Sul. También, posee una Maestría en Ingeniería Eléctrica realizada en  la Universidad del Distrito Federal, Brasilia y un posgrado en Ingeniería de  Sistemas realizado en la Escuela Superior Abierta del Brasil (ESAB).</p>
					<br>
					<p><strong>Ernesto Juan Cassani</strong><br>
					Director Titular</p>
					<p>Argentino, nacido el 16 de diciembre  de 1952. Es Director Titular desde enero de 2017, habiendo sido reelegido para  su mandato actual en abril de 2023. Es considerado un miembro independiente de  acuerdo con las normas de la Comisión Nacional de Valores (CNV). Se desempeña  como Oficial de Cumplimiento PLA/FT titular de Banco Patagonia S.A. y como  miembro de los Comités de Auditoría CNV y BCRA y de Desarrollo Humano.  Asimismo, el Sr. Cassani es miembro de la Comisión Fiscalizadora de Molinos Rio  de la Plata, de Pecom Servicios Energía S.A y de diversas compañías del Grupo  Pérez Companc. Anteriormente el Sr. Cassani fue miembro de las Comisiones  Fiscalizadoras de Telecom S.A., Telecom Personal S.A., Santander Rio S.A, Banco  de Valores S.A. y Grupo Trafigura. Socio de Pistrelli, Díaz y Asociados  posteriormente Pistrelli, Henry Martin y Asociados, firma miembro de EY GLOBAL  hasta su retiro en el año 2013 en el área de servicios financieros y mercado de  capitales de la División de Auditoria, trabajando en la firma por más de 35  años. En este carácter manejó los servicios de auditoría y asesoramiento  gerencial de numerosas entidades financieras y del mercado de capitales entre  las cuales merecen destacarse, Banco Central de la República Argentina, Banco  de la Nación Argentina, Banco Ciudad de Buenos Aires, Banco Santander Rio,  Banco Macro, Nuevo Banco de Santa Fe, Banco de San Juan, Banco de Entre Ríos,  Banco de la Pampa, Mercado de Valores (actualmente BYMA), Caja de Valores,  Bolsa de Comercio de Buenos Aires, entre otros. El Sr. Cassani posee el título  de Contador Público, por la Universidad de Belgrano.</p>
					<br>
					<p><strong>Edgardo Omar Vega</strong><br>
					Director Titular</p>
					<p>Argentino, nacido el 19 de junio de  1966, es Director Titular desde abril de 2024. Fue elegido por el titular de  las acciones Clase &ldquo;A&rdquo; (Provincia de Río Negro) y es considerado miembro  independiente según las Normas de la CNV. Asimismo se desempeña como miembro  del Comité de Auditoría CNV y del Comité de Auditoría BCRA. El Sr. Vega se  desempeñó como Asesor Legal del Gobierno de la Provincia de Río Negro hasta el  año 2017 y como Presidente del Concejo Deliberante de la ciudad de Villa Regina  hasta el año 2023. El Sr. Vega posee el título de Abogado, profesión que ejerce  en la actualidad de forma independiente, emitido por la Universidad de Comahue  y el título de Escribano emitido por la Universidad Empresarial Siglo XXI.  También realizó una Diplomatura en Internacionalización de Gobiernos Locales y  Actores de Territorio en la Universidad de Villa María Córdoba.</p>
					<br>
					<p><strong>Luciano Matarazzo Regno</strong><br>
					Director Suplente</p>
					<p>Brasileño, nacido el 1 de febrero de  1979. Fue designado Director Suplente en abril de 2023. Comenzó su carrera en  Banco do Brasil en el año 1998 y ocupó distintos cargos ejecutivos,  desempeñándose actualmente como Director en la Dirección de Crédito. Asimismo,  es miembro de los Comités de Asesoramiento al Consejo de Administración de  EloPar y de la Gestora de Inteligencia de Crédito S.A. El Sr. Matarazzo es  Analista de Sistemas egresado de la Universidad Metodista de Piracicaba, donde  realizó también una maestría en Ciencias de la Computación. Realizó un Posgrado  en Marketing realizado en la Universidad Gama Filho y un MBA en Data Science  &amp; Analytics de la Universidad de San Pablo.</p>
					<br>
					<p><strong>Luis Carlos Cerolini</strong><br>
					Director Suplente</p>
					<p>Argentino, nacido el 27 de enero de  1954, fue designado como Director Suplente en abril 2017, habiendo sido  reelegido para su mandato actual en abril de 2023. Es considerado como miembro  independiente de acuerdo con las Normas de la CNV. Se desempeñó como miembro  del Directorio de Banco Macro desde el año 2000 hasta el 2015. También fue  Director en Banco del Tucumán S.A., Macro Fiducia S.A., Macro Securities S.A.,  Macro Warrants S.A. y Provincanje S.A. El Sr. Cerolini posee el título de  Abogado emitido por la Universidad Nacional de Córdoba.</p>
					<br>
					<p><strong>Alejandro Damián Mella</strong><br>
					Director Suplente</p>
					<p>Fue designado como Director Suplente desde abril de 2020, habiendo sido  reelegido para su mandato actual en abril de 2023. Su CV se detalla más abajo,  en consideración de que actualmente se desempeña como Superintendente de Red de  Sucursales y Negocios con Personas.</p>
					<p><em>* hasta la Asamblea que apruebe los estados financieros al 31.12.2025.</em></p>
					<!-- ---------------------- -->
					<!-- COMISIÓN FISCALIZADORA -->
					<!-- ---------------------- -->
					<hr>
					<h3>Comisión Fiscalizadora <sup>*</sup></h3>
					<p><strong>Mónica María Cukar</strong><br>
					Síndico Titular</p>
					<p>Argentina, nacida el 6 de enero de  1959. Es Síndico Titular desde abril de 2013, habiendo sido reelegida para su  mandato actual en abril de 2023. Asimismo, es Síndico Titular en GPAT Compañía  Financiera S.A.U. y en Patagonia Valores S.A. Ha desempeñado cargos ejecutivos  en Bertora &amp; Asoc., y Riadigos, Trossero &amp; Asociados. En 2001 fue  designada como Directora Ejecutiva de la División de Financial Services &amp;  Health Care de Pistrelli, Henry Martin &amp; Asoc. S.R.L., firma miembro de  E&amp;Y Global, hasta abril de 2013. Fue integrante de la Comisión Directiva del  Instituto de Auditores Internos de Argentina de 2003 a 2013, siendo Presidente  del Directorio de 2009 a 2011. Asimismo, de 2008 a 2013, presidió la Comisión  de Estudios de Auditoría Interna y Gobierno Corporativo del Consejo Profesional  de Ciencias Económicas de la Ciudad Autónoma de Buenos Aires. La Sra. Cukar  posee título de Contadora Pública expedido por la Universidad de Buenos Aires.</p>
					<br>
					<p><strong>Alberto Mario Tenaillon</strong><br>
					Síndico Titular</p>
					<p>Argentino, nacido el 8 de diciembre  de 1954. Es Síndico Titular desde abril de 2019, habiendo sido reelegido para  su mandato actual en abril de 2023. Es Socio Director del Estudio Jurídico  Tenaillon &amp; Esteban Asesores Legales. Asimismo, se desempeñó como Síndico  Titular en Patagonia Valores S.A y GPAT Compañía Financiera S.A.U. Posee el  título de Abogado expedido por la Facultad de Derecho de la Universidad de  Buenos Aires.</p>
					<br>
					<p><strong>Sebastián María Rossi</strong><br>
					Síndico Titular</p>
					<p>Argentino, nacido el 29 de mayo de  1977. Fue designado Síndico Titular en abril de 2022, habiendo sido reelegido  para su mandato actual en abril de 2023. Asimismo, se desempeña como Síndico  Titular de GPAT Compañía Financiera S.A.U. Posee el título de abogado expedido  por la Universidad Católica Argentina. Es socio del Estudio Jurídico Rossi  Camilión &amp; Asociados.</p>
					<br>
					<p><strong>María Cristina Tapia Sasot</strong><br>
					Síndico Suplente</p>
					<p>Argentina, nacida el 26 de octubre de  1963, es Síndico Suplente desde abril de 2010, habiendo sido reelegida para su  mandato actual en abril de 2023. Asimismo, se desempeña como Síndico Suplente  en GPAT Compañía Financiera S.A.U. y en Patagonia Valores S.A. Es miembro del  Estudio Jurídico Tenaillon &amp; Esteban Asesores Legales. Posee el título de  Abogada emitido por la Facultad de Derecho de la Universidad de Buenos Aires.</p>
					<br>
					<p><strong>Héctor Osvaldo Rossi Camilión</strong><br>
					Síndico Suplente</p>
					<p>Argentino, nacido el 2 de mayo de  1948. Es Síndico Suplente desde abril de 2022, habiendo sido reelegido para su  mandato actual en abril de 2023. Anteriormente, se desempeñó como Síndico  Titular en el período de 2012 a 2022. Asimismo, desempeña el cargo de Síndico  Titular Banco Itaú Argentina S.A. Es Socio del Estudio Jurídico Rossi Camilión  &amp; Asociados. Posee título de abogado expedido por la Facultad de Derecho de  la Universidad Católica Argentina.</p>
					<br>
					<p><strong>Julio Alberto Pueyrredón</strong><br>
					Síndico Suplente</p>
					<p>Argentino, nacido el 29 de agosto de  1960. Es Sindico Suplente desde abril de 2019, habiendo sido reelegido para su  mandato actual en abril de 2023. Asimismo, se desempeña como Síndico Suplente  en Patagonia Valores S.A y en GPAT Compañía Financiera S.A.U. Es Socio del  Estudio Negri &amp; Pueyrredón Abogados. Posee el título de Abogado expedido  por la Universidad Católica Argentina.</p>
					<p><em>* hasta la Asamblea que apruebe los estados financieros al 31.12.2024.</em></p>
					<!-- ------------- -->
					<!-- ALTA GERENCIA -->
					<!-- ------------- -->
					<hr>
					<h3>Alta Gerencia</h3>
					<p><strong>Leonardo Aníbal Sica</strong><br>
					Superintendente de Créditos, Gestión de Riesgos y Controles Internos</p>
					<p>Argentino, nacido el 09 de octubre de  1972. Desde abril de 2022 se encuentra a cargo de la Superintendencia de  Créditos, Gestión de Riesgos y Controles internos. En 2018 fue designado como  Superintendente de Negocios con Empresas, cargo que ocupó hasta su designación  actual. Asimismo, es Vicepresidente de Patagonia Inversora S.A.S.G.F.C.I. y  Director Suplente de Interbanking S.A. Se incorporó al Banco como Oficial de  Negocios en 1997. Luego de desarrollarse en el área de Empresas, alcanzó la  posición de Gerente de Agronegocios en 2008 y en 2010 fue promovido a Gerente  Ejecutivo de Banca Empresas. En junio de 2017, fue designado como Gerente  Ejecutivo de Empresas. El Sr. Sica posee el título de Contador Público expedido  por la Universidad Argentina de la Empresa y ha realizado una Maestría en  Dirección de Empresas en UCEMA.</p>
					<br>
					<p><strong>Karina Guadalupe Gómez Vara</strong><br>
					Superintendente de Negocios con Empresas</p>
					<p>Argentina, nacida el 11 de abril de  1965. Desde abril de 2022 se encuentra a cargo de la Superintendencia de  Negocios con Empresas. En 2017 fue designada como Superintendente de Red de  Sucursales y Negocios con Personas, cargo que ocupó hasta su designación  actual. Asimismo, es Directora Suplente de Patagonia Inversora S.A.S.G.F.C.I.  Inició su experiencia en la actividad financiera en el BNL en 1998 como oficial  de negocios con empresas. También desempeñó funciones en el Banco desde el año  2000, habiendo ocupado cargos como Gerente de Sucursal, Zonal y Regional Integral.</p>
					<br>
					<p><strong>Diego Andrés Ferreyra</strong><br>
					Superintendente de Finanzas, Administración y Sector Público</p>
					<p>Argentino, nacido el 27 de junio de  1974. Desde julio de 2022 se encuentra a cargo de la Superintendencia de  Finanzas, Administración y Sector Público. Asimismo, es Presidente de Patagonia  Inversora S.A.S.G.F.C.I. En Abril 2024 fue designado como Director Suplente de  MAE (Mercado Abierto Electrónico). Se incorporó al Banco a través de sus  entidades predecesoras en 2003. En 2011 fue designado Gerente de Negocios  Corporate, Automotores, Autopartes y Transporte, en 2013 se desempeñó como  Gerente de Productos y Segmentos, y en 2015 fue promovido a Gerente Ejecutivo  Corporate. El Sr. Ferreyra posee el título de Contador Púbico expedido por la  Universidad Argentina de la Empresa y ha realizado una Maestría en Dirección de  Empresas en UCEMA.</p>
					<br>
					<p><strong>Alejandro Damián Mella</strong><br>
					Superintendente de Red de Sucursales y Negocios con Personas</p>
					<p>Argentino, nacido el 15 de junio de  1965. Desde abril de 2022 se encuentra a cargo de la Superintendencia de Red de  Sucursales y Negocios con Personas. En agosto de 2021 fue designado como  Superintendente de Créditos, Gestión de Riesgos y Controles Internos, cargo que  ocupó hasta su designación actual. Previamente estuvo a cargo de la  Superintendencia de Créditos y Comercio Exterior desde el mes de marzo de 2017  hasta julio de 2020. Desde abril 2020 es Director Suplente de Banco Patagonia  S.A., Patagonia Valores S.A., y GPAT Compañía Financiera S.A.U. Antes de  incorporarse al Banco se desempeñó en el Banco Tornquist S.A. – Credit Lyonnais  en el período comprendido entre 1986 y 1999. En ese año ingresó al Banco como  Team Leader de Banca Empresas, ejerciendo distintos cargos gerenciales a partir  del 2002, como Gerente de Sucursal, Gerente Regional, Gerente Comercial de Plan  Sueldos, Gerente Ejecutivo de Riesgo de Crédito y Gerente Ejecutivo de  Finanzas. Posee el título de Contador Público Nacional expedido por la  Universidad de Buenos Aires, y ha realizado un Master en Dirección de Empresas  en UCEMA.</p>
					<br>
					<p><strong>Fabio José dos Santos</strong><br>
					Superintendente de Operaciones</p>
					<p>Brasileño, nacido el 24 de octubre de  1970. Desde abril de 2022, está a cargo de la Superintendencia de Operaciones.  Comenzó su carrera en Banco do Brasil en 1985 y ocupó diferentes cargos como  Gerente de Cambio y Comercio Exterior, Gerente de Administración, Gerente  General Empresarial y Auditor. En el año 2018 fue designado como Gerente  General Corporate, cargo que ocupó hasta el año 2022. Posee el título de  Licenciado en Administración de Empresas con orientación en COMEX expedido por  la UNIMES (Brasil) y es graduado en Derecho en FMU (Brasil). Ha realizado un  MBA en Gestión de Negocios en USP(Brasil).</p>
					<br>
					<p><strong>Vanessa Benvenutti</strong><br>
					Superintendente de Tecnología y Negocios Digitales</p>
					<p>Brasileña, nacida el 29 de julio de  1980. Desde Octubre de 2023, está a cargo de la Superintendencia de Tecnología  y Negocios Digitales. Se desempeña en Banco do Brasil desde el año 2000  habiendo trabajado en distintas áreas como la red de sucursales, desde 2000  hasta 2005 en red de sucursales. Luego, desde 2006 a 2021 se desempeñó en el  área de Tecnología y Gobierno de TI, desde el año 2019 a 2021 formó parte del  Consejo de Gestión de Cultura y Personas en acciones dirigidas a la  transformación cultural del Banco do Brasil S.A. En el año 2022 asumió el cargo  de Gerente Ejecutiva del Departamento de Tecnología del mismo. La Sra.  Benvenutti es graduada en Ciencias de la Computación por la Universidad de Vale  do Itajaí, Brasil. Posee especializaciones en Gestión de Proyectos de  Ingeniería de Software, un MBA en Gobierno Corporativo por FGV y realizó un  Postgrado en Inteligencia Analítica por FGV.</p>
					<br>
					<p><strong>Carlos Daniel Ferreyra</strong><br>
					Gerente Ejecutivo de Desarrollo Humano y Clima Organizacional</p>
					<p>Argentino, nacido el 22 de septiembre  de 1974. Desde junio de 2017, está a cargo de la Gerencia Ejecutiva de  Desarrollo Humano y Clima Organizacional. El Sr. Ferreyra inició su carrera en  el Banco como Jefe de Relaciones Laborales en 2004, luego en 2010 obtuvo el  cargo de Jefe de Gestión de Recursos Humanos y en 2011, fue designado como  Gerente de Gestión y Desarrollo de Personas. Desde 1999 a 2003 trabajó en  América Latina Logística S.A. como Coordinador de Relaciones Laborales para  luego ser promovido a Gerente de la misma área durante el 2003. Posee el título  de Abogado expedido por la Universidad de Buenos Aires y ha realizado un  Posgrado en Gestión de Recursos Humanos en la Universidad de Belgrano.</p>
					<br>
					<p><strong>Alejandro Oscar Pisani</strong><br>
					Gerente Ejecutivo de Asuntos Legales</p>
					<p>Argentino, nacido el 29 de enero de  1958. Desde septiembre de 2011, está a cargo de la Gerencia Ejecutiva de  Asuntos Legales. Se incorporó al Banco a través de sus entidades predecesoras  en 1988 y pasó a ser Gerente de Asuntos Legales en 1992. Desde 1981 a 1982, el  Sr. Pisani trabajó en Banco de Intercambio Regional S.A. y desde 1982 a 1985 en  Banco Financiero. Posee el título de Abogado expedido por la Universidad de  Buenos Aires.</p>
					<br>
					<p><strong>Laura Eugenia Varela</strong><br>
					Gerente Ejecutivo de Planeamiento, Marca y Comunicación</p>
					<p>Argentina, nacida el 02 de marzo de  1974. Desde octubre de 2017, está a cargo de la Gerencia Ejecutiva de  Planeamiento, Marca y Comunicación. Se incorporó al Banco en 2003, fue  designada Gerente en 2011 y en julio de 2015, fue promovida a Gerente Ejecutiva  de Secretaría de Directorio. Posee el título de Contadora Pública expedido por  la Universidad Argentina de la Empresa y obtuvo una Maestría en Finanzas de  UCEMA. Asimismo, ha completado un Programa de Desarrollo Directivo en el  Instituto de Altos Estudios Empresariales de la Universidad Austral.</p>
					<br>
					<p><strong>Ezequiel Bernuez</strong><br>
					Gerente Ejecutivo de Secretaria de Directorio</p>
					<p>Argentino, nacido el 03 de diciembre  de 1973. Desde agosto de 2019, se encuentra a cargo de la Gerencia Ejecutiva de  Secretaría de Directorio. Inició su carrera en el Banco en abril de 2013 a  cargo de la Gerencia de Riesgo Operacional, Controles Internos y Compliance.  Desde esa misma fecha, fue designado Liquidador de Banco do Brasil – Sucursal  Buenos Aires (en liquidación), donde antes de ocupar dicho cargo se desempeñó  como Gerente Adjunto Local y Compliance Officer desde 2006. Desde 2001 hasta  2006 trabajó en Deutsche Bank S.A. como Controller Local y desde 1996 hasta  2001 como Auditor Senior de Entidades Financieras en KPMG. Asimismo, fue  designado liquidador de Banco Patagonia (Uruguay) SAIFE (en liquidación) en  junio de 2022. Posee el título de Contador Público Nacional expedido por la  Universidad del Salvador y ha completado un Programa de Liderazgo en el IAE y  de Corporate Governance en el IGEP.</p>
					<br>
					<p><strong>Favio Daniel Galeano</strong><br>
					Gerente de Auditoría Interna</p>
					<p>Argentino, nacido el 05 de marzo de  1972. Desde septiembre de 2011, está a cargo de la Gerencia de Auditoría  Interna. Se incorporó a la entidad en junio de 2003, y previamente se desempeñó  como Encargado Senior de Entidades Financieras en el Estudio Pistrelli, Díaz y  Asociados, posteriormente Pistrelli, Henry Martin y Asociados, firma miembro de  E&amp;Y GLOBAL desde 1997 a 2003. Actualmente es miembro del Comité BCRA. Posee  el título de Contador Público expedido por la Universidad de Buenos Aires y  obtuvo un MBA en UCEMA.</p>
					<br>
					<p><strong>Gonzalo Estrada</strong><br>
					Gerente de Prevención del Lavado de Activos</p>
					<p>Argentino, nacido el 20 de septiembre  de 1969. Es Gerente de Prevención de Lavado de Activos desde noviembre de 2019.  También es Oficial Responsable de FATCA (Foreign Account Tax Compliance Act  Responsible Officer). Comenzó su carrera a través de las entidades predecesoras  al Banco Patagonia desde mayo de 1994, habiendo adquirido experiencia en su  paso por diversas áreas tales como Gerencia de Riesgos, Gerencia de Análisis de  Créditos PyME y Gerencia de Análisis de Créditos Masivos. Posee los títulos de  Licenciado en Administración de Empresas y de Contador Público expedidos por la  Universidad de Buenos Aires, y ha realizado un Master de Finanzas en UCEMA.</p>
					<br>
					<p><strong>Fernanda Ravizzini Ortiz de Guinea</strong><br>
					Gerente de  Seguridad Informática y Protección de Activos de Información</p>
					<br>
					<p>Argentina, nacida el 16  de mayo de 1980. Se incorporó al Banco como Gerente de Seguridad Informática y  Protección de Activos de Información en octubre de 2024. Anteriormente se  desempeñó como Gerente de Arquitectura, Infraestructura e Identidades de Seguridad  de la Información en la empresa de telecomunicaciones Telecentro S.A., desde el  año 2019. También fue Jefe de Seguridad de la Información e Infraestructura  Tecnología en Aerolíneas Argentinas S.A. en el año 2016, y Supervisora de  Protección de activos informáticos del Banco de Valores S.A. en el año 2014.  Posee el título de Ingeniera en Sistemas expedido por la Universidad Abierta  Interamericana, también realizó una Diplomatura en Dirección de Seguridad de la  Información en la Universidad CAECE y una Diplomatura en Estrategia de  Ciberseguridad e Inteligencia en Cibercrimen en la UNSTA.</p>
					<!-- -->
                </div>
			</div>
		</div>
	</section>
	<div class="container-fluid footer-bar">
	<div class="row">
		<footer class="container">
			<div class="row">
				<div class="col-md-12">
					<p class="flnks"><a href="../../registro-nacional-base-datos.php">Registro Nacional de Base de Datos</a> <span>|</span>   <a href="../../codigo-practicas-bancarias.php">Código de Prácticas Bancarias</a> <span>|</span>   <a href="../../defensa-ley-consumidor.php">Defensa del Consumidor</a>
						<span>|</span>   <a href="https://www.argentina.gob.ar/produccion/defensadelconsumidor/formulario">Defensa de las y los consumidores. Para reclamos ingrese aquí</a><span>|</span> <br class="tbl"> <a href="../../persona-expuesta-politicamente.php">Persona Expuesta Políticamente</a> <span class="tbl">|</span> <br class="dsk">
						
					<a href="../../agencia-acceso-informacion-publica.php">Agencia de Acceso a la Información Pública</a> <span>|</span> <br class="tbl"> 
					<a href="../../cnv-advertencia-publico-inversor.php">CNV - Advertencia al Público Inversor</a> <span>|</span> <a href="../../docs/Idoneos.pdf" target="_blank"> Idóneos en Mercado de Capitales - CNV</a><span>|</span>   <a href="../../codigo-proteccion-inversor.php">Código de Protección al Inversor</a> <span>|</span>   <a href="../../clausulas-legales.php">Cláusulas Legales</a> <span>|</span> <a href="../../resolucion-022021.php">Resol. 02/21 Dir.Gral. Defensa del consumidor Córdoba</a></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<p class="redes">
                        <span>Seguinos en:</span>
                        <!-- -->
                        <a href="https://www.facebook.com/BancoPatagonia/" target="_blank"><img src="../../assets/images/layout/icon-facebook.svg" alt="Facebook"></a>
                        <a href="https://twitter.com/banco_patagonia" target="_blank"><img src="../../assets/images/layout/icon-twitter.svg" alt="Twitter"></a>
                        <a href="https://www.instagram.com/banco_patagonia/" target="_blank"><img src="../../assets/images/layout/icon-instagram.svg" alt="Instagram"></a>
                        <a href="https://www.youtube.com/user/bancopatagonia" target="_blank"><img src="../../assets/images/layout/icon-youtube.svg" alt="Youtube"></a>
                        <!-- -->
                        <!--
                        <a href="https://www.facebook.com/BancoPatagonia/" target="_blank"><i class="fa fa-facebook-square"></i></a>
                        <a href="https://twitter.com/banco_patagonia" target="_blank"><i class="fa fa-twitter"></i></a>
                        <a href="https://www.instagram.com/banco_patagonia/" target="_blank"><i class="fa fa-instagram"></i></a>
                        <a href="https://www.youtube.com/user/bancopatagonia" target="_blank"><i class="fa fa-youtube-play"></i></a>
                        -->
                    </p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					                    <!---->
				    <p class="flegal">BANCO PATAGONIA S.A. ES UNA SOCIEDAD ANÓNIMA CONSTITUIDA BAJO LAS LEYES DE LA REPÚBLICA ARGENTINA CUYOS ACCIONISTAS LIMITAN SU RESPONSABILIDAD A LA INTEGRACIÓN DE LAS ACCIONES SUSCRITAS DE ACUERDO A LA LEY 19.550. POR CONSIGUIENTE, Y EN CUMPLIMIENTO DE LA LEY 25.738, SE INFORMA QUE NI LOS ACCIONISTAS MAYORITARIOS DE CAPITAL EXTRANJERO NI LOS ACCIONISTAS LOCALES O EXTRANJEROS RESPONDEN, EN EXCESO DE LA CITADA INTEGRACIÓN ACCIONARIA, POR LAS OBLIGACIONES EMERGENTES DE LAS OPERACIONES CONCERTADAS POR LA ENTIDAD FINANCIERA.</p>
                    <p class="flegal" style="font-size:10px;">Banco Patagonia S.A. - Agente de Liquidacion y Compensacion y Agente de Negociacion Integral, inscripto en CNV bajo el N° 66</p>
					<p class="flegal">© 2025 Banco Patagonia . Todos los derechos reservados. Prohibida la duplicación , distribución o almacenamiento en cualquier medio.</p>
				</div>
			</div>
		</footer>
	</div>
</div>
<div class="tbl mbl placeholder-shortlinks">
	<div class="container shortlinks">
		<div class="row">
            <!--<php if ($home_personas == false) { ?>
                <div class="col-sm-3 col-xs-3">
                    <a href="#"><span class="icon icon-contacto"></span></a>
                </div>
            <php } ?>-->
            			<div class="col-sm-3 col-xs-3">
				<a href="http://sucursalesycajeros.bancopatagonia.com.ar/sucursales.html" target="_blank"><span class="icon icon-sucursales"></span>Sucursales y Cajeros</a>
			</div>
			<div class="col-sm-3 col-xs-3">
				<a href="../../preguntas-frecuentes/index.php"><span class="icon icon-contacto"></span>Ayuda</a>
			</div>
			<div class="col-sm-3 col-xs-3 last">
				<a href="../../empresas/patagonia-ebank-empresas-mbl.php"><span class="icon icon-ebank"></span>Patagonia e-Bank</a>
			</div>
		</div>
	</div>
</div>	<script src="../../assets/js/jquery-3.5.1.min.js"></script>
<script src="../../assets/bootstrap/js/bootstrap.min.js"></script>
<script src="../../assets/js/slick/slick.min.js"></script>
<script src="../../assets/js/fancybox/jquery.fancybox.min.js"></script>
<script src="../../assets/js/mtabs/jquery.bootstrap-responsive-tabs.min.js"></script>
<script src="../../assets/js/funciones.js"></script>

<!-- Global site tag (gtag.js) - Google Analytics (original) -->
<!--
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-32588129-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-32588129-1');
</script>
-->

<!-- Google Analytics (version anterior / eventos ok)  -->
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');
  ga('create', 'UA-32588129-1', 'auto');
  ga('send', 'pageview');
</script>

<!-- GA4 - Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-C6LG1PT98X"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-C6LG1PT98X');
</script>
</body>
</html>