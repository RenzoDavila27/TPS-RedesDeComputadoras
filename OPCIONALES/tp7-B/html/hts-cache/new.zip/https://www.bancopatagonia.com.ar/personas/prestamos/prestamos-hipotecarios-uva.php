<!DOCTYPE html>
<html lang="es">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
		<meta http-equiv="Pragma" content="no-cache">
		<meta http-equiv="Expires" content="0">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-NL73B44');</script>
<!-- End Google Tag Manager -->

<link rel="shortcut icon" href="../../favicon.ico" type="image/x-icon"/>
<link href="../../assets/fonts/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="../../assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="../../assets/js/mtabs/bootstrap-responsive-tabs.css" rel="stylesheet" type="text/css">
<link href="../../assets/js/slick/slick.css" rel="stylesheet" type="text/css">
<link href="../../assets/js/fancybox/jquery.fancybox.min.css" rel="stylesheet" type="text/css">
<link href="../../assets/css/styles.css" rel="stylesheet" type="text/css">
<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->		
		<!-- METATAGS -->
		<title>Préstamos Hipotecarios UVA | Banco Patagonia</title>
		<meta name="description" content="¡Pedí un préstamo para renovar o comprar tu casa!">

		<!-- Google -->
		<meta name="thumbnail" content="https://www.bancopatagonia.com.ar/personas/prestamos/images/prestamos-hipotecarios-uva/head-prestamos-hipotecarios-uva-mbl.jpg" />

		<!-- Open Graph / Facebook -->
		<meta property="og:type" content="website">
		<meta property="og:url" content="">
		<meta property="og:title" content="Préstamos Hipotecarios UVA">
		<meta property="og:description" content="¡Pedí un préstamo para renovar o comprar tu casa!">
		<meta property="og:image" content="https://www.bancopatagonia.com.ar/personas/prestamos/images/prestamos-hipotecarios-uva/head-prestamos-hipotecarios-uva-mbl.jpg">

		<!-- Twitter -->
		<meta property="twitter:card" content="summary_large_image">
		<meta property="twitter:url" content="">
		<meta property="twitter:title" content="Préstamos Hipotecarios UVA">
		<meta property="twitter:description" content="¡Pedí un préstamo para renovar o comprar tu casa!">
		<meta property="twitter:image" content="https://www.bancopatagonia.com.ar/personas/prestamos/images/prestamos-hipotecarios-uva/head-prestamos-hipotecarios-uva-mbl.jpg">
		
        <!-- SLIDES RESPONSIVE -->
        <style>
            /* DSK */
			#head-prestamos-hipotecarios-uva { background-image: url(images/prestamos-hipotecarios-uva/head-prestamos-hipotecarios-uva-dsk.jpg); background-image: -webkit-image-set ( url("images/prestamos-hipotecarios-uva/head-prestamos-hipotecarios-uva-dsk.jpg") 1x, url("images/prestamos-hipotecarios-uva/head-prestamos-hipotecarios-uva-dsk@2x.jpg") 2x ); }
			#section-prestamos-hipotecarios-uva { background-image: url(images/prestamos-hipotecarios-uva/section-prestamos-hipotecarios-uva-dsk.jpg); background-image: -webkit-image-set ( url("images/prestamos-hipotecarios-uva/section-prestamos-hipotecarios-uva-dsk.jpg") 1x, url("images/prestamos-hipotecarios-uva/section-prestamos-hipotecarios-uva-dsk@2x.jpg") 2x ); }

            @media screen and (max-width: 1200px) {
                /* TBT */
				#head-prestamos-hipotecarios-uva { background-image: url(images/prestamos-hipotecarios-uva/head-prestamos-hipotecarios-uva-tbl.jpg); background-size: auto !important; background-image: -webkit-image-set ( url("images/prestamos-hipotecarios-uva/head-prestamos-hipotecarios-uva-tbl.jpg") 1x, url("images/prestamos-hipotecarios-uva/head-prestamos-hipotecarios-uva-tbl@2x.jpg") 2x ); }
				#section-prestamos-hipotecarios-uva { background-image: url(images/prestamos-hipotecarios-uva/section-prestamos-hipotecarios-uva-tbl.jpg); background-size: auto !important; background-image: -webkit-image-set ( url("images/prestamos-hipotecarios-uva/section-prestamos-hipotecarios-uva-tbl.jpg") 1x, url("images/prestamos-hipotecarios-uva/section-prestamos-hipotecarios-uva-tbl@2x.jpg") 2x ); }
            }
            @media screen and (max-width: 560px) {
                /* MBL */
                #head-prestamos-hipotecarios-uva { background-image: url(images/prestamos-hipotecarios-uva/head-prestamos-hipotecarios-uva-mbl.jpg); background-image: -webkit-image-set ( url("images/prestamos-hipotecarios-uva/head-prestamos-hipotecarios-uva-mbl.jpg") 1x, url("images/prestamos-hipotecarios-uva/head-prestamos-hipotecarios-uva-mbl@2x.jpg") 2x ); }
				#section-prestamos-hipotecarios-uva { background-image: url(images/prestamos-hipotecarios-uva/section-prestamos-hipotecarios-uva-mbl.jpg); background-image: -webkit-image-set ( url("images/prestamos-hipotecarios-uva/section-prestamos-hipotecarios-uva-mbl.jpg") 1x, url("images/prestamos-hipotecarios-uva/section-prestamos-hipotecarios-uva-mbl@2x.jpg") 2x ); }
            }
			/**/
			#sec-head-phuvas .sec-pic-head { background-color: #fff; margin-bottom: 45px; display: flex; align-items: center; justify-content: center; }
        </style>
        <!-- -->
		
		<style>
			.text-data h1 { font-size: 36px; line-height: 1em; margin-bottom: 0; padding: 0 15px; }
			.text-data h1, .text-data h2, .text-data h3, .text-data a { color: #0f2451; }
			.text-data h2.h2-xl-phuvas { font-size: 32px; margin-bottom: 10px; }
			/* ----- */
			/* CAJAS */
			/* ----- */
			.box-phuva, .cuota-phuva { height: 185px; border-radius: 25px; display: flex; align-items: center; justify-content: center; padding: 0 15px; margin-bottom: 25px; column-gap: 15px; }
			.box-phuva big span sup, .cuota-phuva big sup { font-size: 14px; top: -1.4em; }
			.inline-phuva { display: inline-block !important; }
			/* CAJA PRINC. */
			.box-phuva { background-color: #0f2451; }
			.box-phuva big { display: block; font-family: "Roboto-Bold"; font-size: 60px; }
			.box-phuva big.phuva-big-xl { font-size: 110px; }
			.box-phuva big span { font-size: 0.75em; }
			.box-phuva h2, .box-phuva h3, .box-phuva big { color: #fff; margin-bottom: 0px; }
			/* ICONOS */
			figure { position: relative; }
			figure i { position: absolute; background-repeat: no-repeat; background-position: center center; }
			#icon-01-phuvas { background-image: url(images/prestamos-hipotecarios-uva/01-icon.svg); width: 17%; height: 48%; top: 6%; left: -2%; }
			#icon-02a-phuvas { background-image: url(images/prestamos-hipotecarios-uva/02a-icon.svg); width: 23%; height: 31%; top: -9%; left: 8%; }
			#icon-02b-phuvas { background-image: url(images/prestamos-hipotecarios-uva/02b-icon.svg); width: 9%; height: 32%; top: 10%; right: -2.5%; }
			#icon-03-phuvas { background-image: url(images/prestamos-hipotecarios-uva/03-icon.svg); width: 18%; height: 65%; top: 18%; right: -2.5%; }
			#icon-04-phuvas { background-image: url(images/prestamos-hipotecarios-uva/04-icon.svg); width: 20%; height: 80%; top: -5%; left: -1%; }
			#icon-05a-phuvas { background-image: url(images/prestamos-hipotecarios-uva/05a-icon.svg); width: 10%; height: 48%; top: -5%; left: -3%; }
			#icon-05b-phuvas { background-image: url(images/prestamos-hipotecarios-uva/05b-icon.svg); width: 12%; height: 35%; top: 18%; right: -2%; }
			/* CAJA CUOTAS */
			.cuota-phuva { background-color: #a9dd00; }
			.cuota-phuva h2, .cuota-phuva h3 { margin-bottom: 7.5px; }
			.cuota-phuva big { color: #0f2451; display: block; font-family: "Roboto-Bold"; font-size: 34px; }
			/* ------- */
			/* BOTONES */
			/* ------- */
			a.btn-cta-phuva { padding: 15px; text-align: center; display: block; margin: 15px 0; }
			/* CTA */
			a.btn-cta-phuva { font-size: 14px; border-radius: 25px; background-color: #a9dd00; }
			a.btn-cta-phuva:hover { color: #fff; opacity: 0.8; /*transition: 1s;*/ }

			@media screen and (max-width: 1200px) {
				.text-data h1 { font-size: 30px; }
				.text-data h2.h2-xl-phuvas { font-size: 26px; }
                .box-phuva, .cuota-phuva { height: 152px; }
            }
			@media screen and (max-width: 991px) {
				.box-phuva { height: 115px; }
				.cuota-phuva { height: 175px; }
                .box-phuva big { font-size: 40px; }
				.box-phuva big.phuva-big-xl { font-size: 80px; }
				.cuota-phuva big { font-size: 28px; }
            }
			@media screen and (max-width: 560px) {
				.box-phuva, .cuota-phuva { border-radius: 15px; }
				.cuota-phuva { height: 115px; }
            }
			
        </style>
		
	</head>
<body>
	<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NL73B44"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

<div class="placeholder-bar">
	<div class="container-fluid header-bar">
		<div class="row">
			<header class="container">
				<div class="row">
					<div class="col-md-3 col-dsk-6 col-sm-6">
						<span class="c-hamburger c-hamburger--htx">
							<span>toggle menu</span>
						</span>
                        <!-- -->
                        <!--<img style="position: absolute; width: 42px; top: 20px; right: 40px;" class="dsk" src="<php echo $path ?>assets/images/layout/icon-verano-2022.svg">-->
                        <!-- -->
						<h1>
                            <!--<img style="position: absolute; width: 32px; top: 12px; left: 102px;" class="dsk" src="<php echo $path ?>assets/images/layout/icon-navidad-2021.svg">-->
                            <a href="../index.php" class="main-logo">Banco Patagonia</a>
                        </h1>
					</div>
					<div class="col-md-9 col-dsk-6 col-sm-6">
						<div class="general-links">
							<ul class="list-unstyled">
                                <li id="btn-hacete-cliente"><a href="https://tunuevacuenta.bancopatagonia.com.ar/?utm_source=sitiowebbp&utm_medium=sitiowebbp%20banner%20home&utm_campaign=onboarding_sitiowebp_bannerhome" target="_blank"><strong>Hacete cliente <i class="fa fa-angle-right"></i></strong></a></li>								<li><a href="../../preguntas-frecuentes/index.php" class="">Ayuda</a></li>
								<!--<li><a href="<php echo $folder_canales ?>index.php" class="<php echo $canales ?>">Canales de atención</a></li>-->
								<!--<li><a href="http://sucursalesycajeros.bancopatagonia.com.ar/sucursales.html" target="_blank">Sucursales y cajeros</a></li>-->
								<!--<li><a href="<php echo $folder_contactenos ?>index.php" class="<php echo $contactenos ?>">Contactanos</a></li>-->
                                <!--<li><a href="<php echo $path ?>ayuda/index.php" class="<php echo $ayuda ?>">Ayuda</a></li>-->
							</ul>
						</div>
						<div class="top-links">
							<ul class="list-unstyled">
								<li><a href="../index.php" class="active">PERSONAS</a></li>
								<li><a href="../../nyps/index.php" class="">PROFESIONALES Y COMERCIOS</a></li>
								<li><a href="../../pyme/index.php" class="">PYME</a></li>
								<li><a href="../../agro/index.php" class="">AGRO</a></li>
								<li><a href="../../empresas/index.php" class="">EMPRESAS</a></li>
								<li><a href="../../sector-publico/index.php" class="">SECTOR PÚBLICO</a></li>
								<li><a href="../../institucional/index.php" class="">INSTITUCIONAL</a></li>
							</ul>
							<div class="ebank">
                            <!-- antes href: <php echo $folder_empresas ?><php echo $url_ebank ?>-->
															<a href="https://ebankpersonas.bancopatagonia.com.ar/eBanking/usuarios/login.htm" class="patagonia-ebank" target="_blank">Patagonia e-Bank</a>
														</div>
						</div>
					</div>
				</div>
			</header>
		</div>
	</div>
</div>

<div class="container-fluid nav-bar">
	<div class="row">
		<nav class="container">
			<div class="row">
				<!--<div class="col-md-9 col-md-offset-3">-->
                <div class="col-md-10 col-md-offset-3"><!-- ajuste agro -->
					<ul class="list-unstyled sub-navbar">
						
												<!-- PERSONAS -->
                        <li class="nav-item"><a href="#" class="nav-lnk ">PATAGONIA CLÁSICA</a>
							<ul class="list-unstyled submenu">
                                <li><a href="../../personas/patagonia-clasica/patagonia-ahorro/productos.php">Patagonia Ahorro</a></li>
                                <li><a href="../../personas/patagonia-clasica/paquete/productos.php">Patagonia Clásica</a></li>
                                <!--<li><a href="<php echo $path ?>personas/patagonia-clasica/mas/productos.php">Patagonia Clásica Más</a></li>-->
                                <li><a href="../../personas/patagonia-clasica/premium/productos.php">Patagonia Clásica Premium</a></li>
                                <li><a href="../../personas/patagonia-clasica/patagonia-sueldo/productos.php">Patagonia Sueldo</a></li>
							</ul>
						</li>
						<li class="nav-item"><a href="#" class="nav-lnk ">PATAGONIA PLUS</a>
							<ul class="list-unstyled submenu">
                                <li><a href="../../personas/patagonia-plus/productos.php">Patagonia Plus</a></li>
                                <li><a href="../../personas/patagonia-plus/premium/productos.php">Patagonia Plus Premium</a></li>
							</ul>						
						</li>
						<li class="nav-item"><a href="#" class="nav-lnk ">PATAGONIA SINGULAR</a>
							<ul class="list-unstyled submenu">
								<li><a href="../../personas/patagonia-singular/paquete/propuesta.php">Patagonia Singular</a></li>
                                <li><a href="../../personas/patagonia-singular/beneficios-exclusivos.php">Beneficios Exclusivos</a></li>
                                <!--<li><a href="<php echo $path ?>personas/patagonia-singular/atencion-exclusiva/index.php">Atención Exclusiva</a></li>-->
                                <!--<li><a href="<php echo $path ?>personas/patagonia-singular/eventos-y-novedades/index.php">Eventos y Novedades</a></li>-->
							</ul>
						</li>
						<!--<li class="nav-item"><a href="<php echo $path ?>patagoniaon/index.php" target="_blank" class="nav-lnk">PATAGONIA ON</a></li>-->
						<li class="nav-item"><a href="#" class="nav-lnk ">PATAGONIA ON</a>
							<ul class="list-unstyled submenu">
                                <li><a href="../../patagoniaon/index.php" target="_blank">Patagonia ON</a></li>
								<li><a href="../../personas/productos-y-servicios/patagonia-universitaria.php">Patagonia ON Universitaria</a></li>
							</ul>
						</li>
						<li class="nav-item"><a href="#" class="nav-lnk ">PRODUCTOS Y SERVICIOS</a>
							<ul class="list-unstyled submenu">
                                <li><a href="../../personas/apple-pay.php">Apple Pay</a></li>
                                <li><a href="../../personas/productos-y-servicios/caja-de-seguridad.php">Caja de Seguridad</a></li>
                                <li><a href="../../personas/productos-y-servicios/comercio-exterior/productos.php">Comercio exterior</a></li>
								<!--<li><a href="<php echo $path ?>personas/productos-y-servicios/beneficios-wapa.php">Comercios WAPA</a></li>-->
								<li><a href="../../personas/cuotifica-al-toque.php">Cuotificá al Toque</a></li>
								<li><a href="../../personas/google-pay.php">Google Pay</a></li>
                                <li><a href="../../personas/productos-y-servicios/inversiones.php">Inversiones</a></li>
                                <li><a href="../../personas/jubilados/index.php">Jubilados</a></li>
                                <li><a href="../../personas/productos-y-servicios/patagonia-para-menores.php">Patagonia para Menores</a></li>
                                <!--<li><a href="<php echo $path ?>personas/productos-y-servicios/patagonia-universitaria.php">Patagonia Universitaria</a></li>-->
                                <li><a href="../../personas/productos-y-servicios/prestamos.php">Prestamos</a></li>
                                <li><a href="../../personas/seguros/index.php">Seguros</a></li>
                                <li><a href="../../personas/productos-y-servicios/tarjetas-de-credito/visa.php">Tarjetas de crédito</a></li>
								<li><a href="../../personas/productos-y-servicios/tarjetas-de-debito/patagonia-24.php">Tarjetas de débito</a></li>
							</ul>
						</li>
						<!-- FIN PERSONAS -->
						                        
                                                
                                                
                        						
												
												
						
											</ul>
				</div>
			</div>
		</nav>
	</div>
</div>

<div class="mobile-nav-bar">
	<ul class="list-unstyled">
        
        <!-- PERSONAS -->
		<li class="nav-main-item"><a href="#" class="has-sub-items active">PERSONAS <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../index.php" class="active">HOME</a></li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA CLÁSICA</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../personas/patagonia-clasica/patagonia-ahorro/productos.php">Patagonia Ahorro</a></li>
                        <li><a href="../../personas/patagonia-clasica/paquete/productos.php">Patagonia Clásica</a></li>
                        <!--<li><a href="<php echo $path ?>personas/patagonia-clasica/mas/productos.php">Patagonia Clásica Más</a></li>-->
                        <li><a href="../../personas/patagonia-clasica/premium/productos.php">Patagonia Clásica Premium</a></li>
                        <li><a href="../../personas/patagonia-clasica/patagonia-sueldo/productos.php">Patagonia Sueldo</a></li>
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA PLUS</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../personas/patagonia-plus/productos.php">Patagonia Plus</a></li>
                        <li><a href="../../personas/patagonia-plus/premium/productos.php">Patagonia Plus Premium</a></li>
                    </ul>						
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA SINGULAR</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../personas/patagonia-singular/paquete/propuesta.php">Patagonia Singular</a></li>
                        <li><a href="../../personas/patagonia-singular/beneficios-exclusivos.php">Beneficios Exclusivos</a></li>
                        <!--<li><a href="<php echo $path ?>personas/patagonia-singular/atencion-exclusiva/index.php">Atención Exclusiva</a></li>-->
                        <!--<li><a href="<php echo $path ?>personas/patagonia-singular/eventos-y-novedades/index.php">Eventos y Novedades</a></li>-->
                    </ul>
                </li>
				<!--<li class="nav-sub-item"><a href="<php echo $path ?>patagoniaon/index.php" target="_blank">PATAGONIA ON</a></li>-->
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA ON</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../patagoniaon/index.php" target="_blank">Patagonia ON</a></li>
						<li><a href="../../personas/productos-y-servicios/patagonia-universitaria.php">Patagonia ON Universitaria</a></li>
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PRODUCTOS Y SERVICIOS</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../personas/apple-pay.php">Apple Pay</a></li>
                        <li><a href="../../personas/productos-y-servicios/caja-de-seguridad.php">Caja de Seguridad</a></li>
                        <li><a href="../../personas/productos-y-servicios/comercio-exterior/productos.php">Comercio exterior</a></li>
						<!--<li><a href="<php echo $path ?>personas/productos-y-servicios/beneficios-wapa.php">Comercios WAPA</a></li>-->
						<li><a href="../../personas/cuotifica-al-toque.php">Cuotificá al Toque</a></li>
						<li><a href="../../personas/google-pay.php">Google Pay</a></li>
                        <li><a href="../../personas/productos-y-servicios/inversiones.php">Inversiones</a></li>
                        <li><a href="../../personas/jubilados/index.php">Jubilados</a></li>
                        <li><a href="../../personas/productos-y-servicios/patagonia-para-menores.php">Patagonia para Menores</a></li>
                        <!--<li><a href="<php echo $path ?>personas/productos-y-servicios/patagonia-universitaria.php">Patagonia Universitaria</a></li>-->
                        <li><a href="../../personas/productos-y-servicios/prestamos.php">Prestamos</a></li>
                        <li><a href="../../personas/seguros/index.php">Seguros</a></li>
                        <li><a href="../../personas/productos-y-servicios/tarjetas-de-credito/visa.php">Tarjetas de crédito</a></li>
                        <li><a href="../../personas/productos-y-servicios/tarjetas-de-debito/patagonia-24.php">Tarjetas de débito</a></li>
                    </ul>
                </li>
			</ul>
		</li>
        <!-- FIN PERSONAS -->
        
        <!-- NYPS -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">PROFESIONALES Y COMERCIOS <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../nyps/index.php" class="">HOME</a></li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA CLÁSICA</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../nyps/patagonia-clasica/premium/productos.php">Patagonia Clásica Premium</a></li>
                        <li><a href="../../nyps/patagonia-clasica/patagonia-emprendimiento/productos.php">Patagonia Emprendimiento</a></li>
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA PLUS</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../nyps/patagonia-plus/productos.php">Patagonia Plus</a></li>
                        <li><a href="../../nyps/patagonia-plus/premium/productos.php">Patagonia Plus Premium</a></li>
                    </ul>						
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA SINGULAR</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../nyps/patagonia-singular/paquete/propuesta.php">Patagonia Singular</a></li>
                        <li><a href="../../nyps/patagonia-singular/beneficios-exclusivos.php">Beneficios Exclusivos</a></li>
                        <!--<li><a href="<php echo $path ?>nyps/patagonia-singular/eventos-y-novedades/index.php">Eventos y Novedades</a></li>-->
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PRODUCTOS Y SERVICIOS</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../nyps/productos-y-servicios/tarjetas-de-debito/patagonia-24.php">Tarjetas de débito</a></li>
                        <li><a href="../../nyps/productos-y-servicios/tarjetas-de-credito/visa.php">Tarjetas de crédito</a></li>
                        <li><a href="../../nyps/productos-y-servicios/prestamos.php">Prestamos</a></li>
                        <li><a href="../../nyps/seguros/index.php">Seguros</a></li>
                        <li><a href="../../nyps/productos-y-servicios/inversiones.php">Inversiones</a></li>
                        <li><a href="../../nyps/productos-y-servicios/comercio-exterior/productos.php">Comercio exterior</a></li>
                        <li><a href="../../nyps/productos-y-servicios/caja-de-seguridad.php">Caja de Seguridad</a></li>
                        <li><a href="../../nyps/productos-y-servicios/factura-electronica.php">Factura electrónica</a></li>
                        <li><a href="../../nyps/productos-y-servicios/pagos-afip.php">Pagos AFIP</a></li>
                        <!--<li><a href="<php echo $path ?>nyps/productos-y-servicios/soluciones-para-tu-empresa.php">Soluciones para tu empresa</a></li>-->
                        <!--<li><a href="<php echo $path ?>nyps/productos-y-servicios/comercios-patagonia.php">Comercios Patagonia</a></li>-->
						<li><a href="../../nyps/productos-y-servicios/wapa.php">WAPA</a></li>
                    </ul>
                </li>
			</ul>		
		</li>
        <!-- FIN NYPS -->
        
        <!-- PYME -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">PYME <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../pyme/index.php" class="">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">CUENTAS</a>
					<ul class="list-unstyled submenu">
                        <li><a href="../../pyme/cuentas/pequenas-empresas.php">Pyme Pequeñas Empresas</a></li>
				        <li><a href="../../pyme/cuentas/medianas-empresas.php">Pyme Medianas Empresas</a></li>
                        <!--
						<li><a href="../../pyme/cuentas/patagonia-empresario.php">Patagonia Empresario</a></li>
						<li><a href="../../pyme/cuentas/patagonia-empresario-premier.php">Patagonia Empresario Premier</a></li>
						<li><a href="../../pyme/cuentas/patagonia-empresa.php">Patagonia Empresa</a></li>
                        -->
                        <!--<li><a href="../../pyme/cuentas/patagonia-comercio.php">Patagonia Comercio</a></li>-->
                        <li><a href="../../pyme/cuentas/patagonia-consorcio.php">Patagonia Consorcio</a></li>
						<li><a href="../../pyme/cuentas/cuenta-corriente.php">Cuenta Corriente</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA SUELDO</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../pyme/patagonia-sueldo/servicios.php">Servicios</a></li>
						<li><a href="../../pyme/patagonia-sueldo/preguntas-frecuentes.php">Preguntas Frecuentes</a></li>
						<li><a href="../../pyme/patagonia-sueldo/guia-implementacion.php">Guía de Implementación</a></li>
					</ul>
				</li>						
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">COMERCIO EXTERIOR</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../pyme/comercio-exterior/solicitud-electronica.php">Solicitud Electrónica</a></li>
						<li><a href="../../pyme/comercio-exterior/productos.php">Productos</a></li>
						<li><a href="../../pyme/comercio-exterior/otros-servicios.php">Servicios</a></li>
						<!--<li><a href="<php echo $folder_pymeCexterior ?>financiaciones.php">Financiaciones</a></li>-->
                        <li><a href="../../pyme/comercio-exterior/herramientas-para-exportar.php">Herramientas para Exportar</a></li>
						<li><a href="../../pyme/comercio-exterior/marco-regulatorio/normas-y-regulaciones.php">Marco Regulatorio</a></li>
					</ul>
				</li>						
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">FINANCIACIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../pyme/financiacion/patagonia-leasing.php">Patagonia Leasing</a></li>
						<li><a href="../../pyme/financiacion/mercado-capitales.php">Mercado de Capitales</a></li>
						<li><a href="../../pyme/financiacion/alternativas-de-financiacion.php">Alternativas de Financiación</a></li>
					</ul>
				</li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">SEGUROS</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../pyme/seguros/protege-tus-bienes/integral-comercio.php">Protegé tus Bienes</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">INVERSIONES</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../pyme/inversiones/plazo-fijo.php">Plazo Fijo</a></li>
						<li><a href="../../pyme/inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
						<li><a href="../../pyme/inversiones/fidecomisos-financieros.php">Fidecomisos Financieros</a></li>
					</ul>
				</li>						
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">SERVICIOS</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../pyme/servicios/recaudaciones.php">Recaudaciones</a></li>
						<li><a href="../../pyme/servicios/pagos.php">Pagos</a></li>
						<li><a href="../../pyme/servicios/tarjetas-comerciales.php">Tarjetas Comerciales</a></li>
						<li><a href="../../pyme/servicios/comercios-patagonia.php">Comercios Patagonia</a></li>
                        <li><a href="../../pyme/servicios/pago-de-servicios.php">Pago de Servicios</a></li>
						<li><a href="../../pyme/servicios/interbanking.php">Interbanking</a></li>
						<li><a href="../../pyme/servicios/interfacturas.php">Interfacturas</a></li>
						<li><a href="../../pyme/servicios/pagos-afip.php">Pagos AFIP</a></li>
						<li><a href="../../pyme/servicios/wapa.php">WAPA</a></li>
					</ul>
				</li>
			</ul>		
		</li>
        <!-- FIN PYME -->
        
        <!-- AGRO -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">AGRO <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../agro/index.php" class="">HOME</a></li>
                <!-- -->
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">OFERTA AGRO</a>
					<ul class="list-unstyled submenu">
                    	<!--<li><a href="<php echo $folder_agroFinanciacion ?>insumos.php">Insumos en USD</a></li>-->
                        <li><a href="../../agro/convenios/acuerdos-y-beneficios.php">Acuerdos y convenios</a></li>
						<li><a href="../../agro/financiacion/maquinaria-agricola.php">Financiación Maquinaria Agrícola</a></li>
						<li><a href="../../agro/seguros/campo.php">Seguros para tu campo</a></li>
					</ul>
				</li>
                <!-- -->
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">TARJETA PATAGONIA AGRO</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../agro/tarjeta-patagonia-agro/para-usuarios.php">Para Usuarios</a></li>
						<li><a href="../../agro/tarjeta-patagonia-agro/para-comercios.php">Para Comercios</a></li>
						<li><a href="../../agro/tarjeta-patagonia-agro/acuerdo-tasa-0.php">Tarjetas Agro Convenios Preferenciales</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="../../agro/cuenta-agro/cuenta-agro.php" class="">CUENTA AGRO</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">FINANCIACIÓN</a>
					<ul class="list-unstyled submenu">
                        <li><a href="../../agro/insumos/index.php">Insumos</a></li>
                        <li><a href="../../agro/financiacion/maquinaria-agricola.php">Maquinarias</a></li>
                        <li><a href="../../empresas/financiacion/convenios-de-financiacion.php">Camiones</a></li>
						<!--<li><a href="<php echo $folder_agroFinanciacion ?>capital-de-trabajo.php">Capital de Trabajo</a></li>-->
						<!--<li><a href="<php echo $folder_agroFinanciacion ?>proyectos-de-inversion.php">Proyectos de Inversión</a></li>-->
						<!--<li><a href="<php echo $folder_agroFinanciacion ?>creditos-para-hacienda.php">Créditos para Hacienda</a></li>-->
						<!--<li><a href="<php echo $folder_agroFinanciacion ?>leasing-y-prendarios.php">Leasing y Prendarios</a></li>-->
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">INVERSIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../agro/inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
						<li><a href="../../agro/inversiones/fidecomisos-financieros.php">Fidecomisos Financieros</a></li>
						<li><a href="../../agro/inversiones/plazos-fijos.php">Plazos Fijos</a></li>
					</ul>
				</li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">COMERCIO EXTERIOR</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../agro/comercio-exterior/solicitud-electronica.php">Solicitud Electrónica</a></li>
                        <li><a href="../../agro/comercio-exterior/productos.php">Productos</a></li>
                        <li><a href="../../agro/comercio-exterior/otros-servicios.php">Servicios</a></li>
                        <li><a href="../../agro/comercio-exterior/herramientas-para-exportar.php">Herramientas para Exportar</a></li>
                        <li><a href="../../agro/comercio-exterior/marco-regulatorio/normas-y-regulaciones.php">Marco Regulatorio</a></li>
                    </ul>
                </li>
                <!--
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">SERVICIOS</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../agro/servicios/centro-atencion-empresas.php">Centro de Atención para Empresas</a></li>
					</ul>
				</li>
                -->
                <!-- -->
                <li class="nav-sub-item"><a href="../../agro/seguros/campo.php" class="">SEGUROS</a></li>
                <!-- -->
			</ul>
		</li>
        <!-- FIN AGRO -->
        
        <!-- EMPRESAS -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">EMPRESAS <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../empresas/index.php" class="">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA SUELDO</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../empresas/patagonia-sueldo/servicios.php">Servicios</a></li>
						<li><a href="../../empresas/patagonia-sueldo/preguntas-frecuentes.php">Preguntas Frecuentes</a></li>
						<li><a href="../../empresas/patagonia-sueldo/guia-implementacion.php">Guía de Implementación</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">COMERCIO EXTERIOR</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../empresas/comercio-exterior/solicitud-electronica.php">Solicitud Electrónica</a></li>
						<li><a href="../../empresas/comercio-exterior/productos.php">Productos</a></li>
						<li><a href="../../empresas/comercio-exterior/otros-servicios.php">Servicios</a></li>
						<!--<li><a href="<php echo $folder_Cexterior ?>financiaciones.php">Financiaciones</a></li>-->
                        <li><a href="../../empresas/comercio-exterior/herramientas-para-exportar.php">Herramientas para Exportar</a></li>
						<li><a href="../../empresas/comercio-exterior/marco-regulatorio/normas-y-regulaciones.php">Marco Regulatorio</a></li>
					</ul>
				</li>
                <!-- -->
				<!--<li class="nav-sub-item"><a href="../../empresas/comunidades-de-negocios/index.php" class="">COMUNIDADES DE NEGOCIOS</a></li>-->
                <!-- -->
				<li class="nav-sub-item"><a href="index.php" class="nav-lnk ">COMERCIOS PATAGONIA</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">FINANCIACIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../empresas/financiacion/patagonia-leasing.php">Patagonia Leasing</a></li>
						<li><a href="../../empresas/financiacion/mercado-capitales.php">Mercado Capitales</a></li>
						<li><a href="../../empresas/financiacion/alternativas-de-financiacion.php">Alternativas de Financiación</a></li>
                        <li><a href="../../empresas/financiacion/convenios-de-financiacion.php">Convenios de Financiación</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">INVERSIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../empresas/inversiones/plazos-fijos.php">Plazos Fijos</a></li>
						<li><a href="../../empresas/inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
						<li><a href="../../empresas/inversiones/compra-venta-titulos-acciones.php">Compra - Venta de Títulos y Acciones</a></li>
						<li><a href="../../empresas/inversiones/custodia-de-titulos.php">Custodia de Títulos</a></li>
						<li><a href="../../empresas/inversiones/fidecomisos-financieros.php">Fidecomisos Financieros</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">SERVICIOS</a>
					<ul class="list-unstyled submenu">
                        <li><a href="../../empresas/patagonia-movil-empresas.php">Patagonia Móvil Empresas</a></li>
						<li><a href="../../empresas/servicios/pagos.php">Pagos</a></li>
						<li><a href="../../empresas/servicios/recaudaciones.php">Recuadaciones</a></li>
						<li><a href="../../empresas/servicios/pago-de-servicios.php">Pago de Servicios</a></li>
						<li><a href="../../empresas/servicios/interbanking.php">Interbanking</a></li>
						<li><a href="../../empresas/servicios/interfacturas.php">Interfacturas</a></li>
						<li><a href="../../empresas/servicios/tarjetas-comerciales.php">Tarjetas Comerciales</a></li>
                        <!-- -->
						<!--<li><a href="../../empresas/servicios/comercios-patagonia.php">Comercios Patagonia</a></li>-->
                        <!-- -->
                        <li><a href="../../empresas/servicios/centro-atencion-empresas.php">Centro de Atención para Empresas</a></li>
					</ul>
				</li>
			</ul>
		</li>
        <!-- FIN EMPRESAS -->
        
        <!-- SECTOR PÚBLICO -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">SECTOR PÚBLICO <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../sector-publico/index.php" class="">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">INVERSIONES</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../sector-publico/inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
						<li><a href="../../sector-publico/inversiones/plazo-fijo.php">Plazo Fijo</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">SERVICIOS</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../sector-publico/servicios/servicio-de-recaudacion.php">Servicio de Recaudación</a></li>
						<li><a href="../../sector-publico/servicios/servicio-de-pagos.php">Servicio de Pagos</a></li>
						<li><a href="../../sector-publico/servicios/servicios-para-personal.php">Servicios para el Personal</a></li>
						<li><a href="../../sector-publico/servicios/financiacion.php">Financiación</a></li>
						<li><a href="../../sector-publico/servicios/otros-servicios.php">Servicios</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">PROGRAMA UNIVERSIDADES</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../sector-publico/programa-universidades/relacion-institucional.php">Relación Institucional</a></li>
						<li><a href="../../sector-publico/programa-universidades/docentes-yno-docentes.php">Docentes y No Docentes</a></li>
						<li><a href="../../sector-publico/programa-universidades/alumnos.php">Alumnos</a></li>
						<li><a href="../../sector-publico/programa-universidades/graduados.php">Graduados</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">BENEFICIOS RÍO NEGRO</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../sector-publico/rio-negro/presencia.php">Presencia en Río Negro</a></li>
                        <li><a href="../../sector-publico/rio-negro/propuesta-valor.php">Propuesta de valor exclusiva</a></li>
					</ul>
				</li>
			</ul>
		</li>
        <!-- FIN SECTOR PUBLICO -->
        
        <!-- INSTITUCIONAL -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">INSTITUCIONAL <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../institucional/index.php" class="">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">BANCO PATAGONIA</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../institucional/banco-patagonia/historia.php">Historia</a></li>
						<li><a href="../../institucional/banco-patagonia/mercado-de-capitales.php">Mercado de Capitales</a></li>
						<li><a href="../../institucional/banco-patagonia/patagonia-inversora.php">Patagonia Inversora</a></li>
						<li><a href="../../institucional/banco-patagonia/patagonia-valores-sa.php">Patagonia Valores S.A</a></li>
						<li><a href="https://bp.bancopatagonia.com.ar/relacion-con-inversores/es/institucional" target="_blank">Relación con Inversores</a></li>
						<li><a href="../../institucional/banco-patagonia/desarrollo-humano.php">Desarrollo Humano</a></li>
						<li><a href="../../institucional/banco-patagonia/sustentabilidad.php">Sustentabilidad</a></li>
						<li><a href="../../institucional/banco-patagonia/politicas-aml-cft.php">Póliticas AML/CFT</a></li>
						<li><a href="../../institucional/banco-patagonia/disciplina-del-mercado.php">Disciplina de Mercado</a></li>
                        <li><a href="../../institucional/banco-patagonia/asistencia-a-vinculados.php">Asistencia a vinculados</a></li>
                        <li><a href="../../institucional/banco-patagonia/etica-e-integridad.php">Ética e Integridad</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">ORGANIZACIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../institucional/organizacion/accionistas.php">Accionistas</a></li>
						<li><a href="../../institucional/organizacion/autoridades.php">Autoridades</a></li>
                        <li><a href="../../institucional/organizacion/comites.php">Comités</a></li>
						<li><a href="../../institucional/organizacion/sector-financiero.php">Sector Financiero</a></li>
					</ul>
				</li>
			</ul>
		</li>
        <!-- FIN INSTITUCIONAL -->
        
        <li class="nav-main-item"><a href="https://tunuevacuenta.bancopatagonia.com.ar/?utm_source=sitiowebbp&utm_medium=sitiowebbp%20banner%20home&utm_campaign=onboarding_sitiowebp_bannerhome" target="_blank" style="text-transform: none;">Hacete cliente</a></li>		<li class="nav-main-item"><a href="../../preguntas-frecuentes/index.php" class="" style="text-transform: none;">Ayuda</a></li>
		<!--<li class="nav-main-item"><a href="<php echo $folder_canales ?>index.php" class="<php echo $canales ?>" style="text-transform: none;">Canales de Atención</a></li>-->
		<!--<li class="nav-main-item"><a href="http://sucursalesycajeros.bancopatagonia.com.ar/sucursales.html" target="_blank" style="text-transform: none;">Sucursales y Cajeros</a></li>-->
		<!--<li class="nav-main-item"><a href="<php echo $folder_contactenos ?>index.php" class="<php echo $contactenos ?>" style="text-transform: none;">Contactanos</a></li>-->
        <!--<li class="nav-main-item"><a href="<php echo $path ?>ayuda/index.php" class="<php echo $ayuda ?>" style="text-transform: none;">Ayuda</a></li>-->
	</ul>
</div>	<section class="sec-head" title="El hogar que querés. Préstamos Hipotecarios UVA">
        <div class="sec-pic-head" id="head-prestamos-hipotecarios-uva">
        </div>
	</section>
	<section class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
				<ol class="breadcrumb">
					<li><a href="../index.php">Personas</a></li>
					<li>Préstamos</li>
					<li class="active">Préstamos Hipotecarios UVA</li>
				</ol>
			</div>
		</div>
	</section>
    <section id="sec-head-phuvas" class="sec-head">
        <div class="sec-pic-head" id="section-prestamos-hipotecarios-uva">
			<div class="text-data" style="margin-bottom: 0;">
				<h1 class="text-center"><strong>¡Pedí un préstamo para<br> <span class="clr-verde-2">renovar o comprar tu casa!</span></strong></h1>
			</div>
        </div>
	</section>
	<section class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
				<div class="text-data">
					<!-- -->
					
					<div class="row">
						<!-- COLUMNA -->
						<div class="col-md-6 col-sm-6 col-xs-12">
							<!-- -->
							<div class="box-phuva">
								<div>
									<h2 class="text-center"><strong>Te damos hasta</strong></h2>
									<big>$320.000.000</big>
									<!--<h3>Tenés hasta 30 años o 360 meses para devolverlo en cuotas.</h3>-->
								</div>
                            </div>
							<!-- -->
						</div>
						<!-- COLUMNA -->
						<div class="col-md-6 col-sm-6 col-xs-12">
							<!-- -->
							<figure>
								<i id="icon-01-phuvas"></i>
								<img src="images/prestamos-hipotecarios-uva/01.png" srcset="images/prestamos-hipotecarios-uva/01.png 1x, images/prestamos-hipotecarios-uva/01@2x.png 2x" class="img-responsive" alt="Te damos hasta $250.000.000">
							</figure>
							<!-- -->
						</div>
						<!-- -->
					</div>
					
					<div class="row">
						<!-- COLUMNA -->
						<div class="col-md-6 col-sm-6 col-xs-12">
							<!-- -->
							<figure>
								<i id="icon-02a-phuvas"></i>
								<i id="icon-02b-phuvas"></i>
								<img src="images/prestamos-hipotecarios-uva/02.png" srcset="images/prestamos-hipotecarios-uva/02.png 1x, images/prestamos-hipotecarios-uva/02@2x.png 2x" class="img-responsive" alt="Devolvelo en hasta 30 años">
							</figure>
							<!-- -->
						</div>
						<!-- COLUMNA -->
						<div class="col-md-6 col-sm-6 col-xs-12">
							<!-- -->
							<div class="box-phuva">
								<div>
									<h2 class="text-center"><strong>Devolvelo en hasta</strong></h2>
									<big>30 años</big>
								</div>
                            </div>
							<!-- -->
						</div>
						<!-- -->
					</div>
					
					<div class="row">
						<!-- COLUMNA -->
						<div class="col-md-6 col-sm-6 col-xs-12">
							<!-- -->
							<div class="box-phuva">
                                <h2>Relación<br> cuota ingreso<br> de hasta el</h2>
                                <big class="phuva-big-xl">25<span>%</span></big>
								<!--<h3>&nbsp;</h3>-->
                            </div>
							<!-- -->
						</div>
						<!-- COLUMNA -->
						<div class="col-md-6 col-sm-6 col-xs-12">
							<!-- -->
							<figure>
								<i id="icon-03-phuvas"></i>
								<img src="images/prestamos-hipotecarios-uva/03.png" srcset="images/prestamos-hipotecarios-uva/03.png 1x, images/prestamos-hipotecarios-uva/03@2x.png 2x" class="img-responsive" alt="Relación cuota ingreso de hasta el 25%">
							</figure>
							<!-- -->
						</div>
						<!-- -->
					</div>
					
					<div class="row">
						<!-- COLUMNA -->
						<div class="col-md-6 col-sm-6 col-xs-12">
							<!-- -->
							<div class="box-phuva">
								<div>
									<h2 class="text-center">Si cobrás tu sueldo con nosotros</h2>
									<big class="inline-phuva clr-verde-2">6,50<span>%<sup>(1)</sup></span></big>
									<h3 class="inline-phuva">Tasa fija + UVA</h3>
								</div>
							</div>
							<!-- -->
						</div>
						<!-- COLUMNA -->
						<div class="col-md-6 col-sm-6 col-xs-12">
							<!-- -->
							<div class="box-phuva">
								<div>
									<h2 class="text-center">Tasa mercado abierto</h2>
									<big class="inline-phuva">9,00<span>%<sup>(2)</sup></span></big>
									<h3 class="inline-phuva">Tasa fija + UVA</h3>
								</div>
                            </div>
							<!-- -->
						</div>
						<!-- -->
					</div>
					
					<div class="row">
						<!-- COLUMNA -->
						<div class="col-md-6 col-sm-6 col-xs-12">
							<!-- -->
							<div class="box-phuva">
								<h2>Para compra<br> financiá hasta el</h2>
								<big class="phuva-big-xl">75<span>%</span></big>
								<!--<h3>del valor del inmueble</h3>-->
							</div>
							<!-- -->
						</div>
						<!-- COLUMNA -->
						<div class="col-md-6 col-sm-6 col-xs-12">
							<!-- -->
							<figure>
								<i id="icon-04-phuvas"></i>
								<img src="images/prestamos-hipotecarios-uva/04.png" srcset="images/prestamos-hipotecarios-uva/04.png 1x, images/prestamos-hipotecarios-uva/04@2x.png 2x" class="img-responsive" alt="Para compra financiá hasta el 75%">
							</figure>
							<!-- -->
						</div>
						<!-- -->
					</div>
					
					<div class="row">
						<!-- COLUMNA -->
						<div class="col-md-6 col-sm-6 col-xs-12">
							<!-- -->
							<figure>
								<i id="icon-05a-phuvas"></i>
								<i id="icon-05b-phuvas"></i>
								<img src="images/prestamos-hipotecarios-uva/05.png" srcset="images/prestamos-hipotecarios-uva/05.png 1x, images/prestamos-hipotecarios-uva/05@2x.png 2x" class="img-responsive" alt="Para refacción financiá hasta el 25%">
							</figure>
							<!-- -->
						</div>
						<!-- COLUMNA -->
						<div class="col-md-6 col-sm-6 col-xs-12">
							<!-- -->
							<div class="box-phuva">
								<h2>Para refacción<br> financiá hasta el</h2>
								<big class="phuva-big-xl">25<span>%</span></big>
								<!--<h3>del valor del inmueble</h3>-->
							</div>
							<!-- -->
						</div>
						<!-- -->
					</div>
					
					<!-- ---------------- -->
					<!-- EJEMPLO DE CUOTA -->
					<!-- ---------------- -->
					<hr>
					<h2 class="text-center h2-xl-phuvas"><strong>Ejemplo de cuota<sup>(*)</sup></strong></h2>
					<h3 class="text-center">por un préstamo de $100.000.000 en 360 meses.</h3>
					<div class="row">
						<div class="col-md-6 col-sm-6 col-xs-12">
							<!-- -->
							<div class="cuota-phuva">
								<div>
									<h2 class="text-center"><strong>Si cobrás tu sueldo en Banco Patagonia</strong></h2>
									<h3 class="text-center">La cuota inicial será de</h3>
									<big class="text-center">$738.416<sup>(1)</sup></big>
								</div>
							</div>
							<!-- -->
						</div>
						<div class="col-md-6 col-sm-6 col-xs-12">
							<!-- -->
							<div class="cuota-phuva">
								<div>
									<h2 class="text-center"><strong>Si no cobrás tu sueldo en Banco Patagonia</strong></h2>
									<h3 class="text-center">La cuota inicial será de</h3>
									<big class="text-center">$951.110<sup>(2)</sup></big>
								</div>
							</div>
							<!-- -->
						</div>
					</div>
					<div class="row legal-int">
						<div class="col-md-12 col-sm-12 col-xs-12">
							<p>(*) EJEMPLOS DE CUOTAS PURAS (AMORTIZACIÓN DE CAPITAL MÁS INTERESES) Y CONDICIONES FINANCIERAS PARA UN CAPITAL DE $100.000.000 (PESOS CIEN MILLONES) A ABONAR EN 30 AÑOS - COTIZACIÓN DE LA UVA (UNIDAD DE VALOR ADQUISITIVO) PUBLICADA POR EL BANCO CENTRAL DE LA REPÚBLICA ARGENTINA AL 15/01/2025 : $1.315,87</p>
                        </div>
					</div>
					
					<!-- ------- -->
					<!-- BOTONES -->
					<!-- ------- -->
					<div class="row">
						<div class="col-md-4 col-sm-6 col-xs-12 col-md-offset-2">
							<!-- -->
							<a href="https://bp.bancopatagonia.com.ar/prestamos-hipotecarios-uva" target="_blank" class="btn-cta-phuva" style="background: #00b9ad;"><strong>¡QUIERO QUE ME CONTACTEN!</strong></a>
							<!-- -->
						</div>
						<div class="col-md-4 col-sm-6 col-xs-12">
							<!-- -->
							<a href="https://tunuevacuenta.bancopatagonia.com.ar/?utm_source=Webr&utm_medium=HipotecariosUva&utm_content=Boton_CTA" target="_blank" class="btn-cta-phuva"><strong>¡QUIERO HACERME CLIENTE!</strong></a>
							<!-- -->
						</div>
					</div>
						
					<!-- ---- -->
					<!-- FAQS -->
					<!-- ---- -->
					<hr>
					<h2 class="text-center h2-xl-phuvas"><strong>Preguntas Frecuentes</strong></h2>
					<div class="row">
						<!-- -------------------------------------- -->
						<!-- ¿Qué es un Préstamos Hipotecarios UVA? -->
						<!-- -------------------------------------- -->
						<!-- botón -->
						<div class="col-md-12 col-sm-12 col-xs-12">
							<a href="#faqs-phuvas-01" class="btn-faqs-dspl" data-toggle="modal"><i></i>¿Qué es un Préstamos Hipotecarios UVA?</a>
						</div>
						<!-- modal -->
						<div class="modal fade" id="faqs-phuvas-01">
							<div class="modal-dialog modal-lg">
								<div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal"><span>X</span></button>
									</div>
									<div class="modal-body">
										<div class="text-data">
											<!-- -->
											<h2><strong>¿Qué es un Préstamos Hipotecarios UVA?</strong></h2>
											<p>Es un préstamo hipotecario en pesos a tasa fija, actualizable mediante la aplicación del coeficiente de estabilización de  referencia (CER) y expresado en Unidades de Vivienda (UVAs).</p>
											<!-- -->
										</div>
									</div>
								</div>
							</div>
						</div>
						<!-- ------------ -->
						<!-- ¿Qué es UVA? -->
						<!-- ------------ -->
						<!-- botón -->
						<div class="col-md-12 col-sm-12 col-xs-12">
							<a href="#faqs-phuvas-02" class="btn-faqs-dspl" data-toggle="modal"><i></i>¿Qué es UVA?</a>
						</div>
						<!-- modal -->
						<div class="modal fade" id="faqs-phuvas-02">
							<div class="modal-dialog modal-lg">
								<div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal"><span>X</span></button>
									</div>
									<div class="modal-body">
										<div class="text-data">
											<!-- -->
											<h2><strong>¿Qué es UVA?</strong></h2>
											<p>La UVA o Unidad de Valor Adquisitivo es una unidad de medida  establecida por el Banco Central (BCRA), que se actualiza y publica  diariamente según el Coeficiente de  Estabilización de Referencia (CER), basado en el índice de precios al  consumidor. Su cotización es publicada por el BCRA en www.bcra.gob.ar.</p>
											<!-- -->
										</div>
									</div>
								</div>
							</div>
						</div>
						<!-- -------------------------------------------------------- -->
						<!-- ¿Cuál es el sistema de amortización de los Créditos UVA? -->
						<!-- -------------------------------------------------------- -->
						<!-- botón -->
						<div class="col-md-12 col-sm-12 col-xs-12">
							<a href="#faqs-phuvas-03" class="btn-faqs-dspl" data-toggle="modal"><i></i>¿Cuál es el sistema de amortización de los Créditos UVA?</a>
						</div>
						<!-- modal -->
						<div class="modal fade" id="faqs-phuvas-03">
							<div class="modal-dialog modal-lg">
								<div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal"><span>X</span></button>
									</div>
									<div class="modal-body">
										<div class="text-data">
											<!-- -->
											<h2><strong>¿Cuál es el sistema de amortización de los Créditos UVA?</strong></h2>
											<p>El préstamo hipotecario se liquida por sistema francés,  con cuotas mensuales.</p>
											<!-- -->
										</div>
									</div>
								</div>
							</div>
						</div>
						<!-- -------------------------------------------- -->
						<!-- ¿Para qué destinos está habilitada la línea? -->
						<!-- -------------------------------------------- -->
						<!-- botón -->
						<div class="col-md-12 col-sm-12 col-xs-12">
							<a href="#faqs-phuvas-04" class="btn-faqs-dspl" data-toggle="modal"><i></i>¿Para qué destinos está habilitada la línea?</a>
						</div>
						<!-- modal -->
						<div class="modal fade" id="faqs-phuvas-04">
							<div class="modal-dialog modal-lg">
								<div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal"><span>X</span></button>
									</div>
									<div class="modal-body">
										<div class="text-data">
											<!-- -->
											<h2><strong>¿Para qué destinos está habilitada la línea?</strong></h2>
											<p>La línea está habilitada para adquisición y refacción de viviendas, permanentes y no permanentes.</p>
											<!-- -->
										</div>
									</div>
								</div>
							</div>
						</div>
						<!-- -------------------------- -->
						<!-- ¿Cómo es la forma de pago? -->
						<!-- -------------------------- -->
						<!-- botón -->
						<div class="col-md-12 col-sm-12 col-xs-12">
							<a href="#faqs-phuvas-05" class="btn-faqs-dspl" data-toggle="modal"><i></i>¿Cómo es la forma de pago?</a>
						</div>
						<!-- modal -->
						<div class="modal fade" id="faqs-phuvas-05">
							<div class="modal-dialog modal-lg">
								<div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal"><span>X</span></button>
									</div>
									<div class="modal-body">
										<div class="text-data">
											<!-- -->
											<h2><strong>¿Cómo es la forma de pago?</strong></h2>
											<p>Las cuotas serán abonadas por medio de débito  automático en cuenta abierta en Banco Patagonia.</p>
											<!-- -->
										</div>
									</div>
								</div>
							</div>
						</div>
						<!-- ------------------------------------------------------------------------------------------------------------- -->
						<!-- ¿Puedo pagar un inmueble en moneda extranjera con los fondos de un Hipotecario? ¿Tiene algún costo adicional? -->
						<!-- ------------------------------------------------------------------------------------------------------------- -->
						<!-- botón -->
						<div class="col-md-12 col-sm-12 col-xs-12">
							<a href="#faqs-phuvas-06" class="btn-faqs-dspl" data-toggle="modal"><i></i>¿Puedo pagar un inmueble en moneda extranjera con los fondos de un Hipotecario? ¿Tiene algún costo adicional?</a>
						</div>
						<!-- modal -->
						<div class="modal fade" id="faqs-phuvas-06">
							<div class="modal-dialog modal-lg">
								<div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal"><span>X</span></button>
									</div>
									<div class="modal-body">
										<div class="text-data">
											<!-- -->
											<h2><strong>¿Puedo pagar un inmueble en moneda extranjera con los fondos de un Hipotecario? ¿Tiene algún costo adicional?</strong></h2>
											<p>(***) Sí, es posible a través de una operación de títulos - Dólar MEP - en el marco del Préstamo Hipotecario UVA en pesos. Para ello, deberás contar con una cuenta comitente que tiene un costo único de apertura y un costo mensual de mantenimiento. Además, a la operación de títulos se le aplica una comisión del 1,00% + IVA sobre la Compraventa en cada operación y un cargo del 0,0100% por Derechos de mercado.</p>
											<!-- -->
										</div>
									</div>
								</div>
							</div>
						</div>
						<!-- -------------------------------------------- -->
						<!-- ¿Puedo cancelar el préstamo anticipadamente? -->
						<!-- -------------------------------------------- -->
						<!-- botón -->
						<div class="col-md-12 col-sm-12 col-xs-12">
							<a href="#faqs-phuvas-07" class="btn-faqs-dspl" data-toggle="modal"><i></i>¿Puedo cancelar el préstamo anticipadamente?</a>
						</div>
						<!-- modal -->
						<div class="modal fade" id="faqs-phuvas-07">
							<div class="modal-dialog modal-lg">
								<div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal"><span>X</span></button>
									</div>
									<div class="modal-body">
										<div class="text-data">
											<!-- -->
											<h2><strong>¿Puedo cancelar el préstamo anticipadamente?</strong></h2>
											<p>Sí, en forma total o parcial en cualquier momento de la vida del préstamo.</p>
											<p>Solo se cobrará una comisión del 2% + IVA sobre el capital cancelado si no ha transcurrido la cuarta parte del plazo original del préstamo o 180 días corridos desde su otorgamiento, ambos el mayor.</p>
											<!-- -->
										</div>
									</div>
								</div>
							</div>
						</div>
						<!-- ------------------------- -->
						<!-- ¿Se puede sumar ingresos? -->
						<!-- ------------------------- -->
						<!-- botón -->
						<div class="col-md-12 col-sm-12 col-xs-12">
							<a href="#faqs-phuvas-08" class="btn-faqs-dspl" data-toggle="modal"><i></i>¿Se puede sumar ingresos?</a>
						</div>
						<!-- modal -->
						<div class="modal fade" id="faqs-phuvas-08">
							<div class="modal-dialog modal-lg">
								<div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal"><span>X</span></button>
									</div>
									<div class="modal-body">
										<div class="text-data">
											<!-- -->
											<h2><strong>¿Se puede sumar ingresos?</strong></h2>
											<p>Si, se podrá sumar un codeudor.</p>
											<!-- -->
										</div>
									</div>
								</div>
							</div>
						</div>
						<!---->
					</div>
					<!---->
				</div>
			</div>
		</div>
	</section>
	<!-- PRE FOOTER -->
	<section class="container">
		<div class="row legal-int">
			<div class="col-md-12 col-sm-12 col-xs-12">
				<p>CARTERA DE CONSUMO - EL OTORGAMIENTO DEL PRÉSTAMO SE ENCUENTRA SUJETO A LA APROBACIÓN DE LAS CONDICIONES CREDITICIAS Y DE CONTRATACIÓN DE BANCO PATAGONIA S.A.</p>
				<p>EJEMPLOS DE CUOTAS PURAS (AMORTIZACIÓN DE CAPITAL MÁS INTERESES) Y CONDICIONES FINANCIERAS PARA UN CAPITAL DE $100.000.000 (PESOS CIEN MILLONES) A ABONAR EN 30 AÑOS - COTIZACIÓN DE LA UVA (UNIDAD DE VALOR ADQUISITIVO) PUBLICADA POR EL BANCO CENTRAL DE LA REPUBLICA ARGENTINA AL 15/01/2025 : $1.315,87</p>
				<p>(*) PARA CLIENTES QUE PERCIBAN SUS HABERES EN BANCO PATAGONIA S.A.: TASA NOMINAL ANUAL 6,50% - TASA EFECTIVA ANUAL 6,70% - COSTO FINANCIERO TOTAL EFECTIVO ANUAL (C.F.T.E.A.)</p>
                <p style="font-size: 5em;">CFTEA: 6,70% (sin IVA) – 8,15% (con IVA)</p>
                <p>(**) PARA CLIENTES QUE NO PERCIBEN SUS HABERES EN BANCO PATAGONIA S.A.: TASA NOMINAL ANUAL 9,00% - TASA EFECTIVA ANUAL 9,38% - COSTO FINANCIERO TOTAL EFECTIVO ANUAL (C.F.T.E.A.)</p>
                <p style="font-size: 5em;">CFTEA: 9,38% (sin IVA) – 11,45% (con IVA)</p>
                <p>IMPORTE MÁXIMO A OTORGAR: HASTA $320.000.000 (PESOS TRESCIENTOS VEINTE MILLONES). LA ACREDITACIÓN DEL MONTO DEL PRÉSTAMO SE EFECTUARÁ EN SU CAJA DE AHORRO EN PESOS.</p>
				<p>EL CAPITAL DEBERÁ SER REEMBOLSADO EN CUOTAS MENSUALES Y CONSECUTIVAS.</p>
				<p>EL IMPORTE DE CADA CUOTA RESULTARÁ DE APLICAR EL “SISTEMA DE AMORTIZACIÓN FRANCÉS” DE INTERÉS SIMPLE QUE CONTEMPLA LOS DÍAS CALENDARIO TRANSCURRIDOS ENTRE LAS CUOTAS, E INCLUIRÁ EL CAPITAL, LOS INTERESES COMPENSATORIOS A LA TASA PACTADA (AMBOS EN UVAS), MULTIPLICADO POR EL VALOR DE LA UVA A LA FECHA DE VENCIMIENTO O PRIMER DIA HABIL POSTERIOR, MÁS EL MONTO EN PESOS DEL SEGURO DE INCENDIO VIGENTE A LA FECHA DE VENCIMIENTO DE CADA CUOTA.</p>
				<p>(***) Costo total de la operación de títulos: (i) Comisiones de apertura y mantenimiento de cuenta comitente 100% bonificadas durante los primeros doce meses contados desde su apertura, exclusivamente para clientes que accedan a un préstamo hipotecario UVA en Banco Patagonia S.A.; (ii) Comisión sobre la compra y venta de títulos valores para la adquisición de dólar MEP, por cada operación: 1,00% + IVA; (iii) Cargo por derechos de Mercado: 0,0100%, INGRESAR ACÁ https://www.bancopatagonia.com.ar/comisiones/docs/Titulos_Valores.pdf</p>
				<p>LOS ACCIONISTAS DE BANCO PATAGONIA S.A (CUIT 30-50000661-3, AV. DE MAYO 701, PISO 24, CABA), LIMITAN SU RESPONSABILIDAD A LA INTEGRACIÓN DE LAS ACCIONES SUSCRIPTAS. EN VIRTUD DE ELLO, NI LOS ACCIONISTAS MAYORITARIOS DE CAPITAL EXTRANJERO NI LOS ACCIONISTAS LOCALES O EXTRANJEROS, RESPONDEN EN EXCESO DE LA CITADA INTEGRACIÓN ACCIONARIA POR LAS OBLIGACIONES EMERGENTES DE LAS OPERACIONES CONCERTADAS POR LA ENTIDAD FINANCIERA. LEY 25.738.</p>
			</div>
		</div>
	</section>
	<!-- FIN PRE FOOTER -->
	<div class="container-fluid footer-bar">
	<div class="row">
		<footer class="container">
			<div class="row">
				<div class="col-md-12">
					<p class="flnks"><a href="../../registro-nacional-base-datos.php">Registro Nacional de Base de Datos</a> <span>|</span>   <a href="../../codigo-practicas-bancarias.php">Código de Prácticas Bancarias</a> <span>|</span>   <a href="../../defensa-ley-consumidor.php">Defensa del Consumidor</a>
						<span>|</span>   <a href="https://www.argentina.gob.ar/produccion/defensadelconsumidor/formulario">Defensa de las y los consumidores. Para reclamos ingrese aquí</a><span>|</span> <br class="tbl"> <a href="../../persona-expuesta-politicamente.php">Persona Expuesta Políticamente</a> <span class="tbl">|</span> <br class="dsk">
						
					<a href="../../agencia-acceso-informacion-publica.php">Agencia de Acceso a la Información Pública</a> <span>|</span> <br class="tbl"> 
					<a href="../../cnv-advertencia-publico-inversor.php">CNV - Advertencia al Público Inversor</a> <span>|</span> <a href="../../docs/Idoneos.pdf" target="_blank"> Idóneos en Mercado de Capitales - CNV</a><span>|</span>   <a href="../../codigo-proteccion-inversor.php">Código de Protección al Inversor</a> <span>|</span>   <a href="../../clausulas-legales.php">Cláusulas Legales</a> <span>|</span> <a href="../../resolucion-022021.php">Resol. 02/21 Dir.Gral. Defensa del consumidor Córdoba</a></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<p class="redes">
                        <span>Seguinos en:</span>
                        <!-- -->
                        <a href="https://www.facebook.com/BancoPatagonia/" target="_blank"><img src="../../assets/images/layout/icon-facebook.svg" alt="Facebook"></a>
                        <a href="https://twitter.com/banco_patagonia" target="_blank"><img src="../../assets/images/layout/icon-twitter.svg" alt="Twitter"></a>
                        <a href="https://www.instagram.com/banco_patagonia/" target="_blank"><img src="../../assets/images/layout/icon-instagram.svg" alt="Instagram"></a>
                        <a href="https://www.youtube.com/user/bancopatagonia" target="_blank"><img src="../../assets/images/layout/icon-youtube.svg" alt="Youtube"></a>
                        <!-- -->
                        <!--
                        <a href="https://www.facebook.com/BancoPatagonia/" target="_blank"><i class="fa fa-facebook-square"></i></a>
                        <a href="https://twitter.com/banco_patagonia" target="_blank"><i class="fa fa-twitter"></i></a>
                        <a href="https://www.instagram.com/banco_patagonia/" target="_blank"><i class="fa fa-instagram"></i></a>
                        <a href="https://www.youtube.com/user/bancopatagonia" target="_blank"><i class="fa fa-youtube-play"></i></a>
                        -->
                    </p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					                    <!---->
				    <p class="flegal">BANCO PATAGONIA S.A. ES UNA SOCIEDAD ANÓNIMA CONSTITUIDA BAJO LAS LEYES DE LA REPÚBLICA ARGENTINA CUYOS ACCIONISTAS LIMITAN SU RESPONSABILIDAD A LA INTEGRACIÓN DE LAS ACCIONES SUSCRITAS DE ACUERDO A LA LEY 19.550. POR CONSIGUIENTE, Y EN CUMPLIMIENTO DE LA LEY 25.738, SE INFORMA QUE NI LOS ACCIONISTAS MAYORITARIOS DE CAPITAL EXTRANJERO NI LOS ACCIONISTAS LOCALES O EXTRANJEROS RESPONDEN, EN EXCESO DE LA CITADA INTEGRACIÓN ACCIONARIA, POR LAS OBLIGACIONES EMERGENTES DE LAS OPERACIONES CONCERTADAS POR LA ENTIDAD FINANCIERA.</p>
                    <p class="flegal" style="font-size:10px;">Banco Patagonia S.A. - Agente de Liquidacion y Compensacion y Agente de Negociacion Integral, inscripto en CNV bajo el N° 66</p>
					<p class="flegal">© 2025 Banco Patagonia . Todos los derechos reservados. Prohibida la duplicación , distribución o almacenamiento en cualquier medio.</p>
				</div>
			</div>
		</footer>
	</div>
</div>
<div class="tbl mbl placeholder-shortlinks">
	<div class="container shortlinks">
		<div class="row">
            <!--<php if ($home_personas == false) { ?>
                <div class="col-sm-3 col-xs-3">
                    <a href="#"><span class="icon icon-contacto"></span></a>
                </div>
            <php } ?>-->
            			<div class="col-sm-3 col-xs-3">
				<a href="http://sucursalesycajeros.bancopatagonia.com.ar/sucursales.html" target="_blank"><span class="icon icon-sucursales"></span>Sucursales y Cajeros</a>
			</div>
			<div class="col-sm-3 col-xs-3">
				<a href="../../preguntas-frecuentes/index.php"><span class="icon icon-contacto"></span>Ayuda</a>
			</div>
			<div class="col-sm-3 col-xs-3 last">
				<a href="../../empresas/patagonia-ebank-empresas-mbl.php"><span class="icon icon-ebank"></span>Patagonia e-Bank</a>
			</div>
		</div>
	</div>
</div>	<script src="../../assets/js/jquery-3.5.1.min.js"></script>
<script src="../../assets/bootstrap/js/bootstrap.min.js"></script>
<script src="../../assets/js/slick/slick.min.js"></script>
<script src="../../assets/js/fancybox/jquery.fancybox.min.js"></script>
<script src="../../assets/js/mtabs/jquery.bootstrap-responsive-tabs.min.js"></script>
<script src="../../assets/js/funciones.js"></script>

<!-- Global site tag (gtag.js) - Google Analytics (original) -->
<!--
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-32588129-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-32588129-1');
</script>
-->

<!-- Google Analytics (version anterior / eventos ok)  -->
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');
  ga('create', 'UA-32588129-1', 'auto');
  ga('send', 'pageview');
</script>

<!-- GA4 - Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-C6LG1PT98X"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-C6LG1PT98X');
</script>
</body>
</html>