<!DOCTYPE html>
<html lang="es">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
		<meta http-equiv="Pragma" content="no-cache">
		<meta http-equiv="Expires" content="0">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Marco Regulatorio | Comercio Exterior | Banco Patagonia</title>
		<meta name="description" content="Todo el asesoramiento a través de los Oficiales Comex de Banco Patagonia.">
		<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-NL73B44');</script>
<!-- End Google Tag Manager -->

<link rel="shortcut icon" href="../../../favicon.ico" type="image/x-icon"/>
<link href="../../../assets/fonts/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="../../../assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="../../../assets/js/mtabs/bootstrap-responsive-tabs.css" rel="stylesheet" type="text/css">
<link href="../../../assets/js/slick/slick.css" rel="stylesheet" type="text/css">
<link href="../../../assets/js/fancybox/jquery.fancybox.min.css" rel="stylesheet" type="text/css">
<link href="../../../assets/css/styles.css" rel="stylesheet" type="text/css">
<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->		
		<!-- IMPORTANTE: Indicar en el siguiente tag la pagina de origen para evitar el contenido duplicado -->
		<link rel="canonical" href="https://www.bancopatagonia.com.ar/personas/productos-y-servicios/comercio-exterior/marco-regulatorio/normas-y-regulaciones.php">
		
        <!-- SLIDES RESPONSIVE -->
        <style>
            /* DSK */
            #head-marco-regulatorio {background-image: url(../../../personas/productos-y-servicios/comercio-exterior/marco-regulatorio/images/head-marco-regulatorio-dsk.jpg)}

            @media screen and (max-width: 1200px) {
                /* TBT */
                #head-marco-regulatorio {background-image: url(../../../personas/productos-y-servicios/comercio-exterior/marco-regulatorio/images/head-marco-regulatorio-tbl.jpg); background-size: auto !important ;}
            }
            @media screen and (max-width: 560px) {
                /* MBL */
                #head-marco-regulatorio {background-image: url(../../../personas/productos-y-servicios/comercio-exterior/marco-regulatorio/images/head-marco-regulatorio-mbl.jpg)}
            }
        </style>
        <!-- -->
	</head>
<body>
	<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NL73B44"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

<div class="placeholder-bar">
	<div class="container-fluid header-bar">
		<div class="row">
			<header class="container">
				<div class="row">
					<div class="col-md-3 col-dsk-6 col-sm-6">
						<span class="c-hamburger c-hamburger--htx">
							<span>toggle menu</span>
						</span>
                        <!-- -->
                        <!--<img style="position: absolute; width: 42px; top: 20px; right: 40px;" class="dsk" src="<php echo $path ?>assets/images/layout/icon-verano-2022.svg">-->
                        <!-- -->
						<h1>
                            <!--<img style="position: absolute; width: 32px; top: 12px; left: 102px;" class="dsk" src="<php echo $path ?>assets/images/layout/icon-navidad-2021.svg">-->
                            <a href="../../../index.php" class="main-logo">Banco Patagonia</a>
                        </h1>
					</div>
					<div class="col-md-9 col-dsk-6 col-sm-6">
						<div class="general-links">
							<ul class="list-unstyled">
                                								<li><a href="../../../preguntas-frecuentes/index.php" class="">Ayuda</a></li>
								<!--<li><a href="<php echo $folder_canales ?>index.php" class="<php echo $canales ?>">Canales de atención</a></li>-->
								<!--<li><a href="http://sucursalesycajeros.bancopatagonia.com.ar/sucursales.html" target="_blank">Sucursales y cajeros</a></li>-->
								<!--<li><a href="<php echo $folder_contactenos ?>index.php" class="<php echo $contactenos ?>">Contactanos</a></li>-->
                                <!--<li><a href="<php echo $path ?>ayuda/index.php" class="<php echo $ayuda ?>">Ayuda</a></li>-->
							</ul>
						</div>
						<div class="top-links">
							<ul class="list-unstyled">
								<li><a href="../../../personas/index.php" class="">PERSONAS</a></li>
								<li><a href="../../../nyps/index.php" class="">PROFESIONALES Y COMERCIOS</a></li>
								<li><a href="../../../pyme/index.php" class="">PYME</a></li>
								<li><a href="../../index.php" class="active">AGRO</a></li>
								<li><a href="../../../empresas/index.php" class="">EMPRESAS</a></li>
								<li><a href="../../../sector-publico/index.php" class="">SECTOR PÚBLICO</a></li>
								<li><a href="../../../institucional/index.php" class="">INSTITUCIONAL</a></li>
							</ul>
							<div class="ebank">
                            <!-- antes href: <php echo $folder_empresas ?><php echo $url_ebank ?>-->
															<a href="https://ebankempresas.bancopatagonia.com.ar/desktop-webserver/sso" target="_blank" class="patagonia-ebank-empresas">Patagonia e-Bank Empresas</a>
														</div>
						</div>
					</div>
				</div>
			</header>
		</div>
	</div>
</div>

<div class="container-fluid nav-bar">
	<div class="row">
		<nav class="container">
			<div class="row">
				<!--<div class="col-md-9 col-md-offset-3">-->
                <div class="col-md-10 col-md-offset-3"><!-- ajuste agro -->
					<ul class="list-unstyled sub-navbar">
						
						                        
                                                
                                                
                        						<!-- AGRO -->
                        <li class="nav-item"><a href="#" class="nav-lnk ">OFERTA AGRO</a>
							<ul class="list-unstyled submenu">
                            	<!--<li><a href="<php echo $folder_agroFinanciacion ?>insumos.php">Insumos en USD</a></li>-->
								<li><a href="../../convenios/acuerdos-y-beneficios.php">Acuerdos y convenios</a></li>
								<li><a href="../../financiacion/maquinaria-agricola.php">Financiación Maquinaria Agrícola</a></li>
                                <li><a href="../../seguros/campo.php">Seguros para tu campo</a></li>
							</ul>
						</li>
						<li class="nav-item"><a href="#" class="nav-lnk ">TARJETA PATAGONIA AGRO</a>
							<ul class="list-unstyled submenu">
								<li><a href="../../tarjeta-patagonia-agro/para-usuarios.php">Para Usuarios</a></li>
								<li><a href="../../tarjeta-patagonia-agro/para-comercios.php">Para Comercios</a></li>
								<li><a href="../../tarjeta-patagonia-agro/acuerdo-tasa-0.php">Tarjetas Agro Convenios Preferenciales</a></li>
							</ul>
						</li>
						<li class="nav-item"><a href="../../cuenta-agro/cuenta-agro.php" class="nav-lnk ">CUENTA AGRO</a></li>
						<li class="nav-item"><a href="#" class="nav-lnk ">FINANCIACIÓN</a>
							<ul class="list-unstyled submenu">
                                <li><a href="../../insumos/index.php">Insumos</a></li>
                                <li><a href="../../financiacion/maquinaria-agricola.php">Maquinarias</a></li>
                                <li><a href="../../../empresas/financiacion/convenios-de-financiacion.php">Camiones</a></li>
								<!--<li><a href="<php echo $folder_agroFinanciacion ?>capital-de-trabajo.php">Capital de Trabajo</a></li>-->
								<!--<li><a href="<php echo $folder_agroFinanciacion ?>proyectos-de-inversion.php">Proyectos de Inversión</a></li>-->
								<!--<li><a href="<php echo $folder_agroFinanciacion ?>creditos-para-hacienda.php">Créditos para Hacienda</a></li>-->
								<!--<li><a href="<php echo $folder_agroFinanciacion ?>leasing-y-prendarios.php">Leasing y Prendarios</a></li>-->
							</ul>
						</li>
						<li class="nav-item"><a href="#" class="nav-lnk ">INVERSIONES</a>
							<ul class="list-unstyled submenu">
								<li><a href="../../inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
								<li><a href="../../inversiones/fidecomisos-financieros.php">Fidecomisos Financieros</a></li>
								<li><a href="../../inversiones/plazos-fijos.php">Plazos Fijos</a></li>
							</ul>
						</li>
                        <li class="nav-item"><a href="#" class="nav-lnk active">COMERCIO EXTERIOR</a>
							<ul class="list-unstyled submenu">
								<li><a href="../../comercio-exterior/solicitud-electronica.php">Solicitud Electrónica</a></li>
								<li><a href="../../comercio-exterior/productos.php">Productos</a></li>
								<li><a href="../../comercio-exterior/otros-servicios.php">Servicios</a></li>
                                <li><a href="../../comercio-exterior/herramientas-para-exportar.php">Herramientas para Exportar</a></li>
								<li><a href="../../comercio-exterior/marco-regulatorio/normas-y-regulaciones.php">Marco Regulatorio</a></li>
							</ul>
						</li>
                        <!--
						<li class="nav-item"><a href="#" class="nav-lnk ">SERVICIOS</a>
							<ul class="list-unstyled submenu">
								<li><a href="../../servicios/centro-atencion-empresas.php">Centro de Atención para Empresas</a></li>
							</ul>
						</li>
                        -->
                        <!-- -->
                        <li class="nav-item"><a href="../../../agro/seguros/campo.php" class="nav-lnk ">SEGUROS</a></li>
                        <!-- -->
						<!-- FIN AGRO -->						
												
												
												
						
											</ul>
				</div>
			</div>
		</nav>
	</div>
</div>

<div class="mobile-nav-bar">
	<ul class="list-unstyled">
        
        <!-- PERSONAS -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">PERSONAS <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../../personas/index.php" class="">HOME</a></li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA CLÁSICA</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../../personas/patagonia-clasica/patagonia-ahorro/productos.php">Patagonia Ahorro</a></li>
                        <li><a href="../../../personas/patagonia-clasica/paquete/productos.php">Patagonia Clásica</a></li>
                        <!--<li><a href="<php echo $path ?>personas/patagonia-clasica/mas/productos.php">Patagonia Clásica Más</a></li>-->
                        <li><a href="../../../personas/patagonia-clasica/premium/productos.php">Patagonia Clásica Premium</a></li>
                        <li><a href="../../../personas/patagonia-clasica/patagonia-sueldo/productos.php">Patagonia Sueldo</a></li>
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA PLUS</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../../personas/patagonia-plus/productos.php">Patagonia Plus</a></li>
                        <li><a href="../../../personas/patagonia-plus/premium/productos.php">Patagonia Plus Premium</a></li>
                    </ul>						
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA SINGULAR</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../../personas/patagonia-singular/paquete/propuesta.php">Patagonia Singular</a></li>
                        <li><a href="../../../personas/patagonia-singular/beneficios-exclusivos.php">Beneficios Exclusivos</a></li>
                        <!--<li><a href="<php echo $path ?>personas/patagonia-singular/atencion-exclusiva/index.php">Atención Exclusiva</a></li>-->
                        <!--<li><a href="<php echo $path ?>personas/patagonia-singular/eventos-y-novedades/index.php">Eventos y Novedades</a></li>-->
                    </ul>
                </li>
				<!--<li class="nav-sub-item"><a href="<php echo $path ?>patagoniaon/index.php" target="_blank">PATAGONIA ON</a></li>-->
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA ON</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../../patagoniaon/index.php" target="_blank">Patagonia ON</a></li>
						<li><a href="../../../personas/productos-y-servicios/patagonia-universitaria.php">Patagonia ON Universitaria</a></li>
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PRODUCTOS Y SERVICIOS</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../../personas/apple-pay.php">Apple Pay</a></li>
                        <li><a href="../../../personas/productos-y-servicios/caja-de-seguridad.php">Caja de Seguridad</a></li>
                        <li><a href="../../../personas/productos-y-servicios/comercio-exterior/productos.php">Comercio exterior</a></li>
						<!--<li><a href="<php echo $path ?>personas/productos-y-servicios/beneficios-wapa.php">Comercios WAPA</a></li>-->
						<li><a href="../../../personas/cuotifica-al-toque.php">Cuotificá al Toque</a></li>
						<li><a href="../../../personas/google-pay.php">Google Pay</a></li>
                        <li><a href="../../../personas/productos-y-servicios/inversiones.php">Inversiones</a></li>
                        <li><a href="../../../personas/jubilados/index.php">Jubilados</a></li>
                        <li><a href="../../../personas/productos-y-servicios/patagonia-para-menores.php">Patagonia para Menores</a></li>
                        <!--<li><a href="<php echo $path ?>personas/productos-y-servicios/patagonia-universitaria.php">Patagonia Universitaria</a></li>-->
                        <li><a href="../../../personas/productos-y-servicios/prestamos.php">Prestamos</a></li>
                        <li><a href="../../../personas/seguros/index.php">Seguros</a></li>
                        <li><a href="../../../personas/productos-y-servicios/tarjetas-de-credito/visa.php">Tarjetas de crédito</a></li>
                        <li><a href="../../../personas/productos-y-servicios/tarjetas-de-debito/patagonia-24.php">Tarjetas de débito</a></li>
                    </ul>
                </li>
			</ul>
		</li>
        <!-- FIN PERSONAS -->
        
        <!-- NYPS -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">PROFESIONALES Y COMERCIOS <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../../nyps/index.php" class="">HOME</a></li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA CLÁSICA</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../../nyps/patagonia-clasica/premium/productos.php">Patagonia Clásica Premium</a></li>
                        <li><a href="../../../nyps/patagonia-clasica/patagonia-emprendimiento/productos.php">Patagonia Emprendimiento</a></li>
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA PLUS</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../../nyps/patagonia-plus/productos.php">Patagonia Plus</a></li>
                        <li><a href="../../../nyps/patagonia-plus/premium/productos.php">Patagonia Plus Premium</a></li>
                    </ul>						
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA SINGULAR</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../../nyps/patagonia-singular/paquete/propuesta.php">Patagonia Singular</a></li>
                        <li><a href="../../../nyps/patagonia-singular/beneficios-exclusivos.php">Beneficios Exclusivos</a></li>
                        <!--<li><a href="<php echo $path ?>nyps/patagonia-singular/eventos-y-novedades/index.php">Eventos y Novedades</a></li>-->
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PRODUCTOS Y SERVICIOS</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../../nyps/productos-y-servicios/tarjetas-de-debito/patagonia-24.php">Tarjetas de débito</a></li>
                        <li><a href="../../../nyps/productos-y-servicios/tarjetas-de-credito/visa.php">Tarjetas de crédito</a></li>
                        <li><a href="../../../nyps/productos-y-servicios/prestamos.php">Prestamos</a></li>
                        <li><a href="../../../nyps/seguros/index.php">Seguros</a></li>
                        <li><a href="../../../nyps/productos-y-servicios/inversiones.php">Inversiones</a></li>
                        <li><a href="../../../nyps/productos-y-servicios/comercio-exterior/productos.php">Comercio exterior</a></li>
                        <li><a href="../../../nyps/productos-y-servicios/caja-de-seguridad.php">Caja de Seguridad</a></li>
                        <li><a href="../../../nyps/productos-y-servicios/factura-electronica.php">Factura electrónica</a></li>
                        <li><a href="../../../nyps/productos-y-servicios/pagos-afip.php">Pagos AFIP</a></li>
                        <!--<li><a href="<php echo $path ?>nyps/productos-y-servicios/soluciones-para-tu-empresa.php">Soluciones para tu empresa</a></li>-->
                        <!--<li><a href="<php echo $path ?>nyps/productos-y-servicios/comercios-patagonia.php">Comercios Patagonia</a></li>-->
						<li><a href="../../../nyps/productos-y-servicios/wapa.php">WAPA</a></li>
                    </ul>
                </li>
			</ul>		
		</li>
        <!-- FIN NYPS -->
        
        <!-- PYME -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">PYME <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../../pyme/index.php" class="">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">CUENTAS</a>
					<ul class="list-unstyled submenu">
                        <li><a href="../../../pyme/cuentas/pequenas-empresas.php">Pyme Pequeñas Empresas</a></li>
				        <li><a href="../../../pyme/cuentas/medianas-empresas.php">Pyme Medianas Empresas</a></li>
                        <!--
						<li><a href="../../../pyme/cuentas/patagonia-empresario.php">Patagonia Empresario</a></li>
						<li><a href="../../../pyme/cuentas/patagonia-empresario-premier.php">Patagonia Empresario Premier</a></li>
						<li><a href="../../../pyme/cuentas/patagonia-empresa.php">Patagonia Empresa</a></li>
                        -->
                        <!--<li><a href="../../../pyme/cuentas/patagonia-comercio.php">Patagonia Comercio</a></li>-->
                        <li><a href="../../../pyme/cuentas/patagonia-consorcio.php">Patagonia Consorcio</a></li>
						<li><a href="../../../pyme/cuentas/cuenta-corriente.php">Cuenta Corriente</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA SUELDO</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../../pyme/patagonia-sueldo/servicios.php">Servicios</a></li>
						<li><a href="../../../pyme/patagonia-sueldo/preguntas-frecuentes.php">Preguntas Frecuentes</a></li>
						<li><a href="../../../pyme/patagonia-sueldo/guia-implementacion.php">Guía de Implementación</a></li>
					</ul>
				</li>						
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">COMERCIO EXTERIOR</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../../pyme/comercio-exterior/solicitud-electronica.php">Solicitud Electrónica</a></li>
						<li><a href="../../../pyme/comercio-exterior/productos.php">Productos</a></li>
						<li><a href="../../../pyme/comercio-exterior/otros-servicios.php">Servicios</a></li>
						<!--<li><a href="<php echo $folder_pymeCexterior ?>financiaciones.php">Financiaciones</a></li>-->
                        <li><a href="../../../pyme/comercio-exterior/herramientas-para-exportar.php">Herramientas para Exportar</a></li>
						<li><a href="../../../pyme/comercio-exterior/marco-regulatorio/normas-y-regulaciones.php">Marco Regulatorio</a></li>
					</ul>
				</li>						
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">FINANCIACIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../../pyme/financiacion/patagonia-leasing.php">Patagonia Leasing</a></li>
						<li><a href="../../../pyme/financiacion/mercado-capitales.php">Mercado de Capitales</a></li>
						<li><a href="../../../pyme/financiacion/alternativas-de-financiacion.php">Alternativas de Financiación</a></li>
					</ul>
				</li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">SEGUROS</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../../pyme/seguros/protege-tus-bienes/integral-comercio.php">Protegé tus Bienes</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">INVERSIONES</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../../pyme/inversiones/plazo-fijo.php">Plazo Fijo</a></li>
						<li><a href="../../../pyme/inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
						<li><a href="../../../pyme/inversiones/fidecomisos-financieros.php">Fidecomisos Financieros</a></li>
					</ul>
				</li>						
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">SERVICIOS</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../../pyme/servicios/recaudaciones.php">Recaudaciones</a></li>
						<li><a href="../../../pyme/servicios/pagos.php">Pagos</a></li>
						<li><a href="../../../pyme/servicios/tarjetas-comerciales.php">Tarjetas Comerciales</a></li>
						<li><a href="../../../pyme/servicios/comercios-patagonia.php">Comercios Patagonia</a></li>
                        <li><a href="../../../pyme/servicios/pago-de-servicios.php">Pago de Servicios</a></li>
						<li><a href="../../../pyme/servicios/interbanking.php">Interbanking</a></li>
						<li><a href="../../../pyme/servicios/interfacturas.php">Interfacturas</a></li>
						<li><a href="../../../pyme/servicios/pagos-afip.php">Pagos AFIP</a></li>
						<li><a href="../../../pyme/servicios/wapa.php">WAPA</a></li>
					</ul>
				</li>
			</ul>		
		</li>
        <!-- FIN PYME -->
        
        <!-- AGRO -->
		<li class="nav-main-item"><a href="#" class="has-sub-items active">AGRO <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../index.php" class="active">HOME</a></li>
                <!-- -->
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">OFERTA AGRO</a>
					<ul class="list-unstyled submenu">
                    	<!--<li><a href="<php echo $folder_agroFinanciacion ?>insumos.php">Insumos en USD</a></li>-->
                        <li><a href="../../convenios/acuerdos-y-beneficios.php">Acuerdos y convenios</a></li>
						<li><a href="../../financiacion/maquinaria-agricola.php">Financiación Maquinaria Agrícola</a></li>
						<li><a href="../../seguros/campo.php">Seguros para tu campo</a></li>
					</ul>
				</li>
                <!-- -->
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">TARJETA PATAGONIA AGRO</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../tarjeta-patagonia-agro/para-usuarios.php">Para Usuarios</a></li>
						<li><a href="../../tarjeta-patagonia-agro/para-comercios.php">Para Comercios</a></li>
						<li><a href="../../tarjeta-patagonia-agro/acuerdo-tasa-0.php">Tarjetas Agro Convenios Preferenciales</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="../../cuenta-agro/cuenta-agro.php" class="">CUENTA AGRO</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">FINANCIACIÓN</a>
					<ul class="list-unstyled submenu">
                        <li><a href="../../insumos/index.php">Insumos</a></li>
                        <li><a href="../../financiacion/maquinaria-agricola.php">Maquinarias</a></li>
                        <li><a href="../../../empresas/financiacion/convenios-de-financiacion.php">Camiones</a></li>
						<!--<li><a href="<php echo $folder_agroFinanciacion ?>capital-de-trabajo.php">Capital de Trabajo</a></li>-->
						<!--<li><a href="<php echo $folder_agroFinanciacion ?>proyectos-de-inversion.php">Proyectos de Inversión</a></li>-->
						<!--<li><a href="<php echo $folder_agroFinanciacion ?>creditos-para-hacienda.php">Créditos para Hacienda</a></li>-->
						<!--<li><a href="<php echo $folder_agroFinanciacion ?>leasing-y-prendarios.php">Leasing y Prendarios</a></li>-->
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">INVERSIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
						<li><a href="../../inversiones/fidecomisos-financieros.php">Fidecomisos Financieros</a></li>
						<li><a href="../../inversiones/plazos-fijos.php">Plazos Fijos</a></li>
					</ul>
				</li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu active">COMERCIO EXTERIOR</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../comercio-exterior/solicitud-electronica.php">Solicitud Electrónica</a></li>
                        <li><a href="../../comercio-exterior/productos.php">Productos</a></li>
                        <li><a href="../../comercio-exterior/otros-servicios.php">Servicios</a></li>
                        <li><a href="../../comercio-exterior/herramientas-para-exportar.php">Herramientas para Exportar</a></li>
                        <li><a href="../../comercio-exterior/marco-regulatorio/normas-y-regulaciones.php">Marco Regulatorio</a></li>
                    </ul>
                </li>
                <!--
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">SERVICIOS</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../servicios/centro-atencion-empresas.php">Centro de Atención para Empresas</a></li>
					</ul>
				</li>
                -->
                <!-- -->
                <li class="nav-sub-item"><a href="../../../agro/seguros/campo.php" class="">SEGUROS</a></li>
                <!-- -->
			</ul>
		</li>
        <!-- FIN AGRO -->
        
        <!-- EMPRESAS -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">EMPRESAS <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../../empresas/index.php" class="">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA SUELDO</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../../empresas/patagonia-sueldo/servicios.php">Servicios</a></li>
						<li><a href="../../../empresas/patagonia-sueldo/preguntas-frecuentes.php">Preguntas Frecuentes</a></li>
						<li><a href="../../../empresas/patagonia-sueldo/guia-implementacion.php">Guía de Implementación</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">COMERCIO EXTERIOR</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../../empresas/comercio-exterior/solicitud-electronica.php">Solicitud Electrónica</a></li>
						<li><a href="../../../empresas/comercio-exterior/productos.php">Productos</a></li>
						<li><a href="../../../empresas/comercio-exterior/otros-servicios.php">Servicios</a></li>
						<!--<li><a href="<php echo $folder_Cexterior ?>financiaciones.php">Financiaciones</a></li>-->
                        <li><a href="../../../empresas/comercio-exterior/herramientas-para-exportar.php">Herramientas para Exportar</a></li>
						<li><a href="../../../empresas/comercio-exterior/marco-regulatorio/normas-y-regulaciones.php">Marco Regulatorio</a></li>
					</ul>
				</li>
                <!-- -->
				<!--<li class="nav-sub-item"><a href="../../../empresas/comunidades-de-negocios/index.php" class="">COMUNIDADES DE NEGOCIOS</a></li>-->
                <!-- -->
				<li class="nav-sub-item"><a href="../../../empresas/comercios-patagonia/index.php" class="nav-lnk ">COMERCIOS PATAGONIA</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">FINANCIACIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../../empresas/financiacion/patagonia-leasing.php">Patagonia Leasing</a></li>
						<li><a href="../../../empresas/financiacion/mercado-capitales.php">Mercado Capitales</a></li>
						<li><a href="../../../empresas/financiacion/alternativas-de-financiacion.php">Alternativas de Financiación</a></li>
                        <li><a href="../../../empresas/financiacion/convenios-de-financiacion.php">Convenios de Financiación</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">INVERSIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../../empresas/inversiones/plazos-fijos.php">Plazos Fijos</a></li>
						<li><a href="../../../empresas/inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
						<li><a href="../../../empresas/inversiones/compra-venta-titulos-acciones.php">Compra - Venta de Títulos y Acciones</a></li>
						<li><a href="../../../empresas/inversiones/custodia-de-titulos.php">Custodia de Títulos</a></li>
						<li><a href="../../../empresas/inversiones/fidecomisos-financieros.php">Fidecomisos Financieros</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">SERVICIOS</a>
					<ul class="list-unstyled submenu">
                        <li><a href="../../../empresas/patagonia-movil-empresas.php">Patagonia Móvil Empresas</a></li>
						<li><a href="../../../empresas/servicios/pagos.php">Pagos</a></li>
						<li><a href="../../../empresas/servicios/recaudaciones.php">Recuadaciones</a></li>
						<li><a href="../../../empresas/servicios/pago-de-servicios.php">Pago de Servicios</a></li>
						<li><a href="../../../empresas/servicios/interbanking.php">Interbanking</a></li>
						<li><a href="../../../empresas/servicios/interfacturas.php">Interfacturas</a></li>
						<li><a href="../../../empresas/servicios/tarjetas-comerciales.php">Tarjetas Comerciales</a></li>
                        <!-- -->
						<!--<li><a href="../../../empresas/servicios/comercios-patagonia.php">Comercios Patagonia</a></li>-->
                        <!-- -->
                        <li><a href="../../../empresas/servicios/centro-atencion-empresas.php">Centro de Atención para Empresas</a></li>
					</ul>
				</li>
			</ul>
		</li>
        <!-- FIN EMPRESAS -->
        
        <!-- SECTOR PÚBLICO -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">SECTOR PÚBLICO <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../../sector-publico/index.php" class="">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">INVERSIONES</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../../sector-publico/inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
						<li><a href="../../../sector-publico/inversiones/plazo-fijo.php">Plazo Fijo</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">SERVICIOS</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../../sector-publico/servicios/servicio-de-recaudacion.php">Servicio de Recaudación</a></li>
						<li><a href="../../../sector-publico/servicios/servicio-de-pagos.php">Servicio de Pagos</a></li>
						<li><a href="../../../sector-publico/servicios/servicios-para-personal.php">Servicios para el Personal</a></li>
						<li><a href="../../../sector-publico/servicios/financiacion.php">Financiación</a></li>
						<li><a href="../../../sector-publico/servicios/otros-servicios.php">Servicios</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">PROGRAMA UNIVERSIDADES</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../../sector-publico/programa-universidades/relacion-institucional.php">Relación Institucional</a></li>
						<li><a href="../../../sector-publico/programa-universidades/docentes-yno-docentes.php">Docentes y No Docentes</a></li>
						<li><a href="../../../sector-publico/programa-universidades/alumnos.php">Alumnos</a></li>
						<li><a href="../../../sector-publico/programa-universidades/graduados.php">Graduados</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">BENEFICIOS RÍO NEGRO</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../../sector-publico/rio-negro/presencia.php">Presencia en Río Negro</a></li>
                        <li><a href="../../../sector-publico/rio-negro/propuesta-valor.php">Propuesta de valor exclusiva</a></li>
					</ul>
				</li>
			</ul>
		</li>
        <!-- FIN SECTOR PUBLICO -->
        
        <!-- INSTITUCIONAL -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">INSTITUCIONAL <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../../institucional/index.php" class="">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">BANCO PATAGONIA</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../../institucional/banco-patagonia/historia.php">Historia</a></li>
						<li><a href="../../../institucional/banco-patagonia/mercado-de-capitales.php">Mercado de Capitales</a></li>
						<li><a href="../../../institucional/banco-patagonia/patagonia-inversora.php">Patagonia Inversora</a></li>
						<li><a href="../../../institucional/banco-patagonia/patagonia-valores-sa.php">Patagonia Valores S.A</a></li>
						<li><a href="https://bp.bancopatagonia.com.ar/relacion-con-inversores/es/institucional" target="_blank">Relación con Inversores</a></li>
						<li><a href="../../../institucional/banco-patagonia/desarrollo-humano.php">Desarrollo Humano</a></li>
						<li><a href="../../../institucional/banco-patagonia/sustentabilidad.php">Sustentabilidad</a></li>
						<li><a href="../../../institucional/banco-patagonia/politicas-aml-cft.php">Póliticas AML/CFT</a></li>
						<li><a href="../../../institucional/banco-patagonia/disciplina-del-mercado.php">Disciplina de Mercado</a></li>
                        <li><a href="../../../institucional/banco-patagonia/asistencia-a-vinculados.php">Asistencia a vinculados</a></li>
                        <li><a href="../../../institucional/banco-patagonia/etica-e-integridad.php">Ética e Integridad</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">ORGANIZACIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../../institucional/organizacion/accionistas.php">Accionistas</a></li>
						<li><a href="../../../institucional/organizacion/autoridades.php">Autoridades</a></li>
                        <li><a href="../../../institucional/organizacion/comites.php">Comités</a></li>
						<li><a href="../../../institucional/organizacion/sector-financiero.php">Sector Financiero</a></li>
					</ul>
				</li>
			</ul>
		</li>
        <!-- FIN INSTITUCIONAL -->
        
        		<li class="nav-main-item"><a href="../../../preguntas-frecuentes/index.php" class="" style="text-transform: none;">Ayuda</a></li>
		<!--<li class="nav-main-item"><a href="<php echo $folder_canales ?>index.php" class="<php echo $canales ?>" style="text-transform: none;">Canales de Atención</a></li>-->
		<!--<li class="nav-main-item"><a href="http://sucursalesycajeros.bancopatagonia.com.ar/sucursales.html" target="_blank" style="text-transform: none;">Sucursales y Cajeros</a></li>-->
		<!--<li class="nav-main-item"><a href="<php echo $folder_contactenos ?>index.php" class="<php echo $contactenos ?>" style="text-transform: none;">Contactanos</a></li>-->
        <!--<li class="nav-main-item"><a href="<php echo $path ?>ayuda/index.php" class="<php echo $ayuda ?>" style="text-transform: none;">Ayuda</a></li>-->
	</ul>
</div>	<!-- -->
    <!--<php include($folder_Cexterior . "marco-regulatorio/includes/inc_header_marco_regulatorio.php"); ?>-->
    <section class="sec-head" title="Marco Regulatorio. Todo el asesoramiento a través de los Oficiales Comex de Banco Patagonia">
        <div class="sec-pic-head" id="head-marco-regulatorio">
        </div>
	</section>
    <!-- -->
	<section class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
				<ol class="breadcrumb">
					<li><a href="../../index.php">Agro</a></li>
					<li>Comercio Exterior</li>
                    <li>Marco Regulatorio</li>
					<li class="active">Normas y Regulaciones</li>
				</ol>
			</div>
		</div>
	</section>
    <section class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="text-data">
                    <!-- -->
                    <!-- -->
<h1>Marco Regulatorio</h1><!-- -->
<h2>Códigos de Concepto establecidos por el BCRA</h2>
<br>
<!-- -->
<div class="row">
    <div class="col-md-6 col-sm-12 col-xs-12">
        <a href="../compra-cambio.php" class="btn-lnk-block">
            <h5>Compra de Cambio</h5>
            <i class="icon icon-more"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-12 col-xs-12">
        <a href="../venta-cambio.php" class="btn-lnk-block">
            <h5>Venta de Cambio</h5>
            <i class="icon icon-more"></i>
        </a>
    </div>
</div>
<hr>
<!-- -->
<h2>Conocé las últimas normativas cambiarias para que tu empresa opere de forma segura</h2>
<br>
<p><strong>Normas y Regulaciones</strong></p>
<div class="row">
	<div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/RGARCA5651-2025.pdf" target="_blank" class="btn-lnk-block">
            <h4>Resolución General Conjunta 5651/2025</h4>
            <p>Fecha de emisión: 24/02/2025</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
	<div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A8137.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. “A” 8137</h4>
            <p>Fecha de emisión: 28/11/2024</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
	<div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A8133.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. “A” 8133</h4>
            <p>Fecha de emisión: 21/11/2024</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
	<div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A8118.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. “A” 8118</h4>
            <p>Fecha de emisión: 17/10/2024</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
	<div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A8116.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. “A” 8116</h4>
            <p>Fecha de emisión: 20/10/2024</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
	<div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A8108.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. “A” 8108</h4>
            <p>Fecha de emisión: 19/09/2024</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
	<div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/Decreto777-2024.pdf" target="_blank" class="btn-lnk-block">
            <h4>Decreto 777/2024</h4>
            <p>Fecha de emisión: 02/09/2024</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
	<div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A8085.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. “A” 8085</h4>
            <p>Fecha de emisión: 08/08/2024</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
	<div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A8074.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. “A” 8074</h4>
            <p>Fecha de emisión: 23/07/2024</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
	<div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A8073.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. “A” 8073</h4>
            <p>Fecha de emisión: 23/07/2024</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
	<div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A8059.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. “A” 8059</h4>
            <p>Fecha de emisión: 04/07/2024</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
	<div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A8055.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. “A” 8055</h4>
            <p>Fecha de emisión: 28/06/2024</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
	<div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A8054.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. “A” 8054</h4>
            <p>Fecha de emisión: 27/06/2024</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
	<div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7999.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. “A” 7999</h4>
            <p>Fecha de emisión: 30/04/2024</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
	<div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7998.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. “A” 7998</h4>
            <p>Fecha de emisión: 30/04/2024</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
	<div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7994.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. “A” 7994</h4>
            <p>Fecha de emisión: 18/04/2024</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
	<div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7990.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. “A” 7990</h4>
            <p>Fecha de emisión: 11/04/2024</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
	<div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7980.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. “A” 7980</h4>
            <p>Fecha de emisión: 14/03/2024</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
	<div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7952.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. “A” 7952</h4>
            <p>Fecha de emisión: 25/01/2024</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
	<div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7941.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7941</h4>
            <p>Fecha de emisión: 11/01/2024</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
	<div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7940.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7940</h4>
            <p>Fecha de emisión: 11/01/2024</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
	<div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/BOPREAL.pdf" target="_blank" class="btn-lnk-block">
            <h4>Noticia 1-2024</h4>
            <p>Fecha de emisión: 03/01/2024</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
	<div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7935.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7935</h4>
            <p>Fecha de emisión: 28/12/2023</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
	<div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/C96983.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "C" 96983</h4>
            <p>Fecha de emisión: 28/12/2023</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
	<div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7925.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7925</h4>
            <p>Fecha de emisión: 22/12/2023</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
	<div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/Decreto28-2023.pdf" target="_blank" class="btn-lnk-block">
            <h4>Decreto 28/2023</h4>
            <p>Fecha de emisión: 13/12/2023</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
	<div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7918.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7918</h4>
            <p>Fecha de emisión: 13/12/2023</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
	<div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7917.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7917</h4>
            <p>Fecha de emisión: 13/12/2023</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
	
	
	<div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7895.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7895</h4>
            <p>Fecha de emisión: 23/11/2023</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
	<div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7894.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7894</h4>
            <p>Fecha de emisión: 23/11/2023</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
	<div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7893.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7893</h4>
            <p>Fecha de emisión: 23/11/2023</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
	<div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7874.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7874</h4>
            <p>Fecha de emisión: 26/10/2023</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
	<div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7873.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7873</h4>
            <p>Fecha de emisión: 26/10/2023</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
	<div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7867.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7867</h4>
            <p>Fecha de emisión: 24/10/2023</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7864.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7864</h4>
            <p>Fecha de emisión: 12/10/2023</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7838.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7838</h4>
            <p>Fecha de emisión: 07/09/2023</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7820.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7820</h4>
            <p>Fecha de emisión: 10/08/2023</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7799.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7799</h4>
            <p>Fecha de emisión: 29/06/2023</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7798.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7798</h4>
            <p>Fecha de emisión: 29/06/2023</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7782.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7782</h4>
            <p>Fecha de emisión: 01/06/2023</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7781.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7781</h4>
            <p>Fecha de emisión: 01/06/2023</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7780.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7780</h4>
            <p>Fecha de emisión: 01/06/2023</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7772.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7772</h4>
            <p>Fecha de emisión: 19/05/2023</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7771.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7771</h4>
            <p>Fecha de emisión: 18/05/2023</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7770.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7770</h4>
            <p>Fecha de emisión: 18/05/2023</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7766.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7766</h4>
            <p>Fecha de emisión: 11/05/2023</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7746.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7746</h4>
            <p>Fecha de emisión: 20/04/2023</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7732.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7732</h4>
            <p>Fecha de emisión: 23/03/2023</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7682.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7682</h4>
            <p>Fecha de emisión: 26/01/2023</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7676.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7676</h4>
            <p>Fecha de emisión: 19/01/2023</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
	<div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7664.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7664</h4>
            <p>Fecha de emisión: 29/12/2022</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
	<div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7662.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7662</h4>
            <p>Fecha de emisión: 23/12/2022</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7643.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7643</h4>
            <p>Fecha de emisión: 24/11/2022</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7638.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7638</h4>
            <p>Fecha de emisión: 17/11/2022</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7630.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7630</h4>
            <p>Fecha de emisión: 03/11/2022</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7629.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7629</h4>
            <p>Fecha de emisión: 03/11/2022</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7624.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7624</h4>
            <p>Fecha de emisión: 20/10/2022</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7622.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7622</h4>
            <p>Fecha de emisión: 13/10/2022</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7621.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7621</h4>
            <p>Fecha de emisión: 13/10/2022</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7606.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7606</h4>
            <p>Fecha de emisión: 15/09/2022</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7571.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7571</h4>
            <p>Fecha de emisión: 05/08/2022</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7570.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7570</h4>
            <p>Fecha de emisión: 05/08/2022</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7562.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7562</h4>
            <p>Fecha de emisión: 29/07/2022</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7553.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7553</h4>
            <p>Fecha de emisión: 21/07/2022</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7552.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7552</h4>
            <p>Fecha de emisión: 21/07/2022</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7547.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7547</h4>
            <p>Fecha de emisión: 14/07/2022</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7542.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7542</h4>
            <p>Fecha de emisión: 07/07/2022</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7532.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7532</h4>
            <p>Fecha de emisión: 27/06/2022</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7528.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7528</h4>
            <p>Fecha de emisión: 16/06/2022</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7518.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7518</h4>
            <p>Fecha de emisión: 02/06/2022</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7516.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7516</h4>
            <p>Fecha de emisión: 19/05/2022</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7507.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7507</h4>
            <p>Fecha de emisión: 05/05/2022</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7488.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7488</h4>
            <p>Fecha de emisión: 07/04/2022</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7472.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7472</h4>
            <p>Fecha de emisión: 22/03/2022</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7466.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7466</h4>
            <p>Fecha de emisión: 03/03/2022</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7433.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7433</h4>
            <p>Fecha de emisión: 06/01/2022</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7420.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7420</h4>
            <p>Fecha de emisión: 16/12/2021</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7416.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7416</h4>
            <p>Fecha de emisión: 09/12/2021</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7408.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7408</h4>
            <p>Fecha de emisión: 25/11/2021</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7389.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7389</h4>
            <p>Fecha de emisión: 29/10/2021</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7385.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7385</h4>
            <p>Fecha de emisión: 28/10/2021</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7375.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7375</h4>
            <p>Fecha de emisión: 05/10/2021</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7374.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7374</h4>
            <p>Fecha de emisión: 30/09/2021</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7348.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7348</h4>
            <p>Fecha de emisión: 26/08/2021</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7327.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7327</h4>
            <p>Fecha de emisión: 10/07/2021</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7313.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7313</h4>
            <p>Fecha de emisión: 24/06/2021</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7308.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7308</h4>
            <p>Fecha de emisión: 18/06/2021</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7307.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7307</h4>
            <p>Fecha de emisión: 18/06/2021</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7301.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7301</h4>
            <p>Fecha de emisión: 04/06/2021</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7293.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7293</h4>
            <p>Fecha de emisión: 28/05/2021</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/C89971.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "C" 89971</h4>
            <p>Fecha de emisión: 28/05/2021</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7253.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "A" 7253</h4>
            <p>Fecha de emisión: 31/03/2021</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/C89476.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. "C" 89476</h4>
            <p>Fecha de emisión: 22/03/2021</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7239.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 7239</h4>
            <p>Fecha de emisión: 18/03/2021</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7230.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 7230</h4>
            <p>Fecha de emisión: 25/02/2021</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7229.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 7229</h4>
            <p>Fecha de emisión: 25/02/2021</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7218.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 7218</h4>
            <p>Fecha de emisión: 04/02/2021</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7217.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 7217</h4>
            <p>Fecha de emisión: 04/02/2021</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7201.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 7201</h4>
            <p>Fecha de emisión: 06/01/2021</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7200.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 7200</h4>
            <p>Fecha de emisión: 06/01/2021</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7196.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 7196</h4>
            <p>Fecha de emisión: 06/01/2021</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7193.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 7193</h4>
            <p>Fecha de emisión: 30/12/2020</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7168.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 7168</h4>
            <p>Fecha de emisión: 19/11/2020</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7151.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 7151</h4>
            <p>Fecha de emisión: 29/10/2020</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7138.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 7138</h4>
            <p>Fecha de emisión: 15/10/2020</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7133.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 7133</h4>
            <p>Fecha de emisión: 09/10/2020</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7123.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 7123</h4>
            <p>Fecha de emisión: 02/10/2020</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7106.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 7106</h4>
            <p>Fecha de emisión: 15/09/2020</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7105.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 7105</h4>
            <p>Fecha de emisión: 15/09/2020</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7104.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 7104</h4>
            <p>Fecha de emisión: 15/09/2020</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7082.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 7082</h4>
            <p>Fecha de emisión: 06/08/2020</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7080.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 7080</h4>
            <p>Fecha de emisión: 03/08/2020</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7079.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 7079</h4>
            <p>Fecha de emisión: 30/07/2020</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7068.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 7068</h4>
            <p>Fecha de emisión: 08/07/2020</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7059.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 7059</h4>
            <p>Fecha de emisión: 01/07/2020</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7058.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 7058</h4>
            <p>Fecha de emisión: 01/07/2020</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <!--
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="<php echo $folder_empresas ?>docs/A7057.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 7057</h4>
            <p>Fecha de emisión: 01/07/2020</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    -->
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7052.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 7052</h4>
            <p>Fecha de emisión: 25/06/2020</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7042.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 7042</h4>
            <p>Fecha de emisión: 11/06/2020</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/B12020.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. B 12020</h4>
            <p>Fecha de emisión: 08/06/2020</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7030.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 7030</h4>
            <p>Fecha de emisión: 28/05/2020</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7006.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 7006</h4>
            <p>Fecha de emisión: 08/05/2020</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7003.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 7003</h4>
            <p>Fecha de emisión: 07/05/2020</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/B12006.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. B12006</h4>
            <p>Fecha de emisión: 06/05/2020</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A7001.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 7001</h4>
            <p>Fecha de emisión: 30/04/2020</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A6993.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 6993</h4>
            <p>Fecha de emisión: 24/04/2020</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A6972.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 6972</h4>
            <p>Fecha de emisión: 16/04/2020</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A6948.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 6948</h4>
            <p>Fecha de emisión: 28/03/2020</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A6924.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 6924</h4>
            <p>Fecha de emisión: 09/03/2020</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A6908.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 6908</h4>
            <p>Fecha de emisión: 19/02/2020</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A6903.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 6903</h4>
            <p>Fecha de emisión: 14/02/2020</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/B11951.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. B 11951</h4>
            <p>Fecha de emisión: 14/02/2020</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>                                        
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A6869.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 6869</h4>
            <p>Fecha de emisión: 16/01/2020</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A6862.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 6862</h4>
            <p>Fecha de emisión: 13/01/2020</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A6856.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 6856</h4>
            <p>Fecha de emisión: 30/12/2019</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A6855.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 6855</h4>
            <p>Fecha de emisión: 27/12/2019</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A6854.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 6854</h4>
            <p>Fecha de emisión: 27/12/2019</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A6838.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 6838</h4>
            <p>Fecha de emisión: 28/11/2019</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A6833.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 6833</h4>
            <p>Fecha de emisión: 19/11/2019</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A6826.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 6826</h4>
            <p>Fecha de emisión: 12/11/2019</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A6825.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 6825</h4>
            <p>Fecha de emisión: 07/11/2019</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A6818.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 6818</h4>
            <p>Fecha de emisión: 28/10/2019</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A6815.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 6815</h4>
            <p>Fecha de emisión: 28/10/2019</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A6814.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 6814</h4>
            <p>Fecha de emisión: 17/10/2019</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/C84888.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. C 84888</h4>
            <p>Fecha de emisión: 04/10/2019</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A6808.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 6808</h4>
            <p>Fecha de emisión: 04/10/2019</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A6807.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 6807</h4>
            <p>Fecha de emisión: 04/10/2019</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A6805.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 6805</h4>
            <p>Fecha de emisión: 03/10/2019</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A6804.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 6804</h4>
            <p>Fecha de emisión: 03/10/2019</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A6799.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 6799</h4>
            <p>Fecha de emisión: 30/09/2019</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A6797.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 6797</h4>
            <p>Fecha de emisión: 30/09/2019</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A6796.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 6796</h4>
            <p>Fecha de emisión: 27/09/2019</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A6795.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 6795</h4>
            <p>Fecha de emisión: 27/09/2019</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A6793.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 6793</h4>
            <p>Fecha de emisión: 26/09/2019</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A6792.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 6792</h4>
            <p>Fecha de emisión: 24/09/2019</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/Decreto_661-2019.pdf" target="_blank" class="btn-lnk-block">
            <h4>Decreto 661-2019</h4>
            <p>Fecha de emisión: 20/09/2019</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A6788.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 6788</h4>
            <p>Fecha de emisión: 19/09/2019</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A6787.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 6787</h4>
            <p>Fecha de emisión: 19/09/2019</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A6782.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 6782</h4>
            <p>Fecha de emisión: 16/09/2019</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A6780.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 6780</h4>
            <p>Fecha de emisión: 11/09/2019</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A6776.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 6776</h4>
            <p>Fecha de emisión: 05/09/2019</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A6773.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 6773</h4>
            <p>Fecha de emisión: 02/09/2019</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/A6770.pdf" target="_blank" class="btn-lnk-block">
            <h4>Com. A 6770</h4>
            <p>Fecha de emisión: 01/09/2019</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-12 col-sm-12 col-xs-12">
        <a href="../../../empresas/docs/Resolucion_4555-2019.pdf" target="_blank" class="btn-lnk-block">
            <h4>Garantías otorgadas en resguardo del cumplimiento de obligaciones fiscales.</h4>
            <p>Fecha de emisión: 22/08/2019</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/B11857.pdf" target="_blank" class="btn-lnk-block">
            <h4>Relevamiento de Activos y Pasivos Externos</h4>
            <p>Fecha de emisión: 25/06/2019</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/DECRETO_335-2019.pdf" target="_blank" class="btn-lnk-block">
            <h4>Decreto 335-2019</h4>
            <p>Fecha de emisión: 07/05/2019</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/DECRETO_280-2019.pdf" target="_blank" class="btn-lnk-block">
            <h4>Decreto 280/2019</h4>
            <p>Fecha de emisión: 07/05/2019</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/RG_AFIP_4467-2019.pdf" target="_blank" class="btn-lnk-block">
            <h4>Resolución General 4467/2019</h4>
            <p>Fecha de emisión: 07/05/2019</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/RG_AFIP_4476-2019.pdf" target="_blank" class="btn-lnk-block">
            <h4>Resolución General 4476/2019</h4>
            <p>Fecha de emisión: 06/05/2019</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <a href="../../../empresas/docs/Decreto_332-2019.pdf" target="_blank" class="btn-lnk-block">
            <h4>Decreto 332/2019</h4>
            <p>Fecha de emisión: 03/05/2019</p>
            <i class="icon icon-pdf"></i>
        </a>
    </div>

</div>
<!-- -->
<hr>
<!-- -->
<div class="row consulta">
    <div class="col-md-6 col-sm-12 col-xs-12 col-md-offset-3">
        <a href="comunicaciones-anteriores.php" class="lnk">Comunicaciones Anteriores</a>
    </div>
</div>
                    <!-- -->
                </div>
            </div>
        </div>
    </section>
	<div class="container-fluid footer-bar">
	<div class="row">
		<footer class="container">
			<div class="row">
				<div class="col-md-12">
					<p class="flnks"><a href="../../../registro-nacional-base-datos.php">Registro Nacional de Base de Datos</a> <span>|</span>   <a href="../../../codigo-practicas-bancarias.php">Código de Prácticas Bancarias</a> <span>|</span>   <a href="../../../defensa-ley-consumidor.php">Defensa del Consumidor</a>
						<span>|</span>   <a href="https://www.argentina.gob.ar/produccion/defensadelconsumidor/formulario">Defensa de las y los consumidores. Para reclamos ingrese aquí</a><span>|</span> <br class="tbl"> <a href="../../../persona-expuesta-politicamente.php">Persona Expuesta Políticamente</a> <span class="tbl">|</span> <br class="dsk">
						
					<a href="../../../agencia-acceso-informacion-publica.php">Agencia de Acceso a la Información Pública</a> <span>|</span> <br class="tbl"> 
					<a href="../../../cnv-advertencia-publico-inversor.php">CNV - Advertencia al Público Inversor</a> <span>|</span> <a href="../../../docs/Idoneos.pdf" target="_blank"> Idóneos en Mercado de Capitales - CNV</a><span>|</span>   <a href="../../../codigo-proteccion-inversor.php">Código de Protección al Inversor</a> <span>|</span>   <a href="../../../clausulas-legales.php">Cláusulas Legales</a> <span>|</span> <a href="../../../resolucion-022021.php">Resol. 02/21 Dir.Gral. Defensa del consumidor Córdoba</a></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<p class="redes">
                        <span>Seguinos en:</span>
                        <!-- -->
                        <a href="https://www.facebook.com/BancoPatagonia/" target="_blank"><img src="../../../assets/images/layout/icon-facebook.svg" alt="Facebook"></a>
                        <a href="https://twitter.com/banco_patagonia" target="_blank"><img src="../../../assets/images/layout/icon-twitter.svg" alt="Twitter"></a>
                        <a href="https://www.instagram.com/banco_patagonia/" target="_blank"><img src="../../../assets/images/layout/icon-instagram.svg" alt="Instagram"></a>
                        <a href="https://www.youtube.com/user/bancopatagonia" target="_blank"><img src="../../../assets/images/layout/icon-youtube.svg" alt="Youtube"></a>
                        <!-- -->
                        <!--
                        <a href="https://www.facebook.com/BancoPatagonia/" target="_blank"><i class="fa fa-facebook-square"></i></a>
                        <a href="https://twitter.com/banco_patagonia" target="_blank"><i class="fa fa-twitter"></i></a>
                        <a href="https://www.instagram.com/banco_patagonia/" target="_blank"><i class="fa fa-instagram"></i></a>
                        <a href="https://www.youtube.com/user/bancopatagonia" target="_blank"><i class="fa fa-youtube-play"></i></a>
                        -->
                    </p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					                    <!---->
				    <p class="flegal">BANCO PATAGONIA S.A. ES UNA SOCIEDAD ANÓNIMA CONSTITUIDA BAJO LAS LEYES DE LA REPÚBLICA ARGENTINA CUYOS ACCIONISTAS LIMITAN SU RESPONSABILIDAD A LA INTEGRACIÓN DE LAS ACCIONES SUSCRITAS DE ACUERDO A LA LEY 19.550. POR CONSIGUIENTE, Y EN CUMPLIMIENTO DE LA LEY 25.738, SE INFORMA QUE NI LOS ACCIONISTAS MAYORITARIOS DE CAPITAL EXTRANJERO NI LOS ACCIONISTAS LOCALES O EXTRANJEROS RESPONDEN, EN EXCESO DE LA CITADA INTEGRACIÓN ACCIONARIA, POR LAS OBLIGACIONES EMERGENTES DE LAS OPERACIONES CONCERTADAS POR LA ENTIDAD FINANCIERA.</p>
                    <p class="flegal" style="font-size:10px;">Banco Patagonia S.A. - Agente de Liquidacion y Compensacion y Agente de Negociacion Integral, inscripto en CNV bajo el N° 66</p>
					<p class="flegal">© 2025 Banco Patagonia . Todos los derechos reservados. Prohibida la duplicación , distribución o almacenamiento en cualquier medio.</p>
				</div>
			</div>
		</footer>
	</div>
</div>
<div class="tbl mbl placeholder-shortlinks">
	<div class="container shortlinks">
		<div class="row">
            <!--<php if ($home_personas == false) { ?>
                <div class="col-sm-3 col-xs-3">
                    <a href="#"><span class="icon icon-contacto"></span></a>
                </div>
            <php } ?>-->
            			<div class="col-sm-3 col-xs-3">
				<a href="http://sucursalesycajeros.bancopatagonia.com.ar/sucursales.html" target="_blank"><span class="icon icon-sucursales"></span>Sucursales y Cajeros</a>
			</div>
			<div class="col-sm-3 col-xs-3">
				<a href="../../../preguntas-frecuentes/index.php"><span class="icon icon-contacto"></span>Ayuda</a>
			</div>
			<div class="col-sm-3 col-xs-3 last">
				<a href="../../../empresas/patagonia-ebank-empresas-mbl.php"><span class="icon icon-ebank"></span>Patagonia e-Bank</a>
			</div>
		</div>
	</div>
</div>	<script src="../../../assets/js/jquery-3.5.1.min.js"></script>
<script src="../../../assets/bootstrap/js/bootstrap.min.js"></script>
<script src="../../../assets/js/slick/slick.min.js"></script>
<script src="../../../assets/js/fancybox/jquery.fancybox.min.js"></script>
<script src="../../../assets/js/mtabs/jquery.bootstrap-responsive-tabs.min.js"></script>
<script src="../../../assets/js/funciones.js"></script>

<!-- Global site tag (gtag.js) - Google Analytics (original) -->
<!--
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-32588129-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-32588129-1');
</script>
-->

<!-- Google Analytics (version anterior / eventos ok)  -->
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');
  ga('create', 'UA-32588129-1', 'auto');
  ga('send', 'pageview');
</script>

<!-- GA4 - Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-C6LG1PT98X"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-C6LG1PT98X');
</script>
</body>
</html>